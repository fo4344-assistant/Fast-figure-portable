
      const PACKAGE_FORMAT_VERSION = 3;
      const APP_BUILD = "1.1.32-wip";
      const PROJECT_OBJECT_PATHS = Object.freeze({
        project: "meta",
        layout: "layout",
        labels: "annotations.labels",
        captions: "annotations.captions",
        data: "assets.csvFiles",
        images: "assets.images",
        files: "fileSystem",
        charts: "charts",
        slots: "slots",
        sequences: "nextId",
        appearance: "appearance",
        export: "export",
      });
      const DEFAULT_SLOT_STYLE = Object.freeze({
        referenceWidth: 1200,
        gap: 0,
        outerMargin: 120,
        radius: 0,
        aspect: 1.618,
        showBorders: true,
      });
      const DEFAULT_UI_PALETTE = Object.freeze({
        uiColor: "#B0CFCE",
        uiBackgroundColor: "#FAFAFA",
        uiSurfaceColor: "#FFFFFF",
        uiMutedColor: "#4F525D",
        uiSubtleColor: "#94A3B8",
        uiDisabledBgColor: "#E5E7EB",
        uiDisabledTextColor: "#64748B",
        uiShadowColor: "#383A42",
        paperColor: "#FFFFFF",
        fontColor: "#383A42",
      });
      const DEFAULT_COLORS = [
        "#383A42",
        "#E45649",
        "#50A14F",
        "#B37901",
        "#0184BC",
        "#A626A4",
        "#0997B3",
        "#FAFAFA",
      ];
      const DEFAULT_IMAGE_SETTINGS = Object.freeze({
        fit: "contain",
        scale: 100,
        x: 50,
        y: 50,
      });
      const SLOT_LOCAL_DEFAULTS = Object.freeze({
        chart: null,
        imageId: null,
        contentType: "graph",
        imageSettings: DEFAULT_IMAGE_SETTINGS,
        caption: null,
      });
      function createProjectState() {
        let state = {
          kind: "fast-figure-project-object",
          meta: { projectName: "", appBuild: APP_BUILD },
          layout: {
            gridRows: 2,
            gridCols: 2,
            slotStyle: { ...DEFAULT_SLOT_STYLE },
          },
          annotations: {
            labels: {
              enabled: false,
              settings: {
                format: "lower-alpha",
                parentheses: false,
                x: 0,
                y: 0,
                order: "row-major",
                fontFamily: "system-ui, sans-serif",
                fontSize: 14,
              },
            },
            captions: {
              enabled: false,
              text: "",
              afterText: "",
              name: "",
              nameBold: false,
              settings: {
                fontFamily: "system-ui, sans-serif",
                fontSize: 14,
                lineHeight: 1.45,
              },
            },
          },
          assets: { csvFiles: [], images: [] },
          fileSystem: {
            directories: ["/assets", "/assets/csv", "/assets/images", "/assets/trash"],
          },
          charts: [],
          slots: [],
          nextId: { csv: 1, image: 1, chart: 1 },
          appearance: { uiPalette: { ...DEFAULT_UI_PALETTE } },
          export: {
            width: DEFAULT_SLOT_STYLE.referenceWidth,
            heightMode: "auto",
            height: null,
            dpi: 300,
            format: "png",
          },
        };
        for (let index = 0; index < 4; index++)
          state.slots.push(newGridSlot(index, Math.floor(index / 2) + 1, (index % 2) + 1));
        return state;
      }
      function projectObjectPath(state, path) {
        return String(path)
          .split(".")
          .reduce((value, key) => value?.[key], state);
      }
      class ProjectObject {
        constructor(state = createProjectState()) {
          normalizeSlotContents(state.slots);
          validateProjectObjectState(state);
          this._state = state;
        }
        static fromFFPX(payload, fileName) {
          return buildProjectObject(payload, fileName);
        }
        read(path) {
          let value = projectObjectPath(this._state, path);
          if (value === undefined) throw Error(`프로젝트 오브젝트 경로 ${path}가 없습니다.`);
          return value;
        }
        initialize(source) {
          let next = source instanceof ProjectObject ? source._state : source;
          normalizeSlotContents(next.slots);
          validateProjectObjectState(next);
          let previous = this._state;
          this._state = next;
          return previous;
        }
        get meta() {
          return this._state.meta;
        }
        get layout() {
          return this._state.layout;
        }
        get annotations() {
          return this._state.annotations;
        }
        get assets() {
          return this._state.assets;
        }
        get appearance() {
          return this._state.appearance;
        }
        get projectName() {
          return this.meta.projectName;
        }
        set projectName(value) {
          this.meta.projectName = value;
        }
        get appBuild() {
          return this.meta.appBuild;
        }
        get gridRows() {
          return this.layout.gridRows;
        }
        set gridRows(value) {
          this.layout.gridRows = value;
        }
        get gridCols() {
          return this.layout.gridCols;
        }
        set gridCols(value) {
          this.layout.gridCols = value;
        }
        get csvFiles() {
          return this.assets.csvFiles;
        }
        set csvFiles(value) {
          this.assets.csvFiles = value;
        }
        get images() {
          return this.assets.images;
        }
        set images(value) {
          this.assets.images = value;
        }
        get fileSystem() {
          return this._state.fileSystem;
        }
        set fileSystem(value) {
          this._state.fileSystem = value;
        }
        get charts() {
          return this._state.charts;
        }
        set charts(value) {
          this._state.charts = value;
        }
        get slots() {
          return this._state.slots;
        }
        set slots(value) {
          this._state.slots = normalizeSlotContents(value);
        }
        get csvId() {
          return this._state.nextId.csv;
        }
        set csvId(value) {
          this._state.nextId.csv = value;
        }
        get imageId() {
          return this._state.nextId.image;
        }
        set imageId(value) {
          this._state.nextId.image = value;
        }
        get chartId() {
          return this._state.nextId.chart;
        }
        set chartId(value) {
          this._state.nextId.chart = value;
        }
        get labelsEnabled() {
          return this.annotations.labels.enabled;
        }
        set labelsEnabled(value) {
          this.annotations.labels.enabled = value;
        }
        get labelSettings() {
          return this.annotations.labels.settings;
        }
        set labelSettings(value) {
          this.annotations.labels.settings = value;
        }
        get captionsEnabled() {
          return this.annotations.captions.enabled;
        }
        set captionsEnabled(value) {
          this.annotations.captions.enabled = value;
        }
        get captionText() {
          return this.annotations.captions.text;
        }
        set captionText(value) {
          this.annotations.captions.text = value;
        }
        get captionAfterText() {
          return this.annotations.captions.afterText;
        }
        set captionAfterText(value) {
          this.annotations.captions.afterText = value;
        }
        get captionName() {
          return this.annotations.captions.name;
        }
        set captionName(value) {
          this.annotations.captions.name = value;
        }
        get captionNameBold() {
          return this.annotations.captions.nameBold;
        }
        set captionNameBold(value) {
          this.annotations.captions.nameBold = value;
        }
        get captionSettings() {
          return this.annotations.captions.settings;
        }
        set captionSettings(value) {
          this.annotations.captions.settings = value;
        }
        get exportSettings() {
          return this._state.export;
        }
        set exportSettings(value) {
          this._state.export = value;
        }
      }
      const activeProject = new ProjectObject();
      let selectedSlotId = null,
        pendingSlotContentType = "graph",
        dashboardObserver = null,
        graphAreaObserver = null,
        resizePending = false,
        programmaticPlotlyRelayout = new WeakMap(),
        dashboardRenderGeneration = 0,
        projectObjectGeneration = 0,
        slotDragSourceId = null,
        slotDragSuppressClick = false,
        dashboardZoomIntent = 100,
        dashboardZoomLocked = false,
        dashboardZoomLockedWidth = null;
      const $ = (id) => document.getElementById(id);
      const uiTelemetryListeners = new Set();
      let uiTelemetryState = Object.freeze({
        revision: 0,
        status: "",
        debugEnabled: false,
        debugLines: [],
      });
      function publishUiTelemetry(patch = {}) {
        uiTelemetryState = Object.freeze({
          ...uiTelemetryState,
          ...patch,
          revision: uiTelemetryState.revision + 1,
        });
        uiTelemetryListeners.forEach((listener) => listener());
        return uiTelemetryState;
      }
      function subscribeUiTelemetry(listener) {
        uiTelemetryListeners.add(listener);
        return () => uiTelemetryListeners.delete(listener);
      }
      function getUiTelemetrySnapshot() {
        return uiTelemetryState;
      }
      function status(message) {
        let text = String(message ?? "");
        publishUiTelemetry({ status: text });
        return text;
      }
      let debugEnabled = false,
        debugSequence = 0;
      function setDebugEnabled(enabled) {
        debugEnabled = enabled === true;
        publishUiTelemetry({ debugEnabled });
        return debugEnabled;
      }
      function clearDebugOutput() {
        debugSequence = 0;
        publishUiTelemetry({ debugLines: [] });
      }
      function saveDebugOutput() {
        auditApp("debug:save");
        debugLog("debugLog:save", {
          build: projectObjects.read("project").appBuild,
          userAgent: navigator.userAgent,
          location: location.href,
        });
        let blob = new Blob([getUiTelemetrySnapshot().debugLines.join("\n")], {
            type: "text/plain;charset=utf-8",
          }),
          link = document.createElement("a"),
          stamp = new Date().toISOString().replace(/[:.]/g, "-");
        link.href = URL.createObjectURL(blob);
        link.download = `chart-builder-debug-${stamp}.log`;
        link.click();
        setTimeout(() => URL.revokeObjectURL(link.href), 0);
      }
      function debugValue(value) {
        if (value instanceof Error)
          return { name: value.name, message: value.message, stack: value.stack };
        try {
          return JSON.parse(JSON.stringify(value));
        } catch (error) {
          return { serializationError: error.message, value: String(value) };
        }
      }
      function debugLog(event, data = {}, level = "debug") {
        if (!debugEnabled) return;
        let payload = debugValue(data),
          line = `${String(++debugSequence).padStart(4, "0")} ${new Date().toISOString().slice(11, 23)} ${level.toUpperCase()} ${event} ${JSON.stringify(payload)}`;
        let method = console[level] || console.debug;
        method.call(console, "[chart-builder]", event, payload);
        let lines = [...uiTelemetryState.debugLines, line].slice(-500);
        publishUiTelemetry({ debugEnabled, debugLines: lines });
      }
      class ProjectObjectRegistry {
        constructor(projectProvider) {
          if (typeof projectProvider !== "function")
            throw Error("프로젝트 오브젝트 공급자가 없습니다.");
          this.projectProvider = projectProvider;
          this.adapters = new Map();
        }
        register(name, adapter) {
          if (!name || this.adapters.has(name) || typeof adapter?.read !== "function")
            throw Error(`프로젝트 오브젝트 어댑터 ${name}을 등록할 수 없습니다.`);
          this.adapters.set(name, Object.freeze({ ...adapter }));
          return this;
        }
        registerPath(name, path) {
          return this.register(name, {
            path,
            read: (project) => project.read(path),
          });
        }
        read(name) {
          let adapter = this.adapters.get(name);
          if (!adapter) throw Error(`프로젝트 오브젝트 ${name}이 없습니다.`);
          let project = this.projectProvider();
          if (!(project instanceof ProjectObject))
            throw Error("활성 프로젝트 오브젝트가 없습니다.");
          return adapter.read(project);
        }
        snapshot(names = [...this.adapters.keys()]) {
          return Object.fromEntries(names.map((name) => [name, projectClone(this.read(name))]));
        }
        names() {
          return [...this.adapters.keys()];
        }
      }
      class ApplicationStateMachine {
        constructor(objects, definitions) {
          this.objects = objects;
          this.definitions = definitions;
          this.state = Object.freeze({
            lifecycle: "booting",
            workspace: "project",
            overlay: "none",
            assetSelection: "none",
            assetPath: null,
            graphObject: "none",
            graphObjectIndex: null,
            direction: "model-to-ui",
            revision: 0,
            error: null,
          });
          this.listeners = new Set();
          this.transitioning = 0;
          this.writeLocks = new Set();
        }
        definition(region, state = this.state[region]) {
          let definition = this.definitions[region]?.[state];
          if (!definition) throw Error(`${region}.${state} FSM 상태가 등록되지 않았습니다.`);
          return definition;
        }
        context(region, state, event, payload) {
          let definition = this.definition(region, state),
            names = definition.objects || [];
          return {
            machine: this,
            region,
            state,
            event,
            payload,
            direction: payload.direction || this.state.direction || "model-to-ui",
            canWrite: (scope) => !this.writeLocks.has(scope),
            objects: Object.fromEntries(names.map((name) => [name, this.objects.read(name)])),
          };
        }
        withWriteLocks(scopes, operation) {
          scopes.forEach((scope) => this.writeLocks.add(scope));
          try {
            return operation();
          } finally {
            scopes.forEach((scope) => this.writeLocks.delete(scope));
          }
        }
        assertWritable(scope, event) {
          if (this.writeLocks.has(scope))
            throw Error(`${event} 전이 중 잠긴 ${scope} 모델을 수정할 수 없습니다.`);
        }
        publish(event) {
          document.body.dataset.appLifecycle = this.state.lifecycle;
          document.body.dataset.appWorkspace = this.state.workspace;
          document.body.dataset.appOverlay = this.state.overlay;
          document.body.dataset.appAssetSelection = this.state.assetSelection;
          document.body.dataset.appGraphObject = this.state.graphObject;
          this.listeners.forEach((listener) => listener(this.state, event));
          debugLog("fsm:transition", { event, ...this.state });
          return this.state;
        }
        transition(region, target, event, payload = {}) {
          if (typeof target === "function")
            target = target(this.context(region, this.state[region], event, payload));
          let previous = this.state[region];
          if (!target || (target === previous && payload.reenter !== true)) {
            let definition = this.definition(region, previous);
            if (payload.direction)
              this.state = Object.freeze({
                ...this.state,
                direction: payload.direction,
              });
            let update = () =>
              definition.update?.(this.context(region, previous, event, payload));
            if (payload.direction === "model-to-fsm" && region === "workspace")
              this.withWriteLocks(["workspace", "editor"], update);
            else update();
            return this.publish(`${event}:${region}:update`);
          }
          this.transitioning++;
          try {
            this.definition(region, previous).exit?.(
              this.context(region, previous, event, payload),
            );
            this.state = Object.freeze({
              ...this.state,
              [region]: target,
              direction: payload.direction || this.state.direction,
            });
            let enter = () =>
              this.definition(region, target).entry?.(
                this.context(region, target, event, payload),
              );
            if (payload.direction === "model-to-fsm" && region === "workspace")
              this.withWriteLocks(["workspace", "editor"], enter);
            else enter();
          } finally {
            this.transitioning--;
          }
          return this.publish(`${event}:${region}:${previous}->${target}`);
        }
        send(event, payload = {}) {
          let handled = false;
          for (let region of [
            "lifecycle",
            "workspace",
            "overlay",
            "assetSelection",
            "graphObject",
          ]) {
            let transition = this.definition(region).on?.[event];
            if (!transition) continue;
            handled = true;
            if (typeof transition === "function")
              transition = transition(this.context(region, this.state[region], event, payload));
            let target = transition?.target ?? transition;
            transition?.action?.(this.context(region, this.state[region], event, payload));
            if (target) this.transition(region, target, event, payload);
          }
          if (!handled) debugLog("fsm:event-unhandled", { event, state: this.state }, "warn");
          return this.state;
        }
        notify(object, event, payload = {}) {
          if (this.state.lifecycle === "booting" || this.transitioning) return this.state;
          this.state = Object.freeze({
            ...this.state,
            direction: "model-to-ui",
            revision: this.state.revision + 1,
          });
          for (let region of ["workspace", "overlay"]) {
            let definition = this.definition(region);
            if (definition.objects?.includes(object))
              definition.update?.(
                this.context(region, this.state[region], event, {
                  ...payload,
                  direction: "model-to-ui",
                }),
              );
          }
          return this.publish(event);
        }
        run(lifecycle, event, task) {
          if (this.state.lifecycle !== "ready")
            return Promise.reject(
              Error(`현재 ${this.state.lifecycle} 상태에서는 ${event} 작업을 시작할 수 없습니다.`),
            );
          this.transition("lifecycle", lifecycle, `${event}:start`);
          let complete = (result) => {
              let outcome =
                result?.outcome === "rejected" ? "rejected" : result?.outcome || "complete";
              this.transition("lifecycle", "ready", `${event}:${outcome}`);
              return result;
            },
            fail = (error) => {
              this.state = Object.freeze({
                ...this.state,
                error: { event, message: error?.message || String(error) },
              });
              this.transition("lifecycle", "error", `${event}:failed`, { error });
              this.transition("lifecycle", "ready", `${event}:recovered`);
              throw error;
            };
          try {
            let result = task();
            return result && typeof result.then === "function"
              ? result.then(complete, fail)
              : Promise.resolve(complete(result));
          } catch (error) {
            try {
              fail(error);
            } catch (failed) {
              return Promise.reject(failed);
            }
          }
        }
        ready() {
          this.transition("lifecycle", "ready", "READY");
          this.transition("workspace", workspaceStateFromModel(), "WORKSPACE_INIT", {
            direction: "model-to-fsm",
          });
          this.transition("overlay", "none", "OVERLAY_INIT", { reenter: true });
          return this.state;
        }
        subscribe(listener) {
          this.listeners.add(listener);
          return () => this.listeners.delete(listener);
        }
      }
      function workspaceStateForSelection() {
        let slot = getSelectedSlot();
        if (!slot) return "project";
        return slot.contentType === "image" ? "slot.image" : "slot.graph";
      }
      function workspaceStateFromModel(slotId = selectedSlotId) {
        let slot = slotId == null ? null : slotAt(slotId);
        return !slot ? "project" : slot.contentType === "image" ? "slot.image" : "slot.graph";
      }
      function requestedWorkspaceState({ payload }) {
        return payload.direction === "model-to-fsm"
          ? workspaceStateFromModel(payload.slotId)
          : workspaceStateForSelection();
      }
      function applySlotSelectionAction({ machine, payload }) {
        let slot = payload.slotId == null ? null : slotAt(payload.slotId),
          same = !!slot && selectedSlotId === slot.id,
          hydrating = payload.direction === "model-to-fsm";
        machine.assertWritable("workspace", "SELECT_SLOT");
        selectedSlotId = !slot || (!hydrating && same) ? null : slot.id;
        machine.state = Object.freeze({
          ...machine.state,
          graphObject: "none",
          graphObjectIndex: null,
        });
        if (
          !hydrating &&
          selectedSlotId !== null &&
          !slot.chart &&
          !slot.imageId
        )
          slot.contentType = pendingSlotContentType;
      }
      function applySlotTypeAction({ machine, payload }) {
        machine.assertWritable("workspace", "SLOT_TYPE_CHANGED");
        let slot = getSelectedSlot();
        if (!slot) {
          pendingSlotContentType = payload.type;
          return;
        }
        slot.contentType = payload.type === "image" ? "image" : "graph";
        machine.state = Object.freeze({
          ...machine.state,
          graphObject: "none",
          graphObjectIndex: null,
        });
      }
      function applyGraphObjectSelectionAction({ machine, payload }) {
        machine.assertWritable("editor", "SELECT_GRAPH_OBJECT");
        let slot = getSelectedSlot(),
          chart = slot?.chart ? getChart(slot.chart) : null,
          objects = ensureGraphObjects(chart),
          index = Number.isInteger(payload.index) ? payload.index : null;
        if (!slot || slot.contentType === "image" || !chart || index < 0 || index >= objects.length)
          index = null;
        machine.state = Object.freeze({
          ...machine.state,
          graphObjectIndex: index,
        });
      }
      function selectedGraphObjectGuard() {
        return (
          appFSM?.state.graphObject === "selected" &&
          Number.isInteger(appFSM.state.graphObjectIndex)
        );
      }

      function applyCaptionTextAction({ machine, payload }) {
        machine.assertWritable("workspace","CAPTION_TEXT_INPUT");
        let target=payload.target;
        if(target?.kind==="slot"){
          let slot=slotAt(Number(target.id));
          if(!slot)throw Error("캡션을 변경할 슬롯이 없습니다.");
          slot.caption=String(payload.text??"")||null;
        } else if(target?.kind==="global") {
          activeProject.captionText=String(payload.text??"");
        } else throw Error("캡션 변경 대상이 올바르지 않습니다.");
      }
      function applySlotCaptionsInsertedAction({ machine }) {
        machine.assertWritable("workspace", "SLOT_CAPTIONS_INSERTED");
        let inserted = slotCaptionSections()
          .map((section) => [section.label, section.text].filter(Boolean).join(" "))
          .join(" ");
        if (!inserted) return;
        activeProject.captionText += activeProject.captionText && !/\s$/.test(activeProject.captionText) ? ` ${inserted}` : inserted;
      }
      function applyDataObjectCreatedAction({ machine, payload }) {
        machine.assertWritable("data", "DATA_OBJECT_CREATED");
        machine.assertWritable("files", "DATA_OBJECT_CREATED");
        let model = payload.model;
        if (!model || activeProject.csvFiles.some((csv) => csv.id === model.id))
          throw Error(`CSV ID ${model?.id}가 중복되었습니다.`);
        projectVfs.prepare(model, "csv");
        activeProject.csvFiles.push(model);
        activeProject.csvId = Math.max(activeProject.csvId, model.id + 1);
      }
      function applyAssetObjectReplacedAction({ machine, payload }, kind) {
        let image = kind === "image",
          event = image ? "IMAGE_OBJECT_REPLACED" : "DATA_OBJECT_REPLACED",
          scope = image ? "images" : "data",
          collection = image ? activeProject.images : activeProject.csvFiles,
          model = payload.model,
          index = collection.findIndex((item) => item.id === model?.id),
          previous = index >= 0 ? collection[index] : null;
        machine.assertWritable(scope, event);
        machine.assertWritable("files", event);
        if (!previous || projectAssetPath(model) !== projectAssetPath(previous))
          throw Error(`교체할 ${image ? "이미지" : "CSV"} 또는 참조 경로가 올바르지 않습니다.`);
        if (image) model.settings = projectClone(previous.settings);
        try {
          let next = collection.map((item, itemIndex) => itemIndex === index ? model : item);
          if (image) activeProject.images = next;
          else activeProject.csvFiles = next;
          validateProjectObject(activeProject, { requireSlots: true });
        } catch (error) {
          if (image) activeProject.images = collection;
          else activeProject.csvFiles = collection;
          throw error;
        }
        if (image) releaseProjectImageDisplayUrl(previous);
        payload[image ? "image" : "csv"] = model;
      }
      function applyDataObjectReplacedAction(context) {
        applyAssetObjectReplacedAction(context, "csv");
      }
      function applyDataObjectDeletedAction({ machine, payload }) {
        machine.assertWritable("data", "DATA_OBJECT_DELETED");
        activeProject.csvFiles = activeProject.csvFiles.filter((item) => item.id !== payload.csvId);
      }
      function applyImageObjectCreatedAction({ machine, payload }) {
        machine.assertWritable("images", "IMAGE_OBJECT_CREATED");
        machine.assertWritable("files", "IMAGE_OBJECT_CREATED");
        let model = payload.model;
        if (!model || activeProject.images.some((image) => image.id === model.id))
          throw Error(`이미지 ID ${model?.id}가 중복되었습니다.`);
        projectVfs.prepare(model, "image");
        activeProject.images.push(model);
        activeProject.imageId = Math.max(activeProject.imageId, model.id + 1);
      }
      function applyImageObjectReplacedAction(context) {
        applyAssetObjectReplacedAction(context, "image");
      }
      function applyImageObjectDeletedAction({ machine, payload }) {
        machine.assertWritable("images", "IMAGE_OBJECT_DELETED");
        if (activeProject.slots.some((slot) => slot.imageId === payload.imageId))
          throw Error("참조 슬롯을 초기화하지 않은 이미지는 삭제할 수 없습니다.");
        releaseProjectImageDisplayUrl(getProjectImage(payload.imageId));
        activeProject.images = activeProject.images.filter((item) => item.id !== payload.imageId);
      }
      function detachSlotChart(slot) {
        let chartId = slot?.chart;
        if (!Number.isInteger(chartId)) return null;
        slot.chart = null;
        if (!activeProject.slots.some((item) => item !== slot && item.chart === chartId)) {
          activeProject.charts = activeProject.charts.filter((chart) => chart.id !== chartId);
        }
        return chartId;
      }
      function applySlotsResetAction({ machine, payload }) {
        machine.assertWritable("slots", "SLOTS_RESET");
        machine.assertWritable("charts", "SLOTS_RESET");
        machine.assertWritable("workspace", "SLOTS_RESET");
        machine.assertWritable("editor", "SLOTS_RESET");
        let slotIds=new Set((Array.isArray(payload.slotIds)?payload.slotIds:[payload.slotId])
          .map(Number).filter(Number.isInteger)),
          currentTargets=activeProject.slots.filter(slot=>slotIds.has(slot.id));
        if(!currentTargets.length||currentTargets.length!==slotIds.size)
          throw Error("초기화할 슬롯이 없습니다.");
        let candidate=projectClone(activeProject._state);
        normalizeSlotContents(candidate.slots);
        let targets=candidate.slots.filter(slot=>slotIds.has(slot.id)),
          chartIds=new Set(targets.map(slot=>slot.chart).filter(Number.isInteger));
        candidate.charts=candidate.charts.filter(chart=>!chartIds.has(chart.id));
        targets.forEach(resetSlotLocalState);
        validateProjectObjectState(candidate,{requireSlots:true});
        activeProject.initialize(candidate);
        payload.resetCount=targets.length;
        payload.removedChartIds=[...chartIds];
      }
      function applySlotsSwappedAction({ machine, payload }) {
        machine.assertWritable("slots", "SLOTS_SWAPPED");
        machine.assertWritable("workspace", "SLOTS_SWAPPED");
        machine.assertWritable("editor", "SLOTS_SWAPPED");
        let source=slotAt(Number(payload.sourceSlotId)),
          target=slotAt(Number(payload.targetSlotId));
        if(!source||!target||source===target||source.hidden||target.hidden)
          throw Error("교환할 슬롯이 올바르지 않습니다.");
        let candidate=projectClone(activeProject._state);
        normalizeSlotContents(candidate.slots);
        let a=candidate.slots.find(slot=>slot.id===source.id),
          b=candidate.slots.find(slot=>slot.id===target.id),
          aLocal=slotLocalState(a), bLocal=slotLocalState(b);
        setSlotLocalState(a,bLocal); setSlotLocalState(b,aLocal);
        validateProjectObjectState(candidate,{requireSlots:true});
        activeProject.initialize(candidate);
        if(selectedSlotId===source.id)selectedSlotId=target.id;
        else if(selectedSlotId===target.id)selectedSlotId=source.id;
        payload.slotId=selectedSlotId;
      }
      function applySlotImageLinkedAction({ machine, payload }) {
        machine.assertWritable("slots","SLOT_IMAGE_LINKED");
        machine.assertWritable("charts","SLOT_IMAGE_LINKED");
        let slot=slotAt(payload.slotId),image=getProjectImage(payload.imageId);
        if(!slot||!image)throw Error("이미지를 연결할 슬롯 또는 이미지가 없습니다.");
        let candidate=projectClone(activeProject._state);
        normalizeSlotContents(candidate.slots);
        let target=candidate.slots.find(item=>item.id===slot.id),
          oldChart=target.chart;
        if(Number.isInteger(oldChart))
          candidate.charts=candidate.charts.filter(chart=>chart.id!==oldChart);
        target.chart=null;target.imageId=image.id;target.contentType="image";
        target.content.imageSettings=readImageSettings(target.content.imageSettings);
        validateProjectObjectState(candidate,{requireSlots:true});
        activeProject.initialize(candidate);
        payload.image=getProjectImage(image.id);
      }
      function applySlotDataConnectedAction({ machine, payload }) {
        machine.assertWritable("slots", "SLOT_DATA_CONNECTED");
        machine.assertWritable("charts", "SLOT_DATA_CONNECTED");
        machine.assertWritable("editor", "SLOT_DATA_CONNECTED");
        let slot = slotAt(payload.slotId),
          csv = getProjectCsv(payload.csvId);
        if (!slot || (!payload.replaceSlotContent && slot.contentType === "image") || !csv)
          throw Error("데이터를 연결할 슬롯 또는 CSV가 없습니다.");
        if (slot.chart && !payload.replaceSlotContent && getChart(slot.chart)?.editor?.editable === false)
          throw Error("편집 가능 토글을 켠 뒤 CSV를 추가하세요.");
        let previous = payload.replaceSlotContent
          ? {
              charts: activeProject.charts,
              chartId: activeProject.chartId,
              slotChart: slot.chart,
              slotImageId: slot.imageId,
              slotContentType: slot.contentType,
            }
          : null;
        try {
          if (payload.replaceSlotContent) {
            activeProject.charts = [...activeProject.charts];
            detachSlotChart(slot);
            slot.imageId = null;
            slot.contentType = "graph";
          }
          payload.chart = connectDataToSlotModel(slot, csv.rows, csv.name, csv);
          machine.state = Object.freeze({
            ...machine.state,
            graphObject: "none",
            graphObjectIndex: null,
          });
          if (payload.replaceSlotContent)
            validateProjectObject(activeProject, { requireSlots: true });
        } catch (error) {
          if (previous) {
            activeProject.charts = previous.charts;
            activeProject.chartId = previous.chartId;
            slot.chart = previous.slotChart;
            slot.imageId = previous.slotImageId;
            slot.contentType = previous.slotContentType;
          }
          throw error;
        }
      }
      function applyGraphObjectsReplacedAction({ machine, payload }) {
        machine.assertWritable("charts", "GRAPH_OBJECTS_REPLACED");
        let current=getChart(payload.chartId);
        if(!current||!current.editor||current.editor.editable===false)
          throw Error("그래프 오브젝트를 변경할 편집 가능 차트가 없습니다.");
        let candidate=projectClone(activeProject._state),
          chart=candidate.charts.find(item=>item.id===payload.chartId);
        chart.editor.objects=Array.isArray(payload.objects)?projectClone(payload.objects):[];
        validateChartModel(chart,"변경할 차트",candidate.assets.csvFiles);
        validateProjectObjectState(candidate,{requireSlots:true});
        activeProject.initialize(candidate);
        chart=getChart(payload.chartId);
        if(chart.editor.editable!==false)rebuildEditableGraph(chart);
        if(machine.state.graphObject==="selected" &&
          (!Number.isInteger(machine.state.graphObjectIndex)||
           machine.state.graphObjectIndex>=chart.editor.objects.length))
          machine.state=Object.freeze({...machine.state,graphObject:"none",graphObjectIndex:null});
        payload.chart=chart;
      }
      function applyChartLayoutChangedAction({ machine, payload }) {
        machine.assertWritable("charts", "CHART_LAYOUT_CHANGED");
        machine.assertWritable("editor", "CHART_LAYOUT_CHANGED");
        let slot = slotAt(payload.slotId),
          chart = slot?.chart ? getChart(slot.chart) : null;
        if (
          !slot ||
          slot.contentType === "image" ||
          !chart ||
          chart.id !== payload.chartId
        )
          throw Error("전역 설정을 변경할 그래프 슬롯 또는 차트가 없습니다.");
        if (chart.editor?.editable === false)
          throw Error("편집 가능 토글을 켠 뒤 설정을 변경하세요.");
        if (!payload.globalSettings || typeof payload.globalSettings !== "object")
          throw Error("적용할 그래프 전역 설정이 없습니다.");
        chart.editor.title = String(payload.title || "");
        chart.editor.globalSettings = projectClone(payload.globalSettings);
        chart.graph.layout = layout(chart);
        payload.chart = chart;
        payload.layout = chart.graph.layout;
      }
      function applyChartModelReplacedAction({ machine, payload }) {
        machine.assertWritable("charts", "CHART_MODEL_REPLACED");
        machine.assertWritable("editor", "CHART_MODEL_REPLACED");
        let slot = slotAt(payload.slotId),
          chart = payload.chart,
          index = activeProject.charts.findIndex((item) => item.id === payload.chartId);
        if (
          !slot ||
          slot.contentType === "image" ||
          slot.chart !== payload.chartId ||
          !chart ||
          chart.id !== payload.chartId ||
          index < 0
        )
          throw Error("교체할 그래프 슬롯 또는 차트가 없습니다.");
        if (!chart.editor || chart.editor.editable === false)
          throw Error("편집 가능한 차트 모델이 아닙니다.");
        rebuildEditableGraph(chart);
        activeProject.charts[index] = chart;
        payload.chart = chart;
      }
      function applySlotImageImportedAction({ machine, payload }) {
        machine.assertWritable("slots","SLOT_IMAGE_IMPORTED");
        machine.assertWritable("images","SLOT_IMAGE_IMPORTED");
        machine.assertWritable("charts","SLOT_IMAGE_IMPORTED");
        machine.assertWritable("workspace","SLOT_IMAGE_IMPORTED");
        machine.assertWritable("files","SLOT_IMAGE_IMPORTED");
        let slot=slotAt(payload.slotId),source=payload.model||getProjectImage(payload.imageId);
        if(!slot||!source||!Number.isInteger(source.id)||source.id<1||
          typeof source.name!=="string"||typeof source.bytesBase64!=="string"||!source.bytesBase64)
          throw Error("이미지를 연결할 슬롯 또는 이미지가 없습니다.");
        let candidate=projectClone(activeProject._state);
        normalizeSlotContents(candidate.slots);
        let imageId=source.id;
        if(payload.model){
          if(candidate.assets.images.some(item=>item.id===imageId))
            throw Error(`이미지 ID ${imageId}가 중복되었습니다.`);
          let model=projectClone(source);delete model.settings;
          projectVfs.prepare(model,"image",candidate);
          candidate.assets.images.push(model);
          candidate.nextId.image=Math.max(candidate.nextId.image,imageId+1);
        }
        let target=candidate.slots.find(item=>item.id===slot.id);
        if(Number.isInteger(target.chart))
          candidate.charts=candidate.charts.filter(chart=>chart.id!==target.chart);
        target.chart=null;target.imageId=imageId;target.contentType="image";
        target.content.imageSettings={...DEFAULT_IMAGE_SETTINGS};
        validateProjectObjectState(candidate,{requireSlots:true});
        activeProject.initialize(candidate);
        payload.image=getProjectImage(imageId);
        if(slot.id===selectedSlotId)
          machine.state=Object.freeze({...machine.state,graphObject:"none",graphObjectIndex:null});
      }
      function applySlotChartImportedAction({ machine, payload }) {
        machine.assertWritable("slots","SLOT_CHART_IMPORTED");
        machine.assertWritable("data","SLOT_CHART_IMPORTED");
        machine.assertWritable("charts","SLOT_CHART_IMPORTED");
        machine.assertWritable("workspace","SLOT_CHART_IMPORTED");
        machine.assertWritable("editor","SLOT_CHART_IMPORTED");
        machine.assertWritable("files","SLOT_CHART_IMPORTED");
        let slot=slotAt(payload.slotId),
          sourceChart=payload.chart,
          importKind=payload.importKind==="plotly"?"plotly":"ffsx",
          packaged=Array.isArray(payload.csvFiles)?payload.csvFiles:[];
        if(!slot||!sourceChart)
          throw Error("불러온 차트를 적용할 슬롯 또는 차트가 없습니다.");

        let candidate=projectClone(activeProject._state);
        normalizeSlotContents(candidate.slots);
        let chart=projectClone(sourceChart),
          createdCsvIds=[];

        if(importKind==="ffsx"){
          let packagedIds=new Set(),csvMap=new Map(),nextCsvId=candidate.nextId.csv;
          for(let source of packaged){
            if(!source||!Number.isInteger(source.id)||source.id<1||
              packagedIds.has(source.id)||!Array.isArray(source.rows))
              throw Error("FFSX CSV 데이터가 올바르지 않습니다.");
            packagedIds.add(source.id);
            let model=buildProjectCsvModel(
              source.rows,
              source.name||source.sourceName,
              nextCsvId++,
              source.bytesBase64,
              source.mime,
              source.headerLines,
              candidate,
            );
            projectVfs.prepare(model,"csv",candidate);
            candidate.assets.csvFiles.push(model);
            csvMap.set(source.id,model.id);
            createdCsvIds.push(model.id);
          }
          candidate.nextId.csv=nextCsvId;
          for(let object of chart.editor?.objects||[]){
            if(!csvMap.has(object.csvId))
              throw Error("FFSX 차트가 포함되지 않은 CSV를 참조합니다.");
            object.csvId=csvMap.get(object.csvId);
          }
        } else {
          chart.editor.editable=false;
          if(!Array.isArray(chart.editor.conversionRows))
            chart.editor.conversionRows=[];
        }

        chart.id=candidate.nextId.chart++;
        validateChartModel(chart,"불러온 슬롯 차트",candidate.assets.csvFiles);
        let target=candidate.slots.find(item=>item.id===slot.id);
        if(Number.isInteger(target.chart))
          candidate.charts=candidate.charts.filter(item=>item.id!==target.chart);
        candidate.charts.push(chart);
        target.chart=chart.id;
        target.imageId=null;
        target.contentType="graph";
        target.content.imageSettings={...DEFAULT_IMAGE_SETTINGS};
        if(payload.slotCaption!==undefined)
          target.caption=typeof payload.slotCaption==="string"&&payload.slotCaption
            ?payload.slotCaption:null;

        validateProjectObjectState(candidate,{requireSlots:true});
        activeProject.initialize(candidate);
        machine.state=Object.freeze({
          ...machine.state,
          graphObject:"none",
          graphObjectIndex:null,
        });
        payload.chart=getChart(chart.id);
        payload.createdCsvIds=createdCsvIds;
      }
      function applyGridLayoutChangedAction({ machine, payload }) {
        machine.assertWritable("layout", "GRID_LAYOUT_CHANGED");
        machine.assertWritable("slots", "GRID_LAYOUT_CHANGED");
        machine.assertWritable("workspace", "GRID_LAYOUT_CHANGED");
        machine.assertWritable("editor", "GRID_LAYOUT_CHANGED");
        rebuildGridSlots(payload.rows, payload.cols);
      }
      function applyProjectDirectoryCreatedAction({ machine, payload }) {
        machine.assertWritable("files", "PROJECT_DIRECTORY_CREATED");
        projectVfs.ensure(activeProject._state);
        let parent = normalizeProjectPath(payload.parent || "/assets", { directory: true }),
          rawName = String(payload.name || "").trim(),
          name = projectCsvName(rawName, "");
        if (parent !== "/" && !activeProject.fileSystem.directories.includes(parent))
          throw Error(`상위 폴더 ${parent}가 없습니다.`);
        if (!name || name !== rawName || /[\\/]/.test(rawName))
          throw Error("폴더 이름이 올바르지 않습니다.");
        let path = normalizeProjectPath(`${parent}/${name}`, { directory: true });
        if (projectVfs.exists(path)) throw Error(`${path}가 이미 존재합니다.`);
        activeProject.fileSystem.directories.push(path);
        activeProject.fileSystem.directories.sort();
        payload.path = path;
      }
      function projectAssetReferenceCount(csvIds, imageIds) {
        return activeProject.charts.reduce(
          (count, chart) => count + chartCsvIds(chart).filter((id) => csvIds.has(id)).length,
          0,
        ) + activeProject.slots.filter((slot) => imageIds.has(slot.imageId)).length;
      }
      function removeProjectAssetReferences(csvIds, imageIds, state=activeProject._state) {
        let removedGraphReferenceCount=0, resetImageSlotCount=0;
        normalizeSlotContents(state.slots);
        state.charts.forEach(chart=>{
          if(!Array.isArray(chart.editor?.objects))return;
          let objects=chart.editor.objects.filter(object=>!csvIds.has(object.csvId));
          removedGraphReferenceCount+=chart.editor.objects.length-objects.length;
          if(objects.length===chart.editor.objects.length)return;
          chart.editor.objects=objects;
          if(chart.editor.editable!==false){
            chart.graph.data=traces(chart);
            chart.graph.layout=layout(chart);
          }
        });
        state.slots.forEach(slot=>{
          if(!imageIds.has(slot.imageId))return;
          resetImageSlotCount+=1;
          slot.imageId=null;
        });
        return {removedGraphReferenceCount,resetImageSlotCount};
      }
      function applyProjectTrashEmptiedAction({ machine, payload }) {
        machine.assertWritable("files", "PROJECT_TRASH_EMPTIED");
        machine.assertWritable("data", "PROJECT_TRASH_EMPTIED");
        machine.assertWritable("images", "PROJECT_TRASH_EMPTIED");
        let csvFiles = activeProject.csvFiles.filter((csv) => projectVfs.isTrashed(projectAssetPath(csv))),
          images = activeProject.images.filter((image) => projectVfs.isTrashed(projectAssetPath(image))),
          directories = activeProject.fileSystem.directories.filter(
            (path) => path !== PROJECT_TRASH_DIRECTORY && projectVfs.isTrashed(path),
          ),
          csvIds = new Set(csvFiles.map((csv) => csv.id)),
          imageIds = new Set(images.map((image) => image.id));
        let hasReferences = projectAssetReferenceCount(csvIds, imageIds) > 0;
        if (hasReferences) {
          machine.assertWritable("charts", "PROJECT_TRASH_EMPTIED");
          machine.assertWritable("slots", "PROJECT_TRASH_EMPTIED");
          machine.assertWritable("editor", "PROJECT_TRASH_EMPTIED");
        }
        let removedReferences = removeProjectAssetReferences(csvIds, imageIds);
        images.forEach(releaseProjectImageDisplayUrl);
        activeProject.csvFiles = activeProject.csvFiles.filter((csv) => !csvIds.has(csv.id));
        activeProject.images = activeProject.images.filter((image) => !imageIds.has(image.id));
        activeProject.fileSystem.directories = activeProject.fileSystem.directories.filter(
          (path) => path === PROJECT_TRASH_DIRECTORY || !projectVfs.isTrashed(path),
        );
        payload.csvCount = csvFiles.length;
        payload.imageCount = images.length;
        payload.directoryCount = directories.length;
        payload.removedReferenceCount =
          removedReferences.removedGraphReferenceCount + removedReferences.resetImageSlotCount;
        validateProjectObject(activeProject, { requireSlots: true });
      }
      function applyProjectNodeMovedAction({ machine, payload }) {
        machine.assertWritable("files","PROJECT_NODE_MOVED");
        let liveMatch=projectVfs.resolve(payload.path),
          directory=normalizeProjectPath(payload.directory,{directory:true});
        if(!liveMatch) throw Error("이동할 프로젝트 파일 또는 폴더가 없습니다.");
        if(!activeProject.fileSystem.directories.includes(directory))
          throw Error("대상 폴더가 없습니다.");

        let source=liveMatch.kind==="directory"?liveMatch.path:projectAssetPath(liveMatch.asset);
        if(liveMatch.kind==="directory"){
          if(projectVfs.isFixedDirectory(source))
            throw Error("기본 프로젝트 폴더는 이동할 수 없습니다.");
          if(projectPathInDirectory(directory,source))
            throw Error("폴더를 자기 자신 또는 하위 폴더로 이동할 수 없습니다.");
        }

        let movingLive=liveMatch.kind==="directory"
            ?projectVfs.descendants(source)
            :[{kind:liveMatch.kind,asset:liveMatch.asset}],
          csvIds=new Set(movingLive.filter(({kind})=>kind==="csv").map(({asset})=>asset.id)),
          imageIds=new Set(movingLive.filter(({kind})=>kind==="image").map(({asset})=>asset.id));

        if(csvIds.size) machine.assertWritable("data","PROJECT_NODE_MOVED");
        if(imageIds.size) machine.assertWritable("images","PROJECT_NODE_MOVED");

        let requestedName=payload.name===undefined
            ?projectPathName(source)
            :String(payload.name||"").trim(),
          safeName=projectCsvName(requestedName,"");
        if(!safeName||safeName!==requestedName||/[\\/]/.test(requestedName))
          throw Error("이동할 항목의 새 이름이 올바르지 않습니다.");

        let destination=normalizeProjectPath(`${directory}/${safeName}`,{
          directory:liveMatch.kind==="directory",
        });
        if(destination===source){
          payload.path=source;
          payload.trashed=false;
          return;
        }

        let candidate=projectClone(activeProject._state);
        normalizeSlotContents(candidate.slots);
        let match=projectVfs.resolve(source,candidate);
        if(!match) throw Error("이동할 프로젝트 항목을 candidate에서 찾을 수 없습니다.");
        if(projectVfs.exists(destination,candidate))
          throw Error(`${destination}가 이미 존재합니다.`);

        let enteringTrash=projectVfs.isTrashed(destination)&&!projectVfs.isTrashed(source);
        if(enteringTrash){
          machine.assertWritable("charts","PROJECT_NODE_MOVED");
          machine.assertWritable("slots","PROJECT_NODE_MOVED");
          machine.assertWritable("editor","PROJECT_NODE_MOVED");
        }

        let rewritePath=(path)=>
          match.kind==="directory"&&projectPathInDirectory(path,source)
            ?`${destination}${path.slice(source.length)}`
            :destination;

        if(match.kind==="directory"){
          candidate.fileSystem.directories=candidate.fileSystem.directories
            .map(path=>projectPathInDirectory(path,source)?rewritePath(path):path)
            .sort();
          projectVfs.descendants(source,candidate).forEach(({asset})=>{
            let oldPath=projectAssetPath(asset);
            asset.directory=projectParentPath(rewritePath(oldPath));
          });
        } else {
          match.asset.directory=directory;
          match.asset.name=safeName;
        }

        let removedReferences={removedGraphReferenceCount:0,resetImageSlotCount:0};
        if(enteringTrash)
          removedReferences=removeProjectAssetReferences(csvIds,imageIds,candidate);

        validateProjectObjectState(candidate,{requireSlots:true});
        activeProject.initialize(candidate);

        let movedSelectionPath=
          machine.state.assetPath&&projectPathInDirectory(machine.state.assetPath,source)
            ?rewritePath(machine.state.assetPath):null;
        if(movedSelectionPath){
          if(projectVfs.isTrashed(movedSelectionPath))
            payload.clearAssetSelection=true;
          else
            machine.state=Object.freeze({...machine.state,assetPath:movedSelectionPath});
        }
        payload.clearGraphSelection=
          removedReferences.removedGraphReferenceCount>0||
          removedReferences.resetImageSlotCount>0;
        payload.path=destination;
        payload.trashed=enteringTrash;
      }
      function applyAssetSelectionAction({ machine, payload }) {
        let kind = ["csv", "image", "directory"].includes(payload.kind) ? payload.kind : null,
          match = payload.path ? projectVfs.resolve(payload.path) : null,
          asset = match?.kind === kind ? match.asset : null,
          path = kind === "directory" && match?.kind === "directory" ? match.path : asset ? projectAssetPath(asset) : null;
        machine.state = Object.freeze({
          ...machine.state,
          assetPath: path ?? null,
        });
      }
      function assetSelectionTarget({ payload }) {
        let match = payload.path ? projectVfs.resolve(payload.path) : null;
        if (match?.kind === payload.kind) return payload.kind;
        return "none";
      }
      function requestedOverlayState({ state, payload }) {
        return state === payload.overlay ? "none" : payload.overlay;
      }
      function syncGraphWorkspaceState() {
        let slot=getSelectedSlot();
        if(slot?.chart)activateChartModel(slot.chart);
      }
      function exitGraphWorkspaceState({ machine }) {
        machine.state = Object.freeze({
          ...machine.state,
          graphObject: "none",
          graphObjectIndex: null,
        });
      }
      function readmeContentHtml() {
        let template = $("readmeContent");
        return template ? template.innerHTML.replaceAll("{{APP_BUILD}}", APP_BUILD) : "";
      }
      function enterLifecycleState({ state, payload }) {
        let busy = state === "importing" || state === "exporting";
        document.body.classList.toggle("app-busy", busy);
        document.body.setAttribute("aria-busy", String(busy));
        if (state === "error" && payload.error)
          debugLog("fsm:lifecycle-error", payload.error, "error");
      }
      const SHARED_WORKSPACE_EVENTS = {
          SELECT_SLOT: {
            action: applySlotSelectionAction,
            target: requestedWorkspaceState,
          },
          SLOT_TYPE_CHANGED: {
            action: applySlotTypeAction,
            target: requestedWorkspaceState,
          },
          CAPTION_TEXT_INPUT: {
            action: applyCaptionTextAction,
            target: ({ state }) => state,
          },
          SLOT_CAPTIONS_INSERTED: {
            action: applySlotCaptionsInsertedAction,
            target: ({ state }) => state,
          },
          PROJECT_DIRECTORY_CREATED: {
            action: applyProjectDirectoryCreatedAction,
            target: ({ state }) => state,
          },
          PROJECT_NODE_MOVED: {
            action: applyProjectNodeMovedAction,
            target: requestedWorkspaceState,
          },
          PROJECT_TRASH_EMPTIED: {
            action: applyProjectTrashEmptiedAction,
            target: ({ state }) => state,
          },
          DATA_OBJECT_CREATED: {
            action: applyDataObjectCreatedAction,
            target: ({ state }) => state,
          },
          DATA_OBJECT_REPLACED: {
            action: applyDataObjectReplacedAction,
            target: ({ state }) => state,
          },
          DATA_OBJECT_DELETED: {
            action: applyDataObjectDeletedAction,
            target: ({ state }) => state,
          },
          IMAGE_OBJECT_CREATED: {
            action: applyImageObjectCreatedAction,
            target: ({ state }) => state,
          },
          IMAGE_OBJECT_REPLACED: {
            action: applyImageObjectReplacedAction,
            target: ({ state }) => state,
          },
          IMAGE_OBJECT_DELETED: {
            action: applyImageObjectDeletedAction,
            target: ({ state }) => state,
          },
          SLOTS_RESET: {
            action: applySlotsResetAction,
            target: requestedWorkspaceState,
          },
          SLOTS_SWAPPED: {
            action: applySlotsSwappedAction,
            target: requestedWorkspaceState,
          },
          SLOT_IMAGE_LINKED: {
            action: applySlotImageLinkedAction,
            target: ({ state }) => state,
          },
          SLOT_DATA_CONNECTED: {
            action: applySlotDataConnectedAction,
            target: requestedWorkspaceState,
          },
          GRAPH_OBJECTS_REPLACED: {
            action: applyGraphObjectsReplacedAction,
            target: ({ state }) => state,
          },
          CHART_LAYOUT_CHANGED: {
            action: applyChartLayoutChangedAction,
            target: ({ state }) => state,
          },
          CHART_MODEL_REPLACED: {
            action: applyChartModelReplacedAction,
            target: ({ state }) => state,
          },
          SLOT_IMAGE_IMPORTED: {
            action: applySlotImageImportedAction,
            target: requestedWorkspaceState,
          },
          SLOT_CHART_IMPORTED: {
            action: applySlotChartImportedAction,
            target: requestedWorkspaceState,
          },
          GRID_LAYOUT_CHANGED: {
            action: applyGridLayoutChangedAction,
            target: "project",
          },
          PROJECT_LOADED: {
            action: applyProjectLoadedAction,
            target: "project",
          },
        },
        SHARED_OVERLAY_EVENTS = {
          TOGGLE_OVERLAY: { target: requestedOverlayState },
          CLOSE_OVERLAY: { target: "none" },
          OUTSIDE_CLICK: { target: "none" },
          ESCAPE: { target: "none" },
          SELECT_SLOT: {
            target: ({ state, payload }) => payload.slotId == null ? state : "none",
          },
          CAPTION_TEXT_INPUT: { target: ({ state }) => state },
          SLOT_CAPTIONS_INSERTED: { target: ({ state }) => state },
          SLOTS_SWAPPED: { target: ({ state }) => state },
        },
        GRAPH_OBJECT_EVENTS = {
          SELECT_GRAPH_OBJECT: {
            action: applyGraphObjectSelectionAction,
            target: ({ payload }) => Number.isInteger(payload.index) ? "selected" : "none",
          },
          CLEAR_GRAPH_OBJECT: {
            action: applyGraphObjectSelectionAction,
            target: "none",
          },
          SELECT_SLOT: {
            action: applyGraphObjectSelectionAction,
            target: "none",
          },
          SLOT_TYPE_CHANGED: {
            action: applyGraphObjectSelectionAction,
            target: "none",
          },
          SLOTS_RESET: {
            action: applyGraphObjectSelectionAction,
            target: "none",
          },
          SLOTS_SWAPPED: {
            action: applyGraphObjectSelectionAction,
            target: "none",
          },
          GRAPH_OBJECTS_REPLACED: {
            action: applyGraphObjectSelectionAction,
            target: ({ machine }) =>
              Number.isInteger(machine.state.graphObjectIndex) ? "selected" : "none",
          },
          PROJECT_NODE_MOVED: ({ state, payload }) =>
            payload.clearGraphSelection
              ? { action: applyGraphObjectSelectionAction, target: "none" }
              : { target: state },
          GRID_LAYOUT_CHANGED: {
            action: applyGraphObjectSelectionAction,
            target: "none",
          },
          PROJECT_LOADED: {
            action: applyGraphObjectSelectionAction,
            target: "none",
          },
        },
        ASSET_SELECTION_EVENTS = {
          SELECT_ASSET: {
            action: applyAssetSelectionAction,
            target: assetSelectionTarget,
          },
          CLEAR_ASSET_SELECTION: {
            action: applyAssetSelectionAction,
            target: "none",
          },
          DATA_OBJECT_REPLACED: { target: ({ state }) => state },
          IMAGE_OBJECT_REPLACED: { target: ({ state }) => state },
          PROJECT_NODE_MOVED: ({ state, payload }) =>
            payload.clearAssetSelection
              ? { action: applyAssetSelectionAction, target: "none" }
              : { target: state },
          SELECT_SLOT: {
            action: applyAssetSelectionAction,
            target: "none",
          },
          SLOTS_SWAPPED: {
            action: applyAssetSelectionAction,
            target: "none",
          },
          GRID_LAYOUT_CHANGED: {
            action: applyAssetSelectionAction,
            target: "none",
          },
          PROJECT_LOADED: {
            action: applyAssetSelectionAction,
            target: "none",
          },
        },
        APP_STATE_DEFINITIONS = {
          lifecycle: {
            booting: {
              objects: ["project"],
              entry: enterLifecycleState,
              on: { READY: { target: "ready" } },
            },
            ready: {
              objects: ["project", "ui"],
              entry: enterLifecycleState,
              on: {
                BEGIN_IMPORT: { target: "importing" },
                BEGIN_EXPORT: { target: "exporting" },
                FAIL: { target: "error" },
              },
            },
            importing: {
              objects: ["project", "data", "images", "charts", "slots"],
              entry: enterLifecycleState,
              on: { COMPLETE: { target: "ready" }, FAIL: { target: "error" } },
            },
            exporting: {
              objects: ["project", "layout", "labels", "captions", "data", "images", "charts", "slots"],
              entry: enterLifecycleState,
              on: { COMPLETE: { target: "ready" }, FAIL: { target: "error" } },
            },
            error: {
              objects: ["project", "ui"],
              entry: enterLifecycleState,
              on: { RECOVER: { target: "ready" } },
            },
          },
          workspace: {
            project: {
              objects: [
                "project",
                "layout",
                "labels",
                "captions",
                "data",
                "images",
                "files",
                "charts",
                "slots",
                "ui",
              ],
              on: SHARED_WORKSPACE_EVENTS,
            },
            "slot.graph": {
              objects: [
                "slots",
                "charts",
                "data",
                "images",
                "files",
                "layout",
                "labels",
                "captions",
                "ui",
              ],
              entry: syncGraphWorkspaceState,
              exit: exitGraphWorkspaceState,
              update: syncGraphWorkspaceState,
              on: SHARED_WORKSPACE_EVENTS,
            },
            "slot.image": {
              objects: [
                "slots",
                "charts",
                "data",
                "images",
                "files",
                "layout",
                "labels",
                "captions",
                "ui",
              ],
              on: SHARED_WORKSPACE_EVENTS,
            },
          },
          overlay: {
            none: {
              objects: ["ui"],
              on: SHARED_OVERLAY_EVENTS,
            },
            layout: {
              objects: ["layout", "slots", "ui"],
              on: SHARED_OVERLAY_EVENTS,
            },
            label: {
              objects: ["labels", "slots", "ui"],
              on: SHARED_OVERLAY_EVENTS,
            },
            caption: {
              objects: ["captions", "slots", "labels", "ui"],
              on: SHARED_OVERLAY_EVENTS,
            },
            print: {
              objects: ["project", "layout", "labels", "captions", "charts", "images", "slots", "ui"],
              on: SHARED_OVERLAY_EVENTS,
            },
            readme: {
              objects: ["project", "ui"],
              on: SHARED_OVERLAY_EVENTS,
            },
          },
          assetSelection: {
            none: {
              objects: ["data", "images", "ui"],
              on: ASSET_SELECTION_EVENTS,
            },
            csv: {
              objects: ["data", "images", "ui"],
              on: ASSET_SELECTION_EVENTS,
            },
            image: {
              objects: ["data", "images", "ui"],
              on: ASSET_SELECTION_EVENTS,
            },
            directory: {
              objects: ["data", "images", "ui"],
              on: ASSET_SELECTION_EVENTS,
            },
          },
          graphObject: {
            none: {
              objects: ["slots", "charts"],
              on: GRAPH_OBJECT_EVENTS,
            },
            selected: {
              objects: ["slots", "charts"],
              on: GRAPH_OBJECT_EVENTS,
            },
          },
        };
      const projectObjects = new ProjectObjectRegistry(() => activeProject)
        .registerPath("project", PROJECT_OBJECT_PATHS.project)
        .registerPath("layout", PROJECT_OBJECT_PATHS.layout)
        .registerPath("labels", PROJECT_OBJECT_PATHS.labels)
        .registerPath("captions", PROJECT_OBJECT_PATHS.captions)
        .registerPath("data", PROJECT_OBJECT_PATHS.data)
        .registerPath("images", PROJECT_OBJECT_PATHS.images)
        .registerPath("files", PROJECT_OBJECT_PATHS.files)
        .registerPath("charts", PROJECT_OBJECT_PATHS.charts)
        .registerPath("slots", PROJECT_OBJECT_PATHS.slots)
        .registerPath("sequences", PROJECT_OBJECT_PATHS.sequences)
        .registerPath("appearance", PROJECT_OBJECT_PATHS.appearance)
        .registerPath("export", PROJECT_OBJECT_PATHS.export)
        .register("ui", {
          read: (project) => ({
            selectedSlotId,
            pendingSlotContentType,
            palette: project.appearance.uiPalette,
          }),
        });
      const appFSM = new ApplicationStateMachine(projectObjects, APP_STATE_DEFINITIONS);
      function selectedProjectAsset() {
        let path = appFSM.state.assetPath;
        return path ? projectVfs.resolve(path) : null;
      }
      function selectedProjectCsv() {
        let selected = selectedProjectAsset();
        return selected?.kind === "csv" ? selected.asset : null;
      }
      const ALLOWED_CHART_TYPES = new Set(["scatter", "markers", "lines+markers", "bar", "hidden"]);
      const ALLOWED_LINE_DASHES = new Set(["solid", "dot", "dash", "dashdot"]);
      const ALLOWED_MARKER_SYMBOLS = new Set([
        "circle",
        "square",
        "diamond",
        "cross",
        "x",
        "triangle-up",
        "triangle-down",
      ]);
      const ALLOWED_AXIS_SIDES = { x: new Set(["bottom", "top"]), y: new Set(["left", "right"]) };
      const CURRENT_OBJECT_KEYS = new Set([
        "csvId",
        "x",
        "y",
        "xAxisSide",
        "yAxisSide",
        "type",
        "color",
        "legendName",
        "lineWidth",
        "lineDash",
        "markerSymbol",
        "markerSize",
        "barOpacity",
        "barLineWidth",
        "plotlyTrace",
      ]);
      const REQUIRED_APP_FUNCTIONS = [
        ["readProjectNumber", () => typeof readProjectNumber === "function"],
        ["importProject", () => typeof importProject === "function"],
        ["ffpxReadProject", () => typeof ffpxReadProject === "function"],
        ["downloadProject", () => typeof downloadProject === "function"],
        ["ffpxDataUrlBytes", () => typeof ffpxDataUrlBytes === "function"],
        ["ffpxBase64ToBytes", () => typeof ffpxBase64ToBytes === "function"],
        ["ffpxBytesToBase64", () => typeof ffpxBytesToBase64 === "function"],
        ["normalizeGlobalSettings", () => typeof normalizeGlobalSettings === "function"],
        ["normalizeImageSettings", () => typeof normalizeImageSettings === "function"],
        ["traces", () => typeof traces === "function"],
        ["layout", () => typeof layout === "function"],
        ["renderDashboard", () => typeof renderDashboard === "function"],
        ["makeSlots", () => typeof makeSlots === "function"],
        ["applyImageSettingsFromValues", () => typeof applyImageSettingsFromValues === "function"],
        ["projectClone", () => typeof projectClone === "function"],
        ["ProjectObject", () => activeProject instanceof ProjectObject],
        ["buildProjectObject", () => typeof buildProjectObject === "function"],
        ["validateProjectObject", () => typeof validateProjectObject === "function"],
        ["renderProjectObject", () => typeof renderProjectObject === "function"],
        ["projectObjects", () => projectObjects instanceof ProjectObjectRegistry],
        ["appFSM", () => appFSM instanceof ApplicationStateMachine],
        ["auditApp", () => typeof auditApp === "function"],
      ];
      function auditObject(object, chartId, index, issues, allowNoCsv = false) {
        if (!object || typeof object !== "object") {
          issues.push({ kind: "invalid-object", chartId, index, value: object });
          return;
        }
        let keys = Object.keys(object),
          unknown = keys.filter((key) => !CURRENT_OBJECT_KEYS.has(key));
        if (unknown.length)
          issues.push({ kind: "unknown-object-keys", chartId, index, keys: unknown });
        if (typeof object.x !== "string" || typeof object.y !== "string")
          issues.push({ kind: "invalid-object-columns", chartId, index, x: object.x, y: object.y });
        if (!allowNoCsv && (!Number.isInteger(object.csvId) || !getProjectCsv(object.csvId)))
          issues.push({ kind: "orphan-object-csv", chartId, index, csvId: object.csvId });
        if (!ALLOWED_CHART_TYPES.has(object.type))
          issues.push({ kind: "invalid-chart-type", chartId, index, value: object.type });
        if (!ALLOWED_AXIS_SIDES.x.has(object.xAxisSide))
          issues.push({ kind: "invalid-x-axis-side", chartId, index, value: object.xAxisSide });
        if (!ALLOWED_AXIS_SIDES.y.has(object.yAxisSide))
          issues.push({ kind: "invalid-y-axis-side", chartId, index, value: object.yAxisSide });
        if (!ALLOWED_LINE_DASHES.has(object.lineDash || "solid"))
          issues.push({ kind: "invalid-line-dash", chartId, index, value: object.lineDash });
        if (!ALLOWED_MARKER_SYMBOLS.has(object.markerSymbol || "circle"))
          issues.push({
            kind: "invalid-marker-symbol",
            chartId,
            index,
            value: object.markerSymbol,
          });
        [
          ["lineWidth", 0.1, 20],
          ["markerSize", 1, 40],
          ["barOpacity", 0.05, 1],
          ["barLineWidth", 0, 10],
        ].forEach(([key, min, max]) => {
          let value = Number(object[key]);
          if (!Number.isFinite(value) || value < min || value > max)
            issues.push({
              kind: "invalid-numeric-value",
              chartId,
              index,
              key,
              value: object[key],
              min,
              max,
            });
        });
      }
      function auditApp(context = "manual") {
        let issues = [],
          ids = [...document.querySelectorAll("[id]")].map((node) => node.id),
          duplicates = [...new Set(ids.filter((id, index) => ids.indexOf(id) !== index))],
          missingControls = ["dashboard", "dashboardCaption", "graphArea", "readmeContent"].filter(
            (id) => !document.getElementById(id),
          ),
          missingFunctions = REQUIRED_APP_FUNCTIONS.filter(([, check]) => !check()).map(
            ([name]) => name,
          );
        if (missingFunctions.length)
          issues.push({ kind: "missing-functions", names: missingFunctions });
        if (duplicates.length) issues.push({ kind: "duplicate-controls", ids: duplicates });
        if (missingControls.length) issues.push({ kind: "missing-controls", ids: missingControls });
        if (!["booting", "ready", "importing", "exporting", "error"].includes(appFSM.state.lifecycle))
          issues.push({ kind: "invalid-fsm-lifecycle", lifecycle: appFSM.state.lifecycle });
        if (!["project", "slot.graph", "slot.image"].includes(appFSM.state.workspace))
          issues.push({ kind: "invalid-fsm-workspace", workspace: appFSM.state.workspace });
        if (!["none", "layout", "label", "caption", "print", "readme"].includes(appFSM.state.overlay))
          issues.push({ kind: "invalid-fsm-overlay", overlay: appFSM.state.overlay });
        if (
          !["fsm-to-model", "model-to-fsm", "model-to-ui"].includes(
            appFSM.state.direction,
          )
        )
          issues.push({
            kind: "invalid-fsm-direction",
            direction: appFSM.state.direction,
          });
        if (appFSM.state.lifecycle === "ready" && appFSM.writeLocks.size)
          issues.push({
            kind: "fsm-write-lock-leak",
            locks: [...appFSM.writeLocks],
          });
        let derivedWorkspace = workspaceStateFromModel();
        if (appFSM.state.workspace !== derivedWorkspace)
          issues.push({
            kind: "fsm-workspace-out-of-sync",
            state: appFSM.state,
            derived: derivedWorkspace,
          });
        for (let region of ["lifecycle", "workspace", "overlay"]) {
          let definition = appFSM.definition(region);
          (definition.objects || []).forEach((name) => {
            try {
              projectObjects.read(name);
            } catch (error) {
              issues.push({
                kind: "fsm-object-unavailable",
                region,
                state: appFSM.state[region],
                object: name,
                message: error.message,
              });
            }
          });
        }
        for (let state of ["project", "slot.graph", "slot.image"]) {
          let names = APP_STATE_DEFINITIONS.workspace[state].objects || [],
            missing = ["data", "images", "charts", "slots"].filter(
              (name) => !names.includes(name),
            );
          if (missing.length)
            issues.push({
              kind: "fsm-data-tree-objects-missing",
              state,
              missing,
            });
        }
        try {
          validateProjectObject(activeProject, { requireSlots: true });
        } catch (error) {
          issues.push({
            kind: "invalid-project-object",
            message: error.message,
          });
        }
        let selectedPathAsset = appFSM.state.assetPath
          ? projectVfs.resolve(appFSM.state.assetPath)
          : null;
        if (
          (appFSM.state.assetSelection === "none") !== (selectedPathAsset === null) ||
          (selectedPathAsset && selectedPathAsset.kind !== appFSM.state.assetSelection)
        )
          issues.push({
            kind: "fsm-asset-path-out-of-sync",
            selection: appFSM.state.assetSelection,
            path: appFSM.state.assetPath,
          });
        if (typeof activeProject.captionAfterText !== "string")
          issues.push({
            kind: "invalid-caption-after-text",
            value: activeProject.captionAfterText,
          });
        document.querySelectorAll("select[id]").forEach((select) => {
          if (select.value && ![...select.options].some((option) => option.value === select.value))
            issues.push({ kind: "invalid-select-value", id: select.id, value: select.value });
        });
        let csvIds = new Set();
        activeProject.csvFiles.forEach((csv, index) => {
          if (
            !csv ||
            !Number.isInteger(csv.id) ||
            csvIds.has(csv.id) ||
            Object.prototype.hasOwnProperty.call(csv, "path") ||
            typeof csv.name !== "string" ||
            typeof csv.directory !== "string" ||
            !Array.isArray(csv.rows) ||
            typeof csv.bytesBase64 !== "string" ||
            !Number.isInteger(csv.headerLines)
          )
            issues.push({ kind: "invalid-project-csv", index, id: csv?.id });
          else csvIds.add(csv.id);
        });
        let imageIds = new Set();
        activeProject.images.forEach((image, index) => {
          if (
            !image ||
            !Number.isInteger(image.id) ||
            imageIds.has(image.id) ||
            Object.prototype.hasOwnProperty.call(image, "path") ||
            typeof image.name !== "string" ||
            typeof image.directory !== "string" ||
            typeof image.mime !== "string" ||
            typeof image.bytesBase64 !== "string" ||
            !image.bytesBase64
          )
            issues.push({ kind: "invalid-project-image", index, id: image?.id });
          else imageIds.add(image.id);
        });
        let chartIds = new Set();
        activeProject.charts.forEach((chart, index) => {
          if (!chart || typeof chart !== "object") {
            issues.push({ kind: "invalid-chart", index, value: chart });
            return;
          }
          if (!Number.isInteger(chart.id) || chartIds.has(chart.id))
            issues.push({ kind: "invalid-or-duplicate-chart-id", index, id: chart.id });
          chartIds.add(chart.id);
          if (!chart.editor || !Array.isArray(chart.editor.objects))
            issues.push({ kind: "missing-object-array", chartId: chart.id });
          else
            chart.editor.objects.forEach((object, objectIndex) =>
              auditObject(
                object,
                chart.id,
                objectIndex,
                issues,
                chart.editor.editable === false,
              ),
            );
        });
        activeProject.slots.forEach((slot, index) => {
          if (!slot || typeof slot !== "object") issues.push({ kind: "invalid-slot", index });
          else {
            if (slot.chart !== null && slot.chart !== undefined && !chartIds.has(slot.chart))
              issues.push({ kind: "orphan-slot-chart", slotId: slot.id, chart: slot.chart });
            if (slot.imageId !== null && slot.imageId !== undefined && !imageIds.has(slot.imageId))
              issues.push({ kind: "orphan-slot-image", slotId: slot.id, imageId: slot.imageId });
            if (slot.caption !== null && typeof slot.caption !== "string")
              issues.push({
                kind: "invalid-slot-caption",
                slotId: slot.id,
                caption: slot.caption,
              });
          }
        });
        let summary = {
          context,
          build: projectObjects.read("project").appBuild,
          controls: ids.length,
          csvFiles: activeProject.csvFiles.length,
          images: activeProject.images.length,
          charts: activeProject.charts.length,
          slots: activeProject.slots.length,
          issues: issues.length,
        };
        debugLog("audit:summary", summary, issues.length ? "warn" : "info");
        issues.forEach((issue) => debugLog("audit:issue", issue, "warn"));
        return { summary, issues };
      }
      function currentAxes(settings = {}) {
        let saved = settings.axes && typeof settings.axes === "object" ? settings.axes : {},
          axis = (key, savedAxis = {}) => ({
            ...savedAxis,
            min: savedAxis.min ?? "",
            max: savedAxis.max ?? "",
            tick: savedAxis.tick ?? "",
            tickMode:
              savedAxis.scaleType !== "log" && savedAxis.tickMode === "increment"
                ? "increment"
                : "plotly",
            minorTicks: savedAxis.minorTicks === true,
            notation: savedAxis.notation ?? "none",
            scaleType: savedAxis.scaleType ?? "linear",
            divide: savedAxis.divide ?? "1",
            title: savedAxis.title ?? "",
            titleSize: savedAxis.titleSize ?? "14",
            lineWidth: savedAxis.lineWidth ?? "1",
            showGrid: savedAxis.showGrid !== false,
            visible: savedAxis.visible ?? (key === "xBottom" || key === "yLeft"),
            showValues: savedAxis.showValues !== false,
            fontSize: savedAxis.fontSize ?? "12",
          });
        return {
          xBottom: axis("xBottom", saved.xBottom),
          xTop: axis("xTop", saved.xTop),
          yLeft: axis("yLeft", saved.yLeft),
          yRight: axis("yRight", saved.yRight),
        };
      }
      function axisRangeValueFromPlotly(value, scaleType) {
        if (value === "" || value === null || value === undefined) return "";
        let number = Number(value);
        if (!Number.isFinite(number)) return "";
        let converted = scaleType === "log" ? 10 ** number : number;
        return Number.isFinite(converted) ? String(converted) : "";
      }
      function readGlobalSettings(chart) {
        let previous =
            chart.editor.globalSettings && typeof chart.editor.globalSettings === "object"
              ? chart.editor.globalSettings
              : {},
          settings = {
            ...previous,
            showLegend: previous.showLegend !== false,
            showTitle: previous.showTitle !== false,
            showZeroLine: previous.showZeroLine === true,
            graphFontFamily:
              typeof previous.graphFontFamily === "string" ? previous.graphFontFamily : "",
            titleFontSize: previous.titleFontSize ?? "",
            legendFontSize: previous.legendFontSize ?? "",
            axes: currentAxes(previous),
          };
        return settings;
      }
      function normalizeGlobalSettings(chart, force = false) {
        let settings = readGlobalSettings(chart);
        if (force || !appFSM.writeLocks.has("editor")) chart.editor.globalSettings = settings;
        return settings;
      }
      function axisKey(kind, side) {
        return kind === "x"
          ? side === "top"
            ? "xTop"
            : "xBottom"
          : side === "right"
            ? "yRight"
            : "yLeft";
      }
      function dashboardReferenceWidth() {
        return activeProject.layout.slotStyle.referenceWidth;
      }
      function dashboardAspectValue() {
        return activeProject.layout.slotStyle.aspect;
      }
      function dashboardOuterMarginPixels() {
        return activeProject.layout.slotStyle.outerMargin;
      }
      function slotGapPixels() {
        return activeProject.layout.slotStyle.gap;
      }
      function slotRadiusPixels() {
        return activeProject.layout.slotStyle.radius;
      }
      function dashboardGeometry(width = dashboardReferenceWidth(), heightOverride = null) {
        let referenceWidth = dashboardReferenceWidth(),
          scale = Math.max(0.001, Number(width) / referenceWidth),
          configuredAspect = dashboardAspectValue(),
          naturalHeight = (referenceWidth * scale) / configuredAspect,
          height =
            Number.isFinite(heightOverride) && heightOverride > 0
              ? Number(heightOverride)
              : naturalHeight,
          aspect = (referenceWidth * scale) / height,
          outerMargin = Math.min(
            dashboardOuterMarginPixels() * scale,
            Math.min(referenceWidth * scale, height) * 0.49,
          );
        return {
          referenceWidth,
          width: referenceWidth * scale,
          height,
          scale,
          aspect,
          outerMargin,
          gap: slotGapPixels() * scale,
          radius: slotRadiusPixels() * scale,
        };
      }
      function gridSlotGeometry(layout, geometry, slot = null) {
        let gap = geometry.gap,
          colWidth =
            (geometry.width - geometry.outerMargin * 2 - gap * (layout.gridCols - 1)) /
            layout.gridCols,
          rowHeight =
            (geometry.height - geometry.outerMargin * 2 - gap * (layout.gridRows - 1)) /
            layout.gridRows,
          target = slot && !slot.hidden ? slot : { rowSpan: 1, colSpan: 1 };
        return {
          colWidth,
          rowHeight,
          width: Math.max(1, colWidth * target.colSpan + gap * (target.colSpan - 1)),
          height: Math.max(1, rowHeight * target.rowSpan + gap * (target.rowSpan - 1)),
        };
      }
      function applyReferenceGeometry(element) {
        if (!element) return;
        let rect = element.getBoundingClientRect(),
          geometry = dashboardGeometry(rect.width || dashboardReferenceWidth());
        element.style.setProperty("--dashboard-outer-margin", `${geometry.outerMargin}px`);
        element.style.setProperty("--slot-gap", `${geometry.gap}px`);
        element.style.setProperty("--slot-radius", `${geometry.radius}px`);
        return geometry;
      }
      function syncDashboardCaptionWidth() {
        let dashboard = $("dashboard"),
          caption = $("dashboardCaption");
        if (!dashboard || !caption) return;
        let width = dashboard.getBoundingClientRect().width;
        caption.style.marginLeft = "0px";
        caption.style.width = `${width}px`;
        caption.style.minWidth = `${width}px`;
      }
      function applySlotStyle(_fromControls = false, notify = true) {
        let style = activeProject.layout.slotStyle,
          bordersVisible = style.showBorders,
          border = bordersVisible ? "var(--ui-color)" : "transparent",
          aspect = style.aspect,
          hasAspect = Number.isFinite(aspect) && aspect > 0,
          dashboard = $("dashboard");
        ["dashboard", "dashboardCaption"].forEach((id) => {
          let el = $(id);
          if (el) {
            el.style.setProperty("--slot-border-color", border);
            el.style.setProperty("--layout-slot-border-style", bordersVisible ? "solid" : "dashed");
          }
        });
        dashboard.classList.toggle("fixed-aspect", hasAspect);
        if (hasAspect) dashboard.style.setProperty("--dashboard-aspect", `${aspect} / 1`);
        else dashboard.style.removeProperty("--dashboard-aspect");
        requestAnimationFrame(() => {
          applyReferenceGeometry(dashboard);
        });
        let width =
            dashboard.getBoundingClientRect().width ||
            Number.parseFloat(dashboard.style.width) ||
            0,
          minWidth = Number.parseFloat(dashboard.style.minWidth) || width;
        if (width) syncDashboardCaptionWidth();
        if (notify) appFSM.notify("layout", "LAYOUT_STYLE_CHANGED");
      }
      function newGridSlot(id, row, col) {
        return normalizeSlotContent({
          id,
          row,
          col,
          rowSpan: 1,
          colSpan: 1,
          hidden: false,
          content: {
            chart: null,
            imageId: null,
            contentType: "graph",
            imageSettings: { ...DEFAULT_IMAGE_SETTINGS },
          },
          caption: null,
        });
      }
      function rebuildGridSlots(r, c) {
        let rows=Number(r), cols=Number(c);
        if(!Number.isInteger(rows)||!Number.isInteger(cols)||rows<1||rows>8||cols<1||cols>8)
          throw Error("레이아웃 행과 열은 1~8의 정수여야 합니다.");
        let candidate=projectClone(activeProject._state);
        normalizeSlotContents(candidate.slots);
        let removed=candidate.slots.filter(slot=>slot.row>rows||slot.col>cols);
        if(removed.some(slot=>slot.hidden||slot.rowSpan!==1||slot.colSpan!==1||slotHasNonDefaultLocalState(slot)))
          throw Error("내용이나 병합 상태가 있는 영역은 그리드 축소로 제거할 수 없습니다.");
        let retained=candidate.slots.filter(slot=>slot.row<=rows&&slot.col<=cols);
        if(retained.filter(slot=>!slot.hidden).some(slot=>
          slot.row+slot.rowSpan-1>rows||slot.col+slot.colSpan-1>cols))
          throw Error("병합된 슬롯을 가로지르도록 그리드를 축소할 수 없습니다.");
        candidate.layout.gridRows=rows; candidate.layout.gridCols=cols; candidate.slots=retained;
        let occupied=new Set(candidate.slots.map(slot=>`${slot.row}:${slot.col}`)),
          nextId=Math.max(-1,...candidate.slots.map(slot=>slot.id))+1;
        for(let row=1;row<=rows;row++) for(let col=1;col<=cols;col++){
          let key=`${row}:${col}`; if(occupied.has(key))continue;
          candidate.slots.push(newGridSlot(nextId++,row,col)); occupied.add(key);
        }
        validateProjectObjectState(candidate,{requireSlots:true});
        activeProject.initialize(candidate);
        if(selectedSlotId!==null&&!slotAt(selectedSlotId)) selectedSlotId=null;
        renderDashboard();
      }
      function makeSlots(r = activeProject.gridRows, c = activeProject.gridCols) {
        appFSM.send("GRID_LAYOUT_CHANGED", { rows: r, cols: c });
      }
      function parseCSV(text) {
        const d = (text.split(/\r?\n/)[0] || "").includes("\t") ? "\t" : ",";
        let a = [],
          r = [],
          c = "",
          q = false;
        for (let i = 0; i < text.length; i++) {
          let z = text[i],
            n = text[i + 1];
          if (z === '"' && q && n === '"') {
            c += '"';
            i++;
          } else if (z === '"') q = !q;
          else if (z === d && !q) {
            r.push(c);
            c = "";
          } else if ((z === "\n" || z === "\r") && !q) {
            if (z === "\r" && n === "\n") i++;
            r.push(c);
            if (r.some((v) => v.trim())) a.push(r.splice(0));
            c = "";
          } else c += z;
        }
        if (c || r.length) {
          r.push(c);
          if (r.some((v) => v.trim())) a.push(r);
        }
        return a;
      }
      function dataTable(data) {
        if (!Array.isArray(data) || !data.length) throw Error("행이 하나 이상이어야 합니다.");
        if (Array.isArray(data[0]))
          return data.map((row) => (Array.isArray(row) ? row.map((value) => value ?? "") : []));
        if (typeof data[0] === "object" && data[0] !== null) {
          let headers = [...new Set(data.flatMap((row) => Object.keys(row || {})))];
          return [headers, ...data.map((row) => headers.map((header) => row?.[header] ?? ""))];
        }
        throw Error("CSV 행 배열 또는 객체 배열이어야 합니다.");
      }
      function getProjectCsv(id, collection = activeProject.csvFiles) {
        return collection.find((csv) => csv.id === id) || null;
      }
      function getProjectImage(id, collection = activeProject.images) {
        return collection.find((image) => image.id === id) || null;
      }
      function slotImage(slot, collection = activeProject.images) {
        return getProjectImage(slot?.imageId, collection);
      }
      function projectImageDataUrl(image) {
        return image
          ? `data:${image.mime || "application/octet-stream"};base64,${image.bytesBase64 || ""}`
          : "";
      }
      const projectImageDisplayUrls = new Map();
      function projectImageDisplayUrl(image) {
        if (!image) return "";
        let cached = projectImageDisplayUrls.get(image);
        if (cached) return cached;
        let url = URL.createObjectURL(
          new Blob([ffpxBase64ToBytes(image.bytesBase64 || "")], {
            type: image.mime || "application/octet-stream",
          }),
        );
        projectImageDisplayUrls.set(image, url);
        return url;
      }
      function releaseProjectImageDisplayUrl(image) {
        let url = image && projectImageDisplayUrls.get(image);
        if (!url) return;
        URL.revokeObjectURL(url);
        projectImageDisplayUrls.delete(image);
      }
      function releaseProjectImageDisplayUrls(collection) {
        (Array.isArray(collection) ? collection : []).forEach(releaseProjectImageDisplayUrl);
      }
      function buildProjectImageModel(bytes, name, mime, id) {
        let model = {
          id,
          name: projectCsvName(name, "image.bin"),
          directory: PROJECT_ASSET_DIRECTORIES.image,
          mime: typeof mime === "string" && mime ? mime : "application/octet-stream",
          bytesBase64:
            typeof bytes === "string" ? bytes : ffpxBytesToBase64(bytes || new Uint8Array()),
        };
        projectVfs.assignUniqueLocation(model, PROJECT_ASSET_DIRECTORIES.image);
        if (!model.bytesBase64) throw Error("이미지 데이터가 비어 있습니다.");
        return model;
      }
      function createProjectImage(bytes, name, mime, id = null, path = null) {
        let model = buildProjectImageModel(
          bytes,
          name,
          mime,
          Number.isInteger(id) && id > 0 ? id : activeProject.imageId,
        );
        if (path) projectVfs.assignLocation(model, path);
        appFSM.send("IMAGE_OBJECT_CREATED", {
          model,
          imageId: model.id,
          direction: "fsm-to-model",
        });
        return model;
      }
      function projectCsvName(value, fallback = "data.csv") {
        let name = String(value || "")
          .split(/[\\/]/)
          .pop()
          .trim()
          .replace(/[\x00-\x1F:*?"<>|]/g, "-")
          .replace(/\.{2,}/g, "-")
          .replace(/[. ]+$/, "")
          .slice(0, 180);
        return name || fallback;
      }
      function buildProjectCsvModel(
        data,
        name,
        id,
        bytesBase64 = "",
        mime = "text/csv",
        headerLines = 1,
        state = activeProject._state,
      ) {
        let model = {
          id,
          name: projectCsvName(name),
          directory: PROJECT_ASSET_DIRECTORIES.csv,
          rows: projectClone(dataTable(data)),
          bytesBase64:
            typeof bytesBase64 === "string" && bytesBase64
              ? bytesBase64
              : ffpxBytesToBase64(
                  new TextEncoder().encode(ffpxCsv(dataTable(data))),
                ),
          mime: typeof mime === "string" && mime ? mime : "text/csv",
          headerLines: headerLineCount(headerLines, data),
        };
        projectVfs.assignUniqueLocation(model, PROJECT_ASSET_DIRECTORIES.csv, state);
        return model;
      }
      function createProjectCsv(
        data,
        name,
        id = null,
        bytesBase64 = "",
        mime = "text/csv",
        headerLines = 1,
        path = null,
      ) {
        let model = buildProjectCsvModel(
          data,
          name,
          Number.isInteger(id) && id > 0 ? id : activeProject.csvId,
          bytesBase64,
          mime,
          headerLines,
        );
        if (path) projectVfs.assignLocation(model, path);
        appFSM.send("DATA_OBJECT_CREATED", {
          model,
          csvId: model.id,
          direction: "fsm-to-model",
        });
        return model;
      }
      function requireProjectCsv(chart, label = "차트", collection = activeProject.csvFiles) {
        let csv = getProjectCsv(
          chart?.editor?.objects?.[0]?.csvId ?? chart?.csvId,
          collection,
        );
        if (!csv) throw Error(`${label}가 참조하는 프로젝트 CSV가 없습니다.`);
        return csv;
      }



      function chartCsvIds(chart) {
        return [
          ...new Set(
            (chart?.editor?.objects || [])
              .map((object) => object.csvId)
              .filter((id) => Number.isInteger(id)),
          ),
        ];
      }
      const PROJECT_ASSET_DIRECTORIES = Object.freeze({
        csv: "/assets/csv",
        image: "/assets/images",
      });
      const PROJECT_TRASH_DIRECTORY = "/assets/trash";
      const PROJECT_FIXED_DIRECTORIES = Object.freeze([
        "/assets",
        PROJECT_ASSET_DIRECTORIES.csv,
        PROJECT_ASSET_DIRECTORIES.image,
        PROJECT_TRASH_DIRECTORY,
      ]);
      function projectPathInDirectory(path, directory) {
        let normalized = normalizeProjectPath(path, { directory: true }),
          parent = normalizeProjectPath(directory, { directory: true });
        return normalized === parent || normalized.startsWith(`${parent}/`);
      }
      function normalizeProjectPath(value, { directory = false } = {}) {
        let raw = String(value || "").replace(/\\/g, "/").trim(),
          segments = raw.split("/").filter(Boolean);
        if (segments.some((segment) => segment === "." || segment === ".."))
          throw Error("프로젝트 경로에는 . 또는 .. 구간을 사용할 수 없습니다.");
        segments = segments.map((segment) => {
          let clean = projectCsvName(segment, "");
          if (!clean) throw Error("프로젝트 경로 이름이 올바르지 않습니다.");
          return clean;
        });
        let path = `/${segments.join("/")}`;
        if (path === "/" && !directory) throw Error("루트는 파일 경로가 될 수 없습니다.");
        return path;
      }
      function projectParentPath(path) {
        let normalized = normalizeProjectPath(path, { directory: true }),
          index = normalized.lastIndexOf("/");
        return index <= 0 ? "/" : normalized.slice(0, index);
      }
      function projectPathName(path) {
        return normalizeProjectPath(path, { directory: true }).split("/").filter(Boolean).pop() || "/";
      }
      function projectAssetPath(asset) {
        if (!asset || typeof asset !== "object") throw Error("프로젝트 자산이 올바르지 않습니다.");
        if (typeof asset.directory !== "string" || typeof asset.name !== "string")
          throw Error("프로젝트 자산 위치가 올바르지 않습니다.");
        let directory = normalizeProjectPath(asset.directory, { directory: true }),
          name = projectCsvName(asset.name, "");
        if (!name || name !== asset.name) throw Error("프로젝트 자산 이름이 올바르지 않습니다.");
        return normalizeProjectPath(`${directory}/${name}`);
      }
      const projectVfs = Object.freeze({
        exists(path, state = activeProject._state) {
          let target = normalizeProjectPath(path, { directory: true });
          return (
            (state.fileSystem?.directories || []).includes(target) ||
            [...(state.assets?.csvFiles || []), ...(state.assets?.images || [])].some(
              (asset) => projectAssetPath(asset) === target,
            )
          );
        },
        uniquePath(directory, name, state = activeProject._state, reservedPaths = null) {
          let parent = normalizeProjectPath(directory, { directory: true }),
            safeName = projectCsvName(name, "asset"),
            dot = safeName.lastIndexOf("."),
            stem = dot > 0 ? safeName.slice(0, dot) : safeName,
            extension = dot > 0 ? safeName.slice(dot) : "",
            candidate = normalizeProjectPath(`${parent}/${safeName}`),
            suffix = 2;
          while (this.exists(candidate, state) || reservedPaths?.has(candidate))
            candidate = normalizeProjectPath(`${parent}/${stem} (${suffix++})${extension}`);
          return candidate;
        },
        ensure(state) {
          let directories = new Set(PROJECT_FIXED_DIRECTORIES),
            sourceDirectories = Array.isArray(state.fileSystem?.directories)
              ? state.fileSystem.directories
              : [];
          sourceDirectories.forEach((path) => {
            let normalized = normalizeProjectPath(path, { directory: true });
            if (normalized !== "/") {
              let current = normalized;
              while (current !== "/") {
                directories.add(current);
                current = projectParentPath(current);
              }
            }
          });
          state.fileSystem = { directories: [...directories].sort() };
          let occupied = new Set(state.fileSystem.directories);
          for (let [kind, assets] of [
            ["csv", state.assets.csvFiles],
            ["image", state.assets.images],
          ]) {
            for (let asset of assets) {
              let directory = normalizeProjectPath(asset.directory, { directory: true }),
                fullPath = projectAssetPath(asset);
              if (occupied.has(fullPath)) throw Error(`프로젝트 자산 경로 ${fullPath}가 중복되었습니다.`);
              occupied.add(fullPath);
              while (directory !== "/") {
                directories.add(directory);
                directory = projectParentPath(directory);
              }
            }
          }
          state.fileSystem.directories = [...directories].sort();
          return state.fileSystem;
        },
        resolve(path, state = activeProject._state) {
          let normalized = normalizeProjectPath(path, { directory: true });
          if ((state.fileSystem?.directories || []).includes(normalized))
            return { kind: "directory", path: normalized };
          for (let [kind, assets] of [
            ["csv", state.assets.csvFiles],
            ["image", state.assets.images],
          ]) {
            let asset = assets.find((item) => projectAssetPath(item) === normalized);
            if (asset) return { kind, asset };
          }
          return null;
        },
        isFixedDirectory(path) {
          let normalized = normalizeProjectPath(path, { directory: true });
          return PROJECT_FIXED_DIRECTORIES.includes(normalized);
        },
        isTrashed(path) {
          return projectPathInDirectory(path, PROJECT_TRASH_DIRECTORY);
        },
        descendants(path, state = activeProject._state) {
          let root = normalizeProjectPath(path, { directory: true }),
            prefix = `${root}/`;
          return [
            ...(state.assets?.csvFiles || []).map((asset) => ({ kind: "csv", asset })),
            ...(state.assets?.images || []).map((asset) => ({ kind: "image", asset })),
          ].filter(({ asset }) => {
            let path = projectAssetPath(asset);
            return path === root || path.startsWith(prefix);
          });
        },
        assignLocation(model, path) {
          let fullPath = normalizeProjectPath(path);
          model.directory = projectParentPath(fullPath);
          model.name = projectPathName(fullPath);
          return model;
        },
        assignUniqueLocation(model, directory, state = activeProject._state, reservedPaths = null) {
          return this.assignLocation(
            model,
            this.uniquePath(directory, model?.name, state, reservedPaths),
          );
        },
        prepare(model, kind, state = activeProject._state) {
          this.ensure(state);
          let directory = normalizeProjectPath(
              model?.directory || PROJECT_ASSET_DIRECTORIES[kind],
              { directory: true },
            ),
            preferred = projectAssetPath({ ...model, directory });
          if (this.exists(preferred, state)) {
            this.assignUniqueLocation(model, directory, state);
            directory = model.directory;
          } else model.directory = directory;
          let parent = directory;
          while (parent !== "/") {
            if (!state.fileSystem.directories.includes(parent)) state.fileSystem.directories.push(parent);
            parent = projectParentPath(parent);
          }
          state.fileSystem.directories.sort();
          return model;
        },
      });
      function projectAssetImportCollisionModel(file,directory,reservedPaths=null) {
        let kind=slotFileKind(file),
          assetKind=kind==="data"?"csv":kind==="image"?"image":null;
        if(!assetKind)throw Error(`${file?.name||"파일"}: 지원하지 않는 파일 형식입니다.`);
        let parent=normalizeProjectPath(directory,{directory:true}),
          name=projectCsvName(file.name,assetKind==="csv"?"data.csv":"image.bin"),
          path=normalizeProjectPath(`${parent}/${name}`),
          collision=projectVfs.resolve(path),reserved=reservedPaths?.has(path)===true,
          replaceId=collision?.kind===assetKind?collision.asset.id:null,
          mode=!collision&&!reserved?"available":Number.isInteger(replaceId)?"replace-or-rename":"rename-only",
          message=mode==="replace-or-rename"
            ?`${path}에 같은 이름의 파일이 이미 있습니다.\n\n[확인] 기존 파일을 교체하고 참조를 유지합니다.\n[취소] 이름을 바꿔 새 파일로 추가합니다.`:"",
          notice=collision&&mode==="rename-only"
            ?`${path}의 기존 항목은 종류가 달라 참조를 유지한 채 교체할 수 없습니다. 이름을 바꿔 추가합니다.`:"";
        return Object.freeze({assetKind,parent,name,path,mode,replaceId,message,notice});
      }
      function resolveProjectAssetImportPlan(model, choice = "rename", reservedPaths = null) {
        if (!model || typeof model !== "object")
          throw Error("프로젝트 자산 가져오기 계획이 올바르지 않습니다.");
        if (model.mode === "available")
          return { path: model.path, replaceId: null };
        if (choice === "replace" && Number.isInteger(model.replaceId))
          return { path: model.path, replaceId: model.replaceId };
        let unique = projectVfs.uniquePath(
          model.parent,
          model.name,
          activeProject._state,
          reservedPaths,
        );
        return {
          path: unique,
          replaceId: null,
        };
      }
      async function importProjectFilesToDirectory(
        files,
        directory,
        planImport,
      ) {
        if (typeof planImport !== "function")
          throw Error("프로젝트 자산 가져오기 계획이 없습니다.");
        let targetDirectory = normalizeProjectPath(directory, { directory: true }),
          list = Array.from(files || []);
        if (!activeProject.fileSystem.directories.includes(targetDirectory))
          throw Error("대상 폴더가 없습니다.");
        if (projectVfs.isTrashed(targetDirectory))
          throw Error("외부 파일은 휴지통으로 직접 가져올 수 없습니다.");
        let reserved = new Set([
            ...activeProject.fileSystem.directories,
            ...activeProject.csvFiles.map(projectAssetPath),
            ...activeProject.images.map(projectAssetPath),
          ]),
          staged = [];
        for (let file of list) {
          let kind = slotFileKind(file);
          if (kind !== "data" && kind !== "image")
            throw Error(`${file.name}: 폴더에는 CSV/TSV/JSON 또는 이미지만 가져올 수 있습니다.`);
          let plan = await planImport(file, targetDirectory, reserved);
          reserved.add(plan.path);
          staged.push({ file, kind, ...plan });
        }
        let csvIds = new Set(activeProject.csvFiles.map((asset) => asset.id)),
          imageIds = new Set(activeProject.images.map((asset) => asset.id)),
          replacedCsv = new Map(
            staged
              .filter((item) => item.kind === "data" && Number.isInteger(item.replaceId))
              .map((item) => [item.replaceId, projectClone(getProjectCsv(item.replaceId))]),
          ),
          replacedImages = new Map(
            staged
              .filter((item) => item.kind === "image" && Number.isInteger(item.replaceId))
              .map((item) => [item.replaceId, projectClone(getProjectImage(item.replaceId))]),
          );
        try {
          await appFSM.run("importing", "ASSET_TREE_DROP", async () => {
            for (let item of staged) {
              if (item.kind === "data")
                await loadDataFile(item.file, null, {
                  assetPath: item.path,
                  replaceAssetId: item.replaceId,
                });
              else
                await loadImageFile(item.file, null, {
                  assetPath: item.path,
                  replaceAssetId: item.replaceId,
                });
            }
          });
        } catch (error) {
          activeProject.csvFiles
            .filter((asset) => !csvIds.has(asset.id))
            .forEach((asset) =>
              appFSM.send("DATA_OBJECT_DELETED", {
                csvId: asset.id,
                direction: "fsm-to-model",
              }),
            );
          activeProject.images
            .filter((asset) => !imageIds.has(asset.id))
            .forEach((asset) =>
              appFSM.send("IMAGE_OBJECT_DELETED", {
                imageId: asset.id,
                direction: "fsm-to-model",
              }),
            );
          replacedCsv.forEach((model) =>
            appFSM.send("DATA_OBJECT_REPLACED", { model, direction: "fsm-to-model" }),
          );
          replacedImages.forEach((model) =>
            appFSM.send("IMAGE_OBJECT_REPLACED", { model, direction: "fsm-to-model" }),
          );
          throw error;
        }
      }
      function projectDataTreeSnapshot(objects = {}) {
        return {
          directories: Array.isArray(objects.files?.directories)
            ? [...objects.files.directories]
            : [...PROJECT_FIXED_DIRECTORIES],
          data: (Array.isArray(objects.data) ? objects.data : []).map((csv) => ({
            id: csv.id,
            name: csv.name,
            path: projectAssetPath(csv),
            readable: Array.isArray(csv.rows),
            rowCount: Array.isArray(csv.rows)
              ? Math.max(0, csv.rows.length - (Number(csv.headerLines) || 0))
              : 0,
          })),
          images: (Array.isArray(objects.images) ? objects.images : []).map((image) => ({
            id: image.id,
            name: image.name,
            path: projectAssetPath(image),
          })),
          charts: (Array.isArray(objects.charts) ? objects.charts : []).map((chart) => ({
            id: chart.id,
            editable: chart.editor?.editable !== false,
            csvIds: chartCsvIds(chart),
            csvReferences: (chart.editor?.objects || [])
              .map((object) => object.csvId)
              .filter((id) => Number.isInteger(id)),
          })),
          slots: (Array.isArray(objects.slots) ? objects.slots : []).map((slot) => ({
            id: slot.id,
            row: slot.row,
            col: slot.col,
            hidden: slot.hidden === true,
            contentType: slot.contentType,
            chart: slot.chart,
            imageId: slot.imageId,
          })),
        };
      }
      function projectDataTreeObjects() {
        return {
          files: projectObjects.read("files"),
          data: projectObjects.read("data"),
          images: projectObjects.read("images"),
          charts: projectObjects.read("charts"),
          slots: projectObjects.read("slots"),
        };
      }
      function connectProjectAssetToSlot(path, kind, slot) {
        let match = projectVfs.resolve(path);
        if (!match || match.kind !== kind || match.kind === "directory")
          throw Error("드래그한 프로젝트 파일이 없습니다.");
        if (projectVfs.isTrashed(projectAssetPath(match.asset)))
          throw Error("휴지통의 파일은 슬롯에 연결할 수 없습니다.");
        if (!slot || slot.hidden) throw Error("연결할 슬롯이 없습니다.");
        if (match.kind === "csv")
          appFSM.send("SLOT_DATA_CONNECTED", {
            slotId: slot.id,
            csvId: match.asset.id,
            replaceSlotContent: slot.contentType === "image",
            direction: "fsm-to-model",
          });
        else
          appFSM.send("SLOT_IMAGE_IMPORTED", {
            slotId: slot.id,
            imageId: match.asset.id,
            direction: "fsm-to-model",
          });
        setSelectedSlot(slot.id, "model-to-fsm");
        renderDashboard();
        status("프로젝트 파일을 슬롯에 연결했습니다.");
      }
      function headerLineCount(value, table = []) {
        let count = Math.max(0, Math.trunc(Number(value) || 0));
        return Math.min(count, Array.isArray(table) ? table.length : 0);
      }
      function columnIndex(column) {
        let match = /^C([1-9]\d*)$/.exec(String(column || ""));
        return match ? Number(match[1]) - 1 : -1;
      }
      function columnDefinitions(table = [], headerLines = 1) {
        let width = (table || []).reduce(
            (max, row) => Math.max(max, Array.isArray(row) ? row.length : 0),
            0,
          ),
          count = headerLineCount(headerLines, table),
          header = count > 0 && Array.isArray(table[count - 1]) ? table[count - 1] : [];
        return Array.from({ length: width }, (_, index) => {
          let id = `C${index + 1}`,
            name = String(header[index] ?? "").trim();
          return { id, index, name, label: name ? `${id} — ${name}` : id };
        });
      }
      function dataRows(table = [], headerLines = 1) {
        return (table || []).slice(headerLineCount(headerLines, table));
      }
      function esc(v) {
        return String(v).replace(
          /[&<>'"]/g,
          (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[c],
        );
      }
      function value(v) {
        let n = Number(v);
        return v !== "" && Number.isFinite(n) ? n : v;
      }
      function graphDataSelection(matrix, headerLines, editor = {}) {
        let definitions = columnDefinitions(matrix, headerLines),
          body = dataRows(matrix, headerLines),
          numeric = definitions.filter((column) =>
            body.some(
              (row) => row?.[column.index] !== "" && Number.isFinite(Number(row?.[column.index])),
            ),
          ),
          valid = (id) => definitions.some((column) => column.id === id),
          x = valid(editor.x) ? editor.x : numeric[0]?.id || definitions[0]?.id || "",
          y = valid(editor.y)
            ? editor.y
            : numeric.find((column) => column.id !== x)?.id ||
              definitions.find((column) => column.id !== x)?.id ||
              definitions[0]?.id ||
              "";
        return { x, y };
      }
      function defaultChartEditor(slot, matrix, headerLines) {
        let selection = graphDataSelection(matrix, headerLines);
        return {
          objects: [],
          editable: true,
          globalSettings: {
            showLegend: true,
            showTitle: true,
            showZeroLine: false,
            graphFontFamily: "",
            titleFontSize: "",
            legendFontSize: "",
            axes: currentAxes({}),
          },
          colors: [...DEFAULT_COLORS],
          x: selection.x,
          y: selection.y,
          xAxisSide: "bottom",
          yAxisSide: "left",
          legendName: "",
          type: "scatter",
          lineWidth: 2,
          lineDash: "solid",
          markerSymbol: "circle",
          markerSize: 6,
          barOpacity: 1,
          barLineWidth: 0,
          xDivide: 1,
          yDivide: 1,
          title: selection.y,
        };
      }
      function connectDataToSlotModel(slot, data, sourceName, projectCsv = null) {
        let matrix = dataTable(data),
          chart = slot.chart ? getChart(slot.chart) : null,
          csv = projectCsv || createProjectCsv(matrix, sourceName),
          headerLines = headerLineCount(csv.headerLines, matrix);
        if (chart) {
          let selection = graphDataSelection(matrix, headerLines, chart.editor);
          chart.editor.x = selection.x;
          chart.editor.y = selection.y;
          chart.editor.objects = [...ensureGraphObjects(chart), baseGraphObject(chart, csv)];
          if (chart.editor.editable !== false) rebuildEditableGraph(chart);
        } else {
          chart = createChartModel({
            id: activeProject.chartId++,
            editor: defaultChartEditor(slot, matrix, headerLines),
          });
          chart.editor.objects = [baseGraphObject(chart, csv)];
          rebuildEditableGraph(chart);
          activeProject.charts.push(chart);
          slot.chart = chart.id;
        }
        return chart;
      }
      function connectDataToSlot(
        slot,
        data,
        sourceName,
        projectCsv = null,
        { replaceSlotContent = false } = {},
      ) {
        let csv = projectCsv || createProjectCsv(data, sourceName),
          payload = {
            slotId: slot.id,
            csvId: csv.id,
            replaceSlotContent,
            direction: "fsm-to-model",
          };
        appFSM.send("SLOT_DATA_CONNECTED", payload);
        if (!payload.chart) throw Error("슬롯 그래프 오브젝트를 만들지 못했습니다.");
        activateChartModel(payload.chart.id);
        renderDashboard();
        return payload.chart;
      }
      function tracesSingle(c) {
        let b = {},
          colors = c.colors?.length ? c.colors : DEFAULT_COLORS,
          i = 0,
          xDivide = Number(c.xDivide) || 1,
          yDivide = Number(c.yDivide) || 1,
          xIndex = columnIndex(c.x),
          yIndex = columnIndex(c.y);
        if (xIndex < 0 || yIndex < 0) return [];
        dataRows(c.rows || [], c.headerLines ?? 1).forEach((r) => {
          let x = value(r?.[xIndex]),
            y = Number(r?.[yIndex]);
          if (x === "" || x === undefined || !Number.isFinite(y)) return;
          if (typeof x === "number") x /= xDivide;
          y /= yDivide;
          if (c.xScaleType === "reciprocal") {
            x = Number(x);
            if (!Number.isFinite(x) || x === 0) return;
            x = 1 / x;
          } else if (c.xScaleType === "log" && (!Number.isFinite(Number(x)) || Number(x) <= 0))
            return;
          if (c.yScaleType === "reciprocal") {
            if (y === 0) return;
            y = 1 / y;
          } else if (c.yScaleType === "log" && y <= 0) return;
          if (!Number.isFinite(y)) return;
          let g = "";
          (b[g] ??= []).push({ x, y });
        });
        return Object.entries(b).map(([g, p]) => {
          let color = colors[i++ % colors.length],
            isBar = c.type === "bar";
          return {
            x: p.map((v) => v.x),
            y: p.map((v) => v.y),
            name: c.y,
            type: isBar ? "bar" : "scatter",
            mode: isBar ? undefined : c.type === "hidden" ? "lines" : c.type,
            visible: c.type === "hidden" ? false : true,
            opacity: isBar ? Math.max(0.05, Math.min(1, Number(c.barOpacity) || 1)) : undefined,
            line: {
              color,
              width: isBar
                ? Math.max(0, Math.min(10, Number(c.barLineWidth) || 0))
                : Math.max(0.1, Math.min(20, Number(c.lineWidth) || 2)),
              dash: isBar ? undefined : c.lineDash || "solid",
            },
            marker: {
              color,
              symbol: c.markerSymbol || "circle",
              size: Math.max(1, Math.min(40, Number(c.markerSize) || 6)),
              line: isBar
                ? { color, width: Math.max(0, Math.min(10, Number(c.barLineWidth) || 0)) }
                : undefined,
            },
          };
        });
      }
      function traces(c) {
        let settings = normalizeGlobalSettings(c),
          editor = c.editor,
          axes = settings.axes,
          objectList =
            Array.isArray(editor.objects) ? editor.objects : [],
          result = [];
        objectList.forEach((object, index) => {
          let xSide = object.xAxisSide || editor.xAxisSide || "bottom",
            ySide = object.yAxisSide || editor.yAxisSide || "left",
            xAxis = axes[axisKey("x", xSide)],
            yAxis = axes[axisKey("y", ySide)],
            axisRefs = {
              xaxis: xSide === "top" ? "x2" : "x",
              yaxis: ySide === "right" ? "y2" : "y",
            };
          result.push(
            ...tracesSingle({
              ...editor,
              ...object,
              rows: requireProjectCsv(
                { editor: { objects: [object] } },
                `그래프 객체 ${index + 1}`,
              ).rows,
              headerLines: requireProjectCsv(
                { editor: { objects: [object] } },
                `그래프 객체 ${index + 1}`,
              ).headerLines,
              xDivide: Number(xAxis.divide) || 1,
              yDivide: Number(yAxis.divide) || 1,
              xScaleType: xAxis.scaleType,
              yScaleType: yAxis.scaleType,
              colors: [object.color || DEFAULT_COLORS[index % DEFAULT_COLORS.length]],
            }).map((trace) => {
              let extension =
                object.plotlyTrace &&
                typeof object.plotlyTrace === "object" &&
                !Array.isArray(object.plotlyTrace)
                  ? projectClone(object.plotlyTrace)
                  : {};
              return {
                ...extension,
                ...trace,
                line: { ...(extension.line || {}), ...(trace.line || {}) },
                marker: { ...(extension.marker || {}), ...(trace.marker || {}) },
                name: object.legendName || trace.name,
                ...axisRefs,
              };
            }),
          );
        });
        let placeholder = (xaxis, yaxis) => ({
            x: [],
            y: [],
            type: "scatter",
            mode: "markers",
            xaxis,
            yaxis,
            showlegend: false,
            hoverinfo: "skip",
            visible: true,
            marker: { size: 0, opacity: 0 },
            line: { width: 0 },
            name: "",
            meta: { fastFigureAxisPlaceholder: true },
          }),
          xRefs = [],
          yRefs = [];
        if (axes.xBottom.visible === true) xRefs.push("x");
        if (axes.xTop.visible === true) xRefs.push("x2");
        if (axes.yLeft.visible === true) yRefs.push("y");
        if (axes.yRight.visible === true) yRefs.push("y2");
        if (!xRefs.length) xRefs.push("x");
        if (!yRefs.length) yRefs.push("y");
        xRefs.forEach((xaxis) => yRefs.forEach((yaxis) => result.push(placeholder(xaxis, yaxis))));
        return result;
      }
      function layout(c) {
        let bg = activeProject.appearance.uiPalette.paperColor,
          ink = activeProject.appearance.uiPalette.fontColor,
          editor = c.editor,
          settings = normalizeGlobalSettings(c),
          numberOrEmpty = (v) =>
            v === "" || v === undefined || v === null ? undefined : Number(v),
          axis = (title, key) => {
            let setting = settings.axes[key],
              min = numberOrEmpty(setting.min),
              max = numberOrEmpty(setting.max),
              tick = numberOrEmpty(setting.tick),
              notation = setting.notation || "none",
              scaleType = setting.scaleType || "linear";
            return {
              type: scaleType === "log" ? "log" : "linear",
              title: {
                text: setting.visible === true ? setting.title || "" : "",
                font: { size: Number(setting.titleSize) || 14 },
              },
              visible: true,
              showgrid: setting.visible === true && setting.showGrid !== false,
              showticklabels: setting.visible === true && setting.showValues !== false,
              ticks: setting.visible === true ? "outside" : "",
              gridcolor: "#E5E7EB",
              zeroline: setting.visible === true && settings.showZeroLine === true,
              zerolinecolor: "#CBD5E1",
              showline: setting.visible === true,
              linewidth: Number(setting.lineWidth) || 0,
              range:
                Number.isFinite(min) && Number.isFinite(max)
                  ? scaleType === "log"
                    ? min > 0 && max > 0
                      ? [Math.log10(min), Math.log10(max)]
                      : undefined
                    : [min, max]
                  : undefined,
              dtick:
                scaleType === "log"
                  ? 1
                  : Number.isFinite(tick) && tick > 0
                    ? tick
                    : undefined,
              minor:
                scaleType === "log"
                  ? setting.minorTicks === true
                    ? {
                        dtick: "D1",
                        ticks: "outside",
                        showgrid: setting.visible === true && setting.showGrid !== false,
                        gridcolor: "#E5E7EB",
                      }
                    : { ticks: "", showgrid: false }
                  : undefined,
              minorloglabels: scaleType === "log" ? "none" : undefined,
              tickfont: { size: Number(setting.fontSize) || 12 },
              automargin: true,
              exponentformat: notation === "power" ? "power" : notation === "e" ? "e" : "none",
              showexponent: notation === "none" ? "none" : "all",
              tickformat: notation === "e" ? ".3e" : undefined,
            };
          };
        let extension =
            editor.plotlyExtensions?.layout &&
            typeof editor.plotlyExtensions.layout === "object" &&
            !Array.isArray(editor.plotlyExtensions.layout)
              ? editor.plotlyExtensions.layout
              : {},
          known = {
            uirevision: String(c.id),
            title: {
              text: settings.showTitle === false ? "" : editor.title,
              automargin: true,
              font: {
                ...(settings.graphFontFamily ? { family: settings.graphFontFamily } : {}),
                size: Number(settings.titleFontSize) > 0 ? Number(settings.titleFontSize) : 17,
              },
            },
            legend: {
              font: {
                ...(settings.graphFontFamily ? { family: settings.graphFontFamily } : {}),
                size: Number(settings.legendFontSize) > 0 ? Number(settings.legendFontSize) : 12,
              },
            },
            xaxis: axis(editor.x, "xBottom"),
            xaxis2: { ...axis(editor.x, "xTop"), overlaying: "x", side: "top" },
            yaxis: axis(editor.y, "yLeft"),
            yaxis2: { ...axis(editor.y, "yRight"), overlaying: "y", side: "right" },
            paper_bgcolor: bg,
            plot_bgcolor: bg,
            font: {
              color: ink,
              ...(settings.graphFontFamily ? { family: settings.graphFontFamily } : {}),
            },
            margin: { l: 58, r: 58, t: 42, b: 50 },
            showlegend: settings.showLegend !== false,
          };
        return {
          ...extension,
          ...known,
          title: {
            ...(extension.title || {}),
            ...known.title,
            font: { ...(extension.title?.font || {}), ...(known.title.font || {}) },
          },
          legend: {
            ...(extension.legend || {}),
            ...known.legend,
            font: { ...(extension.legend?.font || {}), ...(known.legend.font || {}) },
          },
          xaxis: { ...(extension.xaxis || {}), ...known.xaxis },
          xaxis2: { ...(extension.xaxis2 || {}), ...known.xaxis2 },
          yaxis: { ...(extension.yaxis || {}), ...known.yaxis },
          yaxis2: { ...(extension.yaxis2 || {}), ...known.yaxis2 },
          font: { ...(extension.font || {}), ...known.font },
          margin: { ...(extension.margin || {}), ...known.margin },
        };
      }
      function getChart(id) {
        return activeProject.charts.find((chart) => chart.id === id);
      }
      function slotAt(id) {
        return activeProject.slots.find((s) => s.id === id);
      }
      function resizePlots() {
        document.querySelectorAll(".plot-item").forEach((el) => {
          try {
            Plotly.Plots.resize(el);
          } catch (_) {}
        });
      }
      function schedulePlotResize() {
        if (resizePending) return;
        resizePending = true;
        requestAnimationFrame(() => {
          resizePending = false;
          resizePlots();
        });
      }
      function syncDashboardZoomDisplay() {
        let dashboard = $("dashboard"),
          dashboardWidth = dashboard?.getBoundingClientRect().width || 0;
        if (!dashboardWidth) return;
        return dashboardZoomLocked
          ? Math.max(
              50,
              Math.min(200, Math.round((dashboardWidth / dashboardReferenceWidth()) * 100)),
            )
          : Math.round(dashboardZoomIntent);
      }
      function installResizeObserver() {
        if (dashboardObserver) return;
        let target = $("dashboard"),
          area = $("graphArea"),
          handleResize = () => {
            applyDashboardZoom(false);
            syncDashboardZoomDisplay();
            schedulePlotResize();
          };
        if (window.ResizeObserver) {
          dashboardObserver = new ResizeObserver(() => {
            applyReferenceGeometry(target);
            syncDashboardZoomDisplay();
            schedulePlotResize();
          });
          dashboardObserver.observe(target);
          graphAreaObserver = new ResizeObserver(handleResize);
          if (area) graphAreaObserver.observe(area);
        } else window.addEventListener("resize", handleResize);
      }
      function isSlotSelected(slot) {
        return !!slot && slot.id === selectedSlotId;
      }
      function getSelectedSlot() {
        let slot = selectedSlotId === null ? null : slotAt(selectedSlotId);
        return slot && !slot.hidden ? slot : null;
      }
      function normalizeImageSettings(slot) {
        if (!slot) return null;
        normalizeSlotContent(slot);
        slot.content.imageSettings = readImageSettings(slot.content.imageSettings);
        return slot.content.imageSettings;
      }
      function readImageSettings(settings) {
        let source = settings && typeof settings === "object" && !Array.isArray(settings)
            ? settings
            : {},
          fit = ["contain", "cover", "manual"].includes(source.fit) ? source.fit : "contain",
          number = (value, fallback, min, max) =>
            Math.max(min, Math.min(max, Number.isFinite(Number(value)) ? Number(value) : fallback));
        return {
          fit,
          scale: number(source.scale, 100, 1, 1000),
          x: number(source.x, 50, -100, 200),
          y: number(source.y, 50, -100, 200),
        };
      }
      function updateFileAvailability() {
        let hasSlot = !!getSelectedSlot();
        if (hasSlot && appFSM.state.overlay === "readme")
          appFSM.send("CLOSE_OVERLAY", { reason: "slot-selected" });
      }
      function updateGraphView() {
        debugLog("updateGraphView", { selectedSlotId });
        renderDashboard();
      }
      function swapSlotContents(source, target) {
        if (!source || !target || source === target || source.hidden || target.hidden) return false;
        appFSM.send("SLOTS_SWAPPED", {
          sourceSlotId: source.id,
          targetSlotId: target.id,
        });
        return true;
      }
      function clearSlotDragState() {
        slotDragSourceId = null;
        document
          .querySelectorAll("#dashboard .slot.drag-over")
          .forEach((slot) => slot.classList.remove("drag-over"));
      }
      function installSlotClickController() {
        let dashboard = $("dashboard");
        if (dashboard.dataset.clickController) return;
        dashboard.dataset.clickController = "true";
        dashboard.addEventListener(
          "click",
          (e) => {
            let el = e.target.closest?.(".slot");
            if (!el) {
              debugLog("slotClick:dashboard-background", {
                target: e.target.className?.baseVal || e.target.className || e.target.tagName,
                wasSelected: selectedSlotId !== null,
              });
              if (selectedSlotId !== null) setSelectedSlot(null);
              return;
            }
            let slot = slotAt(+el.dataset.slot),
              tab = !!e.target.closest?.(".slot-tab");
            if (!slot) return;
            if (tab && slotDragSuppressClick) {
              e.preventDefault();
              e.stopPropagation();
              return;
            }
            debugLog("slotClick", {
              slotId: slot.id,
              hasChart: !!slot.chart,
              tab,
              wasSelected: isSlotSelected(slot),
              target: e.target.className?.baseVal || e.target.className || e.target.tagName,
            });
            if (tab || !slot.chart || !isSlotSelected(slot)) {
              e.preventDefault();
              e.stopPropagation();
              setSelectedSlot(slot.id);
            } else debugLog("slotClick:plotly-pass-through", { slotId: slot.id });
          },
          true,
        );
        dashboard.addEventListener("dragstart", (e) => {
          let tab = e.target.closest?.('.slot-tab[draggable="true"]'),
            el = tab?.closest(".slot"),
            slot = el && slotAt(+el.dataset.slot);
          if (!tab || !slot || slot.hidden || (!slot.chart && !slot.imageId)) {
            e.preventDefault();
            return;
          }
          slotDragSourceId = slot.id;
          slotDragSuppressClick = true;
          e.dataTransfer.effectAllowed = "move";
          e.dataTransfer.setData("text/plain", String(slot.id));
          debugLog("slot:drag-start", { slotId: slot.id, row: slot.row, col: slot.col });
        });
        dashboard.addEventListener("dragover", (e) => {
          let el = e.target.closest?.(".slot"),
            target = el && slotAt(+el.dataset.slot);
          if (dataTransferHasFiles(e.dataTransfer)) {
            if (!target || target.hidden) return;
            e.preventDefault();
            e.dataTransfer.dropEffect = "copy";
            dashboard.querySelectorAll(".slot.drag-over").forEach((slot) => {
              if (slot !== el) slot.classList.remove("drag-over");
            });
            el.classList.add("drag-over");
            return;
          }
          let source = slotDragSourceId === null ? null : slotAt(slotDragSourceId);
          if (!source || !target || target.hidden || source === target) return;
          e.preventDefault();
          e.dataTransfer.dropEffect = "move";
          dashboard.querySelectorAll(".slot.drag-over").forEach((slot) => {
            if (slot !== el) slot.classList.remove("drag-over");
          });
          el.classList.add("drag-over");
        });
        dashboard.addEventListener("dragleave", (e) => {
          let el = e.target.closest?.(".slot");
          if (el && !el.contains(e.relatedTarget)) el.classList.remove("drag-over");
        });
        dashboard.addEventListener("drop", (e) => {
          let el = e.target.closest?.(".slot"),
            target = el && slotAt(+el.dataset.slot);
          if (dataTransferHasFiles(e.dataTransfer)) return;
          let source = slotDragSourceId === null ? null : slotAt(slotDragSourceId);
          if (!source || !target || target.hidden || source === target) {
            clearSlotDragState();
            return;
          }
          e.preventDefault();
          e.stopPropagation();
          el.classList.remove("drag-over");
          swapSlotContents(source, target);
          clearSlotDragState();
          setTimeout(() => {
            slotDragSuppressClick = false;
          }, 0);
        });
        dashboard.addEventListener("dragend", () => {
          clearSlotDragState();
          setTimeout(() => {
            slotDragSuppressClick = false;
          }, 0);
        });
      }
      function setSelectedSlot(slotId = null, direction = "fsm-to-model") {
        debugLog("setSelectedSlot:command", {
          slotId,
          previous: selectedSlotId,
          direction,
        });
        appFSM.send("SELECT_SLOT", { slotId, direction });
        updateGraphView();
        requestAnimationFrame(() => window.dispatchEvent(new Event("resize")));
      }
      function alphaIdentifier(index, upper = false) {
        let label = "";
        do {
          label = String.fromCharCode((upper ? 65 : 97) + (index % 26)) + label;
          index = Math.floor(index / 26) - 1;
        } while (index >= 0);
        return label;
      }
      function romanIdentifier(index) {
        let value = index + 1,
          parts = [
            [1000, "M"],
            [900, "CM"],
            [500, "D"],
            [400, "CD"],
            [100, "C"],
            [90, "XC"],
            [50, "L"],
            [40, "XL"],
            [10, "X"],
            [9, "IX"],
            [5, "V"],
            [4, "IV"],
            [1, "I"],
          ],
          result = "";
        for (let [amount, symbol] of parts)
          while (value >= amount) {
            result += symbol;
            value -= amount;
          }
        return result;
      }
      function slotIdentifier(index, project = activeProject) {
        let settings = project.labelSettings;
        if (settings.format === "decimal") return String(index + 1);
        if (settings.format === "lower-roman") return romanIdentifier(index).toLowerCase();
        if (settings.format === "upper-roman") return romanIdentifier(index);
        return alphaIdentifier(index, settings.format === "upper-alpha");
      }
      function displayedSlotIdentifier(index, project = activeProject) {
        let identifier = slotIdentifier(index, project);
        return project.labelSettings.parentheses === true ? `(${identifier})` : identifier;
      }
      function orderedVisibleSlots(project = activeProject) {
        return project.slots
          .filter((slot) => !slot.hidden)
          .sort((a, b) =>
            project.labelSettings.order === "column-major"
              ? a.col - b.col || a.row - b.row
              : a.row - b.row || a.col - b.col,
          );
      }
      function slotLabel(slot, project = activeProject) {
        let index = orderedVisibleSlots(project).findIndex((item) => item.id === slot?.id);
        return slotIdentifier(Math.max(0, index), project);
      }


      function normalizeLegacySlotCaptionDefaults(project = activeProject) {
        orderedVisibleSlots(project).forEach((slot) => {
          if (slot.caption === `${slotLabel(slot, project)} 슬롯 캡션`)
            slot.caption = "슬롯 캡션";
        });
      }

      function slotCaptionSections() {
        let groups = [],
          current = null;
        orderedVisibleSlots().forEach((slot, index) => {
          let text = typeof slot.caption === "string" ? slot.caption : "";
          if (text === "") {
            current = null;
            return;
          }
          if (current && current.end === index - 1 && current.text === text)
            current.end = index;
          else {
            current = { start: index, end: index, text };
            groups.push(current);
          }
        });
        return groups.map((group) => {
          let first = slotIdentifier(group.start),
            last = slotIdentifier(group.end);
          return {
            label: activeProject.labelsEnabled
              ? `(${first}${group.end > group.start ? `-${last}` : ""})`
              : "",
            text: group.text,
          };
        });
      }
      function activeCaptionView(caption=projectObjects.read("captions")) {
        return {
          enabled:caption.enabled,text:caption.text,afterText:caption.afterText,
          sections:[],aggregate:false,label:"",name:caption.name,nameBold:caption.nameBold,
          settings:caption.settings,slot:null,exportText:caption.text,
        };
      }
      function labelStyle() {
        let scale = dashboardGeometry($("dashboard")?.getBoundingClientRect().width).scale;
        return `left:${activeProject.labelSettings.x * scale}px;top:${activeProject.labelSettings.y * scale}px;font-family:${esc(activeProject.labelSettings.fontFamily)};font-size:${activeProject.labelSettings.fontSize * scale}px`;
      }
      function syncDashboardCaption(view = activeCaptionView()) {
        let box = $("dashboardCaption"),
          input = $("captionText"),
          prefix = $("captionPrefix");
        if (!box || !input || !prefix) return;
        box.classList.toggle("hidden", !view.enabled);
        box.classList.toggle("slot-caption-view", !!view.slot);
        let prefixText = view.label || view.name;
        prefix.textContent = prefixText;
        prefix.classList.toggle("hidden", !prefixText);
        prefix.classList.toggle("bold", view.nameBold);
        if (view.aggregate) {
          input.contentEditable = "false";
          let before = input.querySelector('[data-caption-region="before"]'),
            sections = input.querySelector('[data-caption-region="sections"]'),
            after = input.querySelector('[data-caption-region="after"]');
          if (!before || !sections || !after) {
            before = document.createElement("span");
            before.dataset.captionRegion = "before";
            before.className = "caption-edit-region";
            before.contentEditable = "true";
            sections = document.createElement("span");
            sections.dataset.captionRegion = "sections";
            sections.contentEditable = "false";
            after = document.createElement("span");
            after.dataset.captionRegion = "after";
            after.className = "caption-edit-region";
            after.contentEditable = "true";
            input.replaceChildren(before, sections, after);
          }
          if (before.textContent !== view.text) before.textContent = view.text;
          if (after.textContent !== view.afterText) after.textContent = view.afterText;
          let signature = JSON.stringify(view.sections);
          if (sections.dataset.signature !== signature) {
            sections.dataset.signature = signature;
            sections.replaceChildren(
              ...view.sections.map((section) => {
                let wrapper = document.createElement("span");
                wrapper.className = "caption-section";
                if (section.label) {
                  let label = document.createElement("span");
                  label.className = "caption-section-label";
                  label.textContent = section.label;
                  label.contentEditable = "false";
                  wrapper.append(label);
                }
                wrapper.append(document.createTextNode(section.text));
                return wrapper;
              }),
            );
          }
        } else {
          input.contentEditable = "true";
          if (
            input.querySelector("[data-caption-region]") ||
            input.textContent !== view.text
          )
            input.textContent = view.text;
        }
        box.style.fontFamily = view.settings.fontFamily;
        let scale = dashboardGeometry($("dashboard")?.getBoundingClientRect().width).scale;
        box.style.fontSize = `${view.settings.fontSize * scale}px`;
        box.style.lineHeight = view.settings.lineHeight;
      }
      function renderDashboard() {
        let renderGeneration = ++dashboardRenderGeneration;
        debugLog("renderDashboard", {
          selectedSlotId,
          charts: activeProject.charts.length,
          slots: activeProject.slots.filter((s) => !s.hidden).length,
        });
        let d = $("dashboard");
        d.style.setProperty("--grid-cols", activeProject.gridCols);
        d.style.setProperty("--grid-rows", activeProject.gridRows);
        applyDashboardZoom(false);
        d.querySelectorAll(".plot-item").forEach((plot) => {
          try {
            Plotly.purge(plot);
          } catch (error) {
            debugLog("plotly:purge-error", {
              slotId: Number(plot.closest(".slot")?.dataset.slot) || null,
              message: error?.message || String(error),
            }, "warn");
          }
        });
        d.innerHTML = "";
        let visibleSlots = activeProject.slots.filter((s) => !s.hidden),
          orderedSlots = orderedVisibleSlots(),
          labelIndexes = new Map(orderedSlots.map((slot, index) => [slot.id, index]));
        visibleSlots.forEach((s, visibleIndex) => {
          let c = s.chart && getChart(s.chart),
            image = slotImage(s),
            imageSettings = normalizeImageSettings(s),
            el = document.createElement("section");
          el.className =
            "slot" +
            (!c && !image ? " empty" : "") +
            (isSlotSelected(s) ? " selected" : "");
          el.dataset.slot = s.id;
          el.style.gridArea = `${s.row} / ${s.col} / span ${s.rowSpan} / span ${s.colSpan}`;
          el.innerHTML =
            c && s.contentType !== "image"
              ? `<div class="chart-card" title="위쪽 손잡이를 눌러 이 슬롯의 그래프 설정을 엽니다."><div id="plot-${s.id}" class="plot-item"></div></div><button class="slot-tab" type="button" draggable="true" aria-label="그래프 슬롯 이동 및 선택"><span class="slot-tab-shape"></span></button>`
              : image
                ? `<div class="slot-image-frame"><img class="slot-image${imageSettings.fit === "manual" ? " manual" : ""}" src="${esc(projectImageDisplayUrl(image))}" alt="${esc(image.name || "슬롯 이미지")}" style="${imageSettings.fit === "manual" ? `width:${imageSettings.scale}%;left:${imageSettings.x}%;top:${imageSettings.y}%;` : `object-fit:${imageSettings.fit};`}"></div><button class="slot-tab" type="button" draggable="true" aria-label="이미지 슬롯 이동 및 선택"><span class="slot-tab-shape"></span></button>`
                : "";
          if (activeProject.labelsEnabled)
            el.insertAdjacentHTML(
              "beforeend",
              `<span class="slot-label" style="${labelStyle()}" aria-label="슬롯 식별자">${displayedSlotIdentifier(labelIndexes.get(s.id) ?? visibleIndex)}</span>`,
            );
          d.append(el);
          if (c && s.contentType !== "image") {
            Promise.resolve()
              .then(() => {
                let plot = el.querySelector(".plot-item");
                if (
                  renderGeneration !== dashboardRenderGeneration ||
                  !plot?.isConnected ||
                  plot !== document.getElementById(`plot-${s.id}`)
                ) return null;
                let figure = chartFigure(
                  c,
                  dashboardGeometry(d.getBoundingClientRect().width).scale,
                );
                return Promise.resolve(Plotly.react(
                  plot,
                  figure.data,
                  figure.layout,
                  plotlyConfig(c, { ...figure.config, staticPlot: !isSlotSelected(s) }),
                )).then(() => plot);
              })
              .then((plot) => {
                if (
                  !plot?.on ||
                  renderGeneration !== dashboardRenderGeneration ||
                  !plot.isConnected ||
                  plot !== document.getElementById(`plot-${s.id}`)
                ) return;
                let full = plot._fullLayout,
                  axisState = (axis) => ({
                    visible: full?.[axis]?.visible,
                    showline: full?.[axis]?.showline,
                    showticklabels: full?.[axis]?.showticklabels,
                    showgrid: full?.[axis]?.showgrid,
                    zeroline: full?.[axis]?.zeroline,
                    title: full?.[axis]?.title?.text,
                    range: full?.[axis]?.range,
                  });
                debugLog("plotly:axis-layout", {
                  chartId: c.id,
                  xBottom: axisState("xaxis"),
                  xTop: axisState("xaxis2"),
                  yLeft: axisState("yaxis"),
                  yRight: axisState("yaxis2"),
                });
                plot.removeAllListeners?.("plotly_relayout");
                plot.removeAllListeners?.("plotly_doubleclick");
                let syncPlotlyRanges = (event = {}, all = false) =>
                  requestAnimationFrame(() => {
                    if (
                      renderGeneration !== dashboardRenderGeneration ||
                      !plot.isConnected ||
                      plot !== document.getElementById(`plot-${s.id}`)
                    ) return;
                    let settings = normalizeGlobalSettings(c),
                      full = plot._fullLayout,
                      changed = Object.keys(event),
                      copyRange = (plotlyAxis, key) => {
                        let range = full?.[plotlyAxis]?.range;
                        if (!Array.isArray(range) || range.length !== 2) return;
                        let setting = settings.axes[key];
                        setting.min = axisRangeValueFromPlotly(range[0], setting.scaleType);
                        setting.max = axisRangeValueFromPlotly(range[1], setting.scaleType);
                      },
                      axisChanged = (plotlyAxis) =>
                        all ||
                        changed.some(
                          (name) =>
                            name === `${plotlyAxis}.autorange` ||
                            name.startsWith(`${plotlyAxis}.range[`),
                        );
                    [
                      ["xaxis", "xBottom"],
                      ["xaxis2", "xTop"],
                      ["yaxis", "yLeft"],
                      ["yaxis2", "yRight"],
                    ].forEach(([plotlyAxis, key]) => {
                      if (axisChanged(plotlyAxis)) copyRange(plotlyAxis, key);
                    });
                    c.editor.globalSettings = settings;
                    debugLog("plotly:range-sync", { chartId: c.id, event, all, settings });
                  });
                plot.on("plotly_relayout", (event) => {
                  if (!(programmaticPlotlyRelayout.get(plot) > 0))
                    syncPlotlyRanges(event, false);
                });
                plot.on("plotly_doubleclick", () =>
                  setTimeout(() => {
                    if (
                      renderGeneration === dashboardRenderGeneration &&
                      plot.isConnected &&
                      plot === document.getElementById(`plot-${s.id}`)
                    )
                      syncPlotlyRanges({}, true);
                  }, 0),
                );
              })
              .catch((error) => {
                if (renderGeneration !== dashboardRenderGeneration || !el.isConnected)
                  return;
                debugLog("plotly:render-error", {
                  slotId: s.id,
                  chartId: c.id,
                  message: error?.message || String(error),
                });
                status(
                  `그래프 렌더링 오류(슬롯 ${s.row}행 ${s.col}열): ${error?.message || error}`,
                );
              });
          }
        });
        installResizeObserver();
        schedulePlotResize();
        updateFileAvailability();
        syncDashboardCaption();
      }
      function activateChartModel(id) {
        let chart=getChart(id);
        if(!chart){debugLog("chart:activate-missing",{chartId:id});return null;}
        if(chart.editor?.editable!==false)
          for(let object of chart.editor?.objects||[])
            if(!getProjectCsv(object.csvId))
              throw Error("차트가 참조하는 프로젝트 CSV가 없습니다.");
        debugLog("chart:activate",{chartId:id});
        return chart;
      }
      function mergeSlots(slotIds=[]) {
        let selectedIds=[...new Set((Array.isArray(slotIds)?slotIds:[]).filter(Number.isInteger))],
          selected=selectedIds.map(slotAt).filter(slot=>slot&&!slot.hidden);
        if(selected.length!==selectedIds.length||selected.length<2)
          return status("합칠 슬롯을 둘 이상 선택하세요.");
        let top=Math.min(...selected.map(s=>s.row)),left=Math.min(...selected.map(s=>s.col)),
          bottom=Math.max(...selected.map(s=>s.row+s.rowSpan-1)),
          right=Math.max(...selected.map(s=>s.col+s.colSpan-1)),
          selectedCells=new Set();
        selected.forEach(s=>{for(let row=s.row;row<s.row+s.rowSpan;row++)for(let col=s.col;col<s.col+s.colSpan;col++)selectedCells.add(`${row}:${col}`)});
        if(selectedCells.size!==(bottom-top+1)*(right-left+1))
          return status("선택한 슬롯의 전체 영역이 빈칸 없는 직사각형이어야 합니다.");
        let candidate=projectClone(activeProject._state);normalizeSlotContents(candidate.slots);
        let cells=candidate.slots.filter(s=>s.row>=top&&s.row<=bottom&&s.col>=left&&s.col<=right);
        if(cells.length!==selectedCells.size)return status("선택 영역을 확인할 수 없습니다.");
        let nonDefault=cells.filter(slot=>slotHasNonDefaultLocalState(slot));
        if(nonDefault.length>1)return status("로컬 상태가 두 개 이상 있는 슬롯은 합칠 수 없습니다.");
        let anchor=cells.find(s=>s.row===top&&s.col===left),
          source=nonDefault[0]||anchor,local=slotLocalState(source);
        cells.forEach(cell=>{
          cell.rowSpan=1;cell.colSpan=1;cell.hidden=cell!==anchor;
          if(cell!==anchor)resetSlotLocalState(cell);
        });
        setSlotLocalState(anchor,local);
        anchor.rowSpan=bottom-top+1;anchor.colSpan=right-left+1;anchor.hidden=false;
        validateProjectObjectState(candidate,{requireSlots:true});
        activeProject.initialize(candidate);
        if(selectedSlotId!==null&&cells.some(s=>s.id===selectedSlotId))selectedSlotId=anchor.id;
        renderDashboard();appFSM.notify("layout","SLOTS_MERGED");
        return [anchor.id];
      }
      function splitSlots(slotIds=[]) {
        let ids=[...new Set((Array.isArray(slotIds)?slotIds:[]).filter(Number.isInteger))],
          selected=ids.map(slotAt).filter(slot=>slot&&!slot.hidden&&(slot.rowSpan>1||slot.colSpan>1));
        if(!selected.length)return status("나눌 합쳐진 슬롯을 선택하세요.");
        let candidate=projectClone(activeProject._state);normalizeSlotContents(candidate.slots);
        let restored=new Set();
        for(let source of selected){
          let anchor=candidate.slots.find(slot=>slot.id===source.id),
            endRow=anchor.row+anchor.rowSpan,endCol=anchor.col+anchor.colSpan,
            local=slotLocalState(anchor);
          candidate.slots.forEach(cell=>{
            if(cell.row>=anchor.row&&cell.row<endRow&&cell.col>=anchor.col&&cell.col<endCol){
              cell.hidden=false;cell.rowSpan=1;cell.colSpan=1;
              if(cell.id===anchor.id)setSlotLocalState(cell,local);else resetSlotLocalState(cell);
              restored.add(cell.id);
            }
          });
        }
        validateProjectObjectState(candidate,{requireSlots:true});
        activeProject.initialize(candidate);
        renderDashboard();appFSM.notify("layout","SLOTS_SPLIT");
        return [...restored];
      }
      function createChartModel({ id = null, editor = {}, graph = {} } = {}) {
        let model = {
          id,
          editor: {
            ...editor,
            objects: Array.isArray(editor.objects) ? editor.objects : [],
            editable: editor.editable !== false,
            globalSettings:
              editor.globalSettings && typeof editor.globalSettings === "object"
                ? editor.globalSettings
                : {},
          },
          graph: {
            data: Array.isArray(graph.data) ? graph.data : [],
            layout:
              graph.layout && typeof graph.layout === "object" && !Array.isArray(graph.layout)
                ? graph.layout
                : {},
            config:
              graph.config && typeof graph.config === "object" && !Array.isArray(graph.config)
                ? graph.config
                : {},
            frames: Array.isArray(graph.frames) ? graph.frames : [],
          },
        };
        if (graph.imported && typeof graph.imported === "object")
          model.graph.imported = {
            data: Array.isArray(graph.imported.data) ? graph.imported.data : [],
            layout:
              graph.imported.layout && typeof graph.imported.layout === "object"
                ? graph.imported.layout
                : {},
            config:
              graph.imported.config && typeof graph.imported.config === "object"
                ? graph.imported.config
                : {},
            frames: Array.isArray(graph.imported.frames) ? graph.imported.frames : [],
          };
        return model;
      }
      function validateChartModel(chart, label = "차트", csvCollection = activeProject.csvFiles) {
        if (!chart || typeof chart !== "object" || Array.isArray(chart))
          throw Error(`${label} 구조가 올바르지 않습니다.`);
        if (
          !chart.editor ||
          typeof chart.editor !== "object" ||
          !Array.isArray(chart.editor.objects)
        )
          throw Error(`${label} editor.objects가 없습니다.`);
        if (
          !chart.graph ||
          typeof chart.graph !== "object" ||
          !Array.isArray(chart.graph.data) ||
          !chart.graph.layout ||
          typeof chart.graph.layout !== "object" ||
          !chart.graph.config ||
          typeof chart.graph.config !== "object" ||
          !Array.isArray(chart.graph.frames)
        )
          throw Error(`${label} graph 구조가 올바르지 않습니다.`);
        chart.editor.objects.forEach((object, index) => {
          if (
            chart.editor.editable !== false &&
            (!Number.isInteger(object.csvId) || !getProjectCsv(object.csvId, csvCollection))
          )
            throw Error(`${label} 그래프 객체 ${index + 1}의 csvId가 올바르지 않습니다.`);
        });
        return chart;
      }
      function plotlyConfig(chart, extra = {}) {
        return {
          ...(chart.graph?.config || {}),
          ...extra,
          responsive: true,
          displaylogo: false,
          doubleClick: "reset",
        };
      }
      function rebuildEditableGraph(chart) {
        chart.graph.data = traces(chart);
        chart.graph.layout = layout(chart);
        return chart.graph;
      }
      function chartExportCopy(chart) {
        let copy = projectClone(chart);
        return copy;
      }
      function scalePlotlyFigure(figure, scale = 1) {
        let copy = projectClone(figure),
          factor = Math.max(0.01, Number(scale) || 1),
          scaleNumber = (value) =>
            Number.isFinite(Number(value)) ? Number(value) * factor : value,
          scaleFont = (font) =>
            font && typeof font === "object" ? { ...font, size: scaleNumber(font.size) } : font;
        if (factor === 1) return copy;
        let layout = copy.layout || {};
        layout.font = scaleFont(layout.font);
        if (layout.title?.font) layout.title.font = scaleFont(layout.title.font);
        if (layout.title?.pad)
          layout.title.pad = Object.fromEntries(
            Object.entries(layout.title.pad).map(([key, value]) => [key, scaleNumber(value)]),
          );
        if (layout.legend?.font) layout.legend.font = scaleFont(layout.legend.font);
        if (layout.legend) layout.legend.borderwidth = scaleNumber(layout.legend.borderwidth);
        if (layout.margin)
          layout.margin = Object.fromEntries(
            Object.entries(layout.margin).map(([key, value]) => [
              key,
              ["l", "r", "t", "b", "pad"].includes(key) ? scaleNumber(value) : value,
            ]),
          );
        ["xaxis", "xaxis2", "yaxis", "yaxis2"].forEach((key) => {
          let axis = layout[key];
          if (!axis) return;
          axis.linewidth = scaleNumber(axis.linewidth);
          axis.tickwidth = scaleNumber(axis.tickwidth);
          axis.ticklen = scaleNumber(axis.ticklen);
          axis.tickfont = scaleFont(axis.tickfont);
          if (axis.title?.font) axis.title.font = scaleFont(axis.title.font);
          if (axis.minor) {
            axis.minor.tickwidth = scaleNumber(axis.minor.tickwidth);
            axis.minor.ticklen = scaleNumber(axis.minor.ticklen);
          }
        });
        (copy.data || []).forEach((trace) => {
          if (trace.line) trace.line.width = scaleNumber(trace.line.width);
          if (trace.marker) {
            trace.marker.size = scaleNumber(trace.marker.size);
            if (trace.marker.line)
              trace.marker.line.width = scaleNumber(trace.marker.line.width);
          }
        });
        return copy;
      }
      function chartFigure(chart, scale = 1) {
        let copy = chartExportCopy(chart);
        if (copy.editor.editable === false && copy.graph.imported)
          return scalePlotlyFigure(copy.graph.imported, scale);
        rebuildEditableGraph(copy);
        return scalePlotlyFigure(copy.graph, scale);
      }
      function setNestedAxisFromPlotly(target, axis = {}) {
        target.title = typeof axis.title === "string" ? axis.title : axis.title?.text || "";
        let scaleType = axis.type === "log" ? "log" : "linear";
        target.min = Array.isArray(axis.range)
          ? axisRangeValueFromPlotly(axis.range[0], scaleType)
          : "";
        target.max = Array.isArray(axis.range)
          ? axisRangeValueFromPlotly(axis.range[1], scaleType)
          : "";
        let linearTick =
            scaleType !== "log" &&
            typeof axis.dtick === "string" &&
            /^L(?:\d|\.)/.test(axis.dtick),
          denseLogTicks =
            scaleType === "log" &&
            (axis.dtick === "D1" ||
              (axis.minor &&
                (axis.minor.dtick === "D1" ||
                  axis.minor.ticks === "inside" ||
                  axis.minor.ticks === "outside" ||
                  axis.minor.showgrid === true)));
        target.tick = linearTick
            ? axis.dtick.slice(1)
            : typeof axis.dtick === "number"
              && scaleType !== "log"
              ? axis.dtick
              : "";
        target.tickMode = linearTick ? "increment" : "plotly";
        target.minorTicks = denseLogTicks;
        target.titleSize = axis.title?.font?.size ?? target.titleSize;
        target.fontSize = axis.tickfont?.size ?? target.fontSize;
        target.lineWidth = axis.linewidth ?? target.lineWidth;
        target.showGrid = axis.showgrid !== false;
        target.visible = axis.visible !== false;
        target.showValues = axis.showticklabels !== false;
        target.scaleType = scaleType;
        target.notation =
          axis.exponentformat === "e" ? "e" : axis.exponentformat === "power" ? "power" : "none";
      }
      function parsePlotlyToEditor(figure, id) {
        let data = Array.isArray(figure.data) ? figure.data : [],
          rowsOut = [],
          objects = [];
        data.forEach((trace, index) => {
          let x = Array.isArray(trace.x) ? trace.x : [],
            y = Array.isArray(trace.y) ? trace.y : [],
            length = Math.max(x.length, y.length);
          let xKey = `trace${index + 1}_x`,
            yKey = `trace${index + 1}_y`;
          for (let i = 0; i < length; i++) {
            rowsOut[i] ??= {};
            rowsOut[i][xKey] = x[i] ?? "";
            rowsOut[i][yKey] = y[i] ?? "";
          }
          if (length) {
            let isBar = trace.type === "bar",
              mode = isBar ? "bar" : trace.visible === false ? "hidden" : trace.mode || "scatter";
            let plotlyTrace = projectClone(trace);
            delete plotlyTrace.x;
            delete plotlyTrace.y;
            objects.push({
              x: xKey,
              y: yKey,
              xAxisSide: trace.xaxis === "x2" ? "top" : "bottom",
              yAxisSide: trace.yaxis === "y2" ? "right" : "left",
              type: mode,
              color:
                trace.line?.color ||
                trace.marker?.color ||
                DEFAULT_COLORS[index % DEFAULT_COLORS.length],
              legendName: trace.name || "",
              lineWidth: trace.line?.width ?? 2,
              lineDash: trace.line?.dash || "solid",
              markerSymbol: trace.marker?.symbol || "circle",
              markerSize: Array.isArray(trace.marker?.size) ? 6 : (trace.marker?.size ?? 6),
              barOpacity: trace.opacity ?? 1,
              barLineWidth: trace.marker?.line?.width ?? 0,
              plotlyTrace,
            });
          }
        });
        let sourceHeaders = [...new Set(rowsOut.flatMap((row) => Object.keys(row || {})))],
          columnMap = Object.fromEntries(
            sourceHeaders.map((header, index) => [header, `C${index + 1}`]),
          );
        objects = objects.map((object) => ({
          ...object,
          x: columnMap[object.x] || object.x,
          y: columnMap[object.y] || object.y,
        }));
        rowsOut = rowsOut.length ? dataTable(rowsOut) : [];
        let layoutIn = figure.layout && typeof figure.layout === "object" ? figure.layout : {},
          chart = createChartModel({
            id,
            editor: { editable: false, conversionRows: rowsOut, objects },
            graph: {
              data: [],
              layout: {},
              config: {},
              frames: [],
              imported: {
                data: projectClone(data),
                layout: projectClone(layoutIn),
                config: projectClone(figure.config || {}),
                frames: projectClone(figure.frames || []),
              },
            },
          });
        let settings = normalizeGlobalSettings(chart);
        chart.editor.title =
          typeof layoutIn.title === "string" ? layoutIn.title : layoutIn.title?.text || "";
        settings.showTitle = !!chart.editor.title;
        settings.showLegend = layoutIn.showlegend !== false;
        settings.graphFontFamily =
          layoutIn.title?.font?.family ||
          layoutIn.font?.family ||
          layoutIn.legend?.font?.family ||
          "";
        settings.titleFontSize = layoutIn.title?.font?.size ?? "";
        settings.legendFontSize = layoutIn.legend?.font?.size ?? "";
        setNestedAxisFromPlotly(settings.axes.xBottom, layoutIn.xaxis || {});
        setNestedAxisFromPlotly(settings.axes.xTop, layoutIn.xaxis2 || {});
        setNestedAxisFromPlotly(settings.axes.yLeft, layoutIn.yaxis || {});
        setNestedAxisFromPlotly(settings.axes.yRight, layoutIn.yaxis2 || {});
        chart.editor.globalSettings = settings;
        chart.editor.plotlyExtensions = {
          layout: projectClone(layoutIn),
          config: projectClone(figure.config || {}),
        };
        chart.graph.config = projectClone(figure.config || {});
        chart.graph.frames = projectClone(figure.frames || []);
        if (objects.length) {
          Object.assign(chart.editor, objects[0]);
          chart.editor.colors = objects.map((object) => object.color);
        }
        return chart;
      }
      function projectClone(value) {
        return JSON.parse(JSON.stringify(value));
      }
      function slotLocalState(slot) {
        normalizeSlotContent(slot);
        return {
          chart: slot.content.chart,
          imageId: slot.content.imageId,
          contentType: slot.content.contentType,
          imageSettings: readImageSettings(slot.content.imageSettings),
          caption: typeof slot.caption === "string" ? slot.caption : null,
        };
      }
      function setSlotLocalState(slot, localState) {
        normalizeSlotContent(slot);
        let next = localState && typeof localState === "object" ? localState : SLOT_LOCAL_DEFAULTS;
        slot.content.chart = Number.isInteger(next.chart) ? next.chart : null;
        slot.content.imageId = Number.isInteger(next.imageId) ? next.imageId : null;
        slot.content.contentType = next.contentType === "image" ? "image" : "graph";
        slot.content.imageSettings = readImageSettings(next.imageSettings);
        slot.caption = typeof next.caption === "string" && next.caption ? next.caption : null;
        return slot;
      }
      function resetSlotLocalState(slot) {
        return setSlotLocalState(slot, SLOT_LOCAL_DEFAULTS);
      }
      function slotHasNonDefaultLocalState(slot) {
        let local = slotLocalState(slot),
          defaults = SLOT_LOCAL_DEFAULTS;
        return (
          local.chart !== defaults.chart ||
          local.imageId !== defaults.imageId ||
          local.contentType !== defaults.contentType ||
          local.caption !== defaults.caption ||
          local.imageSettings.fit !== defaults.imageSettings.fit ||
          local.imageSettings.scale !== defaults.imageSettings.scale ||
          local.imageSettings.x !== defaults.imageSettings.x ||
          local.imageSettings.y !== defaults.imageSettings.y
        );
      }
      function slotLegacyState(slot) {
        let local = slotLocalState(slot);
        return {
          ...Object.fromEntries(Object.entries(slot).filter(([key]) => key !== "content")),
          chart: local.chart,
          imageId: local.imageId,
          contentType: local.contentType,
          imageSettings: projectClone(local.imageSettings),
          caption: local.caption,
        };
      }
      function normalizeSlotContent(slot) {
        if (!slot || typeof slot !== "object" || Array.isArray(slot)) return slot;
        let sourceContent =
            slot.content && typeof slot.content === "object" && !Array.isArray(slot.content)
              ? slot.content
              : {},
          legacyCaption =
            typeof slot.caption === "string"
              ? slot.caption
              : typeof sourceContent.caption === "string"
                ? sourceContent.caption
                : null,
          legacySettings =
            sourceContent.imageSettings && typeof sourceContent.imageSettings === "object"
              ? sourceContent.imageSettings
              : slot.imageSettings && typeof slot.imageSettings === "object"
                ? slot.imageSettings
                : DEFAULT_IMAGE_SETTINGS;
        slot.content = {
          ...sourceContent,
          chart: Number.isInteger(sourceContent.chart)
            ? sourceContent.chart
            : Number.isInteger(slot.chart) ? slot.chart : null,
          imageId: Number.isInteger(sourceContent.imageId)
            ? sourceContent.imageId
            : Number.isInteger(slot.imageId) ? slot.imageId : null,
          contentType:
            (sourceContent.contentType ?? slot.contentType) === "image" ? "image" : "graph",
          imageSettings: readImageSettings(legacySettings),
        };
        delete slot.content.caption;
        slot.caption = legacyCaption && legacyCaption !== "슬롯 캡션" ? legacyCaption : null;
        Object.defineProperties(slot, {
          chart: {
            configurable: true,
            enumerable: false,
            get() { return this.content.chart; },
            set(value) { this.content.chart = value; },
          },
          imageId: {
            configurable: true,
            enumerable: false,
            get() { return this.content.imageId; },
            set(value) { this.content.imageId = value; },
          },
          contentType: {
            configurable: true,
            enumerable: false,
            get() { return this.content.contentType; },
            set(value) { this.content.contentType = value; },
          },
          toJSON: {
            configurable: true,
            enumerable: false,
            value() { return slotLegacyState(this); },
          },
        });
        return slot;
      }
      function normalizeSlotContents(slots) {
        if (!Array.isArray(slots)) return slots;
        slots.forEach(normalizeSlotContent);
        return slots;
      }
      function projectColor(value, fallback) {
        return /^#[0-9a-f]{6}$/i.test(String(value || "")) ? String(value) : fallback;
      }
      function validateProjectObjectState(state, { requireSlots = false } = {}) {
        let record=(value)=>!!value&&typeof value==="object"&&!Array.isArray(value);
        if(!record(state)||state.kind!=="fast-figure-project-object"||!record(state.meta)||
          !record(state.layout)||!record(state.layout.slotStyle)||!record(state.annotations?.labels)||
          !record(state.annotations?.labels?.settings)||!record(state.annotations?.captions)||
          !record(state.annotations?.captions?.settings)||!record(state.assets)||
          !record(state.fileSystem)||!record(state.nextId)||!record(state.appearance)||
          !record(state.appearance.uiPalette)||!record(state.export))
          throw Error("프로젝트 오브젝트 구조가 올바르지 않습니다.");
        if(typeof state.meta.projectName!=="string"||typeof state.meta.appBuild!=="string"||
          !Number.isInteger(state.layout.gridRows)||!Number.isInteger(state.layout.gridCols)||
          state.layout.gridRows<1||state.layout.gridRows>8||state.layout.gridCols<1||state.layout.gridCols>8||
          typeof state.annotations.labels.enabled!=="boolean"||
          typeof state.annotations.captions.enabled!=="boolean"||
          typeof state.annotations.captions.text!=="string"||
          typeof state.annotations.captions.afterText!=="string"||
          typeof state.annotations.captions.name!=="string"||
          typeof state.annotations.captions.nameBold!=="boolean")
          throw Error("프로젝트 메타데이터 또는 레이아웃이 올바르지 않습니다.");
        let style=state.layout.slotStyle;
        for(let [key,min,max] of [["referenceWidth",100,20000],["gap",0,2000],["outerMargin",0,5000],
          ["radius",0,2000],["aspect",0.1,10]])
          if(!Number.isFinite(style[key])||style[key]<min||style[key]>max)
            throw Error(`프로젝트 슬롯 스타일 ${key}가 올바르지 않습니다.`);
        if(typeof style.showBorders!=="boolean")throw Error("프로젝트 슬롯 외곽선 설정이 올바르지 않습니다.");
        let labelSettings=state.annotations.labels.settings;
        if(!Number.isFinite(labelSettings.x)||!Number.isFinite(labelSettings.y)||
          !Number.isFinite(labelSettings.fontSize)||labelSettings.fontSize<6)
          throw Error("프로젝트 레이블 위치 또는 크기가 올바르지 않습니다.");
        let output=state.export, explicit=output.heightMode==="explicit";
        if(!Number.isFinite(output.width)||output.width<100||output.width>20000||
          !["auto","explicit"].includes(output.heightMode)||
          (explicit&&(!Number.isFinite(output.height)||output.height<100||output.height>20000))||
          !Number.isFinite(output.dpi)||output.dpi<36||output.dpi>1200||
          !["png","jpeg"].includes(output.format))
          throw Error("프로젝트 출력 설정이 올바르지 않습니다.");
        for(let key of Object.keys(DEFAULT_UI_PALETTE))
          if(projectColor(state.appearance.uiPalette[key],null)===null)
            throw Error(`프로젝트 UI 색상 ${key}가 올바르지 않습니다.`);
        if(!Array.isArray(state.assets.csvFiles)||!Array.isArray(state.assets.images)||
          !Array.isArray(state.fileSystem.directories)||!Array.isArray(state.charts)||
          !Array.isArray(state.slots)||(requireSlots&&state.slots.length===0))
          throw Error("프로젝트 자산, 차트 또는 슬롯 목록이 올바르지 않습니다.");
        let filePaths=new Set(),directoryPaths=new Set();
        state.fileSystem.directories.forEach(path=>{
          let normalized=normalizeProjectPath(path,{directory:true});
          if(normalized==="/"||normalized!==path||directoryPaths.has(path))
            throw Error("프로젝트 폴더 경로가 올바르지 않습니다.");
          directoryPaths.add(path);
        });
        for(let required of ["/assets","/assets/csv","/assets/images","/assets/trash"])
          if(!directoryPaths.has(required))throw Error(`프로젝트 기본 폴더 ${required}가 없습니다.`);
        let csvIds=new Set();
        state.assets.csvFiles.forEach(csv=>{
          let path;try{path=projectAssetPath(csv)}catch(_){throw Error("프로젝트 CSV 오브젝트가 올바르지 않습니다.")}
          if(!record(csv)||!Number.isInteger(csv.id)||csv.id<1||csvIds.has(csv.id)||
            typeof csv.name!=="string"||typeof csv.directory!=="string"||!Array.isArray(csv.rows)||
            typeof csv.bytesBase64!=="string"||!csv.bytesBase64||
            normalizeProjectPath(csv.directory,{directory:true})!==csv.directory||
            filePaths.has(path)||!directoryPaths.has(csv.directory))
            throw Error("프로젝트 CSV 오브젝트가 올바르지 않습니다.");
          csvIds.add(csv.id);filePaths.add(path);
        });
        let imageIds=new Set();
        state.assets.images.forEach(image=>{
          let path;try{path=projectAssetPath(image)}catch(_){throw Error("프로젝트 이미지 오브젝트가 올바르지 않습니다.")}
          if(!record(image)||!Number.isInteger(image.id)||image.id<1||imageIds.has(image.id)||
            typeof image.name!=="string"||typeof image.directory!=="string"||
            typeof image.bytesBase64!=="string"||!image.bytesBase64||
            normalizeProjectPath(image.directory,{directory:true})!==image.directory||
            filePaths.has(path)||!directoryPaths.has(image.directory))
            throw Error("프로젝트 이미지 오브젝트가 올바르지 않습니다.");
          imageIds.add(image.id);filePaths.add(path);
        });
        let chartIds=new Set();
        state.charts.forEach((chart,index)=>{
          if(!Number.isInteger(chart?.id)||chart.id<1||chartIds.has(chart.id))
            throw Error("프로젝트 차트 ID가 올바르지 않습니다.");
          chartIds.add(chart.id);validateChartModel(chart,`프로젝트 차트 ${index+1}`,state.assets.csvFiles);
        });
        normalizeSlotContents(state.slots);
        let slotIds=new Set(),owners=new Map([...chartIds].map(id=>[id,0]));
        state.slots.forEach(slot=>{
          if(!record(slot)||!Number.isInteger(slot.id)||slotIds.has(slot.id)||
            !Number.isInteger(slot.row)||!Number.isInteger(slot.col)||
            !Number.isInteger(slot.rowSpan)||!Number.isInteger(slot.colSpan)||
            slot.row<1||slot.col<1||slot.rowSpan<1||slot.colSpan<1||
            slot.row+slot.rowSpan-1>state.layout.gridRows||
            slot.col+slot.colSpan-1>state.layout.gridCols||
            !["graph","image"].includes(slot.contentType)||
            (slot.chart!=null&&slot.imageId!=null)||
            (slot.chart!=null&&!chartIds.has(slot.chart))||
            (slot.imageId!=null&&!imageIds.has(slot.imageId))||
            !(slot.caption===null||typeof slot.caption==="string"))
            throw Error("프로젝트 슬롯 오브젝트가 올바르지 않습니다.");
          slot.content.imageSettings=readImageSettings(slot.content.imageSettings);
          if(slot.chart!=null)owners.set(slot.chart,owners.get(slot.chart)+1);
          slotIds.add(slot.id);
        });
        for(let [chartId,count] of owners)
          if(count!==1)throw Error(`프로젝트 차트 ${chartId}의 슬롯 소유권이 올바르지 않습니다.`);
        let maximums={csv:Math.max(0,...csvIds),image:Math.max(0,...imageIds),chart:Math.max(0,...chartIds)};
        for(let key of ["csv","image","chart"])
          if(!Number.isInteger(state.nextId[key])||state.nextId[key]<=maximums[key])
            throw Error(`프로젝트 ${key} ID 시퀀스가 올바르지 않습니다.`);
        return state;
      }
      function validateProjectObject(project, options = {}) {
        if (!(project instanceof ProjectObject))
          throw Error("ProjectObject 인스턴스가 아닙니다.");
        validateProjectObjectState(project._state, options);
        return project;
      }
      function importedProjectCsvState(payload) {
        if (!Array.isArray(payload.csvFiles)) throw Error("프로젝트 CSV 목록이 없습니다.");
        let ids = new Set(),
          nextCsvFiles = payload.csvFiles.map((source, index) => {
            if (
              !source ||
              typeof source !== "object" ||
              !Number.isInteger(source.id) ||
              source.id < 1 ||
              !Array.isArray(source.rows)
            )
              throw Error("프로젝트 CSV 데이터가 올바르지 않습니다.");
            let id = source.id;
            if (ids.has(id)) throw Error("프로젝트 CSV ID가 중복되었습니다.");
            ids.add(id);
            return {
              id,
              name: projectCsvName(source.name, `data-${index + 1}.csv`),
              directory: typeof source.directory === "string" ? source.directory : null,
              rows: projectClone(source.rows),
              bytesBase64:
                typeof source.bytesBase64 === "string" && source.bytesBase64
                  ? source.bytesBase64
                  : ffpxBytesToBase64(
                      new TextEncoder().encode(ffpxCsv(source.rows)),
                    ),
              mime: typeof source.mime === "string" ? source.mime : "text/csv",
              headerLines: headerLineCount(source.headerLines ?? 1, source.rows),
            };
          });
        return {
          csvFiles: nextCsvFiles,
          csvId: nextCsvFiles.reduce((next, csv) => Math.max(next, csv.id + 1), 1),
        };
      }
      function importedProjectImageState(payload) {
        if (!Array.isArray(payload.images)) throw Error("프로젝트 이미지 목록이 없습니다.");
        let nextImages = [],
          ids = new Set();
        payload.images.forEach((source) => {
          if (
            !source ||
            !Number.isInteger(source.id) ||
            source.id < 1 ||
            ids.has(source.id) ||
            typeof source.bytesBase64 !== "string" ||
            !source.bytesBase64
          )
            throw Error("프로젝트 이미지 데이터가 올바르지 않습니다.");
          ids.add(source.id);
          nextImages.push({
            id: source.id,
            name: projectCsvName(source.name, "image.bin"),
            directory: typeof source.directory === "string" ? source.directory : null,
            mime:
              typeof source.mime === "string" && source.mime
                ? source.mime
                : "application/octet-stream",
            bytesBase64: source.bytesBase64,
          });
        });
        return {
          images: nextImages,
          imageId: nextImages.reduce((next, image) => Math.max(next, image.id + 1), 1),
        };
      }
      function readProjectNumber(value, fallback, min, max) {
        let number = Number(value);
        return Number.isFinite(number) ? Math.max(min, Math.min(max, number)) : fallback;
      }
      function readFiniteProjectNumber(value, fallback) {
        let number = Number(value);
        return Number.isFinite(number) ? number : fallback;
      }
      function buildProjectObject(payload,fileName) {
        if(payload?.schema!=="fast-figure-project"||payload.version!==PACKAGE_FORMAT_VERSION)
          throw Error("지원하지 않는 FFPX 프로젝트 형식입니다.");
        let candidate=new ProjectObject();
        candidate.projectName=typeof payload.projectName==="string"?payload.projectName.trim().slice(0,120):"";
        if(!candidate.projectName)
          candidate.projectName=String(fileName||"").replace(/\.[^.]+$/,"").trim().slice(0,120);
        let rows=Number(payload.gridRows),cols=Number(payload.gridCols);
        if(!Number.isInteger(rows)||!Number.isInteger(cols)||rows<1||rows>8||cols<1||cols>8)
          throw Error("프로젝트의 행 또는 열 값이 올바르지 않습니다.");
        if(!Array.isArray(payload.charts)||!Array.isArray(payload.slots))
          throw Error("프로젝트의 charts 또는 slots 배열이 없습니다.");
        let csvState=importedProjectCsvState(payload),imageState=importedProjectImageState(payload),
          charts=projectClone(payload.charts),chartIds=new Set();
        charts.forEach((chart,index)=>{
          validateChartModel(chart,`프로젝트 차트 ${index+1}`,csvState.csvFiles);
          if(!Number.isInteger(chart.id)||chartIds.has(chart.id))throw Error("프로젝트 차트 ID가 올바르지 않습니다.");
          chartIds.add(chart.id);normalizeGlobalSettings(chart,true);
        });
        let slotIds=new Set(),slots=projectClone(payload.slots).map(raw=>{
          if(!raw||typeof raw!=="object"||!Number.isInteger(raw.id)||slotIds.has(raw.id))
            throw Error("프로젝트 슬롯 데이터가 올바르지 않습니다.");
          slotIds.add(raw.id);
          let row=Number(raw.row),col=Number(raw.col),rowSpan=Number(raw.rowSpan??1),colSpan=Number(raw.colSpan??1);
          if(!Number.isInteger(row)||!Number.isInteger(col)||!Number.isInteger(rowSpan)||!Number.isInteger(colSpan)||
            row<1||col<1||rowSpan<1||colSpan<1||row+rowSpan-1>rows||col+colSpan-1>cols)
            throw Error("프로젝트 슬롯 위치가 올바르지 않습니다.");
          let chart=raw.chart==null?null:(chartIds.has(raw.chart)?raw.chart:null),
            imageId=raw.imageId==null?null:(getProjectImage(raw.imageId,imageState.images)?.id??null);
          if(raw.chart!=null&&chart===null)throw Error("프로젝트 슬롯이 존재하지 않는 차트를 참조합니다.");
          if(raw.imageId!=null&&imageId===null)throw Error("프로젝트 슬롯이 존재하지 않는 이미지를 참조합니다.");
          return normalizeSlotContent({
            id:raw.id,row,col,rowSpan,colSpan,hidden:raw.hidden===true,
            content:{
              chart,imageId,
              contentType:raw.contentType==="image"?"image":"graph",
              imageSettings:readImageSettings(raw.imageSettings||raw.content?.imageSettings),
            },
            caption:typeof raw.caption==="string"&&raw.caption?raw.caption:null,
          });
        });
        if(!slots.length)throw Error("프로젝트 슬롯이 없습니다.");
        candidate.gridRows=rows;candidate.gridCols=cols;
        candidate.csvFiles=csvState.csvFiles;candidate.images=imageState.images;
        candidate.charts=charts;candidate.slots=slots;
        candidate.fileSystem={directories:Array.isArray(payload.fileSystem?.directories)?projectClone(payload.fileSystem.directories):[]};
        projectVfs.ensure(candidate._state);
        candidate.csvId=Math.max(Number.isInteger(payload.csvId)?payload.csvId:1,csvState.csvId);
        candidate.imageId=Math.max(Number.isInteger(payload.imageId)?payload.imageId:1,imageState.imageId);
        candidate.chartId=Math.max(Number.isInteger(payload.chartId)?payload.chartId:1,1,...charts.map(chart=>chart.id+1));
        let annotations=payload.annotations&&typeof payload.annotations==="object"?payload.annotations:{},
          labelPatch=annotations.labelSettings&&typeof annotations.labelSettings==="object"?annotations.labelSettings:{},
          captionPatch=annotations.captionSettings&&typeof annotations.captionSettings==="object"?annotations.captionSettings:{};
        candidate.labelsEnabled=annotations.labelsEnabled===true;
        candidate.labelSettings={...candidate.labelSettings,...labelPatch,
          parentheses:labelPatch.parentheses===true,
          x:readFiniteProjectNumber(labelPatch.x,candidate.labelSettings.x),
          y:readFiniteProjectNumber(labelPatch.y,candidate.labelSettings.y),
          fontSize:Math.max(6,readFiniteProjectNumber(labelPatch.fontSize,candidate.labelSettings.fontSize))};
        candidate.captionsEnabled=annotations.captionsEnabled===true;
        candidate.captionText=typeof annotations.captionText==="string"?annotations.captionText:"";
        candidate.captionAfterText=typeof annotations.captionAfterText==="string"?annotations.captionAfterText:"";
        candidate.captionName=typeof annotations.captionName==="string"?annotations.captionName:"";
        candidate.captionNameBold=annotations.captionNameBold===true;
        candidate.captionSettings={...candidate.captionSettings,...captionPatch,
          fontSize:readProjectNumber(captionPatch.fontSize,candidate.captionSettings.fontSize,6,96),
          lineHeight:readProjectNumber(captionPatch.lineHeight,candidate.captionSettings.lineHeight,0.8,4)};
        let style=payload.slotStyle&&typeof payload.slotStyle==="object"?payload.slotStyle:{},
          palette=payload.uiPalette&&typeof payload.uiPalette==="object"?payload.uiPalette:{},
          output=payload.export&&typeof payload.export==="object"?payload.export:{};
        candidate.layout.slotStyle={
          referenceWidth:readProjectNumber(style.referenceWidth,1200,100,20000),
          gap:readProjectNumber(style.gap,0,0,2000),
          outerMargin:readProjectNumber(style.outerMargin,120,0,5000),
          radius:readProjectNumber(style.radius,0,0,2000),
          aspect:readProjectNumber(style.aspect,1.618,0.1,10),
          showBorders:style.showBorders!==false};
        candidate.appearance.uiPalette=Object.fromEntries(Object.entries(DEFAULT_UI_PALETTE)
          .map(([key,fallback])=>[key,projectColor(palette[key],fallback)]));
        let heightMode=output.heightMode==="explicit"?"explicit":"auto";
        candidate.exportSettings={
          width:readProjectNumber(output.width,candidate.layout.slotStyle.referenceWidth,100,20000),
          heightMode,
          height:heightMode==="explicit"?readProjectNumber(output.height,100,100,20000):null,
          dpi:readProjectNumber(output.dpi,300,36,1200),
          format:output.format==="jpeg"?"jpeg":"png"};
        validateProjectObject(candidate,{requireSlots:true});
        return candidate;
      }
      function captureProjectRuntimeState(machine) {
        return {selectedSlotId,graphObject:machine.state.graphObject,graphObjectIndex:machine.state.graphObjectIndex};
      }
      function restoreProjectRuntimeState(snapshot,machine) {
        selectedSlotId=snapshot.selectedSlotId;
        machine.state=Object.freeze({...machine.state,graphObject:snapshot.graphObject,graphObjectIndex:snapshot.graphObjectIndex});
      }
      function resetProjectRuntimeState(machine) {
        selectedSlotId=null;
        machine.state=Object.freeze({...machine.state,graphObject:"none",graphObjectIndex:null});
      }
      function renderProjectObject(project = activeProject) {
        applySlotStyle(false, false);
        applyUiPalette(false, false);
        syncDashboardCaption();
        updateFileAvailability();
      }
      function applyProjectLoadedAction({ machine, payload }) {
        for (let scope of [
          "project",
          "layout",
          "labels",
          "captions",
          "data",
          "images",
          "files",
          "charts",
          "slots",
          "workspace",
          "editor",
          "ui",
        ])
          machine.assertWritable(scope, "PROJECT_LOADED");
        let candidate = validateProjectObject(payload.project, {
            requireSlots: true,
          }),
          previousState = activeProject._state,
          previousImages = activeProject.images,
          candidateImages = candidate.images,
          previousRuntime = captureProjectRuntimeState(machine);
        try {
          activeProject.initialize(candidate);
          projectObjectGeneration += 1;
          resetProjectRuntimeState(machine);
          renderProjectObject(activeProject);
        } catch (error) {
          releaseProjectImageDisplayUrls(candidateImages);
          activeProject.initialize(previousState);
          projectObjectGeneration += 1;
          restoreProjectRuntimeState(previousRuntime, machine);
          try {
            renderProjectObject(activeProject);
          } catch (rollbackError) {
            debugLog(
              "project:rollback-render-error",
              { message: rollbackError.message },
              "error",
            );
          }
          throw error;
        }
        releaseProjectImageDisplayUrls(previousImages);
        machine.state = Object.freeze({
          ...machine.state,
          revision: machine.state.revision + 1,
        });
        payload.project = activeProject;
        payload.generation = projectObjectGeneration;
      }
      function importProject(payload, fileName) {
        let candidate = ProjectObject.fromFFPX(payload, fileName);
        appFSM.send("PROJECT_LOADED", {
          project: candidate,
          fileName,
          direction: "model-to-fsm",
        });
        appFSM.send("CLOSE_OVERLAY", { reason: "project-loaded" });
        status(`${fileName} 프로젝트를 불러왔습니다.`);
        debugLog("project:import", {
          name: fileName,
          charts: activeProject.charts.length,
          slots: activeProject.slots.length,
          gridRows: activeProject.gridRows,
          gridCols: activeProject.gridCols,
          generation: projectObjectGeneration,
        });
        return activeProject;
      }
      async function importProjectFile(file) {
        let header = new Uint8Array(await file.slice(0, 4).arrayBuffer());
        let payload =
          header.length === 4 && header[0] === 0x50 && header[1] === 0x4b
            ? await ffpxReadProject(file)
            : JSON.parse(await file.text());
        return importProject(payload, file.name);
      }
      function ffpxBytesToBase64(bytes) {
        let text = "",
          step = 0x8000;
        for (let i = 0; i < bytes.length; i += step)
          text += String.fromCharCode(...bytes.subarray(i, i + step));
        return btoa(text);
      }
      function ffpxBase64ToBytes(value) {
        let text = atob(value),
          bytes = new Uint8Array(text.length);
        for (let i = 0; i < text.length; i++) bytes[i] = text.charCodeAt(i);
        return bytes;
      }
      function ffpxConcat(parts, total) {
        let result = new Uint8Array(total),
          offset = 0;
        for (let part of parts) {
          result.set(part, offset);
          offset += part.length;
        }
        return result;
      }
      let ffpxCrcTable = null;
      function ffpxCrc32(bytes) {
        if (!ffpxCrcTable) {
          ffpxCrcTable = new Uint32Array(256);
          for (let i = 0; i < 256; i++) {
            let value = i;
            for (let bit = 0; bit < 8; bit++)
              value = value & 1 ? 0xedb88320 ^ (value >>> 1) : value >>> 1;
            ffpxCrcTable[i] = value >>> 0;
          }
        }
        let value = 0xffffffff;
        for (let byte of bytes) value = ffpxCrcTable[(value ^ byte) & 255] ^ (value >>> 8);
        return (value ^ 0xffffffff) >>> 0;
      }
      function ffpxZipStore(entries) {
        let encoder = new TextEncoder(),
          prepared = entries.map((entry) => {
            if (
              !entry ||
              typeof entry.name !== "string" ||
              !entry.name ||
              entry.name.includes("..") ||
              entry.name.startsWith("/")
            )
              throw Error("FFPX 자산 경로가 올바르지 않습니다.");
            let name = encoder.encode(entry.name),
              data = entry.data instanceof Uint8Array ? entry.data : new Uint8Array(entry.data);
            if (name.length > 0xffff || data.length > 0xffffffff)
              throw Error("FFPX 자산 크기가 너무 큽니다.");
            return { name, data, crc: ffpxCrc32(data) };
          }),
          localSize = prepared.reduce(
            (sum, entry) => sum + 30 + entry.name.length + entry.data.length,
            0,
          ),
          centralSize = prepared.reduce((sum, entry) => sum + 46 + entry.name.length, 0),
          parts = [],
          offset = 0;
        for (let entry of prepared) {
          let header = new Uint8Array(30),
            view = new DataView(header.buffer);
          view.setUint32(0, 0x04034b50, true);
          view.setUint16(4, 20, true);
          view.setUint16(8, 0, true);
          view.setUint32(14, entry.crc, true);
          view.setUint32(18, entry.data.length, true);
          view.setUint32(22, entry.data.length, true);
          view.setUint16(26, entry.name.length, true);
          parts.push(header, entry.name, entry.data);
          entry.offset = offset;
          offset += header.length + entry.name.length + entry.data.length;
        }
        let central = [];
        for (let entry of prepared) {
          let header = new Uint8Array(46),
            view = new DataView(header.buffer);
          view.setUint32(0, 0x02014b50, true);
          view.setUint16(4, 20, true);
          view.setUint16(6, 20, true);
          view.setUint16(8, 0, true);
          view.setUint32(16, entry.crc, true);
          view.setUint32(20, entry.data.length, true);
          view.setUint32(24, entry.data.length, true);
          view.setUint16(28, entry.name.length, true);
          view.setUint32(42, entry.offset, true);
          central.push(header, entry.name);
        }
        let end = new Uint8Array(22),
          endView = new DataView(end.buffer);
        endView.setUint32(0, 0x06054b50, true);
        endView.setUint16(8, prepared.length, true);
        endView.setUint16(10, prepared.length, true);
        endView.setUint32(12, centralSize, true);
        endView.setUint32(16, localSize, true);
        return ffpxConcat([...parts, ...central, end], localSize + centralSize + end.length);
      }
      function ffpxZipRead(bytes) {
        if (!(bytes instanceof Uint8Array) || bytes.length < 22)
          throw Error("FFPX ZIP 파일이 너무 작습니다.");
        let view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength),
          end = -1;
        for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 0x10016); i--)
          if (view.getUint32(i, true) === 0x06054b50) {
            end = i;
            break;
          }
        if (end < 0) throw Error("FFPX ZIP 종료 정보를 찾을 수 없습니다.");
        if (view.getUint16(end + 4, true) || view.getUint16(end + 6, true))
          throw Error("분할 ZIP은 지원하지 않습니다.");
        let count = view.getUint16(end + 10, true),
          centralSize = view.getUint32(end + 12, true),
          offset = view.getUint32(end + 16, true);
        if (count > 10000 || offset + centralSize > end)
          throw Error("FFPX ZIP 중앙 디렉터리가 올바르지 않습니다.");
        let decoder = new TextDecoder(),
          assets = new Map(),
          cursor = offset;
        for (let index = 0; index < count; index++) {
          if (cursor + 46 > offset + centralSize || view.getUint32(cursor, true) !== 0x02014b50)
            throw Error("FFPX ZIP 항목이 올바르지 않습니다.");
          let flags = view.getUint16(cursor + 8, true),
            method = view.getUint16(cursor + 10, true),
            crc = view.getUint32(cursor + 16, true),
            compressed = view.getUint32(cursor + 20, true),
            size = view.getUint32(cursor + 24, true),
            nameLength = view.getUint16(cursor + 28, true),
            extraLength = view.getUint16(cursor + 30, true),
            commentLength = view.getUint16(cursor + 32, true),
            localOffset = view.getUint32(cursor + 42, true),
            next = cursor + 46 + nameLength + extraLength + commentLength;
          if (flags || method !== 0 || compressed !== size || next > offset + centralSize)
            throw Error("FFPX는 압축되지 않은 STORE ZIP만 지원합니다.");
          let name = decoder.decode(bytes.subarray(cursor + 46, cursor + 46 + nameLength));
          if (
            !name ||
            name.includes("..") ||
            name.startsWith("/") ||
            assets.has(name) ||
            localOffset + 30 > bytes.length ||
            view.getUint32(localOffset, true) !== 0x04034b50
          )
            throw Error("FFPX 자산 경로가 올바르지 않습니다.");
          let localNameLength = view.getUint16(localOffset + 26, true),
            localExtraLength = view.getUint16(localOffset + 28, true),
            start = localOffset + 30 + localNameLength + localExtraLength;
          if (start + size > bytes.length) throw Error("FFPX 자산 범위를 벗어났습니다.");
          let data = bytes.slice(start, start + size);
          if (ffpxCrc32(data) !== crc) throw Error("FFPX 자산 CRC 검증에 실패했습니다.");
          assets.set(name, data);
          cursor = next;
        }
        return assets;
      }
      function ffpxCsv(rows) {
        let quote = (value) => '"' + String(value ?? "").replace(/"/g, '""') + '"';
        return (rows || [])
          .map((row) => (Array.isArray(row) ? row : []).map(quote).join(","))
          .join("\r\n");
      }
      function parseProjectCsvAsset(name, bytes) {
        let text = new TextDecoder().decode(bytes);
        if (String(name).toLowerCase().endsWith(".json")) {
          let data = JSON.parse(text);
          if (!Array.isArray(data) && Array.isArray(data?.data)) data = data.data;
          return dataTable(data);
        }
        return parseCSV(text);
      }
      function projectCsvDataRef(csv) {
        return `data/${csv.id}/${projectCsvName(csv.name)}`;
      }
      function ffpxDataUrlBytes(url) {
        let match = /^data:([^,]*),(.*)$/s.exec(url || "");
        if (!match) throw Error("이미지 데이터 URL이 올바르지 않습니다.");
        let meta = match[1].split(";"),
          mime = meta[0] || "application/octet-stream",
          base64 = meta.slice(1).some((value) => value.toLowerCase() === "base64");
        return {
          mime,
          data: base64
            ? ffpxBase64ToBytes(match[2])
            : new TextEncoder().encode(decodeURIComponent(match[2])),
        };
      }
      function ffpxMimeExtension(mime) {
        return (
          {
            "image/png": "png",
            "image/jpeg": "jpg",
            "image/gif": "gif",
            "image/webp": "webp",
            "image/bmp": "bmp",
            "image/svg+xml": "svg",
          }[mime] || "bin"
        );
      }
      function ffpxXmlEscape(value) {
        return String(value)
          .replaceAll("&", "&amp;")
          .replaceAll("<", "&lt;")
          .replaceAll(">", "&gt;")
          .replaceAll('"', "&quot;")
          .replaceAll("'", "&apos;");
      }
      function ffpxXmlValue(value) {
        if (value === null) return '<value type="null"/>';
        if (Array.isArray(value))
          return `<value type="array">${value
            .map((item) => `<item>${ffpxXmlValue(item)}</item>`)
            .join("")}</value>`;
        if (typeof value === "object")
          return `<value type="object">${Object.entries(value)
            .map(
              ([name, item]) =>
                `<property name="${ffpxXmlEscape(name)}">${ffpxXmlValue(item)}</property>`,
            )
            .join("")}</value>`;
        return `<value type="${typeof value}">${ffpxXmlEscape(value)}</value>`;
      }
      function ffpxXmlReadValue(element) {
        if (!element || element.tagName !== "value")
          throw Error("FFPX XML 값 형식이 올바르지 않습니다.");
        let type = element.getAttribute("type");
        if (type === "null") return null;
        if (type === "array")
          return [...element.children]
            .filter((child) => child.tagName === "item")
            .map((item) => ffpxXmlReadValue(item.firstElementChild));
        if (type === "object") {
          let result = {};
          for (let property of element.children) {
            if (property.tagName !== "property") continue;
            result[property.getAttribute("name") || ""] = ffpxXmlReadValue(
              property.firstElementChild,
            );
          }
          return result;
        }
        if (type === "boolean") return element.textContent === "true";
        if (type === "number") {
          let number = Number(element.textContent);
          if (!Number.isFinite(number)) throw Error("FFPX XML 숫자 값이 올바르지 않습니다.");
          return number;
        }
        if (type === "string") return element.textContent;
        throw Error("FFPX XML 값 유형이 올바르지 않습니다.");
      }
      function ffpxXmlDocument(root, version, children) {
        return `<?xml version="1.0" encoding="UTF-8"?><${root} version="${version}">${children}</${root}>`;
      }
      function ffpxReadXmlDocument(assets, name, root) {
        let bytes = assets.get(name);
        if (!bytes) throw Error(`FFPX ${name}이 없습니다.`);
        let documentNode = new DOMParser().parseFromString(
            new TextDecoder().decode(bytes),
            "application/xml",
          ),
          rootNode = documentNode.documentElement;
        if (
          documentNode.querySelector("parsererror") ||
          rootNode?.tagName !== root ||
          rootNode.getAttribute("version") !== String(PACKAGE_FORMAT_VERSION)
        )
          throw Error(`FFPX ${name} 형식이 올바르지 않습니다.`);
        return rootNode;
      }
      function ffpxNamedValue(root, name) {
        let node = [...root.children].find((child) => child.tagName === name);
        if (!node?.firstElementChild)
          throw Error(`FFPX ${name} 값이 없습니다.`);
        return ffpxXmlReadValue(node.firstElementChild);
      }
      function ffpxDeriveHiddenSlots(slotList) {
        let byCell = new Map(
          slotList.map((slot) => [`${Number(slot.row)},${Number(slot.col)}`, slot]),
        );
        slotList.forEach((slot) => {
          slot.hidden = false;
        });
        for (let anchor of slotList) {
          let rowSpan = Number(anchor.rowSpan) || 1,
            colSpan = Number(anchor.colSpan) || 1;
          if (rowSpan === 1 && colSpan === 1) continue;
          for (let row = Number(anchor.row); row < Number(anchor.row) + rowSpan; row++)
            for (let col = Number(anchor.col); col < Number(anchor.col) + colSpan; col++) {
              if (row === Number(anchor.row) && col === Number(anchor.col)) continue;
              let covered = byCell.get(`${row},${col}`);
              if (!covered) throw Error("FFPX 병합 영역에 대응하는 슬롯이 없습니다.");
              if (covered.chart != null || covered.imageId != null)
                throw Error("FFPX 병합 영역의 가려진 슬롯은 비어 있어야 합니다.");
              covered.hidden = true;
            }
        }
        return slotList;
      }
      function ffpxBuildProject() {
        validateProjectObject(activeProject, { requireSlots: true });
        let projectObject = projectObjects.read("project"),
          layoutObject = projectObjects.read("layout"),
          labelObject = projectObjects.read("labels"),
          captionObject = projectObjects.read("captions"),
          dataObjects = projectObjects.read("data").filter((csv) => !projectVfs.isTrashed(projectAssetPath(csv))),
          imageObjects = projectObjects.read("images").filter((image) => !projectVfs.isTrashed(projectAssetPath(image))),
          chartObjects = projectObjects.read("charts"),
          slotObjects = projectObjects.read("slots"),
          appearanceObject = projectObjects.read("appearance"),
          exportObject = projectObjects.read("export"),
          manifest = {
            schema: "fast-figure-project",
            version: PACKAGE_FORMAT_VERSION,
            appBuild: projectObject.appBuild,
            projectName: projectObject.projectName,
            exportedAt: new Date().toISOString(),
            gridRows: layoutObject.gridRows,
            gridCols: layoutObject.gridCols,
            csvFiles: [],
            images: [],
            charts: [],
            slots: [],
            annotations: {
              labelsEnabled: labelObject.enabled,
              labelSettings: projectClone(labelObject.settings),
              captionsEnabled: captionObject.enabled,
              captionText: captionObject.text,
              captionAfterText: captionObject.afterText,
              captionName: captionObject.name,
              captionNameBold: captionObject.nameBold,
              captionSettings: projectClone(captionObject.settings),
            },
            slotStyle: projectClone(layoutObject.slotStyle),
            uiPalette: projectClone(appearanceObject.uiPalette),
            export: projectClone(exportObject),
          },
          assets = [];
        for (let csv of dataObjects) {
          let copy = projectClone(csv),
            dataRef = `assets/${projectCsvDataRef(copy)}`;
          delete copy.rows;
          delete copy.bytesBase64;
          copy.dataRef = dataRef;
          manifest.csvFiles.push(copy);
          assets.push({
            name: dataRef,
            data: ffpxBase64ToBytes(csv.bytesBase64),
          });
        }
        for (let image of imageObjects) {
          let copy = projectClone(image),
            dataRef = `assets/media/${image.id}/${projectCsvName(image.name, "image.bin")}`;
          delete copy.bytesBase64;
          delete copy.settings;
          copy.dataRef = dataRef;
          manifest.images.push(copy);
          assets.push({ name: dataRef, data: ffpxBase64ToBytes(image.bytesBase64) });
        }
        for (let chart of chartObjects) {
          chartCsvIds(chart).forEach((id) => {
            let csv = getProjectCsv(id);
            if (!csv || projectVfs.isTrashed(projectAssetPath(csv)))
              throw Error(`FFPX 차트가 내보낼 수 없는 CSV ${id}를 참조합니다.`);
          });
          manifest.charts.push(chartExportCopy(chart));
        }
        for (let slot of slotObjects) {
          let copy = projectClone(slot);
          if (copy.imageId != null) {
            let image = getProjectImage(copy.imageId);
            if (!image || projectVfs.isTrashed(projectAssetPath(image)))
              throw Error(`FFPX 슬롯이 내보낼 수 없는 이미지 ${copy.imageId}를 참조합니다.`);
          }
          manifest.slots.push(copy);
        }
        let projectDocument = {
            schema: manifest.schema,
            version: manifest.version,
            appBuild: manifest.appBuild,
            projectName: manifest.projectName,
            exportedAt: manifest.exportedAt,
            fileSystem: {
              directories: projectObjects
                .read("files")
                .directories.filter((path) => !projectVfs.isTrashed(path)),
            },
            appearance: {
              slotStyle: manifest.slotStyle,
              uiPalette: manifest.uiPalette,
            },
            export: manifest.export,
          },
          layoutDocument = {
            gridRows: manifest.gridRows,
            gridCols: manifest.gridCols,
            placements: manifest.slots.map((slot) => ({
              slotId: slot.id,
              row: slot.row,
              col: slot.col,
              rowSpan: slot.rowSpan,
              colSpan: slot.colSpan,
            })),
          },
          captionDocument = {
            enabled: manifest.annotations.captionsEnabled,
            beforeText: manifest.annotations.captionText,
            afterText: manifest.annotations.captionAfterText,
            name: manifest.annotations.captionName,
            nameBold: manifest.annotations.captionNameBold,
            settings: manifest.annotations.captionSettings,
          },
          labelDocument = {
            enabled: manifest.annotations.labelsEnabled,
            settings: manifest.annotations.labelSettings,
          },
          slotDocuments = manifest.slots.map((slot) => {
            let chart = manifest.charts.find((item) => item.id === slot.chart),
              image = imageObjects.find((item) => item.id === slot.imageId),
              graphObjects = chart?.editor?.objects || [],
              chartState = chart
                ? {
                    ...projectClone(chart),
                    editor: {
                      ...projectClone(chart.editor || {}),
                      objects: [],
                    },
                  }
                : null;
            return {
              slot: {
                id: slot.id,
                contentType: slot.contentType,
              },
              caption: {
                text: typeof slot.caption === "string" ? slot.caption : null,
              },
              graphObjects: chart
                ? graphObjects.map((object) => projectClone(object))
                : [],
              chartState,
              imageObject: image
                ? {
                    imageRef: image.id,
                    settings: projectClone(slot.imageSettings || DEFAULT_IMAGE_SETTINGS),
                  }
                : null,
            };
          }),
          refs =
            '<assets ref="assets/assets.xml"/><slots ref="slots/"/><layout ref="layout/layout.xml"/><caption ref="caption/caption.xml"/><labels ref="labels/labels.xml"/>';
        manifest.slots.forEach((slot) => {
          delete slot.row;
          delete slot.col;
          delete slot.rowSpan;
          delete slot.colSpan;
        });
        return {
          manifest,
          assets: [
            {
              name: "project.xml",
              data: new TextEncoder().encode(
                ffpxXmlDocument(
                  "fastFigureProject",
                  PACKAGE_FORMAT_VERSION,
                  `${refs}<settings>${ffpxXmlValue(projectDocument)}</settings>`,
                ),
              ),
            },
            {
              name: "assets/assets.xml",
              data: new TextEncoder().encode(
                ffpxXmlDocument(
                  "fastFigureAssets",
                  PACKAGE_FORMAT_VERSION,
                  `<dataAssets>${manifest.csvFiles
                    .map(
                      (csv) =>
                        `<dataAsset id="${csv.id}" src="${ffpxXmlEscape(csv.dataRef)}">${ffpxXmlValue(csv)}</dataAsset>`,
                    )
                    .join("")}</dataAssets><imageAssets>${manifest.images
                    .map(
                      (image) =>
                        `<imageAsset id="${image.id}" src="${ffpxXmlEscape(image.dataRef)}">${ffpxXmlValue(image)}</imageAsset>`,
                    )
                    .join("")}</imageAssets>`,
                ),
              ),
            },
            {
              name: "layout/layout.xml",
              data: new TextEncoder().encode(
                ffpxXmlDocument(
                  "fastFigureLayout",
                  PACKAGE_FORMAT_VERSION,
                  `<layout>${ffpxXmlValue(layoutDocument)}</layout>`,
                ),
              ),
            },
            {
              name: "caption/caption.xml",
              data: new TextEncoder().encode(
                ffpxXmlDocument(
                  "fastFigureCaption",
                  PACKAGE_FORMAT_VERSION,
                  `<caption>${ffpxXmlValue(captionDocument)}</caption>`,
                ),
              ),
            },
            {
              name: "labels/labels.xml",
              data: new TextEncoder().encode(
                ffpxXmlDocument(
                  "fastFigureLabels",
                  PACKAGE_FORMAT_VERSION,
                  `<labels>${ffpxXmlValue(labelDocument)}</labels>`,
                ),
              ),
            },
            ...slotDocuments.map((document) => ({
              name: `slots/slot-${document.slot.id}.xml`,
              data: new TextEncoder().encode(
                ffpxXmlDocument(
                  "fastFigureSlot",
                  PACKAGE_FORMAT_VERSION,
                  `<slot id="${document.slot.id}" contentType="${ffpxXmlEscape(
                    document.slot.contentType,
                  )}"><settings>${ffpxXmlValue(document.slot)}</settings><caption>${ffpxXmlValue(
                    document.caption,
                  )}</caption>${
                    document.chartState
                      ? `<graph><settings>${ffpxXmlValue(
                          document.chartState,
                        )}</settings><graphObjects>${document.graphObjects
                          .map(
                            (object, index) =>
                              `<graphObject index="${index}">${ffpxXmlValue(object)}</graphObject>`,
                          )
                          .join("")}</graphObjects></graph>`
                      : ""
                  }${
                    document.imageObject
                      ? `<imageObject imageRef="${document.imageObject.imageRef}">${ffpxXmlValue(
                          document.imageObject,
                        )}</imageObject>`
                      : ""
                  }</slot>`,
                ),
              ),
            })),
            ...assets,
          ],
        };
      }
      async function ffpxReadProject(file) {
        let assets = ffpxZipRead(new Uint8Array(await file.arrayBuffer())),
          xmlBytes = assets.get("project.xml");
        if (!xmlBytes) throw Error("FFPX project.xml이 없습니다.");
        let projectRoot = ffpxReadXmlDocument(
              assets,
              "project.xml",
              "fastFigureProject",
            ),
            project = ffpxNamedValue(projectRoot, "settings"),
            assetRoot = ffpxReadXmlDocument(
              assets,
              "assets/assets.xml",
              "fastFigureAssets",
            ),
            layoutRoot = ffpxReadXmlDocument(
              assets,
              "layout/layout.xml",
              "fastFigureLayout",
            ),
            captionRoot = ffpxReadXmlDocument(
              assets,
              "caption/caption.xml",
              "fastFigureCaption",
            ),
            labelRoot = ffpxReadXmlDocument(
              assets,
              "labels/labels.xml",
              "fastFigureLabels",
            ),
            layout = ffpxNamedValue(layoutRoot, "layout"),
            caption = ffpxNamedValue(captionRoot, "caption"),
            labels = ffpxNamedValue(labelRoot, "labels"),
            csvFiles = [...assetRoot.querySelectorAll("dataAsset")].map((node) =>
              ffpxXmlReadValue(node.firstElementChild),
            ),
            images = [...assetRoot.querySelectorAll("imageAsset")].map((node) =>
              ffpxXmlReadValue(node.firstElementChild),
            ),
            charts = [],
            slots = [];
          debugLog("project:read-version", {
            format: "FFPX",
            appBuild: typeof project?.appBuild === "string" ? project.appBuild : null,
          });
          for (let placement of layout.placements || []) {
            let slotRoot = ffpxReadXmlDocument(
                assets,
                `slots/slot-${placement.slotId}.xml`,
                "fastFigureSlot",
              ),
              slotNode = slotRoot.querySelector(":scope > slot"),
              slotSettings = ffpxXmlReadValue(
                slotNode.querySelector(":scope > settings > value"),
              ),
              slotCaption = ffpxXmlReadValue(
                slotNode.querySelector(":scope > caption > value"),
              ),
              graphNode = slotNode.querySelector(":scope > graph"),
              imageNode = slotNode.querySelector(":scope > imageObject"),
              chart = graphNode
                ? ffpxXmlReadValue(
                    graphNode.querySelector(":scope > settings > value"),
                  )
                : null;
            if (chart) {
              chart.editor.objects = [
                ...graphNode.querySelectorAll(":scope > graphObjects > graphObject"),
              ].map((node) => ffpxXmlReadValue(node.firstElementChild));
              charts.push(chart);
            }
            let imageObject = imageNode
              ? ffpxXmlReadValue(imageNode.firstElementChild)
              : null;
            slots.push({
              ...slotSettings,
              ...placement,
              id: placement.slotId,
              chart: chart?.id ?? null,
              imageId: imageObject?.imageRef ?? null,
              imageSettings: readImageSettings(imageObject?.settings),
              caption:
                typeof slotCaption?.text === "string" ? slotCaption.text : null,
            });
          }
          ffpxDeriveHiddenSlots(slots);
          let appearance =
            project.appearance && typeof project.appearance === "object"
              ? project.appearance
              : {};
          let payload = {
            ...project,
            schema: "fast-figure-project",
            version: PACKAGE_FORMAT_VERSION,
            gridRows: layout.gridRows,
            gridCols: layout.gridCols,
            slotStyle: appearance.slotStyle,
            uiPalette: appearance.uiPalette,
            csvFiles,
            images,
            charts,
            slots,
            annotations: {
              labelsEnabled: labels.enabled,
              labelSettings: labels.settings,
              captionsEnabled: caption.enabled,
              captionText: caption.beforeText,
              captionAfterText: caption.afterText,
              captionName: caption.name,
              captionNameBold: caption.nameBold,
              captionSettings: caption.settings,
            },
          };
        if (
          payload?.schema !== "fast-figure-project" ||
          payload.version !== PACKAGE_FORMAT_VERSION ||
          !Array.isArray(payload.charts) ||
          !Array.isArray(payload.slots)
        )
          throw Error("지원하지 않는 FFPX 프로젝트 형식입니다.");
        if (!Array.isArray(payload.csvFiles)) throw Error("FFPX CSV 목록이 없습니다.");
        for (let csv of payload.csvFiles) {
          let dataRef = csv?.dataRef;
          if (
            !csv ||
            !Number.isInteger(csv.id) ||
            typeof csv.name !== "string" ||
            typeof dataRef !== "string" ||
            !dataRef.startsWith("assets/data/") ||
            !assets.has(dataRef)
          )
            throw Error("FFPX CSV 자산이 없습니다.");
          csv.rows = parseProjectCsvAsset(csv.name, assets.get(dataRef));
          csv.bytesBase64 = ffpxBytesToBase64(assets.get(dataRef));
          delete csv.dataRef;
        }
        if (!Array.isArray(payload.images)) throw Error("FFPX 이미지 목록이 없습니다.");
        for (let image of payload.images) {
          let dataRef = image?.dataRef;
          if (
            !image ||
            !Number.isInteger(image.id) ||
            typeof image.name !== "string" ||
            typeof dataRef !== "string" ||
            !dataRef.startsWith("assets/media/") ||
            !assets.has(dataRef)
          )
            throw Error("FFPX 이미지 자산이 없습니다.");
          image.bytesBase64 = ffpxBytesToBase64(assets.get(dataRef));
          delete image.dataRef;
        }
        return payload;
      }
      function projectFileStem(value) {
        let stem = String(value || "")
          .trim()
          .replace(/[\\/:*?"<>|\x00-\x1F]/g, "-")
          .replace(/\s+/g, " ")
          .replace(/[. ]+$/, "")
          .slice(0, 100);
        return stem || "fast-figure-project";
      }
      function downloadProject() {
        if (getSelectedSlot())
          return status("프로젝트 내보내기는 슬롯 선택을 해제한 뒤 사용할 수 있습니다.");
        try {
          activeProject.projectName = String(activeProject.projectName || "").trim().slice(0, 120);
          let project = ffpxBuildProject(),
            blob = new Blob([ffpxZipStore(project.assets)], {
              type: "application/vnd.fast-figure-project",
            }),
            link = document.createElement("a"),
            stamp = new Date().toISOString().replace(/[:.]/g, "-");
          link.href = URL.createObjectURL(blob);
          link.download = `${projectFileStem(activeProject.projectName)}-${stamp}.ffpx`;
          link.click();
          setTimeout(() => URL.revokeObjectURL(link.href), 0);
          status(`${activeProject.projectName || "프로젝트"}를 FFPX 파일로 내보냈습니다.`);
          debugLog("project:export-ffpx", {
            projectName: activeProject.projectName,
            charts: activeProject.charts.length,
            slots: activeProject.slots.length,
            assets: project.assets.length,
          });
        } catch (error) {
          status("FFPX 내보내기 오류: " + error.message);
          debugLog("project:export-error", { message: error.message });
        }
      }
      function downloadProjectAsset(path = appFSM.state.assetPath) {
        let selected = path ? projectVfs.resolve(path) : null,
          asset = ["csv", "image"].includes(selected?.kind) ? selected.asset : null;
        if (!asset?.bytesBase64) {
          status("다운로드할 CSV 또는 이미지 에셋을 선택하세요.");
          return false;
        }
        let url = URL.createObjectURL(
            new Blob([ffpxBase64ToBytes(asset.bytesBase64)], {
              type: asset.mime || "application/octet-stream",
            }),
          ),
          link = document.createElement("a");
        link.href = url;
        link.download = asset.name;
        link.click();
        setTimeout(() => URL.revokeObjectURL(url), 0);
        status(`${asset.name} 원본 에셋을 다운로드했습니다.`);
        return true;
      }
      function selectDirectoryFromTree(path) {
        let match = projectVfs.resolve(path);
        if (match?.kind !== "directory") return status("프로젝트 폴더를 선택할 수 없습니다.");
        appFSM.send("SELECT_ASSET", {
          kind: "directory",
          path: match.path,
          direction: "ui-to-fsm",
        });
        status(`${match.path} 폴더를 선택했습니다.`);
      }
      function selectCsvFromTree(path) {
        let slot = getSelectedSlot(),
          match = projectVfs.resolve(path),
          csv = match?.kind === "csv" ? match.asset : null;
        if (!csv) return status("프로젝트 CSV를 선택할 수 없습니다.");
        appFSM.send("CLEAR_GRAPH_OBJECT", {
          index: null,
          direction: "ui-to-fsm",
        });
        appFSM.send("SELECT_ASSET", {
          kind: "csv",
          path: projectAssetPath(csv),
          direction: "ui-to-fsm",
        });
        updateFileAvailability();
        if (!slot) {
          status(`${csv.name}을 선택했습니다.`);
          return;
        }
        if (slot.contentType === "image")
          return status(`${csv.name}을 선택했습니다. 그래프 슬롯에서만 새 그래프를 추가할 수 있습니다.`);
        status(`${csv.name}을 선택했습니다. 기존 그래프 데이터는 변경하지 않았습니다.`);
      }
      function selectImageFromTree(path) {
        let slot = getSelectedSlot(),
          match = projectVfs.resolve(path),
          image = match?.kind === "image" ? match.asset : null;
        if (!image) return status("프로젝트 이미지를 먼저 선택하세요.");
        appFSM.send("CLEAR_GRAPH_OBJECT", {
          index: null,
          direction: "ui-to-fsm",
        });
        appFSM.send("SELECT_ASSET", {
          kind: "image",
          path: projectAssetPath(image),
          direction: "ui-to-fsm",
        });
        updateFileAvailability();
        if (!slot) {
          status(`${image.name}을 선택했습니다.`);
          return;
        }
        if (slot.contentType !== "image")
          return status("이미지를 연결하려면 이미지 슬롯을 선택하세요.");
        appFSM.send("SLOT_IMAGE_LINKED", {
          slotId: slot.id,
          imageId: image.id,
          direction: "fsm-to-model",
        });
        updateFileAvailability();
        renderDashboard();
        status(`${image.name}을 선택 슬롯에 연결했습니다.`);
      }
      function insertEmptyImageIntoSelectedSlot() {
        let slot = getSelectedSlot();
        if (!slot || slot.contentType !== "image")
          return status("빈 이미지를 삽입할 이미지 슬롯을 먼저 선택하세요.");
        let svg =
            '<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="900" viewBox="0 0 1600 900"></svg>',
          image = buildProjectImageModel(
            new TextEncoder().encode(svg),
            "빈 이미지.svg",
            "image/svg+xml",
            activeProject.imageId,
          );
        appFSM.send("SLOT_IMAGE_IMPORTED", {
          slotId: slot.id,
          model: image,
          direction: "fsm-to-model",
        });
        updateFileAvailability();
        renderDashboard();
        status("선택 슬롯에 빈 이미지를 삽입했습니다.");
        return image;
      }
      function setSlotContentType(type) {
        let slot = getSelectedSlot();
        if (!slot) {
          appFSM.send("SLOT_TYPE_CHANGED", {
            slotId: null,
            type,
            direction: "fsm-to-model",
          });
          debugLog("slot:content-type-pending", { type, direction: "fsm-to-model" });
          return;
        }
        appFSM.send("SLOT_TYPE_CHANGED", {
          slotId: slot.id,
          type,
          direction: "fsm-to-model",
        });
        renderDashboard();
        debugLog("slot:content-type", {
          slotId: slot.id,
          type,
          direction: "fsm-to-model",
        });
      }
      function syncSlotImageElement(slot,image) {
        let element=slot&&document.querySelector(`.slot[data-slot="${slot.id}"] .slot-image`);
        if(!element||!image)return false;
        let settings=normalizeImageSettings(slot);
        element.classList.toggle("manual",settings.fit==="manual");
        element.removeAttribute("style");
        if(settings.fit==="manual"){
          element.style.width=`${settings.scale}%`;
          element.style.left=`${settings.x}%`;
          element.style.top=`${settings.y}%`;
        } else element.style.objectFit=settings.fit;
        return true;
      }
      function applyImageSettingsFromValues(values={}) {
        let slot=getSelectedSlot(), image=slotImage(slot);
        if(!slot||!image)return false;
        let current=normalizeImageSettings(slot),
          next={...current,fit:["contain","cover","manual"].includes(values.fit)?values.fit:current.fit};
        if(next.fit==="manual"){
          next.scale=Math.max(1,Math.min(1000,Number(values.scale)||100));
          next.x=Math.max(-100,Math.min(200,Number(values.x)||50));
          next.y=Math.max(-100,Math.min(200,Number(values.y)||50));
        }
        slot.content.imageSettings=readImageSettings(next);
        validateProjectObject(activeProject,{requireSlots:true});
        syncSlotImageElement(slot,image);
        appFSM.notify("images","IMAGE_SETTINGS_CHANGED");
        return readImageEditorApi();
      }
      function readSelectedSlotApi() {
        let slot = getSelectedSlot();
        return slot ? {
          id: slot.id, row: slot.row, col: slot.col,
          contentType: slot.contentType, chart: slot.chart, imageId: slot.imageId,
        } : null;
      }
      function resetSlotApi(slotId) {
        let payload = { slotIds: [slotId], direction: "fsm-to-model" };
        appFSM.send("SLOTS_RESET", payload);
        appFSM.send("CLEAR_ASSET_SELECTION", { direction: "fsm-to-model" });
        renderDashboard();
        status("선택한 슬롯을 초기화했습니다.");
        debugLog("slotReset:complete", {
          slotId, removedChartIds: payload.removedChartIds,
        });
      }
      function prepareDashboardFileDrop(slotId) {
        let slot = slotAt(slotId);
        clearSlotDragState();
        if (!slot || slot.hidden) return false;
        if (!isSlotSelected(slot)) setSelectedSlot(slot.id);
        return true;
      }
      function finishDashboardFileDrop() {
        setTimeout(() => { slotDragSuppressClick = false; }, 0);
      }
      function readImageEditorApi() {
        let slot=getSelectedSlot(), image=slotImage(slot);
        return image&&slot?{
          name:image.name,
          src:projectImageDisplayUrl(image),
          settings:Object.freeze({...normalizeImageSettings(slot)}),
        }:null;
      }
      function setProjectName(value, trim = false) {
        activeProject.projectName = (trim ? String(value).trim() : String(value)).slice(0, 120);
        if (trim) debugLog("project:name", { projectName: activeProject.projectName });
        return activeProject.projectName;
      }
      async function loadImageFile(
        file,
        slot,
        { assetPath = null, replaceAssetId = null, planImport = null } = {},
      ) {
        try {
          if (!assetPath && typeof planImport !== "function")
            throw Error("프로젝트 이미지 가져오기 계획이 없습니다.");
          let bytes = new Uint8Array(await file.arrayBuffer()),
            plan = assetPath
              ? { path: normalizeProjectPath(assetPath), replaceId: replaceAssetId }
              : await planImport(file, PROJECT_ASSET_DIRECTORIES.image),
            image;
          if (Number.isInteger(plan.replaceId)) {
            image = buildProjectImageModel(
              bytes,
              file.name,
              file.type,
              plan.replaceId,
            );
            projectVfs.assignLocation(image, plan.path);
            appFSM.send("IMAGE_OBJECT_REPLACED", {
              model: image,
              direction: "fsm-to-model",
            });
            if (slot)
              appFSM.send("SLOT_IMAGE_LINKED", {
                slotId: slot.id,
                imageId: image.id,
                direction: "fsm-to-model",
              });
          } else if (slot) {
            image = buildProjectImageModel(bytes, file.name, file.type, activeProject.imageId);
            projectVfs.assignLocation(image, plan.path);
            appFSM.send("SLOT_IMAGE_IMPORTED", {
              slotId: slot.id,
              model: image,
              direction: "fsm-to-model",
            });
          } else image = createProjectImage(bytes, file.name, file.type, null, null, plan.path);
          updateFileAvailability();
          renderDashboard();
          status(
            slot
              ? `${file.name} 이미지를 선택 슬롯에 연결했습니다.`
              : Number.isInteger(plan.replaceId)
                ? `${file.name} 이미지를 기존 참조를 유지한 채 교체했습니다.`
                : `${file.name} 이미지를 프로젝트에 추가했습니다.`,
          );
          debugLog("slot:image-load", { slotId: slot?.id ?? null, name: file.name });
        } catch (error) {
          status("이미지 불러오기 실패: " + error.message);
          throw error;
        }
      }
      function slotFileKind(file) {
        let name = String(file?.name || "").toLowerCase(),
          type = String(file?.type || "").toLowerCase();
        if (name.endsWith(".ffsx")) return "slot";
        if (name.endsWith(".csv") || name.endsWith(".tsv") || name.endsWith(".json")) return "data";
        if (type.startsWith("image/") || /\.(png|jpe?g|gif|webp|bmp|svg)$/i.test(name))
          return "image";
        return "";
      }
      function dataTransferHasFiles(dataTransfer) {
        return Array.from(dataTransfer?.types || []).includes("Files");
      }
      async function loadDataFile(
        file,
        slot,
        { replaceSlotContent = false, assetPath = null, replaceAssetId = null, planImport = null } = {},
      ) {
        debugLog("fileLoad:start", {
          name: file.name,
          size: file.size,
          slotId: slot?.id ?? null,
          source: "shared-loader",
        });
        let csv = null;
        try {
          let bytes = new Uint8Array(await file.arrayBuffer()),
            text = new TextDecoder().decode(bytes),
            data = file.name.toLowerCase().endsWith(".json") ? JSON.parse(text) : parseCSV(text);
          if (!Array.isArray(data) && Array.isArray(data.data)) data = data.data;
          if (!Array.isArray(data)) throw Error("지원하는 데이터 배열 형식이 아닙니다.");
          if (!assetPath && typeof planImport !== "function")
            throw Error("프로젝트 데이터 가져오기 계획이 없습니다.");
          let plan = assetPath
            ? { path: normalizeProjectPath(assetPath), replaceId: replaceAssetId }
            : await planImport(file, PROJECT_ASSET_DIRECTORIES.csv);
          if (Number.isInteger(plan.replaceId)) {
            csv = buildProjectCsvModel(
              data,
              file.name,
              plan.replaceId,
              ffpxBytesToBase64(bytes),
              file.type || "text/csv",
              1,
            );
            projectVfs.assignLocation(csv, plan.path);
            appFSM.send("DATA_OBJECT_REPLACED", {
              model: csv,
              direction: "fsm-to-model",
            });
          } else
            csv = createProjectCsv(
              data,
              file.name,
              null,
              ffpxBytesToBase64(bytes),
              file.type || "text/csv",
              1,
              plan.path,
            );
          if (slot) {
            connectDataToSlot(slot, data, file.name, csv, { replaceSlotContent });
          }
          status(
            Number.isInteger(plan.replaceId)
              ? `${file.name}을 기존 참조를 유지한 채 교체했습니다.`
              : `${file.name}을 프로젝트 CSV로 추가했습니다.`,
          );
          debugLog("fileLoad:complete", {
            name: file.name,
            rows: csv.rows.length,
            slotId: slot?.id ?? null,
            chartId: slot?.chart || null,
            csvId: csv.id,
          });
        } catch (error) {
          if (
            csv &&
            !activeProject.charts.some((chart) => chartCsvIds(chart).includes(csv.id))
          )
            appFSM.send("DATA_OBJECT_DELETED", {
              csvId: csv.id,
              direction: "fsm-to-model",
            });
          debugLog("fileLoad:error", {
            name: file.name,
            slotId: slot?.id ?? null,
            message: error.message,
          });
          throw error;
        }
      }
      function baseGraphObject(chart, csv = selectedProjectCsv()) {
        let editor = chart.editor || {};
        if (!csv) throw Error("그래프 오브젝트에 연결할 프로젝트 CSV가 없습니다.");
        let selection = graphDataSelection(csv.rows, csv.headerLines, editor);
        return {
          csvId: csv.id,
          x: selection.x,
          y: selection.y,
          xAxisSide: editor.xAxisSide || "bottom",
          yAxisSide: editor.yAxisSide || "left",
          type: editor.type || "scatter",
          color: editor.colors?.[0] || DEFAULT_COLORS[0],
          legendName: editor.legendName || "",
          lineWidth: Math.max(0.1, Math.min(20, Number(editor.lineWidth) || 2)),
          lineDash: editor.lineDash || "solid",
          markerSymbol: editor.markerSymbol || "circle",
          markerSize: Math.max(1, Math.min(40, Number(editor.markerSize) || 6)),
          barOpacity: Math.max(0.05, Math.min(1, Number(editor.barOpacity) || 1)),
          barLineWidth: Math.max(0, Math.min(10, Number(editor.barLineWidth) || 0)),
        };
      }
      function normalizedGraphObjects(chart) {
        if(!chart)return [];
        if(chart.editor?.editable===false)
          return projectClone(Array.isArray(chart.editor?.objects)?chart.editor.objects:[]);
        return (Array.isArray(chart.editor?.objects)?chart.editor.objects:[]).map((object,index)=>{
          let csv=getProjectCsv(object?.csvId);
          if(!csv)throw Error(`그래프 객체 ${index+1}에 연결할 프로젝트 CSV가 없습니다.`);
          let selection=graphDataSelection(csv.rows,csv.headerLines,object||{});
          return {...baseGraphObject(chart,csv),...(object||{}),csvId:csv.id,x:selection.x,y:selection.y};
        });
      }
      function ensureGraphObjects(chart) {
        if (!chart) return [];
        chart.editor = chart.editor || {};
        chart.editor.objects = normalizedGraphObjects(chart);
        return chart.editor.objects;
      }
      function graphEditorChart() {
        let slot = getSelectedSlot();
        return slot?.chart ? getChart(slot.chart) : null;
      }
      function graphEditorCommit(objects,index=null) {
        let chart=graphEditorChart();
        if(!chart)return null;
        let payload={chartId:chart.id,objects:[...objects],index,direction:"fsm-to-model"};
        appFSM.send("GRAPH_OBJECTS_REPLACED",payload);
        chart=payload.chart;
        let selected=Number.isInteger(index)&&index>=0&&index<chart.editor.objects.length?index:null;
        appFSM.send(selected===null?"CLEAR_GRAPH_OBJECT":"SELECT_GRAPH_OBJECT",
          {index:selected,direction:"fsm-to-model"});
        renderDashboard(); updateFileAvailability();
        appFSM.notify("charts","GRAPH_OBJECTS_CHANGED");
        return chart;
      }
      function graphEditorSelectCsv(csvId) {
        let csv = getProjectCsv(Number(csvId));
        if (!csv) return null;
        appFSM.send("SELECT_ASSET", { kind: "csv", path: projectAssetPath(csv), direction: "ui-to-fsm" });
        appFSM.notify("data", "CSV_SELECTION_CHANGED");
        return csv;
      }
      function graphEditorSelectObject(index) {
        let chart = graphEditorChart(), objects = ensureGraphObjects(chart);
        let selected = Number.isInteger(index) && index >= 0 && index < objects.length ? index : null;
        appFSM.send(selected === null ? "CLEAR_GRAPH_OBJECT" : "SELECT_GRAPH_OBJECT", { index: selected, direction: "fsm-to-model" });
        if (selected !== null) graphEditorSelectCsv(objects[selected].csvId);
        appFSM.notify("charts", "GRAPH_OBJECT_SELECTION_CHANGED");
        return selected;
      }
      function graphEditorObjectValues(index, values = {}) {
        let chart = graphEditorChart(), objects = ensureGraphObjects(chart), current = objects[index];
        if (!chart || !current) return null;
        let csv = getProjectCsv(Number(values.csvId)) || getProjectCsv(current.csvId);
        if (!csv) return null;
        let defaults = baseGraphObject(chart, csv), columns = new Set(columnDefinitions(csv.rows, csv.headerLines).map((column) => column.id));
        let clamp = (value, fallback, min, max) => Number.isFinite(Number(value)) ? Math.max(min, Math.min(max, Number(value))) : fallback;
        let next = { ...defaults, ...current, csvId: csv.id };
        next.x = columns.has(values.x) ? values.x : columns.has(next.x) ? next.x : defaults.x;
        next.y = columns.has(values.y) ? values.y : columns.has(next.y) ? next.y : defaults.y;
        if (["bottom", "top"].includes(values.xAxisSide)) next.xAxisSide = values.xAxisSide;
        if (["left", "right"].includes(values.yAxisSide)) next.yAxisSide = values.yAxisSide;
        if (["scatter", "markers", "lines+markers", "bar", "hidden"].includes(values.type)) next.type = values.type;
        if (values.legendName !== undefined) next.legendName = String(values.legendName);
        if (values.lineDash !== undefined) next.lineDash = String(values.lineDash || "solid");
        if (values.markerSymbol !== undefined) next.markerSymbol = String(values.markerSymbol || "circle");
        if (/^#[0-9a-f]{6}$/i.test(values.color || "")) next.color = values.color;
        next.lineWidth = clamp(values.lineWidth, next.lineWidth, 0.1, 20);
        next.markerSize = clamp(values.markerSize, next.markerSize, 1, 40);
        next.barOpacity = clamp(values.barOpacity, next.barOpacity, 0.05, 1);
        next.barLineWidth = clamp(values.barLineWidth, next.barLineWidth, 0, 10);
        let updated = [...objects];
        updated[index] = next;
        return graphEditorCommit(updated, index);
      }
      function graphEditorAdd(csvId = selectedProjectCsv()?.id) {
        let slot = getSelectedSlot(), csv = getProjectCsv(Number(csvId));
        if (!slot || slot.contentType === "image" || !csv) return status("그래프 슬롯과 데이터를 먼저 선택하세요.");
        graphEditorSelectCsv(csv.id);
        let chart = graphEditorChart();
        if (!chart) {
          let payload = { slotId: slot.id, csvId: csv.id, direction: "fsm-to-model" };
          appFSM.send("SLOT_DATA_CONNECTED", payload);
          chart = payload.chart;
          if (!chart) return status("빈 슬롯에 그래프를 추가하지 못했습니다.");
          return graphEditorCommit(ensureGraphObjects(chart), 0);
        }
        let objects = ensureGraphObjects(chart);
        return graphEditorCommit([...objects, baseGraphObject(chart, csv)], objects.length);
      }
      function graphEditorMove(from, to) {
        let chart = graphEditorChart(), objects = ensureGraphObjects(chart);
        if (!chart || !objects[from] || !objects[to] || from === to) return chart;
        let next = [...objects], moved = next.splice(from, 1)[0];
        next.splice(to, 0, moved);
        return graphEditorCommit(next, to);
      }
      function graphEditorDelete(index) {
        let chart = graphEditorChart(), objects = ensureGraphObjects(chart);
        if (!chart || !objects[index]) return null;
        return graphEditorCommit(objects.filter((_, objectIndex) => objectIndex !== index), null);
      }
      function graphEditorHeaderLines(csvId, value) {
        let csv = getProjectCsv(Number(csvId));
        if (!csv) return null;
        csv.headerLines = headerLineCount(value, csv.rows);
        activeProject.charts.forEach((chart) => {
          if (chart.editor?.editable !== false && chartCsvIds(chart).includes(csv.id)) rebuildEditableGraph(chart);
        });
        renderDashboard();
        debugLog("csv:header-lines", { csvId: csv.id, headerLines: csv.headerLines });
        appFSM.notify("data", "CSV_HEADER_LINES_CHANGED");
        return csv.headerLines;
      }
      function graphEditorSetEditable(editable=null) {
        let current=graphEditorChart();
        if(!current)
          return status("편집 모드를 바꿀 그래프 슬롯을 먼저 선택하세요.");
        let next=typeof editable==="boolean"?editable:current.editor.editable===false;
        if(next===current.editor.editable) return current;

        let candidate=projectClone(activeProject._state),
          chart=candidate.charts.find(item=>item.id===current.id);
        if(!chart) throw Error("편집 상태를 변경할 차트가 없습니다.");

        let createdCsvId=null;
        if(next && chart.editor.editable===false){
          let objects=Array.isArray(chart.editor.objects)?chart.editor.objects:[],
            rows=Array.isArray(chart.editor.conversionRows)?chart.editor.conversionRows:[];
          if(objects.length){
            if(!rows.length)
              throw Error("Plotly 변환 데이터가 없어 편집 가능한 차트로 바꿀 수 없습니다.");
            let csvId=candidate.nextId.csv,
              model=buildProjectCsvModel(
                rows,
                "Plotly JSON.csv",
                csvId,
                "",
                "text/csv",
                1,
                candidate,
              );
            projectVfs.prepare(model,"csv",candidate);
            candidate.assets.csvFiles.push(model);
            candidate.nextId.csv=csvId+1;
            objects.forEach(object=>{object.csvId=model.id;});
            createdCsvId=model.id;
          }
          delete chart.editor.conversionRows;
        }

        chart.editor.editable=next;
        validateChartModel(chart,"편집 상태 변경 차트",candidate.assets.csvFiles);
        validateProjectObjectState(candidate,{requireSlots:true});
        activeProject.initialize(candidate);

        let committed=getChart(current.id);
        if(next) rebuildEditableGraph(committed);
        if(createdCsvId!==null) graphEditorSelectCsv(createdCsvId);
        renderDashboard();
        status(next
          ?"가져온 JSON을 편집기 설정으로 재구성했습니다."
          :"가져온 원본 Plotly JSON 표시로 전환했습니다.");
        debugLog("editor:editable",{chartId:committed.id,editable:next});
        appFSM.notify("charts","GRAPH_EDITABLE_CHANGED");
        return committed;
      }
      function readGraphDataApi() {
        let chart = graphEditorChart(), objects = normalizedGraphObjects(chart);
        let index = appFSM.state.graphObjectIndex;
        let selectedIndex = Number.isInteger(index) && objects[index] ? index : null;
        let csv = getProjectCsv(objects[selectedIndex]?.csvId) ||
          getProjectCsv(objects[0]?.csvId) || selectedProjectCsv() ||
          activeProject.csvFiles[0] || null;
        return {
          chartId: chart?.id ?? null,
          editable: chart?.editor?.editable !== false,
          objects: projectClone(objects),
          selectedIndex,
          csv: csv ? {
            id: csv.id, headerLines: csv.headerLines, rowCount: csv.rows.length,
            rows: projectClone(csv.rows.slice(0, 30)),
            columns: columnDefinitions(csv.rows, csv.headerLines),
          } : null,
          csvOptions: activeProject.csvFiles.map((item) => ({
            value: String(item.id), label: item.name,
          })),
        };
      }
      function readGraphLayoutApi() {
        let chart = graphEditorChart();
        return chart ? {
          chartId: chart.id,
          editable: chart.editor?.editable !== false,
          title: chart.editor?.title ?? "",
          settings: projectClone(readGlobalSettings(chart)),
        } : null;
      }
      function readGraphPaletteApi() {
        let chart = graphEditorChart();
        return {
          slotId: getSelectedSlot()?.id ?? null,
          chartId: chart?.id ?? null,
          editable: chart?.editor?.editable !== false,
          colors: normalizedGraphObjects(chart).map((object) => object.color),
        };
      }
      function importSelectedGraphFile(file) {
        return importSlotFile(file, getSelectedSlot());
      }
      function readAssetDeletionTarget() {
        let selected = appFSM.state.assetPath
          ? projectVfs.resolve(appFSM.state.assetPath) : null;
        if (!["csv", "image"].includes(selected?.kind))
          return null;
        let id = selected.asset.id;
        return {
          kind: selected.kind, id, name: selected.asset.name,
          referenceCount: selected.kind === "csv"
            ? activeProject.charts.reduce((count, chart) =>
                count + (chart.editor?.objects || []).filter((object) => object.csvId === id).length, 0)
            : activeProject.slots.filter((slot) => slot.imageId === id).length,
        };
      }
      function deleteProjectAsset(target) {
        if (!target) return null;
        if (target.kind === "csv") {
          let csv = getProjectCsv(target.id);
          if (!csv) return null;
          let references = activeProject.charts.flatMap((chart) =>
            (chart.editor?.objects || []).filter((object) => object.csvId === csv.id));
          if (references.length) {
            appFSM.send("CLEAR_GRAPH_OBJECT", {
              index: null, direction: "ui-to-fsm",
            });
            activeProject.charts.forEach((chart) => {
              if (!Array.isArray(chart.editor?.objects)) return;
              let objects = chart.editor.objects.filter((object) => object.csvId !== csv.id);
              if (objects.length === chart.editor.objects.length) return;
              appFSM.send("GRAPH_OBJECTS_REPLACED", {
                chartId: chart.id, objects, direction: "fsm-to-model",
              });
            });
          }
          appFSM.send("DATA_OBJECT_DELETED", {
            csvId: csv.id, direction: "fsm-to-model",
          });
          appFSM.send("CLEAR_ASSET_SELECTION", { direction: "fsm-to-model" });
          renderDashboard();
          status(references.length
            ? `${csv.name}과 이를 참조하던 그래프 오브젝트 ${references.length}개를 삭제했습니다.`
            : `${csv.name}을 프로젝트에서 삭제했습니다.`);
        } else if (target.kind === "image") {
          let image = getProjectImage(target.id);
          if (!image) return null;
          let references = activeProject.slots.filter((slot) => slot.imageId === image.id);
          if (references.length)
            appFSM.send("SLOTS_RESET", {
              slotIds: references.map((slot) => slot.id), direction: "fsm-to-model",
            });
          appFSM.send("IMAGE_OBJECT_DELETED", {
            imageId: image.id, direction: "fsm-to-model",
          });
          appFSM.send("CLEAR_ASSET_SELECTION", { direction: "fsm-to-model" });
          renderDashboard();
          status(references.length
            ? `${image.name}을 삭제하고 참조 슬롯 ${references.length}개를 초기화했습니다.`
            : `${image.name}을 프로젝트에서 삭제했습니다.`);
        }
        return null;
      }
      function movableProjectNode(path) {
        let match = path ? projectVfs.resolve(path) : null;
        if (!match || projectVfs.isTrashed(path)) return false;
        if (match.kind === "directory") return !projectVfs.isFixedDirectory(path);
        return true;
      }
      function projectNodeReferenceCount(path) {
        let match = projectVfs.resolve(path);
        if (!match) return 0;
        let movingAssets = match.kind === "directory"
          ? projectVfs.descendants(path)
          : [{ kind: match.kind, asset: match.asset }];
        return projectAssetReferenceCount(
          new Set(movingAssets.filter(({ kind }) => kind === "csv").map(({ asset }) => asset.id)),
          new Set(movingAssets.filter(({ kind }) => kind === "image").map(({ asset }) => asset.id)),
        );
      }
      function readProjectTrash() {
        let snapshot = projectDataTreeSnapshot(projectDataTreeObjects());
        let csvIds = new Set(snapshot.data.filter((asset) =>
          projectVfs.isTrashed(asset.path)).map((asset) => asset.id));
        let imageIds = new Set(snapshot.images.filter((asset) =>
          projectVfs.isTrashed(asset.path)).map((asset) => asset.id));
        return {
          hasContents: snapshot.directories.some((path) =>
            path !== PROJECT_TRASH_DIRECTORY && projectVfs.isTrashed(path)) ||
            csvIds.size > 0 || imageIds.size > 0,
          referenceCount: projectAssetReferenceCount(csvIds, imageIds),
        };
      }
      function projectNodeMoveOptions(path) {
        let match = path ? projectVfs.resolve(path) : null;
        return activeProject.fileSystem.directories.filter((directory) =>
          (directory === "/assets" || directory.startsWith("/assets/")) &&
          !projectVfs.isTrashed(directory) &&
          !(match?.kind === "directory" && projectPathInDirectory(directory, path)));
      }
      function planProjectNodeMove(path, directory) {
        let match = projectVfs.resolve(path);
        if (!match || !movableProjectNode(path))
          throw Error("이동할 수 없는 프로젝트 항목입니다.");
        let source = match.kind === "directory" ? match.path : projectAssetPath(match.asset);
        let targetDirectory = normalizeProjectPath(directory, { directory: true });
        if (!activeProject.fileSystem.directories.includes(targetDirectory))
          throw Error("대상 폴더가 없습니다.");
        if (match.kind === "directory" && projectPathInDirectory(targetDirectory, source))
          throw Error("폴더를 자기 자신 또는 하위 폴더로 이동할 수 없습니다.");
        let destination = normalizeProjectPath(
          `${targetDirectory}/${projectPathName(source)}`,
          { directory: match.kind === "directory" },
        );
        if (destination === source) return null;
        let collision = projectVfs.exists(destination);
        let uniquePath = collision
          ? projectVfs.uniquePath(targetDirectory, projectPathName(source))
          : destination;
        let enteringTrash =
          projectVfs.isTrashed(destination) && !projectVfs.isTrashed(source);
        return {
          path: source, kind: match.kind, directory: targetDirectory,
          destination, collision, uniqueName: projectPathName(uniquePath),
          enteringTrash,
          referenceCount: enteringTrash ? projectNodeReferenceCount(source) : 0,
        };
      }
      function moveProjectNode(plan, useUniqueName = false) {
        if (!plan) return null;
        let payload = {
          path: plan.path, directory: plan.directory, direction: "ui-to-fsm",
        };
        if (useUniqueName) payload.name = plan.uniqueName;
        appFSM.send("PROJECT_NODE_MOVED", payload);
        status(payload.trashed
          ? `${projectPathName(plan.path)}을 휴지통으로 이동했습니다.`
          : `${projectPathName(plan.path)}을 ${projectParentPath(payload.path)}로 이동했습니다.`);
        return { path: payload.path, trashed: payload.trashed };
      }
      function createProjectDirectory(parent, name) {
        let payload = { parent, name, direction: "ui-to-fsm" };
        appFSM.send("PROJECT_DIRECTORY_CREATED", payload);
        appFSM.send("SELECT_ASSET", {
          kind: "directory", path: payload.path, direction: "ui-to-fsm",
        });
        status(`${payload.path} 폴더를 만들었습니다.`);
        return payload.path;
      }
      function emptyProjectTrash() {
        let payload = { direction: "ui-to-fsm" };
        appFSM.send("PROJECT_TRASH_EMPTIED", payload);
        updateFileAvailability();
        status(`휴지통을 비웠습니다. 폴더 ${payload.directoryCount}개, CSV ${payload.csvCount}개, 이미지 ${payload.imageCount}개를 삭제했습니다.`);
      }
      function draggableProjectAsset(path) {
        let match = path ? projectVfs.resolve(path) : null;
        return match && match.kind !== "directory" && !projectVfs.isTrashed(path)
          ? { path, kind: match.kind } : null;
      }
      function connectProjectAssetPathToSlot(path, kind, slotId) {
        return connectProjectAssetToSlot(path, kind, slotAt(slotId));
      }
      async function importProjectFileToSlot(file, slotId, choosePlan) {
        let slot = slotAt(slotId), kind = slotFileKind(file);
        if (!kind) throw Error(`${file.name}: 지원하지 않는 파일 형식입니다.`);
        if (kind === "slot") return importSlotFile(file, slot);
        if (kind === "image")
          return loadImageFile(file, slot, {
            planImport: choosePlan,
          });
        return loadDataFile(file, slot, {
          replaceSlotContent: slot.contentType === "image",
          planImport: choosePlan,
        });
      }
      async function importProjectAssetFiles(files, choosePlan) {
        let selectedFiles = Array.isArray(files) ? files : files ? [files] : [];
        let target = getSelectedSlot();
        if (target && (target.contentType || "graph") === "image") {
          let file = selectedFiles[0], kind = slotFileKind(file);
          if (kind === "slot") return importSlotFile(file, target);
          if (kind === "image") {
            let plan = await choosePlan(file, PROJECT_ASSET_DIRECTORIES.image);
            return loadImageFile(file, target, {
              assetPath: plan.path, replaceAssetId: plan.replaceId,
            });
          }
          if (kind === "data") {
            let plan = await choosePlan(file, PROJECT_ASSET_DIRECTORIES.csv);
            return loadDataFile(file, target, {
              replaceSlotContent: true,
              assetPath: plan.path, replaceAssetId: plan.replaceId,
            });
          }
          throw Error(`${file.name}: 지원하지 않는 파일 형식입니다.`);
        }
        if (target) {
          for (let file of selectedFiles) {
            let plan = await choosePlan(file, PROJECT_ASSET_DIRECTORIES.csv);
            await loadDataFile(file, target, {
              assetPath: plan.path, replaceAssetId: plan.replaceId,
            });
          }
          return;
        }
        for (let file of selectedFiles) {
          let kind = slotFileKind(file);
          if (kind !== "image" && kind !== "data")
            throw Error(`${file.name}: 지원하지 않는 파일 형식입니다.`);
          let plan = await choosePlan(file, PROJECT_ASSET_DIRECTORIES[kind === "image" ? "image" : "csv"]);
          if (kind === "image")
            await loadImageFile(file, null, {
              assetPath: plan.path, replaceAssetId: plan.replaceId,
            });
          else
            await loadDataFile(file, null, {
              assetPath: plan.path, replaceAssetId: plan.replaceId,
            });
        }
      }
      function updateGraphLayoutApi({ title, globalSettings, axisKey, axisValues } = {}) {
        let slot = getSelectedSlot(), chart = graphEditorChart();
        if (!slot || !chart) return null;
        if (chart.editor?.editable === false)
          return status("편집 가능 토글을 켠 뒤 설정을 변경하세요.");
        let settings = readGlobalSettings(chart);
        if (globalSettings) settings = { ...settings, ...globalSettings };
        if (axisKey && settings.axes[axisKey])
          settings = { ...settings, axes: {
            ...settings.axes,
            [axisKey]: { ...settings.axes[axisKey], ...axisValues },
          } };
        appFSM.send("CHART_LAYOUT_CHANGED", {
          slotId: slot.id, chartId: chart.id,
          title: title === undefined ? chart.editor.title : title,
          globalSettings: settings, direction: "fsm-to-model",
        });
        renderDashboard();
        debugLog("mantine:graph-layout", { slotId: slot.id, chartId: chart.id });
        return readGraphLayoutApi();
      }
      function applyGraphPaletteApi(colors) {
        let chart = graphEditorChart();
        if (!chart || chart.editor?.editable === false)
          return status("편집 가능 토글을 켠 뒤 색상 구성을 변경하세요.");
        if (!Array.isArray(colors) || !colors.length)
          throw Error("적용할 색상 배열이 없습니다.");
        let objects = ensureGraphObjects(chart);
        let index = appFSM.state.graphObjectIndex;
        let selected = Number.isInteger(index) && index >= 0 && index < objects.length ? index : null;
        return graphEditorCommit(objects.map((object, objectIndex) => ({
          ...object, color: colors[objectIndex % colors.length],
        })), selected);
      }
      function setAnnotationEnabled(kind, enabled) {
        if (kind === "label") activeProject.labelsEnabled = enabled;
        else activeProject.captionsEnabled = enabled;
        renderDashboard();
        debugLog(`annotation:${kind}`, { enabled });
        appFSM.notify(
          kind === "label" ? "labels" : "captions",
          "ANNOTATION_VISIBILITY_CHANGED",
        );
      }
      function applyCaptionSettings(notify = true) {
        syncDashboardCaption();
        debugLog("annotation:caption-settings", {
          name: activeProject.captionName,
          bold: activeProject.captionNameBold,
          ...activeProject.captionSettings,
        });
        if (notify) appFSM.notify("captions", "CAPTION_SETTINGS_CHANGED");
      }
      function exportImageLoad(src) {
        return new Promise((resolve, reject) => {
          let image = new Image();
          image.onload = () => resolve(image);
          image.onerror = () => reject(Error("이미지를 읽을 수 없습니다."));
          image.src = src;
        });
      }
      function exportDrawImage(ctx,image,rect,slot,scaleX,scaleY) {
        let settings=readImageSettings(slot?.content?.imageSettings),
          width=rect.width,height=rect.height,ratio=image.naturalWidth/image.naturalHeight||1,
          fit=settings.fit||"contain",drawW,drawH,left,top;
        if(fit==="manual"){
          drawW=(width*(Number(settings.scale)||100))/100; drawH=drawW/ratio;
          left=rect.left+width*((Number(settings.x)||50)/100)-drawW/2;
          top=rect.top+height*((Number(settings.y)||50)/100)-drawH/2;
        } else {
          let contain=fit!=="cover", fitWidth=width, fitHeight=fitWidth/ratio;
          if((contain&&fitHeight>height)||(!contain&&fitHeight<height)){
            fitHeight=height; fitWidth=fitHeight*ratio;
          }
          drawW=fitWidth; drawH=fitHeight;
          left=rect.left+(width-drawW)/2; top=rect.top+(height-drawH)/2;
        }
        ctx.drawImage(image,left*scaleX,top*scaleY,drawW*scaleX,drawH*scaleY);
      }
      function exportWrapText(ctx, text, x, y, maxWidth, lineHeight) {
        let words = (text || "").split(/\s+/),
          line = "";
        for (let word of words) {
          let trial = line ? line + " " + word : word;
          if (ctx.measureText(trial).width > maxWidth && line) {
            ctx.fillText(line, x, y);
            y += lineHeight;
            line = word;
          } else line = trial;
        }
        if (line) ctx.fillText(line, x, y);
        return y + lineHeight;
      }
      function exportCrc32(bytes) {
        let crc = 0xffffffff;
        for (let byte of bytes) {
          crc ^= byte;
          for (let i = 0; i < 8; i++) crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0);
        }
        return (crc ^ 0xffffffff) >>> 0;
      }
      function exportSetPngDpi(bytes, dpi) {
        let meter = Math.round(dpi / 0.0254),
          chunk = new Uint8Array(21),
          view = new DataView(chunk.buffer);
        view.setUint32(0, 9);
        chunk.set([112, 72, 89, 115], 4);
        view.setUint32(8, meter);
        view.setUint32(12, meter);
        chunk[16] = 1;
        view.setUint32(17, exportCrc32(chunk.slice(4, 17)));
        let ihdrLength = new DataView(bytes.buffer, bytes.byteOffset + 8, 4).getUint32(0),
          offset = 8 + 4 + 4 + ihdrLength + 4,
          result = new Uint8Array(bytes.length + chunk.length);
        result.set(bytes.slice(0, offset));
        result.set(chunk, offset);
        result.set(bytes.slice(offset), offset + chunk.length);
        return result;
      }
      function exportSetJpegDpi(bytes, dpi) {
        let result = new Uint8Array(bytes);
        for (let i = 0; i + 17 < result.length; i++)
          if (
            result[i] === 74 &&
            result[i + 1] === 70 &&
            result[i + 2] === 73 &&
            result[i + 3] === 70 &&
            result[i + 4] === 0
          ) {
            let value = Math.max(1, Math.min(65535, Math.round(dpi)));
            result[i + 7] = 1;
            result[i + 8] = value >> 8;
            result[i + 9] = value & 255;
            result[i + 10] = value >> 8;
            result[i + 11] = value & 255;
            break;
          }
        return result;
      }
      async function exportCanvasBlob(canvas, mime, dpi) {
        let blob = await new Promise((resolve, reject) =>
            canvas.toBlob(
              (value) => (value ? resolve(value) : reject(Error("이미지 인코딩에 실패했습니다."))),
              mime,
              mime === "image/jpeg" ? 0.92 : undefined,
            ),
          ),
          bytes = new Uint8Array(await blob.arrayBuffer()),
          withDpi =
            mime === "image/png" ? exportSetPngDpi(bytes, dpi) : exportSetJpegDpi(bytes, dpi);
        return new Blob([withDpi], { type: mime });
      }
      async function exportDashboard(capture = false, options = null) {
        let dashboard = $("dashboard"),
          caption = $("dashboardCaption"),
          statusOut = {
            set textContent(value) {
              options?.onStatus?.(value);
            },
          },
          bordersVisible = activeProject.layout.slotStyle.showBorders,
          captionView = activeCaptionView(),
          dashboardRect = dashboard.getBoundingClientRect();
        if (!dashboardRect.width || !dashboardRect.height) {
          statusOut.textContent = "저장할 그래프 영역이 없습니다.";
          return;
        }
        let captionShown = !caption.classList.contains("hidden"),
          captionRect = captionShown ? caption.getBoundingClientRect() : null,
          labels = [...dashboard.querySelectorAll(".slot-label")],
          left = dashboardRect.left,
          top = dashboardRect.top,
          right = dashboardRect.right,
          bottom = Math.max(dashboardRect.bottom, captionRect?.bottom || 0);
        labels.forEach((label) => {
          let rect = label.getBoundingClientRect();
          left = Math.min(left, rect.left);
          top = Math.min(top, rect.top);
          right = Math.max(right, rect.right);
          bottom = Math.max(bottom, rect.bottom);
        });
        let sourceWidth = right - left,
          sourceHeight = bottom - top,
          width = capture
            ? Math.round(sourceWidth)
            : Math.max(
                100,
                Math.min(20000, Number(options?.width) || Math.round(sourceWidth)),
              ),
          height = capture
            ? Math.round(sourceHeight)
            : Math.max(
                100,
                Math.min(20000, Number(options?.height) || Math.round(sourceHeight)),
              ),
          dpi = Math.max(36, Math.min(1200, Number(options?.dpi) || 300)),
          format = options?.format === "jpeg" ? "jpeg" : "png";
        let canvas = document.createElement("canvas"),
          ctx = canvas.getContext("2d"),
          scaleX = width / sourceWidth,
          scaleY = height / sourceHeight,
          point = (rect) => ({
            left: rect.left - left,
            top: rect.top - top,
            width: rect.width,
            height: rect.height,
          });
        canvas.width = width;
        canvas.height = height;
        ctx.fillStyle = getComputedStyle(dashboard).backgroundColor || "#fff";
        ctx.fillRect(0, 0, width, height);
        statusOut.textContent = "그래프를 합성하는 중…";
        try {
          let slotElements = [...dashboard.querySelectorAll(".slot")];
          for (let element of slotElements) {
            let rect = point(element.getBoundingClientRect());
            ctx.fillStyle = getComputedStyle(element).backgroundColor || "#fff";
            ctx.fillRect(
              rect.left * scaleX,
              rect.top * scaleY,
              rect.width * scaleX,
              rect.height * scaleY,
            );
            if (bordersVisible) {
              ctx.strokeStyle = getComputedStyle(element).borderColor || "#B0CFCE";
              ctx.lineWidth = Math.max(1, scaleX);
              ctx.strokeRect(
                rect.left * scaleX,
                rect.top * scaleY,
                rect.width * scaleX,
                rect.height * scaleY,
              );
            }
            let plot = element.querySelector(".plot-item"),
              imageElement = element.querySelector(".slot-image");
            if (plot) {
              let uri = await Plotly.toImage(plot, {
                format: "png",
                width: Math.max(2, Math.round(rect.width * scaleX)),
                height: Math.max(2, Math.round(rect.height * scaleY)),
              });
              let image = await exportImageLoad(uri);
              ctx.drawImage(
                image,
                rect.left * scaleX,
                rect.top * scaleY,
                rect.width * scaleX,
                rect.height * scaleY,
              );
            } else if (imageElement) {
              let image = await exportImageLoad(imageElement.currentSrc || imageElement.src),
                slot = slotAt(+element.dataset.slot);
              exportDrawImage(ctx, image, rect, slot, scaleX, scaleY);
            }
          }
          for (let label of labels) {
            let rect = point(label.getBoundingClientRect()),
              style = getComputedStyle(label);
            ctx.fillStyle = style.color || "#383A42";
            ctx.font = `${style.fontWeight} ${parseFloat(style.fontSize) * scaleY}px ${style.fontFamily}`;
            ctx.textBaseline = "middle";
            ctx.fillText(
              label.textContent || "",
              (rect.left + parseFloat(style.paddingLeft || 0)) * scaleX,
              (rect.top + rect.height / 2) * scaleY,
            );
          }
          if (captionShown && captionRect) {
            let rect = point(captionRect),
              style = getComputedStyle(caption);
            ctx.fillStyle = style.backgroundColor || "#fff";
            ctx.fillRect(
              rect.left * scaleX,
              rect.top * scaleY,
              rect.width * scaleX,
              rect.height * scaleY,
            );
            ctx.strokeStyle = style.borderColor || "#B0CFCE";
            ctx.strokeRect(
              rect.left * scaleX,
              rect.top * scaleY,
              rect.width * scaleX,
              rect.height * scaleY,
            );
            let prefix = $("captionPrefix").textContent || "",
              body = captionView.aggregate
                ? captionView.exportText
                : $("captionText").textContent || "",
              fontSize = captionView.settings.fontSize * scaleY,
              lineHeight =
                captionView.settings.fontSize * captionView.settings.lineHeight * scaleY,
              baseX = (rect.left + 8) * scaleX,
              y = (rect.top + 8) * scaleY + fontSize;
            ctx.fillStyle = getComputedStyle(caption).color || "#383A42";
            if (prefix) {
              ctx.font = `${captionView.nameBold ? "700" : "400"} ${fontSize}px ${captionView.settings.fontFamily}`;
              ctx.fillText(prefix, baseX, y);
              let prefixWidth = ctx.measureText(prefix + " ").width,
                available = Math.max(10, (rect.width - 16) * scaleX),
                words = body.split(/\s+/).filter(Boolean),
                firstLine = "";
              ctx.font = `400 ${fontSize}px ${captionView.settings.fontFamily}`;
              while (words.length) {
                let trial = firstLine ? `${firstLine} ${words[0]}` : words[0];
                if (
                  firstLine &&
                  ctx.measureText(trial).width > Math.max(10, available - prefixWidth)
                )
                  break;
                firstLine = trial;
                words.shift();
              }
              if (firstLine) ctx.fillText(firstLine, baseX + prefixWidth, y);
              body = words.join(" ");
              if (body) y += lineHeight;
            }
            ctx.font = `400 ${fontSize}px ${captionView.settings.fontFamily}`;
            if (body)
              exportWrapText(
                ctx,
                body,
                baseX,
                y,
                Math.max(10, (rect.width - 16) * scaleX),
                lineHeight,
              );
          }
          let mime = format === "jpeg" ? "image/jpeg" : "image/png",
            blob = await exportCanvasBlob(canvas, mime, dpi),
            link = document.createElement("a"),
            stamp = new Date().toISOString().replace(/[:.]/g, "-");
          link.href = URL.createObjectURL(blob);
          link.download = `전체-그래프-${width}x${height}-${dpi}dpi-${stamp}.${format === "jpeg" ? "jpg" : "png"}`;
          link.click();
          setTimeout(() => URL.revokeObjectURL(link.href), 0);
          statusOut.textContent = `${width} × ${height}px, ${dpi} DPI로 저장했습니다.`;
          debugLog("dashboard:export", { format, width, height, dpi, slots: slotElements.length });
        } catch (error) {
          statusOut.textContent = "저장 실패: " + error.message;
          debugLog("dashboard:export-error", { message: error.message });
          throw error;
        }
      }
      async function exportChartImage(chart, width, height, layoutScale, rasterScale) {
        let host = document.createElement("div"),
          figure = chartFigure(chart, layoutScale);
        host.style.cssText =
          "position:fixed;left:-100000px;top:0;visibility:hidden;pointer-events:none;";
        host.style.width = `${Math.max(2, width)}px`;
        host.style.height = `${Math.max(2, height)}px`;
        document.body.append(host);
        try {
          await Plotly.newPlot(
            host,
            figure.data,
            { ...figure.layout, width, height, autosize: false },
            plotlyConfig(chart, { ...figure.config, staticPlot: true, responsive: false }),
          );
          return await Plotly.toImage(host, {
            format: "png",
            width: Math.max(2, Math.round(width)),
            height: Math.max(2, Math.round(height)),
            scale: rasterScale,
          });
        } finally {
          Plotly.purge(host);
          host.remove();
        }
      }
      function exportCaptionLayout(ctx, view, width, scale) {
        if (!view.enabled)
          return {
            height: 0,
            gap: 0,
            padding: 0,
            fontSize: 0,
            lineHeight: 0,
            lines: [],
          };
        let padding = 8 * scale,
          fontSize = view.settings.fontSize * scale,
          lineHeight = fontSize * view.settings.lineHeight,
          available = Math.max(10, width - padding * 2),
          prefix = view.name || "",
          body = view.text || "",
          lines = [],
          firstLine = true,
          prefixWidth = 0;
        if (prefix) {
          ctx.font = `${view.nameBold ? "700" : "400"} ${fontSize}px ${view.settings.fontFamily}`;
          prefixWidth = ctx.measureText(prefix + " ").width;
        }
        ctx.font = `400 ${fontSize}px ${view.settings.fontFamily}`;
        let paragraphs = String(body).split(/\n/);
        paragraphs.forEach((paragraph, paragraphIndex) => {
          let words = paragraph.split(/\s+/).filter(Boolean),
            line = "";
          for (let word of words) {
            let trial = line ? `${line} ${word}` : word,
              lineWidth = available - (firstLine ? prefixWidth : 0);
            if (line && ctx.measureText(trial).width > Math.max(10, lineWidth)) {
              lines.push({ text: line, prefix: firstLine ? prefix : "" });
              line = word;
              firstLine = false;
            } else line = trial;
          }
          if (line || paragraphIndex < paragraphs.length - 1 || (firstLine && prefix)) {
            lines.push({ text: line, prefix: firstLine ? prefix : "" });
            firstLine = false;
          }
        });
        if (!lines.length) lines.push({ text: "", prefix });
        return {
          height: padding * 2 + lines.length * lineHeight + 2 * scale,
          gap: 10 * scale,
          padding,
          fontSize,
          lineHeight,
          lines,
        };
      }
      function targetExportGeometry(layout, width, heightOverride = null) {
        let slotStyle = layout.slotStyle || {},
          referenceWidth = Math.max(
            100,
            Math.min(20000, Number(slotStyle.referenceWidth) || 1200),
          ),
          scale = Math.max(0.001, Number(width) / referenceWidth),
          configuredAspect = Math.max(
            0.1,
            Math.min(10, Number(slotStyle.aspect) || 1.618),
          ),
          naturalHeight = Number(width) / configuredAspect,
          height =
            Number.isFinite(heightOverride) && heightOverride > 0
              ? Number(heightOverride)
              : naturalHeight,
          outerMargin = Math.min(
            Math.max(0, Math.min(5000, Number(slotStyle.outerMargin) || 0)) * scale,
            Math.min(Number(width), height) * 0.49,
          );
        return {
          referenceWidth,
          width: Number(width),
          height,
          scale,
          aspect: Number(width) / height,
          outerMargin,
          gap: Math.max(0, Math.min(2000, Number(slotStyle.gap) || 0)) * scale,
          radius: Math.max(0, Math.min(2000, Number(slotStyle.radius) || 0)) * scale,
        };
      }
      function targetSlotIdentifier(index, settings) {
        if (settings.format === "decimal") return String(index + 1);
        if (settings.format === "lower-roman") return romanIdentifier(index).toLowerCase();
        if (settings.format === "upper-roman") return romanIdentifier(index);
        return alphaIdentifier(index, settings.format === "upper-alpha");
      }
      function createTargetExportSnapshot() {
        let objects = projectObjects.snapshot([
            "layout",
            "labels",
            "captions",
            "images",
            "charts",
            "slots",
          ]),
          dashboard = $("dashboard"),
          caption = $("dashboardCaption"),
          visibleSlots = objects.slots.filter((slot) => !slot.hidden),
          ordered = [...visibleSlots].sort((a, b) =>
            objects.labels.settings.order === "column-major"
              ? a.col - b.col || a.row - b.row
              : a.row - b.row || a.col - b.col,
          );
        return Object.freeze({
          revision: appFSM.state.revision,
          ...objects,
          captionView: projectClone(activeCaptionView(objects.captions)),
          bordersVisible: activeProject.layout.slotStyle.showBorders,
          slotColors: Object.fromEntries(
            visibleSlots.map((slot) => {
              let element = $(`plot-${slot.id}`)?.closest(".slot"),
                style = element ? getComputedStyle(element) : null;
              return [
                slot.id,
                {
                  background: style?.backgroundColor || "#fff",
                  border: style?.borderColor || "#B0CFCE",
                },
              ];
            }),
          ),
          labelText: Object.fromEntries(
            ordered.map((slot, index) => {
              let identifier = targetSlotIdentifier(index, objects.labels.settings),
                text =
                  objects.labels.settings.parentheses === true
                    ? `(${identifier})`
                    : identifier;
              return [slot.id, text];
            }),
          ),
          dashboardStyle: {
            background: getComputedStyle(dashboard).backgroundColor || "#fff",
            color: getComputedStyle(dashboard).color || "#383A42",
          },
          captionStyle: {
            background: getComputedStyle(caption).backgroundColor || "#fff",
            border: getComputedStyle(caption).borderColor || "#B0CFCE",
            color: getComputedStyle(caption).color || "#383A42",
          },
        });
      }
      async function exportDashboardTarget(options = null) {
        let statusOut = {
            set textContent(value) {
              options?.onStatus?.(value);
            },
          },
          snapshot = createTargetExportSnapshot(),
          captionView = snapshot.captionView,
          width = Math.max(
            100,
            Math.min(20000, Number(options?.width) || 1000),
          ),
          requestedHeight = Number(options?.height),
          dpi = Math.max(36, Math.min(1200, Number(options?.dpi) || 300)),
          rasterScale = 1,
          format = options?.format === "jpeg" ? "jpeg" : "png",
          bordersVisible = snapshot.bordersVisible,
          visibleSlots = snapshot.slots.filter((slot) => !slot.hidden),
          captionShown = captionView.enabled;
        let canvas = document.createElement("canvas"),
          ctx = canvas.getContext("2d"),
          baseReference = targetExportGeometry(snapshot.layout, width),
          outputScale = width / baseReference.referenceWidth,
          captionLayout = exportCaptionLayout(ctx, captionView, width, outputScale),
          automaticHeight = !Number.isFinite(requestedHeight) || requestedHeight <= 0,
          height = automaticHeight
            ? Math.ceil(baseReference.height + captionLayout.height + captionLayout.gap)
            : Math.max(100, Math.min(20000, requestedHeight)),
          rasterWidth = Math.round(width),
          rasterHeight = Math.round(height),
          maxRasterDimension = 16384,
          maxRasterArea = 64000000;
        if (
          rasterWidth > maxRasterDimension ||
          rasterHeight > maxRasterDimension ||
          rasterWidth * rasterHeight > maxRasterArea
        ) {
          statusOut.textContent = `요청한 ${rasterWidth} × ${rasterHeight}px 래스터가 출력 한도(한 변 16384px, 총 64MP)를 넘습니다. 가로 또는 세로 크기를 낮추세요.`;
          return { outcome: "rejected", reason: "raster-limit" };
        }
        canvas.width = rasterWidth;
        canvas.height = rasterHeight;
        ctx.imageSmoothingQuality = "high";
        ctx.fillStyle = snapshot.dashboardStyle.background;
        ctx.fillRect(0, 0, width, height);
        let reference = targetExportGeometry(snapshot.layout, width),
          dashboardHeight = height - captionLayout.height - captionLayout.gap,
          minimumDashboardHeight = Math.ceil(
            reference.outerMargin * 2 +
              reference.gap * Math.max(0, snapshot.layout.gridRows - 1) +
              snapshot.layout.gridRows,
          );
        if (dashboardHeight < minimumDashboardHeight) {
          let minimumHeight = Math.ceil(
            captionLayout.height + captionLayout.gap + minimumDashboardHeight,
          );
          statusOut.textContent = `캡션 높이 ${Math.ceil(captionLayout.height)}px를 배치하기에는 설정된 세로 ${height}px가 너무 작습니다. 세로를 최소 ${minimumHeight}px로 늘리세요.`;
          return { outcome: "rejected", reason: "caption-height" };
        }
        let geometry = targetExportGeometry(snapshot.layout, width, dashboardHeight),
          dashboardLeft = 0,
          dashboardTop = 0,
          gap = geometry.gap,
          grid = gridSlotGeometry(snapshot.layout, geometry),
          colWidth = grid.colWidth,
          rowHeight = grid.rowHeight;
        if (colWidth <= 0 || rowHeight <= 0)
          throw Error("출력 크기에 비해 슬롯 간격이 너무 큽니다.");
        let slotRect = (slot) => ({
          left: dashboardLeft + geometry.outerMargin + (slot.col - 1) * (colWidth + gap),
          top: dashboardTop + geometry.outerMargin + (slot.row - 1) * (rowHeight + gap),
          width: colWidth * slot.colSpan + gap * (slot.colSpan - 1),
          height: rowHeight * slot.rowSpan + gap * (slot.rowSpan - 1),
        });
        let slotRadius = () => geometry.radius;
        statusOut.textContent = "출력 크기로 그래프를 다시 렌더링하는 중…";
        try {
          for (let slot of visibleSlots) {
            let rect = slotRect(slot),
              colors = snapshot.slotColors[slot.id],
              chart = slot.chart && snapshot.charts.find((item) => item.id === slot.chart),
              imageModel = slotImage(slot, snapshot.images);
            ctx.save();
            ctx.beginPath();
              ctx.roundRect(rect.left, rect.top, rect.width, rect.height, slotRadius());
            ctx.clip();
            ctx.fillStyle = colors?.background || "#fff";
            ctx.fillRect(rect.left, rect.top, rect.width, rect.height);
            if (slot.contentType !== "image" && chart) {
              let uri = await exportChartImage(
                  chart,
                  rect.width,
                  rect.height,
                  geometry.scale,
                  rasterScale,
                ),
                image = await exportImageLoad(uri);
              ctx.drawImage(image, rect.left, rect.top, rect.width, rect.height);
            } else if (imageModel) {
              let image = await exportImageLoad(projectImageDataUrl(imageModel));
              exportDrawImage(ctx, image, rect, slot, 1, 1);
            }
            ctx.restore();
            if (bordersVisible) {
              ctx.strokeStyle = colors?.border || "#B0CFCE";
              ctx.lineWidth = 1;
              ctx.beginPath();
              ctx.roundRect(
                rect.left + 0.5,
                rect.top + 0.5,
                Math.max(0, rect.width - 1),
                Math.max(0, rect.height - 1),
                slotRadius(),
              );
              ctx.stroke();
            }
          }
          if (snapshot.labels.enabled) {
            let ordered = [...visibleSlots].sort((a, b) =>
              snapshot.labels.settings.order === "column-major"
                ? a.col - b.col || a.row - b.row
                : a.row - b.row || a.col - b.col,
            );
            for (let slot of ordered) {
              let rect = slotRect(slot),
                text = snapshot.labelText[slot.id],
                x = rect.left + snapshot.labels.settings.x * geometry.scale,
                y = rect.top + snapshot.labels.settings.y * geometry.scale;
              let scaledLabelFontSize =
                snapshot.labels.settings.fontSize * geometry.scale;
              ctx.font = `800 ${scaledLabelFontSize}px ${snapshot.labels.settings.fontFamily}`;
              let labelHeight = Math.ceil(scaledLabelFontSize * 1.2) + 4 * geometry.scale;
              ctx.fillStyle = snapshot.dashboardStyle.color;
              ctx.textBaseline = "middle";
              ctx.fillText(text, x + 6 * geometry.scale, y + labelHeight / 2);
            }
          }
          if (captionShown) {
            let top = dashboardTop + geometry.height + captionLayout.gap;
            ctx.fillStyle = snapshot.captionStyle.background;
            ctx.fillRect(0, top, width, captionLayout.height);
            if (bordersVisible) {
              ctx.strokeStyle = snapshot.captionStyle.border;
              ctx.strokeRect(
                0.5,
                top + 0.5,
                Math.max(0, width - 1),
                captionLayout.height - 1,
              );
            }
            let y = top + captionLayout.padding + captionLayout.fontSize;
            ctx.fillStyle = snapshot.captionStyle.color;
            for (let line of captionLayout.lines) {
              let x = captionLayout.padding;
              if (line.prefix) {
                ctx.font = `${captionView.nameBold ? "700" : "400"} ${captionLayout.fontSize}px ${captionView.settings.fontFamily}`;
                ctx.fillText(line.prefix, x, y);
                x += ctx.measureText(line.prefix + " ").width;
              }
              ctx.font = `400 ${captionLayout.fontSize}px ${captionView.settings.fontFamily}`;
              ctx.fillText(line.text, x, y);
              y += captionLayout.lineHeight;
            }
          }
          let mime = format === "jpeg" ? "image/jpeg" : "image/png",
            blob = await exportCanvasBlob(canvas, mime, dpi),
            link = document.createElement("a"),
            stamp = new Date().toISOString().replace(/[:.]/g, "-");
          link.href = URL.createObjectURL(blob);
          link.download = `전체-그래프-${width}x${height}-r${rasterWidth}x${rasterHeight}-${dpi}dpi-${stamp}.${format === "jpeg" ? "jpg" : "png"}`;
          link.click();
          setTimeout(() => URL.revokeObjectURL(link.href), 0);
          statusOut.textContent = `레이아웃 ${width} × ${height}px · 래스터 ${rasterWidth} × ${rasterHeight}px · ${dpi} DPI로 저장했습니다.`;
          debugLog("dashboard:export-target", {
            format,
            width,
            height,
            rasterWidth,
            rasterHeight,
            dpi,
            rasterScale,
            slots: visibleSlots.length,
            gridRows: snapshot.layout.gridRows,
            gridCols: snapshot.layout.gridCols,
            gap,
            referenceWidth: reference.referenceWidth,
            renderScale: geometry.scale,
            dashboardWidth: geometry.width,
            dashboardHeight: geometry.height,
            dashboardAspect: geometry.aspect,
            captionHeight: captionLayout.height,
            automaticHeight,
            revision: snapshot.revision,
          });
          return { outcome: "saved", width, height, automaticHeight };
        } catch (error) {
          statusOut.textContent = "저장 실패: " + error.message;
          debugLog("dashboard:export-error", { message: error.message });
          throw error;
        }
      }
      function downloadJsonFile(payload, name) {
        let blob = new Blob([JSON.stringify(payload, null, 2)], {
            type: "application/json;charset=utf-8",
          }),
          link = document.createElement("a");
        link.href = URL.createObjectURL(blob);
        link.download = name;
        link.click();
        setTimeout(() => URL.revokeObjectURL(link.href), 0);
      }
      function ffsxBuildSlot(slot, chart) {
        let projectObject = projectObjects.read("project"),
          copy = chartExportCopy(chart),
          referenced = chartCsvIds(chart).map((id) => {
            let csv = getProjectCsv(id);
            if (!csv) throw Error(`FFSX가 참조하는 CSV ${id}가 없습니다.`);
            return csv;
          }),
          slotIds = new Map(referenced.map((csv, index) => [csv.id, index + 1])),
          packaged = referenced.map((source) => {
            let csv = projectClone(source);
            csv.id = slotIds.get(source.id);
            delete csv.rows;
            delete csv.bytesBase64;
            delete csv.directory;
            csv.dataRef = `assets/${projectCsvDataRef(csv)}`;
            return csv;
          });
        delete copy.id;
        copy.editor.objects.forEach((object) => {
          if (Number.isInteger(object.csvId)) object.csvId = slotIds.get(object.csvId);
        });
        let manifest = {
            schema: "fast-figure-slot",
            version: PACKAGE_FORMAT_VERSION,
            appBuild: projectObject.appBuild,
            exportedAt: new Date().toISOString(),
            slot: {
              contentType: "graph",
              caption: typeof slot.caption === "string" ? slot.caption : null,
            },
            chart: copy,
            csvFiles: packaged,
          };
        let graphObjects = projectClone(manifest.chart.editor?.objects || []),
          chartState = {
            ...projectClone(manifest.chart),
            editor: {
              ...projectClone(manifest.chart.editor || {}),
              objects: [],
            },
          },
          refs = '<assets ref="assets/assets.xml"/>';
        return {
          manifest,
          assets: [
            {
              name: "slot.xml",
              data: new TextEncoder().encode(
                ffpxXmlDocument(
                  "fastFigureSlot",
                  PACKAGE_FORMAT_VERSION,
                  `${refs}<slot contentType="graph"><settings>${ffpxXmlValue(
                    { ...manifest.slot, appBuild: manifest.appBuild },
                  )}</settings><caption>${ffpxXmlValue({
                    text: manifest.slot.caption,
                  })}</caption><graph><settings>${ffpxXmlValue(
                    chartState,
                  )}</settings><graphObjects>${graphObjects
                    .map(
                      (object, index) =>
                        `<graphObject index="${index}">${ffpxXmlValue(object)}</graphObject>`,
                    )
                    .join("")}</graphObjects></graph></slot>`,
                ),
              ),
            },
            {
              name: "assets/assets.xml",
              data: new TextEncoder().encode(
                ffpxXmlDocument(
                  "fastFigureAssets",
                  PACKAGE_FORMAT_VERSION,
                  `<dataAssets>${manifest.csvFiles
                    .map(
                      (csv) =>
                        `<dataAsset id="${csv.id}" src="${ffpxXmlEscape(csv.dataRef)}">${ffpxXmlValue(csv)}</dataAsset>`,
                    )
                    .join("")}</dataAssets>`,
                ),
              ),
            },
            ...referenced.map((csv, index) => ({
              name: `assets/${projectCsvDataRef({ ...csv, id: index + 1 })}`,
              data: ffpxBase64ToBytes(csv.bytesBase64),
            })),
          ],
        };
      }
      async function ffsxReadSlot(file) {
        let assets = ffpxZipRead(new Uint8Array(await file.arrayBuffer())),
          xmlBytes = assets.get("slot.xml");
        if (!xmlBytes) throw Error("FFSX slot.xml이 없습니다.");
        let slotRoot = ffpxReadXmlDocument(assets, "slot.xml", "fastFigureSlot"),
            slotNode = slotRoot.querySelector(":scope > slot"),
            slot = ffpxXmlReadValue(
              slotNode.querySelector(":scope > settings > value"),
            ),
            caption = ffpxXmlReadValue(
              slotNode.querySelector(":scope > caption > value"),
            ),
            graphNode = slotNode.querySelector(":scope > graph"),
            chart = ffpxXmlReadValue(
              graphNode.querySelector(":scope > settings > value"),
            ),
            assetRoot = ffpxReadXmlDocument(
              assets,
              "assets/assets.xml",
              "fastFigureAssets",
            );
          delete chart.id;
          debugLog("slotFfsx:read-version", {
            format: "FFSX",
            appBuild: typeof slot?.appBuild === "string" ? slot.appBuild : null,
          });
          delete slot.appBuild;
          chart.editor.objects = [
            ...graphNode.querySelectorAll(":scope > graphObjects > graphObject"),
          ].map((node) => ffpxXmlReadValue(node.firstElementChild));
          let payload = {
            schema: "fast-figure-slot",
            version: PACKAGE_FORMAT_VERSION,
            slot: {
              ...slot,
              caption: typeof caption?.text === "string" ? caption.text : null,
            },
            chart,
            csvFiles: [...assetRoot.querySelectorAll("dataAsset")].map((node) =>
              ffpxXmlReadValue(node.firstElementChild),
            ),
          };
        if (
          payload?.schema !== "fast-figure-slot" ||
          payload.version !== PACKAGE_FORMAT_VERSION ||
          !payload.chart ||
          typeof payload.chart !== "object"
        )
          throw Error("지원하지 않는 FFSX 슬롯 형식입니다.");
        if (!Array.isArray(payload.csvFiles))
          throw Error("FFSX CSV 목록이 올바르지 않습니다.");
        let slotCsvIds = new Set();
        for (let csv of payload.csvFiles) {
          let dataRef = csv?.dataRef,
            data = typeof dataRef === "string" ? assets.get(dataRef) : null;
          if (
            !csv ||
            !chartCsvIds(chart).includes(csv.id) ||
            typeof csv.name !== "string" ||
            typeof dataRef !== "string" ||
            !dataRef.startsWith("assets/data/") ||
            !data
          )
            throw Error("FFSX 슬롯 CSV 자산이 없습니다.");
          if (!Number.isInteger(csv.id) || csv.id < 1 || slotCsvIds.has(csv.id))
            throw Error("FFSX 슬롯 내부 CSV ID가 올바르지 않습니다.");
          slotCsvIds.add(csv.id);
          csv.rows = parseProjectCsvAsset(csv.name, data);
          csv.bytesBase64 = ffpxBytesToBase64(data);
          delete csv.dataRef;
        }
        validateChartModel(chart, "FFSX 차트", payload.csvFiles);
        return payload;
      }
      function downloadSlotFfsx() {
        let slot = getSelectedSlot(),
          chart = slot?.chart && getChart(slot.chart);
        if (!slot || !chart) return status("FFSX로 내보낼 그래프 슬롯을 먼저 선택하세요.");
        try {
          let bundle = ffsxBuildSlot(slot, chart),
            blob = new Blob([ffpxZipStore(bundle.assets)], {
              type: "application/vnd.fast-figure-slot",
            }),
            link = document.createElement("a"),
            stamp = new Date().toISOString().replace(/[:.]/g, "-");
          link.href = URL.createObjectURL(blob);
          link.download = `fast-figure-slot-${slot.id}-${stamp}.ffsx`;
          link.click();
          setTimeout(() => URL.revokeObjectURL(link.href), 0);
          status("선택한 슬롯을 FFSX 파일로 내보냈습니다.");
          debugLog("slotFfsx:export", {
            slotId: slot.id,
            chartId: chart.id,
            assets: bundle.assets.length,
          });
        } catch (error) {
          status("FFSX 내보내기 오류: " + error.message);
          debugLog("slotFfsx:export-error", { message: error.message });
        }
      }
      function downloadPlotlyJson() {
        let slot = getSelectedSlot(),
          chart = slot?.chart && getChart(slot.chart);
        if (!slot || !chart) return status("Plotly JSON으로 내보낼 그래프 슬롯을 먼저 선택하세요.");
        let stamp = new Date().toISOString().replace(/[:.]/g, "-"),
          figure = chartFigure(chart);
        downloadJsonFile(figure, `plotly-figure-${slot.id}-${stamp}.json`);
        status("선택한 슬롯의 Plotly JSON을 내보냈습니다.");
      }
      async function importSlotFile(file, slot) {
        if (!slot) throw Error("FFSX 또는 Plotly JSON을 불러올 슬롯을 먼저 선택하세요.");
        let header = new Uint8Array(await file.slice(0, 4).arrayBuffer()),
          payload =
            header.length === 4 && header[0] === 0x50 && header[1] === 0x4b
              ? await ffsxReadSlot(file)
              : JSON.parse(await file.text());
        let chart,
          slotCaption,
          importKind,
          packagedCsvFiles = [];
        if (
          payload?.schema === "fast-figure-slot" &&
          payload.version === PACKAGE_FORMAT_VERSION &&
          payload.chart &&
          typeof payload.chart === "object"
        ) {
          importKind = "ffsx";
          packagedCsvFiles = payload.csvFiles;
          if (
            !Array.isArray(packagedCsvFiles) ||
            packagedCsvFiles.some((csv) => !Array.isArray(csv.rows))
          )
            throw Error("FFSX CSV 데이터가 없습니다.");
          chart = projectClone(payload.chart);
          packagedCsvFiles = projectClone(packagedCsvFiles);
          chart = validateChartModel(chart, "FFSX 차트", packagedCsvFiles);
          slotCaption =
            typeof payload.slot?.caption === "string" ? payload.slot.caption : undefined;
        } else if (
          Array.isArray(payload?.data) ||
          payload?.layout ||
          payload?.config ||
          payload?.frames
        ) {
          importKind = "plotly";
          chart = parsePlotlyToEditor(payload, null);
          chart.editor.editable = false;
        } else throw Error("지원하지 않는 FFSX 슬롯 또는 Plotly JSON 형식입니다.");
        normalizeGlobalSettings(chart);
        let importPayload = {
          slotId: slot.id,
          chart,
          csvFiles: packagedCsvFiles || [],
          importKind,
          slotCaption,
          direction: "fsm-to-model",
        };
        appFSM.send("SLOT_CHART_IMPORTED", importPayload);
        chart = importPayload.chart;
        selectedSlotId = null;
        setSelectedSlot(slot.id, "model-to-fsm");
        status(`${file.name}을 현재 슬롯에 불러왔습니다.`);
        debugLog("slot:import", {
          slotId: slot.id,
          chartId: chart.id,
          editable: chart.editor.editable,
          objects: chart.editor.objects.length,
          rows:
            chart.editor.editable === false
              ? 0
              : getProjectCsv(chart.editor.objects[0]?.csvId)?.rows.length || 0,
          schema: payload?.schema || "plotly",
        });
      }
      function applyDashboardZoom(resize = true, requestedValue = null) {
        if (requestedValue !== null && !dashboardZoomLocked)
          dashboardZoomIntent = Math.max(50, Math.min(200, Number(requestedValue) || 100));
        let dashboard = $("dashboard"),
          width;
        if (dashboardZoomLocked && Number.isFinite(dashboardZoomLockedWidth)) {
          width = dashboardZoomLockedWidth;
        } else {
          width = dashboardReferenceWidth() * (dashboardZoomIntent / 100);
        }
        dashboard.style.minWidth = `${width}px`;
        dashboard.style.width = `${width}px`;
        applyReferenceGeometry(dashboard);
        syncDashboardCaptionWidth();
        if (resize) schedulePlotResize();
        requestAnimationFrame(syncDashboardZoomDisplay);
      }
      function commitDashboardScale(reason) {
        renderDashboard();
        debugLog("dashboard:scale-commit", {
          reason,
          zoom: dashboardZoomIntent,
          width: $("dashboard").getBoundingClientRect().width,
        });
        appFSM.notify("layout", "DASHBOARD_SCALE_COMMITTED");
      }
      function setDashboardZoomLocked(locked) {
        let dashboard = $("dashboard");
        dashboardZoomLocked = locked;
        if (locked) dashboardZoomLockedWidth = dashboard.getBoundingClientRect().width;
        else {
          dashboardZoomLockedWidth = null;
          dashboardZoomIntent = 100;
        }
        applyDashboardZoom(false);
        if (locked) schedulePlotResize();
        else commitDashboardScale("unlock-reset-100");
        debugLog("dashboard:zoom-lock", { locked, width: dashboardZoomLockedWidth });
      }
      function applyUiPalette(_fromControls = false, notify = true) {
        let palette = activeProject.appearance.uiPalette;
        document.documentElement.style.setProperty("--ui-color", palette.uiColor);
        document.documentElement.style.setProperty(
          "--paper",
          palette.uiBackgroundColor,
        );
        document.documentElement.style.setProperty("--ui-subtle", palette.uiSubtleColor);
        document.documentElement.style.setProperty("--ink", palette.fontColor);
        document.documentElement.style.setProperty("--graph-bg", palette.paperColor);
        renderDashboard();
        if (notify) appFSM.notify("ui", "UI_PALETTE_CHANGED");
      }
      function applyUiPaletteValues(values, notify = true) {
        activeProject.appearance.uiPalette = Object.fromEntries(
          Object.entries(DEFAULT_UI_PALETTE).map(([key, fallback]) => [
            key,
            projectColor(values?.[key], fallback),
          ]),
        );
        applyUiPalette(false, notify);
        return activeProject.appearance.uiPalette;
      }
      function readGlobalCaptionState() {
        return Object.freeze({
          enabled:activeProject.captionsEnabled,
          text:activeProject.captionText,
          afterText:activeProject.captionAfterText,
          name:activeProject.captionName,
          nameBold:activeProject.captionNameBold,
          settings:Object.freeze({...activeProject.captionSettings}),
        });
      }
      function readSlotCaptionState(slotId) {
        let slot=slotAt(Number(slotId));
        return slot?Object.freeze({
          id:slot.id,row:slot.row,col:slot.col,text:slot.caption??"",
        }):null;
      }
      function setCaptionsApiEnabled(enabled) {
        setAnnotationEnabled("caption",enabled===true);
        return readGlobalCaptionState();
      }
      function setGlobalCaptionText(text) {
        appFSM.send("CAPTION_TEXT_INPUT",{
          target:{kind:"global"},text:String(text??""),direction:"fsm-to-model",
        });
        syncDashboardCaption();
        return readGlobalCaptionState();
      }
      function setSlotCaptionText(slotId,text) {
        appFSM.send("CAPTION_TEXT_INPUT",{
          target:{kind:"slot",id:Number(slotId)},text:String(text??""),direction:"fsm-to-model",
        });
        return readSlotCaptionState(slotId);
      }
      function insertCaptionsApiSlotCaptions(slotIds=null) {
        appFSM.send("SLOT_CAPTIONS_INSERTED",{
          slotIds:Array.isArray(slotIds)?slotIds:null,direction:"fsm-to-model",
        });
        syncDashboardCaption();
        return readGlobalCaptionState();
      }

      function setCaptionsApiName(name) {
        activeProject.captionName = String(name ?? "");
        syncDashboardCaption();
        appFSM.notify("captions", "CAPTION_NAME_CHANGED");
        return readGlobalCaptionState();
      }
      function setCaptionsApiNameBold(bold) {
        activeProject.captionNameBold = bold === true;
        syncDashboardCaption();
        appFSM.notify("captions", "CAPTION_NAME_WEIGHT_CHANGED");
        return readGlobalCaptionState();
      }
      function setCaptionsApiSettings(patch = {}) {
        let current = activeProject.captionSettings,
          next = { ...current };
        if (Object.prototype.hasOwnProperty.call(patch, "fontFamily"))
          next.fontFamily = String(patch.fontFamily ?? "");
        if (Object.prototype.hasOwnProperty.call(patch, "fontSize")) {
          let fontSize = Number(patch.fontSize);
          next.fontSize = Number.isFinite(fontSize)
            ? Math.max(6, Math.min(96, fontSize))
            : 14;
        }
        if (Object.prototype.hasOwnProperty.call(patch, "lineHeight")) {
          let lineHeight = Number(patch.lineHeight);
          next.lineHeight = Number.isFinite(lineHeight)
            ? Math.max(0.8, Math.min(4, lineHeight))
            : 1.45;
        }
        activeProject.captionSettings = next;
        applyCaptionSettings();
        return readGlobalCaptionState();
      }
      function readPrintApiSettings() {
        return Object.freeze({...activeProject.exportSettings});
      }
      function setPrintApiSettings(values={}) {
        let current=activeProject.exportSettings,
          heightMode=values.heightMode==="explicit"?"explicit":
            values.heightMode==="auto"?"auto":current.heightMode,
          candidate={
            width:readProjectNumber(values.width,current.width,100,20000),
            heightMode,
            height:heightMode==="explicit"
              ?readProjectNumber(values.height,current.height??100,100,20000):null,
            dpi:readProjectNumber(values.dpi,current.dpi,36,1200),
            format:values.format==="jpeg"?"jpeg":values.format==="png"?"png":current.format,
          },
          state=projectClone(activeProject._state);
        state.export=candidate;
        validateProjectObjectState(state,{requireSlots:true});
        activeProject.initialize(state);
        return readPrintApiSettings();
      }
      function savePrintApi(options={}) {
        let settings=readPrintApiSettings();
        return exportDashboardTarget({
          width:settings.width,
          height:settings.heightMode==="explicit"?settings.height:"",
          dpi:settings.dpi,
          format:settings.format,
          onStatus:options.onStatus,
        });
      }
      function capturePrintApi(options={}) {
        let settings=readPrintApiSettings();
        return exportDashboard(true,{
          dpi:settings.dpi,
          format:settings.format,
          onStatus:options.onStatus,
        });
      }
      function readLabelsApiState() {
        let reference = gridSlotGeometry(
          activeProject.layout,
          dashboardGeometry(dashboardReferenceWidth()),
          getSelectedSlot(),
        );
        return Object.freeze({
          enabled: activeProject.labelsEnabled,
          settings: Object.freeze({ ...activeProject.labelSettings }),
          reference: Object.freeze({
            width: reference.width,
            height: reference.height,
          }),
          sampleText: displayedSlotIdentifier(0),
        });
      }
      function setLabelsApiEnabled(enabled) {
        setAnnotationEnabled("label", enabled === true);
        return readLabelsApiState();
      }
      function setLabelsApiSettings(patch = {}) {
        let current = activeProject.labelSettings,
          next = { ...current };
        if (Object.prototype.hasOwnProperty.call(patch, "format")) {
          let format = String(patch.format || "");
          if (
            ["lower-alpha", "upper-alpha", "decimal", "lower-roman", "upper-roman"].includes(
              format,
            )
          )
            next.format = format;
        }
        if (Object.prototype.hasOwnProperty.call(patch, "order")) {
          let order = String(patch.order || "");
          if (["row-major", "column-major"].includes(order)) next.order = order;
        }
        if (Object.prototype.hasOwnProperty.call(patch, "parentheses"))
          next.parentheses = patch.parentheses === true;
        if (Object.prototype.hasOwnProperty.call(patch, "fontFamily"))
          next.fontFamily = String(patch.fontFamily ?? "");
        if (Object.prototype.hasOwnProperty.call(patch, "fontSize")) {
          let fontSize = Number(patch.fontSize);
          next.fontSize = Number.isFinite(fontSize) ? Math.max(6, fontSize) : current.fontSize;
        }
        activeProject.labelSettings = next;
        renderDashboard();
        schedulePlotResize();
        debugLog("mantine:label-settings", { ...next });
        appFSM.notify("labels", "LABEL_SETTINGS_CHANGED");
        return readLabelsApiState();
      }
      function updateLabelsApiPosition(x, y, eventName = null) {
        let current = activeProject.labelSettings,
          nextX = Number(x),
          nextY = Number(y);
        current.x = Number.isFinite(nextX) ? nextX : current.x;
        current.y = Number.isFinite(nextY) ? nextY : current.y;
        renderDashboard();
        schedulePlotResize();
        if (eventName) {
          debugLog("mantine:label-settings", { ...current });
          appFSM.notify("labels", eventName);
        }
        return readLabelsApiState();
      }
      function setLabelsApiPosition(x, y) {
        return updateLabelsApiPosition(x, y, "LABEL_POSITION_CHANGED");
      }

      function finishLabelsApiPositionInteraction() {
        debugLog("mantine:label-position",{
          x:activeProject.labelSettings.x,y:activeProject.labelSettings.y,
        });
        appFSM.notify("labels","LABEL_POSITION_DRAGGED");
        return readLabelsApiState();
      }
      function resetLabelsApiPosition() {
        return updateLabelsApiPosition(0, 0, "LABEL_POSITION_RESET");
      }
      function readAppearanceApiPalette() {
        return Object.freeze({ ...activeProject.appearance.uiPalette });
      }
      function setAppearanceApiPalette(values) {
        applyUiPaletteValues(values);
        return readAppearanceApiPalette();
      }
      function resetAppearanceApiPalette() {
        applyUiPaletteValues(DEFAULT_UI_PALETTE);
        return readAppearanceApiPalette();
      }
      function readLayoutApiState(previewWidth = 600) {
        let width = readProjectNumber(previewWidth, 600, 1, 20000),
          geometry = dashboardGeometry(width);
        return Object.freeze({
          gridRows: activeProject.gridRows,
          gridCols: activeProject.gridCols,
          slotStyle: Object.freeze({ ...activeProject.layout.slotStyle }),
          visibleSlots: Object.freeze(
            activeProject.slots
              .filter((slot) => !slot.hidden)
              .map((slot) =>
                Object.freeze({
                  id: slot.id,
                  row: slot.row,
                  col: slot.col,
                  rowSpan: slot.rowSpan,
                  colSpan: slot.colSpan,
                }),
              ),
          ),
          previewGeometry: Object.freeze({ ...geometry }),
          zoom: dashboardZoomIntent,
          zoomLocked: dashboardZoomLocked,
        });
      }
      function setLayoutApiStyle(patch = {}) {
        let current = activeProject.layout.slotStyle,
          next = { ...current };
        if (Object.prototype.hasOwnProperty.call(patch, "referenceWidth"))
          next.referenceWidth = readProjectNumber(
            patch.referenceWidth,
            current.referenceWidth,
            100,
            20000,
          );
        if (Object.prototype.hasOwnProperty.call(patch, "gap"))
          next.gap = readProjectNumber(patch.gap, current.gap, 0, 2000);
        if (Object.prototype.hasOwnProperty.call(patch, "outerMargin"))
          next.outerMargin = readProjectNumber(
            patch.outerMargin,
            current.outerMargin,
            0,
            5000,
          );
        if (Object.prototype.hasOwnProperty.call(patch, "radius"))
          next.radius = readProjectNumber(patch.radius, current.radius, 0, 2000);
        if (Object.prototype.hasOwnProperty.call(patch, "aspect"))
          next.aspect = readProjectNumber(patch.aspect, current.aspect, 0.1, 10);
        if (Object.prototype.hasOwnProperty.call(patch, "showBorders"))
          next.showBorders = patch.showBorders === true;
        activeProject.layout.slotStyle = next;
        applySlotStyle(false);
        applyDashboardZoom(false);
        schedulePlotResize();
        return readLayoutApiState();
      }
      function setLayoutApiGrid(rows, cols) {
        let nextRows = Number(rows),
          nextCols = Number(cols);
        if (
          !Number.isInteger(nextRows) ||
          !Number.isInteger(nextCols) ||
          nextRows < 1 ||
          nextRows > 8 ||
          nextCols < 1 ||
          nextCols > 8
        )
          throw Error("레이아웃 행과 열은 1~8의 정수여야 합니다.");
        makeSlots(nextRows, nextCols);
        applySlotStyle(false);
        schedulePlotResize();
        return readLayoutApiState();
      }
      function setLayoutApiZoom(value) {
        applyDashboardZoom(false, readProjectNumber(value, 100, 50, 200));
        appFSM.notify("layout", "DASHBOARD_ZOOM_CHANGED");
        return readLayoutApiState();
      }
      function commitLayoutApiZoom() {
        commitDashboardScale("layout-api");
        return readLayoutApiState();
      }
      function setLayoutApiZoomLocked(locked) {
        setDashboardZoomLocked(locked === true);
        if (locked === true)
          appFSM.notify("layout", "DASHBOARD_ZOOM_LOCK_CHANGED");
        return readLayoutApiState();
      }
      function resetLayoutApiZoom() {
        if (dashboardZoomLocked) setDashboardZoomLocked(false);
        else {
          applyDashboardZoom(false, 100);
          commitDashboardScale("layout-api-reset");
        }
        return readLayoutApiState();
      }
      window.FastFigureApi = Object.freeze({
        project: Object.freeze({
          readName: () => activeProject.projectName,
          setName: setProjectName,
          importFile: importProjectFile,
          exportFile: downloadProject,
        }),
        slots: Object.freeze({
          readSelected: readSelectedSlotApi,
          select: setSelectedSlot,
          setContentType: setSlotContentType,
          reset: resetSlotApi,
          prepareFileDrop: prepareDashboardFileDrop,
          finishFileDrop: finishDashboardFileDrop,
        }),
        images: Object.freeze({
          readEditor: readImageEditorApi,
          setSettings: applyImageSettingsFromValues,
          insertEmpty: insertEmptyImageIntoSelectedSlot,
        }),
        assets: Object.freeze({
          readDeletionTarget: readAssetDeletionTarget,
          delete: deleteProjectAsset,
          readTree: () => projectDataTreeSnapshot(projectDataTreeObjects()),
          isTrashed: (path) => projectVfs.isTrashed(path),
          movable: movableProjectNode,
          readTrash: readProjectTrash,
          moveOptions: projectNodeMoveOptions,
          planMove: planProjectNodeMove,
          move: moveProjectNode,
          createDirectory: createProjectDirectory,
          emptyTrash: emptyProjectTrash,
          draggableAsset: draggableProjectAsset,
          connectToSlot: connectProjectAssetPathToSlot,
          importToDirectory: importProjectFilesToDirectory,
          importToSlot: importProjectFileToSlot,
          fileKind: slotFileKind,
          importFiles: importProjectAssetFiles,
          collisionModel: projectAssetImportCollisionModel,
          resolveImportPlan: resolveProjectAssetImportPlan,
          selectDirectory: selectDirectoryFromTree,
          selectCsv: selectCsvFromTree,
          selectImage: selectImageFromTree,
          download: downloadProjectAsset,
        }),
        graphs: Object.freeze({
          readData: readGraphDataApi,
          readLayout: readGraphLayoutApi,
          readPalette: readGraphPaletteApi,
          selectCsv: graphEditorSelectCsv,
          setHeaderLines: graphEditorHeaderLines,
          setEditable: graphEditorSetEditable,
          addObject: graphEditorAdd,
          moveObject: graphEditorMove,
          selectObject: graphEditorSelectObject,
          setObjectValues: graphEditorObjectValues,
          deleteObject: graphEditorDelete,
          updateLayout: updateGraphLayoutApi,
          applyPalette: applyGraphPaletteApi,
          defaultColors: () => [...DEFAULT_COLORS],
          hasSelectedSlot: () => !!getSelectedSlot(),
          importFile: importSelectedGraphFile,
          exportFfsx: downloadSlotFfsx,
          exportPlotlyJson: downloadPlotlyJson,
        }),
        print: Object.freeze({
          readSettings: readPrintApiSettings,
          setSettings: setPrintApiSettings,
          save: savePrintApi,
          capture: capturePrintApi,
        }),
        captions: Object.freeze({
          readGlobal: readGlobalCaptionState,
          readSlot: readSlotCaptionState,
          setEnabled: setCaptionsApiEnabled,
          setGlobalText: setGlobalCaptionText,
          setSlotText: setSlotCaptionText,
          insertSlotCaptions: insertCaptionsApiSlotCaptions,
          setName: setCaptionsApiName,
          setNameBold: setCaptionsApiNameBold,
          setSettings: setCaptionsApiSettings,
        }),
        labels: Object.freeze({
          readState: readLabelsApiState,
          setEnabled: setLabelsApiEnabled,
          setSettings: setLabelsApiSettings,
          setPosition: setLabelsApiPosition,
          finishPositionInteraction: finishLabelsApiPositionInteraction,
          resetPosition: resetLabelsApiPosition,
        }),
        appearance: Object.freeze({
          readPalette: readAppearanceApiPalette,
          setPalette: setAppearanceApiPalette,
          resetPalette: resetAppearanceApiPalette,
        }),
        layout: Object.freeze({
          readState: readLayoutApiState,
          setStyle: setLayoutApiStyle,
          setGrid: setLayoutApiGrid,
          setZoom: setLayoutApiZoom,
          commitZoom: commitLayoutApiZoom,
          setZoomLocked: setLayoutApiZoomLocked,
          resetZoom: resetLayoutApiZoom,
          mergeSlots,
          splitSlots,
        }),
      });
      window.addEventListener("error", (event) =>
        debugLog("window:error", {
          message: event.message,
          source: event.filename,
          line: event.lineno,
          column: event.colno,
        }),
      );
      window.addEventListener("unhandledrejection", (event) =>
        debugLog("window:unhandledrejection", {
          message: event.reason?.message || String(event.reason),
        }),
      );
      debugLog("app:init", {
        build: projectObjects.read("project").appBuild,
        userAgent: navigator.userAgent,
        location: location.href,
      });
      applyDashboardZoom();
      installSlotClickController();
      applySlotStyle();
      renderDashboard();
      appFSM.ready();
      debugLog(
        "app:init-complete",
        {
          slots: activeProject.slots.length,
          charts: activeProject.charts.length,
          build: projectObjects.read("project").appBuild,
        },
        "info",
      );
      auditApp("app:init");
    