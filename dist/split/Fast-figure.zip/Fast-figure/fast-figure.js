// sourcecode/backend/settings.js
function readBackendSettings() {
  const config = JSON.parse(document.getElementById("ff-backend-settings").textContent);
  if (!config.backend?.project_object || !config.backend?.defaults)
    throw Error("Backend 설정 원천이 올바르지 않습니다.");
  const freeze = (value2) => {
    if (value2 && typeof value2 === "object") {
      Object.values(value2).forEach(freeze);
      Object.freeze(value2);
    }
    return value2;
  };
  return freeze(config.backend);
}
var BackendSettings = readBackendSettings();
var PACKAGE_FORMAT_VERSION = BackendSettings.project_object.ffpx.formatVersion;
var APP_BUILD = "1.1.43-wip";
var PROJECT_OBJECT_PATHS = Object.freeze({
  project: "meta",
  layout: "layout",
  labels: "annotations.labels",
  captions: "annotations.captions",
  data: "assets.csvFiles",
  images: "assets.images",
  files: "fileSystem",
  charts: "charts",
  slots: "slots",
  sequences: "nextId",
  appearance: "appearance",
  export: "export"
});
var DEFAULT_SLOT_STYLE = BackendSettings.project_object.layout.slotStyle;
var DEFAULT_UI_PALETTE = BackendSettings.project_object.appearance.uiPalette;
var DEFAULT_COLORS = BackendSettings.defaults.graphColors;
var DEFAULT_IMAGE_SETTINGS = BackendSettings.defaults.slotSettings.content.imageSettings;
var SLOT_LOCAL_DEFAULTS = Object.freeze({
  chart: null,
  imageId: null,
  contentType: "graph",
  imageSettings: DEFAULT_IMAGE_SETTINGS,
  caption: null
});

// sourcecode/backend/layout_annotations.js
function resolveLayoutCommandSlots(candidate, slotIds) {
  if (!Array.isArray(slotIds) || !slotIds.length || !slotIds.every(Number.isInteger))
    throw Error("현재 표시된 슬롯 ID를 선택하세요.");
  return [...new Set(slotIds)].map((id) => {
    const slot = candidate.slots.find((item) => item.id === id);
    if (!slot || slot.hidden) throw Error("현재 표시된 슬롯을 확인할 수 없습니다.");
    return slot;
  });
}
function dashboardReferenceWidth() {
  return activeProject.layout.slotStyle.referenceWidth;
}
function dashboardAspectValue() {
  return activeProject.layout.slotStyle.aspect;
}
function dashboardOuterMarginPixels() {
  return activeProject.layout.slotStyle.outerMargin;
}
function slotGapPixels() {
  return activeProject.layout.slotStyle.gap;
}
function slotRadiusPixels() {
  return activeProject.layout.slotStyle.radius;
}
function dashboardGeometry(width = dashboardReferenceWidth(), heightOverride = null) {
  return dashboardGeometryInProject(activeProject._state, width, heightOverride);
}
function dashboardGeometryInProject(project, width, heightOverride = null) {
  let style = project.layout.slotStyle, referenceWidth = style.referenceWidth, scale = width / referenceWidth, configuredAspect = style.aspect, naturalHeight = width / configuredAspect, height = Number.isFinite(heightOverride) && heightOverride > 0 ? Number(heightOverride) : naturalHeight, aspect = configuredAspect, outerMargin = Math.min(
    style.outerMargin * scale,
    Math.min(width, height) * 0.49
  );
  return {
    referenceWidth,
    width,
    height,
    scale,
    aspect,
    outerMargin,
    gap: style.gap * scale,
    radius: style.radius * scale
  };
}
function gridSlotGeometry(layout2, geometry, slot = null) {
  let gap = geometry.gap, colWidth = (geometry.width - geometry.outerMargin * 2 - gap * (layout2.gridCols - 1)) / layout2.gridCols, rowHeight = (geometry.height - geometry.outerMargin * 2 - gap * (layout2.gridRows - 1)) / layout2.gridRows, target = slot && !slot.hidden ? slot : { rowSpan: 1, colSpan: 1 };
  return {
    colWidth,
    rowHeight,
    width: colWidth * target.colSpan + gap * (target.colSpan - 1),
    height: rowHeight * target.rowSpan + gap * (target.rowSpan - 1)
  };
}
function newGridSlot(id, row, col) {
  return normalizeSlotContent({
    id,
    row,
    col,
    rowSpan: 1,
    colSpan: 1,
    hidden: false,
    content: { ...projectClone(BackendSettings.defaults.slotSettings.content), chart: null, imageId: null },
    caption: null
  });
}
function buildGridResizeCandidate(rows, cols) {
  return buildGridResizeInProject(activeProject._state, rows, cols);
}
function buildGridResizeInProject(source, rows, cols) {
  const limits = BackendSettings.defaults.limits.layout;
  if (!Number.isInteger(rows) || !Number.isInteger(cols) || rows < limits.gridRows[0] || rows > limits.gridRows[1] || cols < limits.gridCols[0] || cols > limits.gridCols[1])
    throw Error("레이아웃 행과 열은 설정 범위 안의 정수여야 합니다.");
  for (const slot of source.slots) {
    if (slot.row + slot.rowSpan - 1 <= rows && slot.col + slot.colSpan - 1 <= cols) continue;
    if (slotHasNonDefaultLocalState(slot))
      throw Error("내용이 있는 영역은 그리드 축소로 제거할 수 없습니다.");
    if (slot.rowSpan > 1 || slot.colSpan > 1)
      throw Error("병합된 슬롯을 가로지르도록 그리드를 축소할 수 없습니다.");
  }
  const candidate = projectClone(source), oldRows = source.layout.gridRows, oldCols = source.layout.gridCols;
  let nextId = Math.max(-1, ...source.slots.map((slot) => slot.id)) + 1;
  candidate.layout.gridRows = rows;
  candidate.layout.gridCols = cols;
  candidate.slots = candidate.slots.filter((slot) => slot.row <= rows && slot.col <= cols);
  for (let row = 1; row <= rows; row++) for (let col = 1; col <= cols; col++) {
    if (row > oldRows || col > oldCols) candidate.slots.push(newGridSlot(nextId++, row, col));
  }
  validateProjectObjectState(candidate, { requireSlots: true });
  return candidate;
}
function slotImage(slot, collection = activeProject.images) {
  return getProjectImage(slot?.imageId, collection);
}
function normalizeImageSettings(slot) {
  if (!slot) return null;
  const content = slot.content && typeof slot.content === "object" && !Array.isArray(slot.content) ? slot.content : {};
  const settings = content.imageSettings && typeof content.imageSettings === "object" ? content.imageSettings : slot.imageSettings && typeof slot.imageSettings === "object" ? slot.imageSettings : DEFAULT_IMAGE_SETTINGS;
  return readImageSettings(settings);
}
function readImageSettings(settings) {
  let source = settings && typeof settings === "object" && !Array.isArray(settings) ? settings : {}, defaults = BackendSettings.defaults.slotSettings.content.imageSettings, limits = BackendSettings.defaults.limits.imageSettings, fit = ["contain", "cover", "manual"].includes(source.fit) ? source.fit : defaults.fit, number = (value2, fallback, min, max) => Math.max(min, Math.min(max, Number.isFinite(Number(value2)) ? Number(value2) : fallback));
  return {
    ...projectClone(source),
    fit,
    scale: number(source.scale, defaults.scale, ...limits.scale),
    x: number(source.x, defaults.x, ...limits.x),
    y: number(source.y, defaults.y, ...limits.y)
  };
}
function alphaIdentifier(index, upper = false) {
  let label = "";
  do {
    label = String.fromCharCode((upper ? 65 : 97) + index % 26) + label;
    index = Math.floor(index / 26) - 1;
  } while (index >= 0);
  return label;
}
function romanIdentifier(index) {
  let value2 = index + 1, parts = [
    [1e3, "M"],
    [900, "CM"],
    [500, "D"],
    [400, "CD"],
    [100, "C"],
    [90, "XC"],
    [50, "L"],
    [40, "XL"],
    [10, "X"],
    [9, "IX"],
    [5, "V"],
    [4, "IV"],
    [1, "I"]
  ], result = "";
  for (let [amount, symbol] of parts)
    while (value2 >= amount) {
      result += symbol;
      value2 -= amount;
    }
  return result;
}
function slotIdentifier(index, project = activeProject) {
  let settings = project.annotations?.labels.settings ?? project.labelSettings;
  if (settings.format === "decimal") return String(index + 1);
  if (settings.format === "lower-roman") return romanIdentifier(index).toLowerCase();
  if (settings.format === "upper-roman") return romanIdentifier(index);
  return alphaIdentifier(index, settings.format === "upper-alpha");
}
function displayedSlotIdentifier(index, project = activeProject) {
  let identifier = slotIdentifier(index, project);
  return project.annotations.labels.settings.parentheses === true ? `(${identifier})` : identifier;
}
function orderedVisibleSlots(project = activeProject) {
  let settings = project.annotations?.labels.settings ?? project.labelSettings;
  return project.slots.filter((slot) => !slot.hidden).sort(
    (a, b) => settings.order === "column-major" ? a.col - b.col || a.row - b.row : a.row - b.row || a.col - b.col
  );
}
function slotLabel(slot, project = activeProject) {
  let index = orderedVisibleSlots(project).findIndex((item) => item.id === slot?.id);
  return slotIdentifier(Math.max(0, index), project);
}
function normalizeLegacySlotCaptionDefaults(project = activeProject) {
  orderedVisibleSlots(project).forEach((slot) => {
    if (slot.caption === `${slotLabel(slot, project)} 슬롯 캡션`)
      slot.caption = "슬롯 캡션";
  });
}
function orderedSlotLabels(project) {
  let settings = project.annotations.labels.settings;
  return Object.freeze(orderedVisibleSlots(project).map((slot, ordinal) => {
    let identifier = slotIdentifier(ordinal, project);
    return Object.freeze({
      slotId: slot.id,
      ordinal,
      identifier,
      displayLabel: settings.parentheses ? `(${identifier})` : identifier
    });
  }));
}
function insertSlotCaptions(project, slotIds = null) {
  let labels = orderedSlotLabels(project), selected = null;
  if (slotIds !== null) {
    if (!Array.isArray(slotIds)) throw Error("캡션 대상은 슬롯 ID 목록이어야 합니다.");
    selected = new Set(slotIds);
    let visible = new Set(labels.map((label) => label.slotId));
    for (let id of selected)
      if (!visible.has(id)) throw Error("캡션 대상 슬롯이 없거나 숨겨져 있습니다.");
  }
  let groups = [], current = null;
  for (let label of labels) {
    if (selected && !selected.has(label.slotId)) continue;
    let text = project.slots.find((slot) => slot.id === label.slotId).caption ?? "";
    if (current && label.ordinal === current.endOrdinal + 1 && (text === "" || text === current.text)) {
      current.endOrdinal = label.ordinal;
      current.last = label.identifier;
    } else {
      current = {
        first: label.identifier,
        last: label.identifier,
        endOrdinal: label.ordinal,
        text
      };
      groups.push(current);
    }
  }
  let inserted = groups.map((group) => `(${group.first}${group.first === group.last ? "" : `-${group.last}`})` + (group.text === "" ? "" : ` ${group.text}`)).join(" "), before = project.annotations.captions.text;
  if (!inserted) return before;
  return before + (before && !before.endsWith(" ") ? " " : "") + inserted;
}
function activeCaptionView(caption = projectObjects.read("captions")) {
  return {
    enabled: caption.enabled,
    text: caption.text,
    afterText: caption.afterText,
    sections: [],
    aggregate: false,
    label: "",
    name: caption.name,
    nameBold: caption.nameBold,
    settings: caption.settings,
    slot: null,
    exportText: caption.text
  };
}

// sourcecode/backend/project_state.js
function createProjectState() {
  let state = {
    kind: "fast-figure-project-object",
    meta: { projectName: "", appBuild: APP_BUILD },
    layout: structuredClone(BackendSettings.project_object.layout),
    annotations: {
      labels: projectClone(BackendSettings.project_object.annotations.labels),
      captions: {
        ...projectClone(BackendSettings.project_object.annotations.captions),
        text: "",
        afterText: "",
        name: ""
      }
    },
    assets: { csvFiles: [], images: [] },
    fileSystem: {
      directories: Object.values(BackendSettings.defaults.vfs)
    },
    charts: [],
    slots: [],
    nextId: { csv: 1, image: 1, chart: 1 },
    appearance: { uiPalette: { ...DEFAULT_UI_PALETTE } },
    export: {
      ...structuredClone(BackendSettings.project_object.export),
      width: BackendSettings.project_object.layout.slotStyle.referenceWidth,
      height: BackendSettings.project_object.export.heightMode === "auto" ? null : BackendSettings.defaults.limits.export.logicalHeight[0]
    }
  };
  for (let index = 0; index < state.layout.gridRows * state.layout.gridCols; index++)
    state.slots.push(newGridSlot(
      index,
      Math.floor(index / state.layout.gridCols) + 1,
      index % state.layout.gridCols + 1
    ));
  return validateProjectObjectState(state, { requireSlots: true });
}
function projectObjectPath(state, path) {
  return String(path).split(".").reduce((value2, key) => value2?.[key], state);
}
var ProjectObject = class _ProjectObject {
  constructor(state = createProjectState()) {
    const next = structuredClone(state instanceof _ProjectObject ? state._state : state);
    normalizeSlotContents(next.slots);
    normalizeProjectSettings(next);
    validateProjectObjectState(next, { requireSlots: true });
    this._state = next;
  }
  static fromFFPX(payload, fileName) {
    return buildProjectObject(payload, fileName);
  }
  read(path) {
    let value2 = projectObjectPath(this._state, path);
    if (value2 === void 0) throw Error(`프로젝트 오브젝트 경로 ${path}가 없습니다.`);
    return value2;
  }
  initialize(source) {
    let next = projectClone(source instanceof _ProjectObject ? source._state : source);
    normalizeSlotContents(next.slots);
    normalizeProjectSettings(next);
    validateProjectObjectState(next, { requireSlots: true });
    let previous = this._state;
    this._state = next;
    return previous;
  }
  get meta() {
    return this._state.meta;
  }
  get layout() {
    return this._state.layout;
  }
  get annotations() {
    return this._state.annotations;
  }
  get assets() {
    return this._state.assets;
  }
  get appearance() {
    return this._state.appearance;
  }
  get projectName() {
    return this.meta.projectName;
  }
  set projectName(value2) {
    this.meta.projectName = value2;
  }
  get appBuild() {
    return this.meta.appBuild;
  }
  get gridRows() {
    return this.layout.gridRows;
  }
  set gridRows(value2) {
    this.layout.gridRows = value2;
  }
  get gridCols() {
    return this.layout.gridCols;
  }
  set gridCols(value2) {
    this.layout.gridCols = value2;
  }
  get csvFiles() {
    return this.assets.csvFiles;
  }
  set csvFiles(value2) {
    this.assets.csvFiles = value2;
  }
  get images() {
    return this.assets.images;
  }
  set images(value2) {
    this.assets.images = value2;
  }
  get fileSystem() {
    return this._state.fileSystem;
  }
  set fileSystem(value2) {
    this._state.fileSystem = value2;
  }
  get charts() {
    return this._state.charts;
  }
  set charts(value2) {
    this._state.charts = value2;
  }
  get slots() {
    return this._state.slots;
  }
  set slots(value2) {
    this._state.slots = normalizeSlotContents(value2);
  }
  get csvId() {
    return this._state.nextId.csv;
  }
  set csvId(value2) {
    this._state.nextId.csv = value2;
  }
  get imageId() {
    return this._state.nextId.image;
  }
  set imageId(value2) {
    this._state.nextId.image = value2;
  }
  get chartId() {
    return this._state.nextId.chart;
  }
  set chartId(value2) {
    this._state.nextId.chart = value2;
  }
  get labelsEnabled() {
    return this.annotations.labels.enabled;
  }
  set labelsEnabled(value2) {
    this.annotations.labels.enabled = value2;
  }
  get labelSettings() {
    return this.annotations.labels.settings;
  }
  set labelSettings(value2) {
    this.annotations.labels.settings = value2;
  }
  get captionsEnabled() {
    return this.annotations.captions.enabled;
  }
  set captionsEnabled(value2) {
    this.annotations.captions.enabled = value2;
  }
  get captionText() {
    return this.annotations.captions.text;
  }
  set captionText(value2) {
    this.annotations.captions.text = value2;
  }
  get captionAfterText() {
    return this.annotations.captions.afterText;
  }
  set captionAfterText(value2) {
    this.annotations.captions.afterText = value2;
  }
  get captionName() {
    return this.annotations.captions.name;
  }
  set captionName(value2) {
    this.annotations.captions.name = value2;
  }
  get captionNameBold() {
    return this.annotations.captions.nameBold;
  }
  set captionNameBold(value2) {
    this.annotations.captions.nameBold = value2;
  }
  get captionSettings() {
    return this.annotations.captions.settings;
  }
  set captionSettings(value2) {
    this.annotations.captions.settings = value2;
  }
  get exportSettings() {
    return this._state.export;
  }
  set exportSettings(value2) {
    this._state.export = value2;
  }
};
var activeProject;
function initializeActiveProject() {
  const candidate = createProjectState();
  validateProjectObjectState(candidate, { requireSlots: true });
  activeProject = new ProjectObject(candidate);
}
var ProjectObjectRegistry = class {
  constructor(projectProvider) {
    if (typeof projectProvider !== "function")
      throw Error("프로젝트 오브젝트 공급자가 없습니다.");
    this.projectProvider = projectProvider;
    this.adapters = /* @__PURE__ */ new Map();
  }
  register(name, adapter) {
    if (!name || this.adapters.has(name) || typeof adapter?.read !== "function")
      throw Error(`프로젝트 오브젝트 어댑터 ${name}을 등록할 수 없습니다.`);
    this.adapters.set(name, Object.freeze({ ...adapter }));
    return this;
  }
  registerPath(name, path) {
    return this.register(name, {
      path,
      read: (project) => project.read(path)
    });
  }
  read(name) {
    let adapter = this.adapters.get(name);
    if (!adapter) throw Error(`프로젝트 오브젝트 ${name}이 없습니다.`);
    let project = this.projectProvider();
    if (!(project instanceof ProjectObject))
      throw Error("활성 프로젝트 오브젝트가 없습니다.");
    return adapter.read(project);
  }
  snapshot(names = Object.keys(PROJECT_OBJECT_PATHS)) {
    const project = this.projectProvider();
    if (!(project instanceof ProjectObject)) throw Error("활성 프로젝트 오브젝트가 없습니다.");
    const source = project._state;
    return immutableProjectCopy(Object.fromEntries(names.map((name) => {
      const adapter = this.adapters.get(name);
      if (!Object.hasOwn(PROJECT_OBJECT_PATHS, name) || !adapter?.path)
        throw Error(`프로젝트 오브젝트 ${name}이 없습니다.`);
      const value2 = projectObjectPath(source, adapter.path);
      if (value2 === void 0) throw Error(`프로젝트 오브젝트 경로 ${adapter.path}가 없습니다.`);
      return [name, value2];
    })));
  }
  names() {
    return [...this.adapters.keys()];
  }
};
var BACKEND_QUERY_KINDS = /* @__PURE__ */ new Set([
  "project-api",
  "slot-selection-context",
  "interface-reconciliation",
  "renderer",
  "export"
]);
var PUBLIC_BACKEND_READ_OPERATIONS = /* @__PURE__ */ new Set([
  "project.readName",
  "slots.readSelected",
  "images.readEditor",
  "print.readSettings",
  "appearance.readPalette",
  "graphs.readData",
  "graphs.readLayout",
  "graphs.readPalette",
  "graphs.hasSelectedSlot",
  "graphs.defaultColors",
  "captions.readGlobal",
  "captions.readSlot",
  "labels.readState",
  "layout.readState",
  "assets.readTree",
  "assets.readTrash",
  "assets.isTrashed",
  "assets.movable",
  "assets.draggableAsset",
  "assets.readDeletionTarget",
  "assets.moveOptions",
  "assets.planMove",
  "assets.resolveTreeSelection",
  "assets.fileKind",
  "assets.collisionModel",
  "assets.resolveImportPlan",
  "project.exportFile",
  "assets.download",
  "graphs.exportFfsx",
  "graphs.exportPlotlyJson"
]);
function buildSlotAssetDisplay(slot, source) {
  const display = { kind: "empty", assets: [] };
  if (slot.content.contentType === "image") {
    const image = source.assets.images.find((item) => item.id === slot.content.imageId);
    if (image) {
      display.kind = "assets";
      display.assets.push({ kind: "image", id: image.id, name: image.name, path: projectAssetPath(image) });
    }
  } else if (slot.content.contentType === "graph") {
    const chart = source.charts.find((item) => item.id === slot.content.chart);
    if (chart?.editor.editable === false) display.kind = "embedded";
    else if (chart) {
      const seen = /* @__PURE__ */ new Set();
      for (const object of chart.editor.objects) {
        const csv = source.assets.csvFiles.find((item) => item.id === object.csvId);
        if (csv && !seen.has(csv.id)) {
          seen.add(csv.id);
          display.assets.push({ kind: "csv", id: csv.id, name: csv.name, path: projectAssetPath(csv) });
        }
      }
      if (display.assets.length) display.kind = "assets";
    }
  }
  return immutableProjectCopy(display);
}
function buildBackendVfsTree(source) {
  const nodes = new Map(source.fileSystem.directories.map((path) => [path, {
    kind: "directory",
    path,
    name: projectPathName(path),
    children: []
  }]));
  for (const [kind, assets] of [["csv", source.assets.csvFiles], ["image", source.assets.images]]) {
    for (const asset of assets) {
      const path = projectAssetPath(asset);
      nodes.set(path, { kind, path, id: asset.id, name: asset.name, asset: structuredClone(asset) });
    }
  }
  for (const node of nodes.values()) {
    const parent = nodes.get(projectParentPath(node.path));
    if (parent && parent !== node) parent.children.push(node);
  }
  return nodes;
}
function readBackendProjection(kind, request = {}) {
  if (!BACKEND_QUERY_KINDS.has(kind) || kind === "project-api" && !PUBLIC_BACKEND_READ_OPERATIONS.has(request.operation))
    throw Error(`알 수 없는 Backend query: ${kind}/${request.operation}`);
  if (kind === "project-api" && ["project.exportFile", "assets.download", "graphs.exportFfsx", "graphs.exportPlotlyJson"].includes(request.operation))
    return readBackendProjection("export", request);
  if (kind === "interface-reconciliation")
    return buildFrontendReconciliationInput(request.event, request.mutationResult, request.frontendReferences);
  if (kind === "project-api" && request.operation === "project.readName")
    return activeProject._state.meta.projectName;
  if (kind === "project-api" && request.operation === "appearance.readPalette" || kind === "renderer" && request.operation === "ui-palette")
    return Object.freeze({ ...activeProject._state.appearance.uiPalette });
  if (kind === "project-api" && request.operation === "layout.readState") {
    const source = activeProject._state, preview = BackendSettings.defaults.preview, width = request.renderedWidth == null ? preview.fallbackWidth : readProjectNumber(
      request.renderedWidth,
      preview.fallbackWidth,
      ...preview.widthRange
    );
    return immutableProjectCopy({
      gridRows: source.layout.gridRows,
      gridCols: source.layout.gridCols,
      gridLimits: structuredClone(BackendSettings.defaults.limits.layout),
      slotStyle: Object.freeze({ ...source.layout.slotStyle }),
      visibleSlots: Object.freeze(source.slots.filter((slot2) => !slot2.hidden).map((slot2) => Object.freeze({
        id: slot2.id,
        row: slot2.row,
        col: slot2.col,
        rowSpan: slot2.rowSpan,
        colSpan: slot2.colSpan,
        contentType: slot2.content.contentType,
        chart: slot2.content.chart,
        imageId: slot2.content.imageId,
        assetDisplay: buildSlotAssetDisplay(slot2, source)
      }))),
      previewGeometry: Object.freeze(dashboardGeometryInProject(source, width))
    });
  }
  if (kind === "project-api" && request.operation === "labels.readState") {
    const source = activeProject._state, labels = source.annotations.labels, slot2 = source.slots.find((item) => item.id === request.slotId && !item.hidden) ?? null, geometry = dashboardGeometryInProject(source, source.layout.slotStyle.referenceWidth), reference = gridSlotGeometry(source.layout, geometry, slot2), identifier = slotIdentifier(0, source);
    return immutableProjectCopy({
      enabled: labels.enabled,
      settings: Object.freeze({ ...labels.settings }),
      reference: Object.freeze(reference),
      sampleText: labels.settings.parentheses ? `(${identifier})` : identifier
    });
  }
  if (kind === "project-api" && request.operation === "captions.readGlobal") {
    let captions = activeProject._state.annotations.captions;
    return immutableProjectCopy(captions);
  }
  if (kind === "project-api" && request.operation === "captions.readSlot") {
    const slot2 = activeProject._state.slots.find((item) => item.id === request.slotId && !item.hidden);
    return slot2 ? Object.freeze({
      id: slot2.id,
      row: slot2.row,
      col: slot2.col,
      text: slot2.caption ?? ""
    }) : null;
  }
  if (kind === "project-api" && request.operation === "assets.isTrashed")
    return projectVfs.isTrashed(request.path);
  if (kind === "project-api" && request.operation === "assets.planMove")
    return planProjectNodeMove(request.path, request.directory, activeProject._state);
  if (kind === "project-api" && [
    "assets.movable",
    "assets.moveOptions",
    "assets.draggableAsset",
    "assets.resolveTreeSelection"
  ].includes(request.operation)) {
    const source = activeProject._state, path = normalizeProjectPath(request.path, { directory: true }), node = projectVfs.resolve(path, source), fixed = projectVfs.isFixedDirectory(path);
    if (request.operation === "assets.movable") return !!node && !fixed;
    if (request.operation === "assets.moveOptions")
      return immutableProjectCopy(!node || fixed ? [] : source.fileSystem.directories.filter((directory) => node.kind !== "directory" || !projectPathInDirectory(directory, path)));
    if (request.operation === "assets.resolveTreeSelection")
      return immutableProjectCopy(node ? {
        accepted: true,
        kind: node.kind,
        path: node.kind === "directory" ? node.path : projectAssetPath(node.asset)
      } : { accepted: false, kind: null, path: null });
    if (!node || !["csv", "image"].includes(node.kind) || projectVfs.isTrashed(path)) return null;
    return immutableProjectCopy({
      kind: node.kind,
      id: node.asset.id,
      path: projectAssetPath(node.asset),
      name: node.asset.name
    });
  }
  if (kind === "project-api" && request.operation === "assets.fileKind")
    return slotFileKind(request.file);
  if (kind === "project-api" && request.operation === "assets.collisionModel")
    return immutableProjectCopy(projectAssetImportCollisionModel(
      request.file,
      request.directory,
      new Set(request.reservedPaths || [])
    ));
  if (kind === "project-api" && request.operation === "assets.resolveImportPlan")
    return immutableProjectCopy(resolveProjectAssetImportPlan(
      request.model,
      request.choice,
      new Set(request.reservedPaths || [])
    ));
  if (kind === "project-api" && request.operation === "assets.readDeletionTarget") {
    const source = activeProject._state, node = request.path ? projectVfs.resolve(request.path, source) : null;
    if (!["csv", "image"].includes(node?.kind)) return null;
    const references = collectAssetReferences(
      new Set(node.kind === "csv" ? [node.asset.id] : []),
      new Set(node.kind === "image" ? [node.asset.id] : []),
      source
    );
    return immutableProjectCopy({
      target: node.asset,
      kind: node.kind,
      path: projectAssetPath(node.asset),
      referenceCount: references.length,
      references
    });
  }
  if (kind === "project-api" && request.operation === "slots.readSelected") {
    const source = activeProject._state, slot2 = source.slots.find((item) => item.id === request.frontendState?.selectedSlotId && !item.hidden);
    return slot2 ? immutableProjectCopy({
      id: slot2.id,
      row: slot2.row,
      col: slot2.col,
      rowSpan: slot2.rowSpan,
      colSpan: slot2.colSpan,
      hidden: slot2.hidden,
      content: slot2.content,
      caption: slot2.caption
    }) : null;
  }
  if (kind === "project-api" && request.operation === "assets.readTrash") {
    const source = activeProject._state, tree = buildBackendVfsTree(source);
    return immutableProjectCopy(tree.get(BackendSettings.defaults.vfs.trash) ?? null);
  }
  if (kind === "project-api" && request.operation === "assets.readTree") {
    const source = activeProject._state;
    return immutableProjectCopy(Array.from(buildBackendVfsTree(source).values()));
  }
  if (kind === "project-api" && request.operation === "graphs.defaultColors")
    return immutableProjectCopy(DEFAULT_COLORS);
  if (kind === "project-api" && request.operation === "graphs.hasSelectedSlot")
    return activeProject._state.slots.some((slot2) => slot2.id === request.selectedSlotId && !slot2.hidden && slot2.content.contentType === "graph");
  if (kind === "project-api" && request.operation === "graphs.readPalette") {
    const source = activeProject._state, slot2 = source.slots.find((item) => item.id === request.selectedSlotId && !item.hidden && item.content.contentType === "graph"), chart = slot2 ? source.charts.find((item) => item.id === slot2.content.chart) : null;
    return immutableProjectCopy((chart?.editor?.objects || []).map((object) => object.color));
  }
  if (kind === "project-api" && request.operation === "graphs.readLayout") {
    const source = activeProject._state, slot2 = source.slots.find((item) => item.id === request.selectedSlotId && !item.hidden), chartId = slot2?.content.chart, chart = slot2?.content.contentType === "graph" ? source.charts.find((item) => item.id === chartId) : null;
    return chart ? immutableProjectCopy({
      chartId: chart.id,
      editable: chart.editor?.editable !== false,
      title: chart.editor?.title ?? "",
      settings: normalizeGraphLayoutSettings(chart.editor?.globalSettings)
    }) : null;
  }
  if (kind === "project-api" && request.operation === "graphs.readData") {
    const source = activeProject._state, state = request.frontendState || {}, slot2 = Object.hasOwn(request, "chartId") ? resolveOwningSlot(request.chartId, source) : source.slots.find((item) => item.id === state.selectedSlotId && !item.hidden), chartId = slot2?.content.chart, chart = slot2 && slot2.content.contentType === "graph" ? source.charts.find((item) => item.id === chartId) || null : null, objects = chart?.editor?.objects || [], index = state.graphObjectIndex, selectedIndex = chart && chart.editor.editable !== false && Number.isInteger(index) && index >= 0 && index < objects.length ? index : null, node = state.assetSelection === "csv" && state.assetPath ? projectVfs.resolve(state.assetPath, source) : null, csv = node?.kind === "csv" ? node.asset : null, objectCsv = selectedIndex === null ? null : source.assets.csvFiles.find((item) => item.id === objects[selectedIndex].csvId);
    return immutableProjectCopy({
      chart,
      objects,
      selectedIndex,
      currentCsv: csv,
      columns: csv ? columnDefinitions(csv.rows, csv.headerLines) : [],
      objectColumns: objectCsv ? columnDefinitions(objectCsv.rows, objectCsv.headerLines) : []
    });
  }
  if (kind === "project-api" && request.operation === "print.readSettings")
    return immutableProjectCopy(activeProject._state.export);
  if (kind === "project-api" && request.operation === "images.readEditor" || kind === "renderer" && request.operation === "slot-image") {
    return immutableProjectCopy(buildBackendImageRead(activeProject._state, request.slotId));
  }
  if (kind === "renderer" || kind === "export" && ["print.save", "print.capture"].includes(request.operation)) {
    const source = activeProject._state, output = buildBackendSurfaceRead(source);
    if (kind === "export") {
      output.export = structuredClone(source.export);
      output.rasterLimits = structuredClone(BackendSettings.defaults.limits.export);
    }
    return immutableProjectCopy(output);
  }
  if (kind === "export" && request.operation == null) {
    const source = activeProject._state;
    return immutableProjectCopy({
      ...source,
      slots: source.slots.map((slot2) => ({ ...slot2, content: { ...slot2.content } }))
    });
  }
  if (kind === "export" && request.operation === "project.exportFile") {
    const source = activeProject._state, bundle = ffpxBuildProject(source);
    return Object.freeze({
      name: `${projectFileStem(source.meta.projectName)}-${request.stamp}.ffpx`,
      mime: "application/vnd.fast-figure-project",
      entries: Object.freeze(bundle.assets.map((entry) => Object.freeze({
        name: entry.name,
        data: Object.freeze(Array.from(entry.data))
      })))
    });
  }
  if (kind === "export" && request.operation === "assets.download") {
    const source = activeProject._state, selected = request.path ? projectVfs.resolve(request.path, source) : null, asset = ["csv", "image"].includes(selected?.kind) ? selected.asset : null;
    if (!asset?.bytesBase64) return null;
    return Object.freeze({
      name: asset.name,
      mime: asset.mime || "application/octet-stream",
      bytes: Object.freeze(Array.from(ffpxBase64ToBytes(asset.bytesBase64)))
    });
  }
  if (kind === "export" && ["graphs.exportPlotlyJson", "graphs.exportFfsx"].includes(request.operation)) {
    const source = activeProject._state, slot2 = source.slots.find((item) => item.id === request.slotId && !item.hidden), chart = slot2 && slot2.content.contentType === "graph" ? source.charts.find((item) => item.id === slot2.content.chart) : null;
    if (!chart) return null;
    if (request.operation === "graphs.exportFfsx") {
      const bundle = ffsxBuildSlot(slot2, chart, source);
      return Object.freeze({
        name: `fast-figure-slot-${slot2.id}-${request.stamp}.ffsx`,
        mime: "application/vnd.fast-figure-slot",
        entries: Object.freeze(bundle.assets.map((entry) => Object.freeze({
          name: entry.name,
          data: Object.freeze(Array.from(entry.data))
        })))
      });
    }
    const bytes = new TextEncoder().encode(JSON.stringify(chartFigure(chart, source)));
    return Object.freeze({
      name: `plotly-figure-${slot2.id}-${request.stamp}.json`,
      mime: "application/json",
      bytes: Object.freeze(Array.from(bytes))
    });
  }
  if (kind !== "slot-selection-context") throw Error(`알 수 없는 Backend query: ${kind}`);
  let slot = request.slotId == null ? null : slotAt(request.slotId);
  return slot && !slot.hidden ? Object.freeze({
    id: slot.id,
    empty: slot.content.chart === null && slot.content.imageId === null,
    contentType: slot.content.contentType
  }) : null;
}
function buildBackendImageRead(source, slotId) {
  const original = source.slots.find((item) => item.id === slotId && !item.hidden);
  if (!original || original.content.contentType !== "image") return null;
  const image = source.assets.images.find((item) => item.id === original.content.imageId);
  if (!image) return null;
  const slot = normalizeSlotContent(structuredClone(original));
  return {
    slotId: slot.id,
    name: image.name,
    bytes: Array.from(ffpxBase64ToBytes(image.bytesBase64 || "")),
    src: projectImageDataUrl(image),
    settings: structuredClone(slot.content.imageSettings)
  };
}
function buildBackendSurfaceRead(source) {
  const output = {
    layout: structuredClone(source.layout),
    appearance: structuredClone(source.appearance),
    annotations: structuredClone(source.annotations),
    visibleSlots: [],
    orderedSlotLabels: orderedSlotLabels(source),
    captionReferenceStyle: structuredClone(BackendSettings.defaults.captionReferenceStyle)
  };
  for (const original of source.slots) {
    if (original.hidden) continue;
    const slot = structuredClone(original), chart = source.charts.find((item) => item.id === original.content.chart);
    if (chart) {
      slot.chart = structuredClone(chart);
      slot.figure = chartFigure(structuredClone(chart), source);
      slot.csvViews = [];
      if (!chartUsesConversionView(chart)) {
        for (const object of chart.editor.objects) {
          const csv = source.assets.csvFiles.find((item) => item.id === object.csvId);
          if (csv) slot.csvViews.push({ csv: structuredClone(csv), columns: columnDefinitions(csv.rows, csv.headerLines) });
        }
      }
    }
    if (original.content.imageId !== null) slot.imageView = buildBackendImageRead(source, original.id);
    output.visibleSlots.push(slot);
  }
  return output;
}
function validateFrontendIntent(event, payload = {}) {
  let input = { event, accepted: true, reference: null, workspaceHint: null, selectionHint: null };
  if (event === "SELECT_SLOT") {
    if (!Object.hasOwn(payload, "slotId")) input.accepted = false;
    else if (payload.slotId === null) {
      input.workspaceHint = "project";
      input.selectionHint = "toggle-clear";
    } else {
      let slot = slotAt(payload.slotId);
      if (!slot || slot.hidden) input.accepted = false;
      else {
        input.reference = slot.id;
        input.workspaceHint = slot.content.contentType === "image" ? "slot.image" : "slot.graph";
        input.selectionHint = payload.direction === "model-to-fsm" ? "clear-graph-object" : "toggle-clear";
      }
    }
  } else if (event === "SELECT_ASSET") {
    if (!Object.hasOwn(payload, "path")) input.accepted = false;
    else if (payload.path !== null) {
      let match = projectVfs.resolve(payload.path);
      if (!match || match.kind !== payload.kind || !["csv", "image", "directory"].includes(match.kind))
        input.accepted = false;
      else {
        input.reference = match.kind === "directory" ? match.path : projectAssetPath(match.asset);
        input.selectionHint = match.kind;
      }
    }
  } else if (event === "SELECT_GRAPH_OBJECT") {
    if (!Object.hasOwn(payload, "index")) input.accepted = false;
    else if (payload.index !== null) {
      let slot = slotAt(payload.selectedSlotId), chart = slot && !slot.hidden && slot.content.contentType === "graph" ? getChart(slot.content.chart) : null, object = Number.isInteger(payload.index) && payload.index >= 0 ? chart?.editor?.objects?.[payload.index] : null, csv = object ? getProjectCsv(object.csvId) : null;
      if (chart?.editor?.editable === false || !object || !csv) input.accepted = false;
      else {
        input.reference = payload.index;
        input.selectionHint = payload.selectAsset === true ? projectAssetPath(csv) : null;
      }
    }
  } else input.accepted = false;
  return Object.freeze(input);
}
function buildFrontendReconciliationInput(event, result, references) {
  if (result.committed !== true) throw Error("commit된 Project 결과만 재조정할 수 있습니다.");
  let hints = result.selectionHints || {}, slotId = references.selectedSlotId, assetPath = references.assetPath, graphObjectIndex = references.graphObjectIndex;
  if (hints.resetInterfaceSelection) {
    slotId = assetPath = graphObjectIndex = null;
  } else {
    if (Array.isArray(hints.swapSlotIds) && hints.swapSlotIds.length === 2) {
      let [source, target] = hints.swapSlotIds;
      if (slotId === source) slotId = target;
      else if (slotId === target) slotId = source;
    }
    if (hints.mergeSlotIds?.includes(slotId)) slotId = hints.anchorId;
    if (assetPath && hints.movedPathFrom && projectPathInDirectory(assetPath, hints.movedPathFrom))
      assetPath = `${hints.movedPathTo}${assetPath.slice(hints.movedPathFrom.length)}`;
  }
  let slot = slotId == null ? null : slotAt(slotId);
  if (!slot || slot.hidden) slotId = null;
  let asset = assetPath ? projectVfs.resolve(assetPath) : null;
  if (hints.clearAssetSelection || !asset || hints.enteringTrash && projectVfs.isTrashed(assetPath)) {
    asset = null;
    assetPath = null;
  } else assetPath = asset.kind === "directory" ? asset.path : projectAssetPath(asset.asset);
  let chart = slotId !== null && slot.content.contentType === "graph" ? getChart(slot.content.chart) : null;
  if (chart?.editor?.editable === false) chart = null;
  if (chart && hints.chartId === chart.id && Object.hasOwn(hints, "selectedIndexHint"))
    graphObjectIndex = hints.selectedIndexHint;
  else if (chart) {
    const map = hints.graphObjectIndexMaps?.find((item) => item.chartId === chart.id);
    if (map) graphObjectIndex = Number.isInteger(graphObjectIndex) ? map.indices[graphObjectIndex] ?? null : null;
  }
  if (hints.resetInterfaceSelection || hints.clearGraphSelection || !Number.isInteger(graphObjectIndex) || graphObjectIndex < 0 || graphObjectIndex >= (chart?.editor?.objects?.length || 0))
    graphObjectIndex = null;
  return Object.freeze({
    event,
    selectedSlot: slotId,
    projectionEffect: result.projectionEffect ? immutableProjectCopy(result.projectionEffect) : result.projectionEffect,
    assetSelection: assetPath,
    assetKind: asset?.kind ?? null,
    graphObject: graphObjectIndex,
    workspaceHint: slotId === null ? "project" : slot.content.contentType === "image" ? "slot.image" : "slot.graph"
  });
}
function immutableProjectCopy(value2) {
  const freeze = (copy) => {
    if (copy && typeof copy === "object") {
      Object.values(copy).forEach(freeze);
      Object.freeze(copy);
    }
    return copy;
  };
  return freeze(structuredClone(value2));
}
var projectObjects;
function initializeProjectObjects() {
  projectObjects = new ProjectObjectRegistry(() => activeProject).registerPath("project", PROJECT_OBJECT_PATHS.project).registerPath("layout", PROJECT_OBJECT_PATHS.layout).registerPath("labels", PROJECT_OBJECT_PATHS.labels).registerPath("captions", PROJECT_OBJECT_PATHS.captions).registerPath("data", PROJECT_OBJECT_PATHS.data).registerPath("images", PROJECT_OBJECT_PATHS.images).registerPath("files", PROJECT_OBJECT_PATHS.files).registerPath("charts", PROJECT_OBJECT_PATHS.charts).registerPath("slots", PROJECT_OBJECT_PATHS.slots).registerPath("sequences", PROJECT_OBJECT_PATHS.sequences).registerPath("appearance", PROJECT_OBJECT_PATHS.appearance).registerPath("export", PROJECT_OBJECT_PATHS.export);
}
function getProjectCsv(id, collection = activeProject.csvFiles) {
  return collection.find((csv) => csv.id === id) || null;
}
function getProjectImage(id, collection = activeProject.images) {
  return collection.find((image) => image.id === id) || null;
}
function resolveOwningSlot(chartId, state) {
  if (!state.charts.some((chart) => chart.id === chartId)) return null;
  const owners = state.slots.filter((slot) => slot.content.chart === chartId);
  return owners.length === 1 ? owners[0] : null;
}
function getChart(id) {
  return activeProject.charts.find((chart) => chart.id === id) ?? null;
}
function slotAt(id) {
  return activeProject.slots.find((s) => s.id === id);
}
function projectClone(value2) {
  const projectState = value2?.kind === "fast-figure-project-object" && Array.isArray(value2.slots), source = projectState ? { ...value2, slots: value2.slots.map((slot) => ({ ...slot })) } : value2, copy = JSON.parse(JSON.stringify(source));
  if (projectState) normalizeSlotContents(copy.slots);
  return copy;
}
function slotLocalState(slot) {
  const local = normalizeSlotContent(structuredClone(slot));
  return { ...local.content, caption: local.caption };
}
function setSlotLocalState(slot, localState) {
  const next = structuredClone(localState || SLOT_LOCAL_DEFAULTS);
  slot.content = { ...next };
  delete slot.content.caption;
  slot.caption = next.caption;
  return normalizeSlotContent(slot);
}
function resetSlotLocalState(slot) {
  return setSlotLocalState(slot, SLOT_LOCAL_DEFAULTS);
}
function projectValuesEqual(left, right) {
  if (left === right) return true;
  if (!left || !right || typeof left !== "object" || typeof right !== "object" || Array.isArray(left) !== Array.isArray(right)) return false;
  const keys = Object.keys(left);
  return keys.length === Object.keys(right).length && keys.every((key) => Object.hasOwn(right, key) && projectValuesEqual(left[key], right[key]));
}
function normalizeProjectSettings(state) {
  for (const key of ["layout", "annotations", "export"])
    state[key] = Object.hasOwn(state, key) ? fillMissingSettingRecord(state[key], BackendSettings.project_object[key]) : structuredClone(BackendSettings.project_object[key]);
  if (!Object.hasOwn(state, "appearance")) state.appearance = {};
  const palette = state.appearance.uiPalette;
  state.appearance.uiPalette = Object.fromEntries(Object.entries(DEFAULT_UI_PALETTE).map(([key, fallback]) => [key, typeof palette?.[key] === "string" && /^#[0-9a-fA-F]{6}$/.test(palette[key]) ? palette[key] : fallback]));
  delete state.layout.layoutMapWidth;
  return state;
}
function slotHasNonDefaultLocalState(slot) {
  return !projectValuesEqual(slotLocalState(slot), SLOT_LOCAL_DEFAULTS);
}
function slotLegacyState(slot) {
  let local = slotLocalState(slot);
  return {
    ...Object.fromEntries(Object.entries(slot).filter(([key]) => key !== "content")),
    chart: local.chart,
    imageId: local.imageId,
    contentType: local.contentType,
    imageSettings: projectClone(local.imageSettings),
    caption: local.caption
  };
}
function normalizeSlotContent(slot) {
  if (!slot || typeof slot !== "object" || Array.isArray(slot)) return slot;
  if (Object.hasOwn(slot, "content") && (!slot.content || typeof slot.content !== "object" || Array.isArray(slot.content)))
    throw Error("슬롯 content 구조가 올바르지 않습니다.");
  const content = Object.hasOwn(slot, "content") ? structuredClone(slot.content) : {}, caption = Object.hasOwn(slot, "caption") ? structuredClone(slot.caption) : Object.hasOwn(content, "caption") ? structuredClone(content.caption) : null;
  for (const key of ["chart", "imageId", "contentType", "imageSettings"]) {
    if (!Object.hasOwn(content, key)) {
      const legacy = Object.getOwnPropertyDescriptor(slot, key);
      content[key] = structuredClone(legacy?.enumerable && Object.hasOwn(legacy, "value") ? legacy.value : SLOT_LOCAL_DEFAULTS[key]);
    }
  }
  if (content.imageSettings && typeof content.imageSettings === "object" && !Array.isArray(content.imageSettings)) {
    for (const key of Object.keys(DEFAULT_IMAGE_SETTINGS))
      if (!Object.hasOwn(content.imageSettings, key))
        content.imageSettings[key] = structuredClone(DEFAULT_IMAGE_SETTINGS[key]);
  }
  delete content.caption;
  slot.content = content;
  slot.caption = caption;
  Object.defineProperties(slot, {
    chart: {
      configurable: true,
      enumerable: false,
      get() {
        return this.content.chart;
      },
      set(value2) {
        this.content.chart = value2;
      }
    },
    imageId: {
      configurable: true,
      enumerable: false,
      get() {
        return this.content.imageId;
      },
      set(value2) {
        this.content.imageId = value2;
      }
    },
    contentType: {
      configurable: true,
      enumerable: false,
      get() {
        return this.content.contentType;
      },
      set(value2) {
        this.content.contentType = value2;
      }
    },
    imageSettings: {
      configurable: true,
      enumerable: false,
      get() {
        return this.content.imageSettings;
      },
      set(value2) {
        this.content.imageSettings = value2;
      }
    },
    toJSON: {
      configurable: true,
      enumerable: false,
      value() {
        return slotLegacyState(this);
      }
    }
  });
  return slot;
}
function normalizeSlotContents(slots) {
  if (!Array.isArray(slots)) return slots;
  slots.forEach(normalizeSlotContent);
  return slots;
}
function projectColor(value2, fallback) {
  return /^#[0-9a-f]{6}$/i.test(String(value2 || "")) ? String(value2) : fallback;
}
function validateProjectObjectState(state, { requireSlots = false } = {}) {
  let record = (value2) => !!value2 && typeof value2 === "object" && !Array.isArray(value2);
  if (!record(state) || state.kind !== "fast-figure-project-object" || !record(state.meta) || !record(state.layout) || !record(state.layout.slotStyle) || !record(state.annotations?.labels) || !record(state.annotations?.labels?.settings) || !record(state.annotations?.captions) || !record(state.annotations?.captions?.settings) || !record(state.assets) || !record(state.fileSystem) || !record(state.nextId) || !record(state.appearance) || !record(state.appearance.uiPalette) || !record(state.export))
    throw Error("프로젝트 오브젝트 구조가 올바르지 않습니다.");
  if (typeof state.meta.projectName !== "string" || typeof state.meta.appBuild !== "string" || !Number.isInteger(state.layout.gridRows) || !Number.isInteger(state.layout.gridCols) || state.layout.gridRows < BackendSettings.defaults.limits.layout.gridRows[0] || state.layout.gridRows > BackendSettings.defaults.limits.layout.gridRows[1] || state.layout.gridCols < BackendSettings.defaults.limits.layout.gridCols[0] || state.layout.gridCols > BackendSettings.defaults.limits.layout.gridCols[1] || typeof state.annotations.labels.enabled !== "boolean" || typeof state.annotations.captions.enabled !== "boolean" || typeof state.annotations.captions.text !== "string" || typeof state.annotations.captions.afterText !== "string" || typeof state.annotations.captions.name !== "string" || typeof state.annotations.captions.nameBold !== "boolean")
    throw Error("프로젝트 메타데이터 또는 레이아웃이 올바르지 않습니다.");
  let style = state.layout.slotStyle;
  const limits = BackendSettings.defaults.limits;
  for (let key of ["referenceWidth", "gap", "outerMargin", "radius", "aspect"])
    if (!Number.isFinite(style[key]) || style[key] < limits.layout[key][0] || style[key] > limits.layout[key][1])
      throw Error(`프로젝트 슬롯 스타일 ${key}가 올바르지 않습니다.`);
  if (typeof style.showBorders !== "boolean") throw Error("프로젝트 슬롯 외곽선 설정이 올바르지 않습니다.");
  let labelSettings = state.annotations.labels.settings;
  if (!Number.isFinite(labelSettings.x) || !Number.isFinite(labelSettings.y) || !Number.isFinite(labelSettings.fontSize) || labelSettings.fontSize < limits.labels.fontSizeMin)
    throw Error("프로젝트 레이블 위치 또는 크기가 올바르지 않습니다.");
  let output = state.export, explicit = output.heightMode === "explicit";
  if (!Number.isFinite(output.width) || output.width < limits.export.logicalWidth[0] || output.width > limits.export.logicalWidth[1] || !["auto", "explicit"].includes(output.heightMode) || !explicit && output.height !== null || explicit && (!Number.isFinite(output.height) || output.height < limits.export.logicalHeight[0] || output.height > limits.export.logicalHeight[1]) || !Number.isFinite(output.dpi) || output.dpi < limits.export.dpi[0] || output.dpi > limits.export.dpi[1] || !["png", "jpeg"].includes(output.format))
    throw Error("프로젝트 출력 설정이 올바르지 않습니다.");
  for (let key of Object.keys(DEFAULT_UI_PALETTE))
    if (projectColor(state.appearance.uiPalette[key], null) === null)
      throw Error(`프로젝트 UI 색상 ${key}가 올바르지 않습니다.`);
  if (!Array.isArray(state.assets.csvFiles) || !Array.isArray(state.assets.images) || !Array.isArray(state.fileSystem.directories) || !Array.isArray(state.charts) || !Array.isArray(state.slots) || requireSlots && state.slots.length === 0)
    throw Error("프로젝트 자산, 차트 또는 슬롯 목록이 올바르지 않습니다.");
  let filePaths = /* @__PURE__ */ new Set(), directoryPaths = /* @__PURE__ */ new Set();
  state.fileSystem.directories.forEach((path) => {
    let normalized = normalizeProjectPath(path, { directory: true });
    if (normalized === "/" || normalized !== path || directoryPaths.has(path))
      throw Error("프로젝트 폴더 경로가 올바르지 않습니다.");
    directoryPaths.add(path);
  });
  for (let required of Object.values(BackendSettings.defaults.vfs))
    if (!directoryPaths.has(required)) throw Error(`프로젝트 기본 폴더 ${required}가 없습니다.`);
  let csvIds = /* @__PURE__ */ new Set();
  state.assets.csvFiles.forEach((csv) => {
    let path;
    try {
      path = projectAssetPath(csv);
    } catch (_) {
      throw Error("프로젝트 CSV 오브젝트가 올바르지 않습니다.");
    }
    if (!record(csv) || !Number.isInteger(csv.id) || csv.id < 1 || csvIds.has(csv.id) || typeof csv.name !== "string" || typeof csv.directory !== "string" || !Array.isArray(csv.rows) || typeof csv.bytesBase64 !== "string" || !csv.bytesBase64 || normalizeProjectPath(csv.directory, { directory: true }) !== csv.directory || filePaths.has(path) || !directoryPaths.has(csv.directory))
      throw Error("프로젝트 CSV 오브젝트가 올바르지 않습니다.");
    csvIds.add(csv.id);
    filePaths.add(path);
  });
  let imageIds = /* @__PURE__ */ new Set();
  state.assets.images.forEach((image) => {
    let path;
    try {
      path = projectAssetPath(image);
    } catch (_) {
      throw Error("프로젝트 이미지 오브젝트가 올바르지 않습니다.");
    }
    if (!record(image) || !Number.isInteger(image.id) || image.id < 1 || imageIds.has(image.id) || typeof image.name !== "string" || typeof image.directory !== "string" || typeof image.bytesBase64 !== "string" || !image.bytesBase64 || normalizeProjectPath(image.directory, { directory: true }) !== image.directory || filePaths.has(path) || !directoryPaths.has(image.directory))
      throw Error("프로젝트 이미지 오브젝트가 올바르지 않습니다.");
    imageIds.add(image.id);
    filePaths.add(path);
  });
  let chartIds = /* @__PURE__ */ new Set();
  state.charts.forEach((chart, index) => {
    if (!Number.isInteger(chart?.id) || chart.id < 1 || chartIds.has(chart.id))
      throw Error("프로젝트 차트 ID가 올바르지 않습니다.");
    chartIds.add(chart.id);
    validateChartModel(chart, `프로젝트 차트 ${index + 1}`, state.assets.csvFiles);
  });
  let slotIds = /* @__PURE__ */ new Set(), owners = new Map([...chartIds].map((id) => [id, 0]));
  state.slots.forEach((slot) => {
    if (!record(slot) || !Number.isInteger(slot.id) || slotIds.has(slot.id) || !Number.isInteger(slot.row) || !Number.isInteger(slot.col) || !Number.isInteger(slot.rowSpan) || !Number.isInteger(slot.colSpan) || slot.row < 1 || slot.col < 1 || slot.rowSpan < 1 || slot.colSpan < 1 || slot.row + slot.rowSpan - 1 > state.layout.gridRows || slot.col + slot.colSpan - 1 > state.layout.gridCols || !record(slot.content) || !["graph", "image"].includes(slot.content.contentType) || slot.content.chart !== null && slot.content.imageId !== null || slot.content.chart !== null && !chartIds.has(slot.content.chart) || slot.content.imageId !== null && !imageIds.has(slot.content.imageId) || !(slot.caption === null || typeof slot.caption === "string"))
      throw Error("프로젝트 슬롯 오브젝트가 올바르지 않습니다.");
    const settings = slot.content.imageSettings;
    if (!record(settings) || !["contain", "cover", "manual"].includes(settings.fit) || !Number.isFinite(settings.scale) || settings.scale < limits.imageSettings.scale[0] || settings.scale > limits.imageSettings.scale[1] || !Number.isFinite(settings.x) || settings.x < limits.imageSettings.x[0] || settings.x > limits.imageSettings.x[1] || !Number.isFinite(settings.y) || settings.y < limits.imageSettings.y[0] || settings.y > limits.imageSettings.y[1])
      throw Error("프로젝트 슬롯 이미지 설정이 올바르지 않습니다.");
    if (slot.content.chart !== null) owners.set(slot.content.chart, owners.get(slot.content.chart) + 1);
    slotIds.add(slot.id);
  });
  for (let [chartId, count] of owners)
    if (count !== 1) throw Error(`프로젝트 차트 ${chartId}의 슬롯 소유권이 올바르지 않습니다.`);
  let maximums = { csv: Math.max(0, ...csvIds), image: Math.max(0, ...imageIds), chart: Math.max(0, ...chartIds) };
  for (let key of ["csv", "image", "chart"])
    if (!Number.isInteger(state.nextId[key]) || state.nextId[key] <= maximums[key])
      throw Error(`프로젝트 ${key} ID 시퀀스가 올바르지 않습니다.`);
  return state;
}
function validateProjectObject(project, options = {}) {
  if (!(project instanceof ProjectObject))
    throw Error("ProjectObject 인스턴스가 아닙니다.");
  validateProjectObjectState(project._state, options);
  return project;
}
function readProjectNumber(value2, fallback, min, max) {
  let number = ["number", "string", "boolean"].includes(typeof value2) || value2 === null ? Number(value2) : NaN;
  return Number.isFinite(number) ? Math.max(min, Math.min(max, number)) : fallback;
}
function readFiniteProjectNumber(value2, fallback) {
  let number = Number(value2);
  return Number.isFinite(number) ? number : fallback;
}
var projectRuntime = {
  projectObjectGeneration: 0
};

// sourcecode/backend/graphs.js
function createCandidateBaseGraphObject(csv) {
  const selection = graphDataSelection(csv.rows, csv.headerLines);
  return {
    ...projectClone(BackendSettings.defaults.chartSettings.editor.objectStyle),
    csvId: csv.id,
    x: selection.x,
    y: selection.y,
    color: DEFAULT_COLORS[0],
    legendName: ""
  };
}
var ALLOWED_CHART_TYPES = /* @__PURE__ */ new Set(["scatter", "markers", "lines+markers", "bar", "hidden"]);
var ALLOWED_LINE_DASHES = /* @__PURE__ */ new Set(["solid", "dot", "dash", "dashdot"]);
var ALLOWED_MARKER_SYMBOLS = /* @__PURE__ */ new Set([
  "circle",
  "square",
  "diamond",
  "cross",
  "x",
  "triangle-up",
  "triangle-down"
]);
var ALLOWED_AXIS_SIDES = { x: /* @__PURE__ */ new Set(["bottom", "top"]), y: /* @__PURE__ */ new Set(["left", "right"]) };
var CURRENT_OBJECT_KEYS = /* @__PURE__ */ new Set([
  "csvId",
  "x",
  "y",
  "xAxisSide",
  "yAxisSide",
  "type",
  "color",
  "legendName",
  "lineWidth",
  "lineDash",
  "markerSymbol",
  "markerSize",
  "barOpacity",
  "barLineWidth",
  "plotlyTrace"
]);
function currentAxes(settings = {}) {
  let saved = settings.axes && typeof settings.axes === "object" ? settings.axes : {}, axis = (key, savedAxis = {}) => ({
    ...savedAxis,
    min: savedAxis.min ?? "",
    max: savedAxis.max ?? "",
    tick: savedAxis.tick ?? "",
    tickMode: savedAxis.scaleType !== "log" && savedAxis.tickMode === "increment" ? "increment" : "plotly",
    minorTicks: savedAxis.minorTicks === true,
    notation: savedAxis.notation ?? "none",
    scaleType: savedAxis.scaleType ?? "linear",
    divide: savedAxis.divide ?? "1",
    title: savedAxis.title ?? "",
    titleSize: savedAxis.titleSize ?? "14",
    lineWidth: savedAxis.lineWidth ?? "1",
    showGrid: savedAxis.showGrid !== false,
    visible: savedAxis.visible ?? (key === "xBottom" || key === "yLeft"),
    showValues: savedAxis.showValues !== false,
    fontSize: savedAxis.fontSize ?? "12"
  });
  return {
    xBottom: axis("xBottom", saved.xBottom),
    xTop: axis("xTop", saved.xTop),
    yLeft: axis("yLeft", saved.yLeft),
    yRight: axis("yRight", saved.yRight)
  };
}
function axisRangeValueFromPlotly(value2, scaleType) {
  if (value2 === "" || value2 === null || value2 === void 0) return "";
  let number = Number(value2);
  if (!Number.isFinite(number)) return "";
  let converted = scaleType === "log" ? 10 ** number : number;
  return Number.isFinite(converted) ? String(converted) : "";
}
function readGlobalSettings(chart) {
  return normalizeGlobalSettings(chart.editor.globalSettings);
}
function normalizeGraphLayoutSettings(input) {
  const defaults = BackendSettings.defaults.chartSettings.editor, source = input && typeof input === "object" && !Array.isArray(input) ? input : {}, scalar = (value2) => (typeof value2 === "number" || typeof value2 === "string") && value2 !== "" ? Number(value2) : NaN, positive = (value2, fallback) => {
    const number = scalar(value2);
    return Number.isFinite(number) && number > 0 ? number : fallback;
  }, settings = {
    ...projectClone(defaults.globalSettings),
    showLegend: Object.hasOwn(source, "showLegend") ? source.showLegend !== false : defaults.globalSettings.showLegend,
    showTitle: Object.hasOwn(source, "showTitle") ? source.showTitle !== false : defaults.globalSettings.showTitle,
    showZeroLine: source.showZeroLine === true,
    graphFontFamily: typeof source.graphFontFamily === "string" ? source.graphFontFamily : "",
    titleFontSize: positive(source.titleFontSize, ""),
    legendFontSize: positive(source.legendFontSize, ""),
    axes: {}
  };
  for (const key of ["xBottom", "xTop", "yLeft", "yRight"]) {
    const raw = source.axes?.[key], axis = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {}, result = { ...projectClone(defaults.axis), visible: defaults.axisVisibility[key] };
    for (const field of ["min", "max", "tick"]) {
      const number = scalar(axis[field]);
      result[field] = Number.isFinite(number) ? number : "";
    }
    result.title = typeof axis.title === "string" ? axis.title : defaults.axis.title;
    result.titleSize = positive(axis.titleSize, defaults.axis.titleSize);
    result.fontSize = positive(axis.fontSize, defaults.axis.fontSize);
    const width = scalar(axis.lineWidth), divide = scalar(axis.divide);
    result.lineWidth = Number.isFinite(width) && width >= 0 ? width : defaults.axis.lineWidth;
    result.divide = Number.isFinite(divide) && divide !== 0 ? divide : 1;
    if (Object.hasOwn(axis, "showGrid")) result.showGrid = axis.showGrid !== false;
    if (Object.hasOwn(axis, "showValues")) result.showValues = axis.showValues !== false;
    if (typeof axis.visible === "boolean") result.visible = axis.visible;
    result.minorTicks = axis.minorTicks === true;
    result.notation = ["none", "e", "power"].includes(axis.notation) ? axis.notation : "none";
    result.scaleType = ["linear", "log", "reciprocal"].includes(axis.scaleType) ? axis.scaleType : "linear";
    result.tickMode = result.scaleType !== "log" && axis.tickMode === "increment" ? "increment" : "plotly";
    settings.axes[key] = result;
  }
  return settings;
}
function normalizeGlobalSettings(settings) {
  return normalizeGraphLayoutSettings(settings);
}
function axisKey(kind, side) {
  return kind === "x" ? side === "top" ? "xTop" : "xBottom" : side === "right" ? "yRight" : "yLeft";
}
function dataTable(data) {
  if (!Array.isArray(data) || !data.length) throw Error("행이 하나 이상이어야 합니다.");
  if (data.every(Array.isArray)) return structuredClone(data);
  if (data.every((row) => row !== null && typeof row === "object" && !Array.isArray(row))) {
    let headers = [...new Set(data.flatMap((row) => Object.keys(row)))];
    return [headers, ...data.map((row) => headers.map((header) => Object.hasOwn(row, header) ? structuredClone(row[header]) : ""))];
  }
  throw Error("CSV 행 배열 또는 객체 배열이어야 합니다.");
}
function requireProjectCsv(chart, label = "차트", collection = activeProject.csvFiles) {
  let csv = getProjectCsv(
    chart?.editor?.objects?.[0]?.csvId ?? chart?.csvId,
    collection
  );
  if (!csv) throw Error(`${label}가 참조하는 프로젝트 CSV가 없습니다.`);
  return csv;
}
function chartUsesConversionView(chart) {
  return chart?.editor?.editable === false && Object.hasOwn(chart.editor, "conversionRows");
}
function chartCsvIds(chart) {
  if (chartUsesConversionView(chart)) return [];
  return [
    ...new Set(
      (chart?.editor?.objects || []).map((object) => object.csvId).filter((id) => Number.isInteger(id))
    )
  ];
}
function headerLineCount(value2, table = []) {
  const number = Number(value2);
  return Number.isFinite(number) ? Math.min(Math.max(0, Math.trunc(number)), Array.isArray(table) ? table.length : 0) : 0;
}
function columnIndex(column) {
  let match = /^C([1-9]\d*)$/.exec(String(column || ""));
  return match ? Number(match[1]) - 1 : -1;
}
function columnDefinitions(table = [], headerLines = 1) {
  let width = (table || []).reduce(
    (max, row) => Math.max(max, Array.isArray(row) ? row.length : 0),
    0
  ), count = headerLineCount(headerLines, table), header = count > 0 && Array.isArray(table[count - 1]) ? table[count - 1] : [];
  return Array.from({ length: width }, (_, index) => {
    let id = `C${index + 1}`, name = header[index], text = String(name ?? "").trim();
    return { id, index, name, label: text ? `${id} — ${text}` : id };
  });
}
function dataRows(table = [], headerLines = 1) {
  return (table || []).slice(headerLineCount(headerLines, table));
}
function value(v) {
  let n = Number(v);
  return v !== "" && Number.isFinite(n) ? n : v;
}
function graphDataSelection(matrix, headerLines, editor = {}) {
  let definitions = columnDefinitions(matrix, headerLines), body = dataRows(matrix, headerLines), numeric = definitions.filter(
    (column) => body.some(
      (row) => row?.[column.index] !== "" && Number.isFinite(graphScalarNumber(row?.[column.index]))
    )
  ), valid = (id) => definitions.some((column) => column.id === id), x = valid(editor.x) ? editor.x : numeric[0]?.id || definitions[0]?.id || "", y = valid(editor.y) ? editor.y : numeric.find((column) => column.id !== x)?.id || definitions.find((column) => column.id !== x)?.id || definitions[0]?.id || "";
  return { x, y };
}
function defaultChartEditor(slot, matrix, headerLines) {
  let selection = graphDataSelection(matrix, headerLines);
  return {
    objects: [],
    editable: true,
    globalSettings: {
      showLegend: true,
      showTitle: true,
      showZeroLine: false,
      graphFontFamily: "",
      titleFontSize: "",
      legendFontSize: "",
      axes: currentAxes({})
    },
    colors: [...DEFAULT_COLORS],
    x: selection.x,
    y: selection.y,
    xAxisSide: "bottom",
    yAxisSide: "left",
    legendName: "",
    type: "scatter",
    lineWidth: 2,
    lineDash: "solid",
    markerSymbol: "circle",
    markerSize: 6,
    barOpacity: 1,
    barLineWidth: 0,
    xDivide: 1,
    yDivide: 1,
    title: selection.y
  };
}
function graphScalarNumber(input) {
  return input === null || ["number", "string", "boolean"].includes(typeof input) ? Number(input) : NaN;
}
function graphDivisor(input) {
  const number = graphScalarNumber(input);
  return Number.isFinite(number) && number !== 0 ? number : 1;
}
function graphScaleCoordinate(value2, numeric, scaleType) {
  if (scaleType === "linear") return value2;
  if (!numeric) return void 0;
  if (scaleType === "log") return Number.isFinite(value2) && value2 > 0 ? value2 : void 0;
  const reciprocal = value2 !== 0 ? 1 / value2 : NaN;
  return Number.isFinite(value2) && Number.isFinite(reciprocal) ? reciprocal : void 0;
}
function tracesSingle(c) {
  const rows = c.rows || [], width = columnDefinitions(rows, c.headerLines).length, xi = columnIndex(c.x), yi = columnIndex(c.y), dx = graphDivisor(c.xDivide), dy = graphDivisor(c.yDivide), defaults = BackendSettings.defaults.chartSettings.editor.objectStyle, limits = BackendSettings.defaults.limits.graphObject, style = (key) => {
    const number = graphScalarNumber(c[key]), [min, max] = limits[key];
    return Number.isFinite(number) ? Math.max(min, Math.min(max, number)) : defaults[key];
  }, xs = [], ys = [];
  if (xi < 0 || yi < 0 || xi >= width || yi >= width) return [];
  for (const row of dataRows(rows, c.headerLines ?? 1)) {
    const rawX = row?.[xi], rawY = row?.[yi];
    if (rawX === void 0 || rawX === "" || rawY === void 0) continue;
    let x = graphScalarNumber(rawX), y = graphScalarNumber(rawY);
    if (!Number.isFinite(y)) continue;
    const numericX = Number.isFinite(x);
    if (!numericX) {
      if (typeof rawX !== "string") continue;
      x = rawX;
    }
    if (numericX) x /= dx;
    y /= dy;
    if (!Number.isFinite(y) || numericX && !Number.isFinite(x)) continue;
    x = graphScaleCoordinate(x, numericX, c.xScaleType ?? "linear");
    y = graphScaleCoordinate(y, true, c.yScaleType ?? "linear");
    if (x === void 0 || y === void 0) continue;
    xs.push(x);
    ys.push(y);
  }
  if (!xs.length) return [];
  const trace = {
    x: xs,
    y: ys,
    name: c.y,
    visible: true,
    line: { color: c.color },
    marker: { color: c.color }
  };
  if (c.type === "bar") {
    trace.type = "bar";
    trace.line.width = style("barLineWidth");
    trace.marker.line = { color: c.color, width: trace.line.width };
    trace.opacity = style("barOpacity");
  } else {
    trace.type = "scatter";
    trace.mode = ["markers", "lines+markers"].includes(c.type) ? c.type : "lines";
    trace.visible = c.type !== "hidden";
    trace.line.width = style("lineWidth");
    trace.line.dash = ALLOWED_LINE_DASHES.has(c.lineDash) ? c.lineDash : defaults.lineDash;
    trace.marker.symbol = ALLOWED_MARKER_SYMBOLS.has(c.markerSymbol) ? c.markerSymbol : defaults.markerSymbol;
    trace.marker.size = style("markerSize");
  }
  return [trace];
}
function traces(c, project = activeProject._state) {
  const owners = project.slots.filter((slot) => (slot.content?.chart ?? slot.chart) === c.id), current = project.charts.find((chart) => chart.id === c.id);
  if (owners.length !== 1 || !current || chartUsesConversionView(current))
    throw Error("그래프 투영에 같은 프로젝트의 유일한 owning chart가 필요합니다.");
  c = current;
  let settings = normalizeGraphLayoutSettings(c.editor.globalSettings), editor = c.editor, axes = settings.axes, objectList = Array.isArray(editor.objects) ? editor.objects : [], result = [];
  objectList.forEach((object, index) => {
    let csv = requireProjectCsv({ editor: { objects: [object] } }, `그래프 객체 ${index + 1}`, project.assets.csvFiles), xSide = object.xAxisSide || editor.xAxisSide || "bottom", ySide = object.yAxisSide || editor.yAxisSide || "left", xAxis = axes[axisKey("x", xSide)], yAxis = axes[axisKey("y", ySide)], axisRefs = {
      xaxis: xSide === "top" ? "x2" : "x",
      yaxis: ySide === "right" ? "y2" : "y"
    };
    result.push(
      ...tracesSingle({
        ...editor,
        ...object,
        rows: csv.rows,
        headerLines: csv.headerLines,
        xDivide: xAxis.divide,
        yDivide: yAxis.divide,
        xScaleType: xAxis.scaleType,
        yScaleType: yAxis.scaleType,
        color: object.color || DEFAULT_COLORS[index % DEFAULT_COLORS.length]
      }).map((trace) => {
        let extension = object.plotlyTrace && typeof object.plotlyTrace === "object" && !Array.isArray(object.plotlyTrace) ? projectClone(object.plotlyTrace) : {};
        const record = (value2) => value2 && typeof value2 === "object" && !Array.isArray(value2) ? value2 : {}, merged = {
          ...extension,
          ...trace,
          line: { ...record(extension.line), ...trace.line },
          marker: { ...record(extension.marker), ...trace.marker },
          name: object.legendName || object.y,
          ...axisRefs
        };
        if (!Object.hasOwn(trace, "mode")) delete merged.mode;
        return merged;
      })
    );
  });
  let placeholder = (xaxis, yaxis) => ({
    x: [],
    y: [],
    type: "scatter",
    mode: "markers",
    xaxis,
    yaxis,
    showlegend: false,
    hoverinfo: "skip",
    visible: true,
    marker: { size: 0, opacity: 0 },
    line: { width: 0 },
    name: "",
    meta: { fastFigureAxisPlaceholder: true }
  }), xRefs = [], yRefs = [];
  if (axes.xBottom.visible === true) xRefs.push("x");
  if (axes.xTop.visible === true) xRefs.push("x2");
  if (axes.yLeft.visible === true) yRefs.push("y");
  if (axes.yRight.visible === true) yRefs.push("y2");
  if (!xRefs.length) xRefs.push("x");
  if (!yRefs.length) yRefs.push("y");
  xRefs.forEach((xaxis) => yRefs.forEach((yaxis) => result.push(placeholder(xaxis, yaxis))));
  return result;
}
function layout(c, project = activeProject._state) {
  let bg = project.appearance.uiPalette.paperColor, ink = project.appearance.uiPalette.fontColor, editor = c.editor, settings = normalizeGraphLayoutSettings(editor.globalSettings), renderDefaults = BackendSettings.defaults.graphRendering, axisDefaults = BackendSettings.defaults.chartSettings.editor.axis, numberOrEmpty = (v) => v === "" || v === void 0 || v === null ? void 0 : Number(v), axis = (title, key) => {
    let setting = settings.axes[key], min = numberOrEmpty(setting.min), max = numberOrEmpty(setting.max), tick = numberOrEmpty(setting.tick), notation = setting.notation || "none", scaleType = setting.scaleType || "linear";
    return {
      type: scaleType === "log" ? "log" : "linear",
      title: {
        text: setting.visible === true ? setting.title || "" : "",
        font: { size: setting.titleSize || axisDefaults.titleSize }
      },
      visible: true,
      showgrid: setting.visible === true && setting.showGrid !== false,
      showticklabels: setting.visible === true && setting.showValues !== false,
      ticks: setting.visible === true ? "outside" : "",
      gridcolor: renderDefaults.gridColor,
      zeroline: setting.visible === true && settings.showZeroLine === true,
      zerolinecolor: renderDefaults.zeroLineColor,
      showline: setting.visible === true,
      linewidth: Number(setting.lineWidth) || 0,
      range: Number.isFinite(min) && Number.isFinite(max) ? scaleType === "log" ? min > 0 && max > 0 ? [Math.log10(min), Math.log10(max)] : void 0 : [min, max] : void 0,
      dtick: scaleType === "log" ? 1 : Number.isFinite(tick) && tick > 0 ? tick : void 0,
      minor: scaleType === "log" ? setting.minorTicks === true ? {
        dtick: "D1",
        ticks: "outside",
        showgrid: setting.visible === true && setting.showGrid !== false,
        gridcolor: renderDefaults.gridColor
      } : { ticks: "", showgrid: false } : void 0,
      minorloglabels: scaleType === "log" ? "none" : void 0,
      tickfont: { size: setting.fontSize || axisDefaults.fontSize },
      automargin: true,
      exponentformat: notation === "power" ? "power" : notation === "e" ? "e" : "none",
      showexponent: notation === "none" ? "none" : "all",
      tickformat: notation === "e" ? ".3e" : void 0
    };
  };
  const record = (value2) => value2 && typeof value2 === "object" && !Array.isArray(value2) ? value2 : {};
  let extension = projectClone(record(editor.plotlyExtensions?.layout)), known = {
    uirevision: String(c.id),
    title: {
      text: settings.showTitle === false ? "" : editor.title,
      automargin: true,
      font: {
        ...settings.graphFontFamily ? { family: settings.graphFontFamily } : {},
        size: settings.titleFontSize || renderDefaults.titleFontSize
      }
    },
    legend: {
      font: {
        ...settings.graphFontFamily ? { family: settings.graphFontFamily } : {},
        size: settings.legendFontSize || renderDefaults.legendFontSize
      }
    },
    xaxis: axis(editor.x, "xBottom"),
    xaxis2: { ...axis(editor.x, "xTop"), overlaying: "x", side: "top" },
    yaxis: axis(editor.y, "yLeft"),
    yaxis2: { ...axis(editor.y, "yRight"), overlaying: "y", side: "right" },
    paper_bgcolor: bg,
    plot_bgcolor: bg,
    font: {
      color: ink,
      ...settings.graphFontFamily ? { family: settings.graphFontFamily } : {}
    },
    margin: projectClone(renderDefaults.margin),
    showlegend: settings.showLegend !== false
  };
  const merged = { ...extension, ...known };
  for (const key of ["title", "legend", "font", "margin", "xaxis", "xaxis2", "yaxis", "yaxis2"])
    merged[key] = { ...record(extension[key]), ...known[key] };
  for (const key of ["title", "legend"])
    merged[key].font = { ...record(extension[key]?.font), ...known[key].font };
  for (const key of ["xaxis", "xaxis2", "yaxis", "yaxis2"])
    for (const field of ["range", "dtick", "minor", "minorloglabels", "tickformat"])
      if (known[key][field] === void 0) delete merged[key][field];
  return merged;
}
function createChartModel({ id = null, editor = {}, graph = {} } = {}) {
  let model = {
    id,
    editor: {
      ...editor,
      objects: Array.isArray(editor.objects) ? editor.objects : [],
      editable: editor.editable !== false,
      globalSettings: editor.globalSettings && typeof editor.globalSettings === "object" ? editor.globalSettings : {}
    },
    graph: {
      data: Array.isArray(graph.data) ? graph.data : [],
      layout: graph.layout && typeof graph.layout === "object" && !Array.isArray(graph.layout) ? graph.layout : {},
      config: graph.config && typeof graph.config === "object" && !Array.isArray(graph.config) ? graph.config : {},
      frames: Array.isArray(graph.frames) ? graph.frames : []
    }
  };
  if (graph.imported && typeof graph.imported === "object")
    model.graph.imported = {
      data: Array.isArray(graph.imported.data) ? graph.imported.data : [],
      layout: graph.imported.layout && typeof graph.imported.layout === "object" ? graph.imported.layout : {},
      config: graph.imported.config && typeof graph.imported.config === "object" ? graph.imported.config : {},
      frames: Array.isArray(graph.imported.frames) ? graph.imported.frames : []
    };
  return model;
}
function validateChartModel(chart, label = "차트", csvCollection = activeProject.csvFiles) {
  const record = (value2) => value2 !== null && typeof value2 === "object" && !Array.isArray(value2), figureShape = (figure) => record(figure) && Array.isArray(figure.data) && figure.data.every(record) && record(figure.layout) && record(figure.config) && Array.isArray(figure.frames), fail = (detail) => {
    throw Error(`${label} ${detail}`);
  };
  if (!record(chart)) fail("구조가 올바르지 않습니다.");
  if (Object.hasOwn(chart, "id") && (!Number.isInteger(chart.id) || chart.id <= 0))
    fail("id는 양의 정수여야 합니다.");
  if (!record(chart.editor) || typeof chart.editor.editable !== "boolean" || !Array.isArray(chart.editor.objects))
    throw Error(`${label} editor.objects가 없습니다.`);
  if (!figureShape(chart.graph) || Object.hasOwn(chart.graph, "imported") && !figureShape(chart.graph.imported))
    fail("graph/imported 구조가 올바르지 않습니다.");
  const settings = chart.editor.globalSettings;
  if (!record(settings) || Object.hasOwn(settings, "axes") && !record(settings.axes))
    fail("globalSettings/axes 구조가 올바르지 않습니다.");
  for (const key of ["xBottom", "xTop", "yLeft", "yRight"])
    if (settings.axes && Object.hasOwn(settings.axes, key) && !record(settings.axes[key]))
      fail(`${key} axis 구조가 올바르지 않습니다.`);
  if (Object.hasOwn(chart.editor, "plotlyExtensions")) {
    const extension = chart.editor.plotlyExtensions;
    if (!record(extension) || ["layout", "config"].some((key) => Object.hasOwn(extension, key) && !record(extension[key]))) fail("plotlyExtensions 구조가 올바르지 않습니다.");
  }
  const conversion = chartUsesConversionView(chart);
  if (conversion && (!Array.isArray(chart.editor.conversionRows) || !chart.editor.conversionRows.every(Array.isArray)))
    throw Error(`${label} conversionRows table이 올바르지 않습니다.`);
  chart.editor.objects.forEach((object, index) => {
    if (!object || typeof object !== "object" || Array.isArray(object))
      throw Error(`${label} 그래프 객체 ${index + 1} 구조가 올바르지 않습니다.`);
    const csv = conversion ? null : getProjectCsv(object.csvId, csvCollection);
    if (!conversion && (!Number.isInteger(object.csvId) || !csv))
      throw Error(`${label} 그래프 객체 ${index + 1}의 csvId가 올바르지 않습니다.`);
    const columns = columnDefinitions(
      conversion ? chart.editor.conversionRows : csv.rows,
      conversion ? chart.editor.headerLines : csv.headerLines
    ), valid = (id) => columns.some((column) => column.id === id);
    if (columns.length ? !valid(object.x) || !valid(object.y) : object.x !== "" || object.y !== "")
      throw Error(`${label} 그래프 객체 ${index + 1}의 x/y column이 올바르지 않습니다.`);
    if (!ALLOWED_CHART_TYPES.has(object.type) || !ALLOWED_AXIS_SIDES.x.has(object.xAxisSide) || !ALLOWED_AXIS_SIDES.y.has(object.yAxisSide) || !ALLOWED_LINE_DASHES.has(object.lineDash) || !ALLOWED_MARKER_SYMBOLS.has(object.markerSymbol)) fail(`그래프 객체 ${index + 1} enum이 올바르지 않습니다.`);
    for (const [key, [min, max]] of Object.entries(BackendSettings.defaults.limits.graphObject))
      if (!Number.isFinite(object[key]) || object[key] < min || object[key] > max)
        fail(`그래프 객체 ${index + 1} ${key} 범위가 올바르지 않습니다.`);
    if (Object.hasOwn(object, "plotlyTrace") && !record(object.plotlyTrace))
      fail(`그래프 객체 ${index + 1} plotlyTrace 구조가 올바르지 않습니다.`);
  });
  return chart;
}
function rebuildEditableGraph(chart, project = activeProject._state) {
  chart.graph.data = traces(chart, project);
  chart.graph.layout = layout(chart, project);
  return chart;
}
function chartExportCopy(chart) {
  let copy = projectClone(chart);
  return copy;
}
function scalePlotlyFigure(figure, scale = 1) {
  let copy = projectClone(figure), factor = Math.max(0.01, Number(scale) || 1), scaleNumber = (value2) => Number.isFinite(Number(value2)) ? Number(value2) * factor : value2, scaleFont = (font) => font && typeof font === "object" ? { ...font, size: scaleNumber(font.size) } : font;
  if (factor === 1) return copy;
  let layout2 = copy.layout || {};
  layout2.font = scaleFont(layout2.font);
  if (layout2.title?.font) layout2.title.font = scaleFont(layout2.title.font);
  if (layout2.title?.pad)
    layout2.title.pad = Object.fromEntries(
      Object.entries(layout2.title.pad).map(([key, value2]) => [key, scaleNumber(value2)])
    );
  if (layout2.legend?.font) layout2.legend.font = scaleFont(layout2.legend.font);
  if (layout2.legend) layout2.legend.borderwidth = scaleNumber(layout2.legend.borderwidth);
  if (layout2.margin)
    layout2.margin = Object.fromEntries(
      Object.entries(layout2.margin).map(([key, value2]) => [
        key,
        ["l", "r", "t", "b", "pad"].includes(key) ? scaleNumber(value2) : value2
      ])
    );
  ["xaxis", "xaxis2", "yaxis", "yaxis2"].forEach((key) => {
    let axis = layout2[key];
    if (!axis) return;
    axis.linewidth = scaleNumber(axis.linewidth);
    axis.tickwidth = scaleNumber(axis.tickwidth);
    axis.ticklen = scaleNumber(axis.ticklen);
    axis.tickfont = scaleFont(axis.tickfont);
    if (axis.title?.font) axis.title.font = scaleFont(axis.title.font);
    if (axis.minor) {
      axis.minor.tickwidth = scaleNumber(axis.minor.tickwidth);
      axis.minor.ticklen = scaleNumber(axis.minor.ticklen);
    }
  });
  (copy.data || []).forEach((trace) => {
    if (trace.line) trace.line.width = scaleNumber(trace.line.width);
    if (trace.marker) {
      trace.marker.size = scaleNumber(trace.marker.size);
      if (trace.marker.line)
        trace.marker.line.width = scaleNumber(trace.marker.line.width);
    }
  });
  return copy;
}
function chartFigure(chart, project = activeProject._state, scale = 1) {
  let copy = chartExportCopy(chart);
  if (copy.editor.editable === false && copy.graph.imported)
    return scalePlotlyFigure(copy.graph.imported, scale);
  rebuildEditableGraph(copy, project);
  return scalePlotlyFigure(copy.graph, scale);
}
function setNestedAxisFromPlotly(target, input = {}, key = "xBottom") {
  const axis = input && typeof input === "object" && !Array.isArray(input) ? input : {}, scaleType = axis.type === "log" ? "log" : "linear", range = Array.isArray(axis.range) && axis.range.length === 2 ? axis.range : [], bound = (value2) => typeof value2 === "number" && Number.isFinite(value2) ? axisRangeValueFromPlotly(value2, scaleType) : "", linearTick = scaleType !== "log" && typeof axis.dtick === "string" && axis.dtick.startsWith("L") && axis.dtick.slice(1).trim() !== "" && Number.isFinite(Number(axis.dtick.slice(1))), raw = {
    title: typeof axis.title === "string" ? axis.title : typeof axis.title?.text === "string" ? axis.title.text : "",
    scaleType,
    divide: 1,
    min: bound(range[0]),
    max: bound(range[1]),
    tick: linearTick ? Number(axis.dtick.slice(1)) : scaleType !== "log" && typeof axis.dtick === "number" && Number.isFinite(axis.dtick) ? axis.dtick : "",
    tickMode: linearTick ? "increment" : "plotly",
    minorTicks: scaleType === "log" && (axis.dtick === "D1" || axis.minor?.dtick === "D1" || ["inside", "outside"].includes(axis.minor?.ticks) || axis.minor?.showgrid === true),
    titleSize: axis.title?.font?.size,
    fontSize: axis.tickfont?.size,
    lineWidth: axis.linewidth,
    showGrid: axis.showgrid !== false,
    showValues: axis.showticklabels !== false,
    visible: axis.visible !== false,
    notation: ["e", "power"].includes(axis.exponentformat) ? axis.exponentformat : "none"
  };
  Object.assign(target, normalizeGraphLayoutSettings({ axes: { [key]: raw } }).axes[key]);
}
function parsePlotlyToEditor(figure, id) {
  const record = (value2) => value2 !== null && typeof value2 === "object" && !Array.isArray(value2), text = (value2) => typeof value2 === "string" ? value2 : "", titleText = (value2) => typeof value2 === "string" ? value2 : text(value2?.text);
  if (!record(figure) || !Array.isArray(figure.data) && !record(figure.layout) || figure.data !== void 0 && !Array.isArray(figure.data) || figure.layout !== void 0 && !record(figure.layout) || figure.config !== void 0 && !record(figure.config) || figure.frames !== void 0 && !Array.isArray(figure.frames) || (figure.data || []).some((trace) => !record(trace)))
    throw Error("유효한 Plotly figure 구조가 아닙니다.");
  const data = figure.data || [], layoutIn = figure.layout || {}, defaults = BackendSettings.defaults.chartSettings.editor.objectStyle, limits = BackendSettings.defaults.limits.graphObject, style = (value2, key) => {
    const number = graphScalarNumber(value2), [min, max] = limits[key];
    return Number.isFinite(number) ? Math.max(min, Math.min(max, number)) : defaults[key];
  }, headers = [], points = [], objects = [];
  data.forEach((trace, index) => {
    const x = Array.isArray(trace.x) ? trace.x : [], y = Array.isArray(trace.y) ? trace.y : [], length = Math.max(x.length, y.length), column = headers.length;
    headers.push(`trace${index + 1}_x`, `trace${index + 1}_y`);
    for (let i = 0; i < length; i++) points[i] ??= [];
    for (let i = 0; i < points.length; i++) {
      points[i][column] = x[i] !== void 0 ? projectClone(x[i]) : "";
      points[i][column + 1] = y[i] !== void 0 ? projectClone(y[i]) : "";
    }
    if (!length) return;
    const plotlyTrace = projectClone(trace), modes = text(trace.mode).split("+");
    delete plotlyTrace.x;
    delete plotlyTrace.y;
    objects.push({
      ...projectClone(defaults),
      x: `C${column + 1}`,
      y: `C${column + 2}`,
      xAxisSide: trace.xaxis === "x2" ? "top" : "bottom",
      yAxisSide: trace.yaxis === "y2" ? "right" : "left",
      type: trace.visible === false ? "hidden" : trace.type === "bar" ? "bar" : modes.includes("markers") ? modes.includes("lines") ? "lines+markers" : "markers" : "scatter",
      color: [trace.line?.color, trace.marker?.color].find((value2) => typeof value2 === "string" && value2.length) || DEFAULT_COLORS[index % DEFAULT_COLORS.length],
      legendName: text(trace.name),
      lineWidth: style(trace.line?.width, "lineWidth"),
      lineDash: ALLOWED_LINE_DASHES.has(trace.line?.dash) ? trace.line.dash : defaults.lineDash,
      markerSymbol: ALLOWED_MARKER_SYMBOLS.has(trace.marker?.symbol) ? trace.marker.symbol : defaults.markerSymbol,
      markerSize: style(trace.marker?.size, "markerSize"),
      barOpacity: style(trace.opacity, "barOpacity"),
      barLineWidth: style(trace.marker?.line?.width, "barLineWidth"),
      plotlyTrace
    });
  });
  const rows = objects.length ? [headers, ...points.map((row) => headers.map((_, column) => Object.hasOwn(row, column) ? row[column] : ""))] : [];
  const chart = createChartModel({
    id,
    editor: { editable: false, conversionRows: rows, objects, title: titleText(layoutIn.title) },
    graph: {
      config: projectClone(figure.config || {}),
      frames: projectClone(figure.frames || []),
      imported: projectClone({ data, layout: layoutIn, config: figure.config || {}, frames: figure.frames || [] })
    }
  });
  if (id === null || id === void 0) delete chart.id;
  const settings = {
    showTitle: chart.editor.title.length > 0,
    showLegend: layoutIn.showlegend !== false,
    showZeroLine: false,
    graphFontFamily: [layoutIn.title?.font?.family, layoutIn.font?.family, layoutIn.legend?.font?.family].find((value2) => typeof value2 === "string" && value2.length) || "",
    titleFontSize: layoutIn.title?.font?.size,
    legendFontSize: layoutIn.legend?.font?.size,
    axes: {}
  };
  for (const [key, plotlyKey] of [["xBottom", "xaxis"], ["xTop", "xaxis2"], ["yLeft", "yaxis"], ["yRight", "yaxis2"]]) {
    settings.axes[key] = {};
    setNestedAxisFromPlotly(settings.axes[key], layoutIn[plotlyKey], key);
  }
  chart.editor.globalSettings = normalizeGraphLayoutSettings(settings);
  chart.editor.plotlyExtensions = projectClone({ layout: layoutIn, config: figure.config || {} });
  return chart;
}
function baseGraphObject(chart, csv) {
  if (!csv) throw Error("그래프 오브젝트에 연결할 프로젝트 CSV가 없습니다.");
  return createCandidateBaseGraphObject(csv);
}
function normalizedGraphObjects(chart) {
  const objects = projectClone(chart.editor.objects), defaults = BackendSettings.defaults.chartSettings.editor.objectStyle;
  for (const object of objects)
    for (const [key, value2] of Object.entries(defaults))
      if (!Object.hasOwn(object, key)) object[key] = projectClone(value2);
  return objects;
}
function ensureGraphObjects(chart) {
  if (!chart) return [];
  chart.editor = chart.editor || {};
  chart.editor.objects = normalizedGraphObjects(chart);
  return chart.editor.objects;
}

// sourcecode/backend/assets_files.js
function projectImageDataUrl(image) {
  return image ? `data:${image.mime || "application/octet-stream"};base64,${image.bytesBase64 || ""}` : "";
}
function collectAssetReferences(csvIds, imageIds, state) {
  const refs = [];
  state.charts.forEach((chart) => {
    if (chartUsesConversionView(chart)) return;
    chart.editor.objects.forEach((object, originalObjectIndex) => {
      if (csvIds.has(object.csvId)) refs.push({
        kind: "csv",
        assetId: object.csvId,
        chartId: chart.id,
        originalObjectIndex,
        object
      });
    });
  });
  state.slots.forEach((slot) => {
    const imageId = slot.content?.imageId ?? slot.imageId;
    if (imageIds.has(imageId)) refs.push({ kind: "image", assetId: imageId, slotId: slot.id, slot });
  });
  return refs;
}
function projectAssetReferenceCount(csvIds, imageIds, state = activeProject._state) {
  return collectAssetReferences(csvIds, imageIds, state).length;
}
function removeProjectAssetReferences(csvIds, imageIds, state = activeProject._state) {
  normalizeSlotContents(state.slots);
  const refs = collectAssetReferences(csvIds, imageIds, state), graphObjectIndexMaps = [];
  let removedGraphReferenceCount = 0, resetImageSlotCount = 0;
  state.charts.forEach((chart) => {
    const removed = new Set(refs.filter((ref) => ref.kind === "csv" && ref.chartId === chart.id).map((ref) => ref.originalObjectIndex));
    if (!removed.size) return;
    const indices = [], objects = [];
    chart.editor.objects.forEach((object, index) => {
      indices.push(removed.has(index) ? null : objects.length);
      if (!removed.has(index)) objects.push(object);
    });
    chart.editor.objects = objects;
    graphObjectIndexMaps.push({ chartId: chart.id, indices });
    removedGraphReferenceCount += removed.size;
    rebuildEditableGraph(chart, state);
  });
  refs.filter((ref) => ref.kind === "image").forEach((ref) => {
    ref.slot.content.imageId = null;
    resetImageSlotCount++;
  });
  return { removedGraphReferenceCount, resetImageSlotCount, graphObjectIndexMaps };
}
function buildProjectAssetImportCandidate(source, payload) {
  const { files, choices, targetSlotId } = payload;
  if (!Array.isArray(files) || !files.length || !Array.isArray(choices) || files.length !== choices.length || typeof payload.directory !== "string" || projectVfs.resolve(payload.directory, source)?.kind !== "directory")
    return null;
  const directory = normalizeProjectPath(payload.directory, { directory: true }), candidate = projectClone(source), reserved = /* @__PURE__ */ new Set(), imported = [];
  candidate.slots.forEach((slot) => {
    const original = source.slots.find((item) => item.id === slot.id);
    if (original?.content) slot.content = projectClone(original.content);
  });
  normalizeSlotContents(candidate.slots);
  const target = targetSlotId == null ? null : candidate.slots.find((slot) => slot.id === targetSlotId && !slot.hidden);
  if (targetSlotId != null && !target) return null;
  for (let i = 0; i < files.length; i++) {
    const file = files[i], plan = choices[i], kind = slotFileKind(file);
    if (!["data", "image"].includes(kind) || !plan || typeof plan.path !== "string" || !(plan.replaceId === null || Number.isInteger(plan.replaceId) && plan.replaceId > 0)) return null;
    const path = normalizeProjectPath(plan.path), current = projectVfs.resolve(path, candidate), assetKind = kind === "data" ? "csv" : "image";
    if (path !== plan.path || projectParentPath(path) !== directory || reserved.has(path) || (plan.replaceId === null ? !!current : current?.kind !== assetKind || current.asset.id !== plan.replaceId))
      return null;
    let staged;
    try {
      staged = stageProjectAssetImport(candidate, { file, kind, path, replaceId: plan.replaceId });
    } catch {
      return null;
    }
    reserved.add(path);
    if (target) {
      if (kind === "image") {
        candidate.charts = candidate.charts.filter((chart) => chart.id !== target.content.chart);
        target.content.chart = null;
        target.content.contentType = "image";
        target.content.imageId = staged.id;
      } else {
        if (target.contentType !== "graph") return null;
        let chart = candidate.charts.find((item) => item.id === target.chart);
        if (chart?.editor?.editable === false) return null;
        const csv = candidate.assets.csvFiles.find((item) => item.id === staged.id);
        if (!chart) {
          chart = createChartModel({ id: candidate.nextId.chart++, editor: {
            title: csv.name,
            globalSettings: readGlobalSettings({ editor: {} }),
            plotlyExtensions: { layout: {}, config: {} },
            objects: []
          } });
          candidate.charts.push(chart);
          target.chart = chart.id;
        }
        chart.editor.objects.push(createCandidateBaseGraphObject(csv));
      }
    }
    imported.push({ role: "imported", kind: assetKind, id: staged.id, path });
  }
  const csvIds = new Set(imported.filter((item) => item.kind === "csv").map((item) => item.id));
  candidate.charts.forEach((chart) => {
    if (chart.editor?.editable !== false && chartCsvIds(chart).some((id) => csvIds.has(id)))
      rebuildEditableGraph(chart, candidate);
  });
  for (const fact of imported)
    fact.owners = collectAssetReferences(
      new Set(fact.kind === "csv" ? [fact.id] : []),
      new Set(fact.kind === "image" ? [fact.id] : []),
      candidate
    );
  try {
    validateProjectObjectState(candidate, { requireSlots: true });
  } catch {
    return null;
  }
  return { candidate, imported };
}
function parseCSV(text, d = ",") {
  const rows = [];
  let row = [], field = "", quoted = false, afterQuote = false, explicitLine = false, pendingBlankLines = 0;
  const finish = () => {
    if (explicitLine || field.length || row.length || afterQuote) {
      while (pendingBlankLines > 0) {
        rows.push([""]);
        pendingBlankLines--;
      }
      rows.push([...row, field]);
    } else pendingBlankLines++;
    row = [];
    field = "";
    afterQuote = false;
    explicitLine = false;
  };
  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    if (quoted) {
      if (char === '"') {
        if (text[i + 1] === '"') {
          field += '"';
          i++;
        } else {
          quoted = false;
          afterQuote = true;
        }
      } else field += char;
      continue;
    }
    if (char === d) {
      row.push(field);
      field = "";
      afterQuote = false;
      explicitLine = true;
    } else if (char === "\r" || char === "\n") {
      finish();
      if (char === "\r" && text[i + 1] === "\n") i++;
    } else if (char === '"') {
      if (field.length || afterQuote) throw Error("CSV 인용 문자열 위치가 올바르지 않습니다.");
      quoted = true;
      explicitLine = true;
    } else {
      if (afterQuote) throw Error("CSV 닫는 인용부호 뒤에 문자가 있습니다.");
      field += char;
      explicitLine = true;
    }
  }
  if (quoted) throw Error("CSV 인용 문자열이 닫히지 않았습니다.");
  if (explicitLine || field.length || row.length || afterQuote) finish();
  return rows;
}
function buildProjectImageModel(bytes, name, mime, id, state = activeProject._state) {
  let model = {
    id,
    name: projectCsvName(name, "image.bin"),
    directory: PROJECT_ASSET_DIRECTORIES.image,
    mime: typeof mime === "string" && mime ? mime : "application/octet-stream",
    bytesBase64: typeof bytes === "string" ? bytes : ffpxBytesToBase64(bytes || new Uint8Array())
  };
  projectVfs.assignUniqueLocation(model, PROJECT_ASSET_DIRECTORIES.image, state);
  if (!model.bytesBase64) throw Error("이미지 데이터가 비어 있습니다.");
  return model;
}
function createProjectImage(bytes, name, mime, id = null, path = null) {
  const copiedBytes = typeof bytes === "string" ? bytes : new Uint8Array(bytes || []).slice(), [result] = dispatchProjectCommand("IMAGE_OBJECT_CREATED", { bytes: copiedBytes, name, mime, id, path });
  if (!result.committed) return result;
  const created = result.changed.assets.find((asset) => asset.role === "created" && asset.kind === "image");
  return appFSM.query("project-api", { operation: "assets.readDeletionTarget", path: created.path }).target;
}
function projectCsvName(value2, fallback = "data.csv") {
  let name = String(value2 || "").split(/[\\/]/).pop().trim().replace(/[\x00-\x1F:*?"<>|]/g, "-").replace(/\.{2,}/g, "-").replace(/[. ]+$/, "").slice(0, 180);
  return name || fallback;
}
function buildProjectCsvModel(data, name, id, bytesBase64 = "", mime = "text/csv", headerLines = 1, state = activeProject._state) {
  let model = {
    id,
    name: projectCsvName(name),
    directory: PROJECT_ASSET_DIRECTORIES.csv,
    rows: projectClone(dataTable(data)),
    bytesBase64: typeof bytesBase64 === "string" && bytesBase64 ? bytesBase64 : ffpxBytesToBase64(
      serializeNewDataTable(dataTable(data), projectCsvName(name))
    ),
    mime: typeof mime === "string" && mime ? mime : "text/csv",
    headerLines: headerLineCount(headerLines, data)
  };
  projectVfs.assignUniqueLocation(model, PROJECT_ASSET_DIRECTORIES.csv, state);
  return model;
}
function createProjectCsv(data, name, id = null, bytesBase64 = "", mime = "text/csv", headerLines = 1, path = null) {
  const [result] = dispatchProjectCommand("DATA_OBJECT_CREATED", {
    data,
    name,
    id,
    bytesBase64,
    mime,
    headerLines,
    path
  });
  if (!result.committed) return result;
  const created = result.changed.assets.find((asset) => asset.role === "created" && asset.kind === "csv");
  return appFSM.query("project-api", { operation: "assets.readDeletionTarget", path: created.path }).target;
}
function createEmptyProjectCsv() {
  return createProjectCsv(
    [["X", "Y"], ["", ""]],
    "빈 CSV.csv",
    null,
    "",
    "text/csv",
    1
  );
}
var PROJECT_ASSET_DIRECTORIES = Object.freeze({
  csv: BackendSettings.defaults.vfs.csv,
  image: BackendSettings.defaults.vfs.image
});
var PROJECT_TRASH_DIRECTORY = BackendSettings.defaults.vfs.trash;
var PROJECT_FIXED_DIRECTORIES = Object.freeze(Object.values(BackendSettings.defaults.vfs));
function projectPathInDirectory(path, directory) {
  let normalized = normalizeProjectPath(path, { directory: true }), parent = normalizeProjectPath(directory, { directory: true });
  return parent === "/" || normalized === parent || normalized.startsWith(`${parent}/`);
}
function normalizeProjectPath(value2, { directory = false } = {}) {
  let raw = String(value2 || "").replace(/\\/g, "/").trim(), segments = raw.split("/").filter(Boolean);
  if (segments.some((segment) => segment === "." || segment === ".."))
    throw Error("프로젝트 경로에는 . 또는 .. 구간을 사용할 수 없습니다.");
  segments = segments.map((segment) => {
    let clean = projectCsvName(segment, "");
    if (!clean) throw Error("프로젝트 경로 이름이 올바르지 않습니다.");
    return clean;
  });
  let path = `/${segments.join("/")}`;
  if (path === "/" && !directory) throw Error("루트는 파일 경로가 될 수 없습니다.");
  return path;
}
function projectParentPath(path) {
  let normalized = normalizeProjectPath(path, { directory: true }), index = normalized.lastIndexOf("/");
  return index <= 0 ? "/" : normalized.slice(0, index);
}
function projectPathName(path) {
  return normalizeProjectPath(path, { directory: true }).split("/").filter(Boolean).pop() || "/";
}
function projectAssetPath(asset) {
  if (!asset || typeof asset !== "object") throw Error("프로젝트 자산이 올바르지 않습니다.");
  if (typeof asset.directory !== "string" || typeof asset.name !== "string")
    throw Error("프로젝트 자산 위치가 올바르지 않습니다.");
  let directory = normalizeProjectPath(asset.directory, { directory: true }), name = projectCsvName(asset.name, "");
  if (!name || name !== asset.name) throw Error("프로젝트 자산 이름이 올바르지 않습니다.");
  return normalizeProjectPath(`${directory}/${name}`);
}
var projectVfs = Object.freeze({
  exists(path, state = activeProject._state) {
    return this.resolve(path, state) !== null;
  },
  uniquePath(directory, name, state = activeProject._state, reservedPaths = null) {
    let parent = normalizeProjectPath(directory, { directory: true }), safeName = projectCsvName(name, "asset"), dot = safeName.lastIndexOf("."), stem = dot > 0 ? safeName.slice(0, dot) : safeName, extension = dot > 0 ? safeName.slice(dot) : "", candidate = normalizeProjectPath(`${parent}/${safeName}`), suffix = 2;
    while (this.exists(candidate, state) || reservedPaths?.has(candidate))
      candidate = normalizeProjectPath(`${parent}/${stem} (${suffix++})${extension}`);
    return candidate;
  },
  ensure(state) {
    let directories = new Set(PROJECT_FIXED_DIRECTORIES), sourceDirectories = Array.isArray(state.fileSystem?.directories) ? state.fileSystem.directories : [];
    sourceDirectories.forEach((path) => {
      let normalized = normalizeProjectPath(path, { directory: true });
      if (normalized !== "/") {
        let current = normalized;
        while (current !== "/") {
          directories.add(current);
          current = projectParentPath(current);
        }
      }
    });
    state.fileSystem = { directories: [...directories].sort() };
    let occupied = new Set(state.fileSystem.directories);
    for (let [kind, assets] of [
      ["csv", state.assets.csvFiles],
      ["image", state.assets.images]
    ]) {
      for (let asset of assets) {
        let directory = normalizeProjectPath(asset.directory, { directory: true }), fullPath = projectAssetPath(asset);
        if (occupied.has(fullPath)) throw Error(`프로젝트 자산 경로 ${fullPath}가 중복되었습니다.`);
        occupied.add(fullPath);
        while (directory !== "/") {
          directories.add(directory);
          directory = projectParentPath(directory);
        }
      }
    }
    state.fileSystem.directories = [...directories].sort();
    return state.fileSystem;
  },
  resolve(path, state = activeProject._state) {
    const normalized = normalizeProjectPath(path, { directory: true }), directories = state.fileSystem?.directories || [], matches = directories.filter((item) => item === normalized).map((path2) => ({ kind: "directory", path: path2 }));
    if (PROJECT_FIXED_DIRECTORIES.includes(normalized) && !directories.includes(normalized))
      matches.push({ kind: "directory", path: normalized });
    for (const [kind, assets] of [["csv", state.assets.csvFiles], ["image", state.assets.images]])
      for (const asset of assets)
        if (projectAssetPath(asset) === normalized) matches.push({ kind, asset });
    if (matches.length > 1) throw Error("프로젝트 경로에 둘 이상의 소유자가 있습니다.");
    return matches[0] || null;
  },
  isFixedDirectory(path) {
    let normalized = normalizeProjectPath(path, { directory: true });
    return PROJECT_FIXED_DIRECTORIES.includes(normalized);
  },
  isTrashed(path) {
    return projectPathInDirectory(path, PROJECT_TRASH_DIRECTORY);
  },
  descendants(path, state = activeProject._state) {
    const parent = normalizeProjectPath(path, { directory: true });
    return [
      ...(state.fileSystem?.directories || []).map((path2) => ({ kind: "directory", path: path2 })),
      ...(state.assets?.csvFiles || []).map((asset) => ({ kind: "csv", asset })),
      ...(state.assets?.images || []).map((asset) => ({ kind: "image", asset }))
    ].filter((node) => {
      const path2 = node.kind === "directory" ? node.path : projectAssetPath(node.asset);
      return path2 !== parent && projectPathInDirectory(path2, parent);
    });
  },
  assignLocation(model, path) {
    let fullPath = normalizeProjectPath(path);
    model.directory = projectParentPath(fullPath);
    model.name = projectPathName(fullPath);
    return model;
  },
  assignUniqueLocation(model, directory, state = activeProject._state, reservedPaths = null) {
    return this.assignLocation(
      model,
      this.uniquePath(directory, model?.name, state, reservedPaths)
    );
  },
  prepare(model, kind, state = activeProject._state) {
    this.ensure(state);
    let directory = normalizeProjectPath(
      model?.directory || PROJECT_ASSET_DIRECTORIES[kind],
      { directory: true }
    ), preferred = projectAssetPath({ ...model, directory });
    if (this.exists(preferred, state)) {
      this.assignUniqueLocation(model, directory, state);
      directory = model.directory;
    } else model.directory = directory;
    let parent = directory;
    while (parent !== "/") {
      if (!state.fileSystem.directories.includes(parent)) state.fileSystem.directories.push(parent);
      parent = projectParentPath(parent);
    }
    state.fileSystem.directories.sort();
    return model;
  }
});
function calculateAssetCollisionInProject(source, kind, directory, filename, reservedPaths) {
  if (!["data", "image"].includes(kind)) throw Error("지원하지 않는 자산 파일 형식입니다.");
  const parent = normalizeProjectPath(directory, { directory: true });
  if (projectVfs.resolve(parent, source)?.kind !== "directory") throw Error("대상 폴더가 없습니다.");
  const name = projectCsvName(filename, kind === "data" ? "data.csv" : "image.bin"), path = normalizeProjectPath(`${parent}/${name}`), collision = projectVfs.resolve(path, source), sameKind = collision?.kind === (kind === "data" ? "csv" : "image"), mode = reservedPaths?.has(path) ? "rename-only" : !collision ? "available" : sameKind ? "replace-or-rename" : "rename-only", replaceId = mode === "replace-or-rename" ? collision.asset.id : null, message = mode === "replace-or-rename" ? `${path}에 같은 이름의 파일이 이미 있습니다.

[확인] 기존 파일을 교체하고 참조를 유지합니다.
[취소] 이름을 바꿔 새 파일로 추가합니다.` : "", notice = mode === "rename-only" ? `${path}은 이미 사용 중입니다. 이름을 바꿔 추가합니다.` : "";
  return Object.freeze({ assetKind: kind, parent, name, path, mode, replaceId, message, notice });
}
function projectAssetImportCollisionModel(file, directory, reservedPaths = null) {
  const source = activeProject._state;
  return calculateAssetCollisionInProject(source, slotFileKind(file), directory, file?.name, reservedPaths);
}
function resolveProjectAssetImportPlan(model, choice = "rename", reservedPaths = null) {
  const source = activeProject._state;
  if (!model || !["data", "image"].includes(model.assetKind) || typeof model.parent !== "string" || typeof model.name !== "string" || !model.name || typeof model.path !== "string" || !["available", "replace-or-rename", "rename-only"].includes(model.mode) || !(model.replaceId === null || Number.isInteger(model.replaceId) && model.replaceId > 0) || model.parent !== normalizeProjectPath(model.parent, { directory: true }) || model.name !== projectCsvName(model.name, "asset") || model.path !== normalizeProjectPath(`${model.parent}/${model.name}`))
    throw Error("프로젝트 자산 가져오기 계획이 올바르지 않습니다.");
  const fresh = calculateAssetCollisionInProject(source, model.assetKind, model.parent, model.name, reservedPaths);
  if (choice === "replace" && model.replaceId !== null && (fresh.mode !== "replace-or-rename" || fresh.replaceId !== model.replaceId))
    throw Error("교체할 자산이 변경되었습니다.");
  if (fresh.mode === "available") return Object.freeze({ path: fresh.path, replaceId: null });
  if (choice === "replace" && fresh.mode === "replace-or-rename" && model.replaceId === fresh.replaceId)
    return Object.freeze({ path: fresh.path, replaceId: fresh.replaceId });
  return Object.freeze({ path: projectVfs.uniquePath(fresh.parent, fresh.name, source, reservedPaths), replaceId: null });
}
function stageProjectAssetImport(candidate, item) {
  if (!["data", "image"].includes(item.kind)) throw Error("지원하지 않는 자산 종류입니다.");
  const bytes = new Uint8Array(item.file.bytes), kind = item.kind === "data" ? "csv" : "image", id = item.replaceId === null ? candidate.nextId[kind]++ : item.replaceId, model = projectVfs.assignLocation({ id, mime: item.file.type, bytesBase64: ffpxBytesToBase64(bytes) }, item.path), collection = candidate.assets[kind === "csv" ? "csvFiles" : "images"], index = collection.findIndex((asset) => asset.id === id);
  if (kind === "csv") {
    model.rows = parseProjectCsvAsset(item.file.name, bytes);
    if (item.replaceId !== null && index < 0) throw Error("교체할 자산이 없습니다.");
    model.headerLines = headerLineCount(item.replaceId === null ? 1 : collection[index].headerLines, model.rows);
  }
  if (item.replaceId !== null) {
    if (index < 0) throw Error("교체할 자산이 없습니다.");
    collection[index] = model;
  } else {
    if (index >= 0) throw Error(`자산 ID ${id}가 중복되었습니다.`);
    collection.push(model);
  }
  return { kind, id, name: model.name, model };
}
function projectDataTreeSnapshot(objects = {}) {
  return {
    directories: Array.isArray(objects.files?.directories) ? [...objects.files.directories] : [...PROJECT_FIXED_DIRECTORIES],
    data: (Array.isArray(objects.data) ? objects.data : []).map((csv) => ({
      id: csv.id,
      name: csv.name,
      path: projectAssetPath(csv),
      readable: Array.isArray(csv.rows),
      rowCount: Array.isArray(csv.rows) ? Math.max(0, csv.rows.length - (Number(csv.headerLines) || 0)) : 0
    })),
    images: (Array.isArray(objects.images) ? objects.images : []).map((image) => ({
      id: image.id,
      name: image.name,
      path: projectAssetPath(image)
    })),
    charts: (Array.isArray(objects.charts) ? objects.charts : []).map((chart) => ({
      id: chart.id,
      editable: chart.editor?.editable !== false,
      csvIds: chartCsvIds(chart),
      csvReferences: (chart.editor?.objects || []).map((object) => object.csvId).filter((id) => Number.isInteger(id))
    })),
    slots: (Array.isArray(objects.slots) ? objects.slots : []).map((slot) => ({
      id: slot.id,
      row: slot.row,
      col: slot.col,
      hidden: slot.hidden === true,
      contentType: slot.contentType,
      chart: slot.chart,
      imageId: slot.imageId
    }))
  };
}
function importedProjectCsvState(payload) {
  if (!Array.isArray(payload.csvFiles)) throw Error("프로젝트 CSV 목록이 없습니다.");
  let ids = /* @__PURE__ */ new Set(), nextCsvFiles = payload.csvFiles.map((source, index) => {
    if (!source || typeof source !== "object" || !Number.isInteger(source.id) || source.id < 1 || !Array.isArray(source.rows))
      throw Error("프로젝트 CSV 데이터가 올바르지 않습니다.");
    let id = source.id;
    if (ids.has(id)) throw Error("프로젝트 CSV ID가 중복되었습니다.");
    ids.add(id);
    return {
      id,
      name: projectCsvName(source.name, `data-${index + 1}.csv`),
      directory: typeof source.directory === "string" ? source.directory : null,
      rows: projectClone(source.rows),
      bytesBase64: typeof source.bytesBase64 === "string" && source.bytesBase64 ? source.bytesBase64 : ffpxBytesToBase64(
        serializeNewDataTable(source.rows, projectCsvName(source.name, `data-${index + 1}.csv`))
      ),
      mime: typeof source.mime === "string" ? source.mime : "text/csv",
      headerLines: headerLineCount(Object.hasOwn(source, "headerLines") ? source.headerLines : 1, source.rows)
    };
  });
  return {
    csvFiles: nextCsvFiles,
    csvId: nextCsvFiles.reduce((next, csv) => Math.max(next, csv.id + 1), 1)
  };
}
function importedProjectImageState(payload) {
  if (!Array.isArray(payload.images)) throw Error("프로젝트 이미지 목록이 없습니다.");
  let nextImages = [], ids = /* @__PURE__ */ new Set();
  payload.images.forEach((source) => {
    if (!source || !Number.isInteger(source.id) || source.id < 1 || ids.has(source.id) || typeof source.bytesBase64 !== "string" || !source.bytesBase64)
      throw Error("프로젝트 이미지 데이터가 올바르지 않습니다.");
    ids.add(source.id);
    nextImages.push({
      id: source.id,
      name: projectCsvName(source.name, "image.bin"),
      directory: typeof source.directory === "string" ? source.directory : null,
      mime: typeof source.mime === "string" && source.mime ? source.mime : "application/octet-stream",
      bytesBase64: source.bytesBase64
    });
  });
  return {
    images: nextImages,
    imageId: nextImages.reduce((next, image) => Math.max(next, image.id + 1), 1)
  };
}
function fillMissingSettingRecord(current, defaults) {
  if (!current || typeof current !== "object" || Array.isArray(current))
    throw Error("프로젝트 설정 구조가 올바르지 않습니다.");
  const copy = projectClone(current);
  for (const [key, value2] of Object.entries(defaults)) {
    if (!Object.hasOwn(copy, key)) copy[key] = projectClone(value2);
    else if (value2 && typeof value2 === "object" && !Array.isArray(value2) && copy[key] && typeof copy[key] === "object" && !Array.isArray(copy[key]))
      copy[key] = fillMissingSettingRecord(copy[key], value2);
  }
  return copy;
}
function buildProjectObject(payload, fileName) {
  if (payload?.schema !== "fast-figure-project" || payload.version !== PACKAGE_FORMAT_VERSION)
    throw Error("지원하지 않는 FFPX 프로젝트 형식입니다.");
  const defaults = BackendSettings.project_object, limits = BackendSettings.defaults.limits, own = (source, key, fallback) => Object.hasOwn(source, key) ? source[key] : fallback, record = (value2) => !!value2 && typeof value2 === "object" && !Array.isArray(value2);
  if (payload.kind !== "fast-figure-project-object" || !record(payload.meta) || typeof payload.meta.projectName !== "string" || payload.meta.projectName.length > BackendSettings.defaults.naming.projectNameMaxLength || !record(payload.layout) || !Number.isInteger(payload.layout.gridRows) || !Number.isInteger(payload.layout.gridCols) || payload.layout.gridRows < limits.layout.gridRows[0] || payload.layout.gridRows > limits.layout.gridRows[1] || payload.layout.gridCols < limits.layout.gridCols[0] || payload.layout.gridCols > limits.layout.gridCols[1] || !Array.isArray(payload.charts) || !Array.isArray(payload.slots) || !record(payload.fileSystem) || !record(payload.assets))
    throw Error("프로젝트 이름, grid 또는 목록 구조가 올바르지 않습니다.");
  const candidate = structuredClone(payload);
  delete candidate.schema;
  delete candidate.version;
  delete candidate.layout.layoutMapWidth;
  candidate.assets = { csvFiles: [], images: [] };
  candidate.slots = [];
  candidate.nextId = {};
  const paths = /* @__PURE__ */ new Set();
  for (const [kind, collection] of [["csv", payload.assets.csvFiles], ["image", payload.assets.images]]) {
    if (!Array.isArray(collection)) throw Error("프로젝트 자산 목록이 없습니다.");
    const ids = /* @__PURE__ */ new Set();
    for (const raw of collection) {
      if (!record(raw) || !Number.isInteger(raw.id) || raw.id < 1 || ids.has(raw.id) || typeof raw.bytesBase64 !== "string" || kind === "image" && Object.hasOwn(raw, "imageSettings"))
        throw Error("프로젝트 자산 데이터가 올바르지 않습니다.");
      const path = projectAssetPath(raw);
      if (paths.has(path) || !candidate.fileSystem.directories?.includes(projectParentPath(path)))
        throw Error("프로젝트 자산 경로가 중복되거나 parent가 없습니다.");
      ids.add(raw.id);
      paths.add(path);
      const asset = {
        id: raw.id,
        directory: projectParentPath(path),
        name: projectPathName(path),
        mime: raw.mime,
        bytesBase64: ffpxBytesToBase64(ffpxBase64ToBytes(raw.bytesBase64))
      };
      if (kind === "csv") {
        asset.rows = dataTable(raw.rows);
        asset.headerLines = headerLineCount(own(raw, "headerLines", 1), asset.rows);
      }
      candidate.assets[kind === "csv" ? "csvFiles" : "images"].push(asset);
    }
  }
  for (const chart of candidate.charts) {
    if (!record(chart?.editor) || !Array.isArray(chart.editor.objects) || !Number.isInteger(chart.id) || chart.id < 1)
      throw Error("프로젝트 차트 구조가 올바르지 않습니다.");
    chart.editor.globalSettings = normalizeGlobalSettings(chart.editor.globalSettings);
    chart.editor.objects = chart.editor.objects.map((object) => fillMissingSettingRecord(object, BackendSettings.defaults.chartSettings.editor.objectStyle));
    validateChartModel(chart, "프로젝트 차트", candidate.assets.csvFiles);
  }
  const slotIds = /* @__PURE__ */ new Set(), owners = new Map(candidate.charts.map((chart) => [chart.id, 0]));
  for (const raw of payload.slots) {
    const slot = normalizeSlotContent(structuredClone(raw));
    if (!slot || !Number.isInteger(slot.id) || slotIds.has(slot.id) || typeof slot.hidden !== "boolean" || ![slot.row, slot.col, slot.rowSpan, slot.colSpan].every((value2) => Number.isInteger(value2) && value2 > 0) || slot.row + slot.rowSpan - 1 > candidate.layout.gridRows || slot.col + slot.colSpan - 1 > candidate.layout.gridCols || !["graph", "image"].includes(slot.content.contentType) || slot.content.chart !== null && slot.content.imageId !== null || slot.content.chart !== null && !owners.has(slot.content.chart) || slot.content.imageId !== null && !candidate.assets.images.some((image) => image.id === slot.content.imageId) || !(slot.caption === null || typeof slot.caption === "string"))
      throw Error("프로젝트 슬롯 데이터가 올바르지 않습니다.");
    slotIds.add(slot.id);
    if (slot.content.chart !== null) owners.set(slot.content.chart, owners.get(slot.content.chart) + 1);
    if (!["contain", "cover", "manual"].includes(slot.content.imageSettings.fit) || Object.entries(limits.imageSettings).some(([key, [min, max]]) => !Number.isFinite(slot.content.imageSettings[key]) || slot.content.imageSettings[key] < min || slot.content.imageSettings[key] > max))
      throw Error("프로젝트 슬롯 이미지 설정이 올바르지 않습니다.");
    candidate.slots.push(slot);
  }
  if ([...owners.values()].some((count) => count !== 1)) throw Error("프로젝트 차트의 슬롯 소유권이 올바르지 않습니다.");
  candidate.layout = fillMissingSettingRecord(candidate.layout, defaults.layout);
  if (!Object.hasOwn(candidate, "annotations")) candidate.annotations = {};
  if (!record(candidate.annotations)) throw Error("프로젝트 annotation 구조가 올바르지 않습니다.");
  for (const key of ["labels", "captions"])
    candidate.annotations[key] = fillMissingSettingRecord(own(candidate.annotations, key, {}), defaults.annotations[key]);
  for (const key of ["text", "afterText", "name"])
    if (!Object.hasOwn(candidate.annotations.captions, key)) candidate.annotations.captions[key] = "";
  if (!Object.hasOwn(candidate, "appearance")) candidate.appearance = {};
  if (!record(candidate.appearance)) throw Error("프로젝트 appearance 구조가 올바르지 않습니다.");
  const palette = own(candidate.appearance, "uiPalette", {});
  if (!record(palette)) throw Error("프로젝트 palette 구조가 올바르지 않습니다.");
  candidate.appearance.uiPalette = Object.fromEntries(Object.entries(DEFAULT_UI_PALETTE).map(([key, fallback]) => [key, projectColor(palette[key], fallback)]));
  candidate.export = fillMissingSettingRecord(own(candidate, "export", {}), defaults.export);
  if (!Object.hasOwn(candidate.export, "width")) candidate.export.width = candidate.layout.slotStyle.referenceWidth;
  if (!Object.hasOwn(candidate.export, "height")) candidate.export.height = candidate.export.heightMode === "auto" ? null : limits.export.logicalHeight[0];
  for (const [kind, collection] of [
    ["csv", candidate.assets.csvFiles],
    ["image", candidate.assets.images],
    ["chart", candidate.charts]
  ]) candidate.nextId[kind] = Math.max(0, ...collection.map((item) => item.id)) + 1;
  validateProjectObjectState(candidate, { requireSlots: true });
  return new ProjectObject(candidate);
}
function ffpxBytesToBase64(bytes) {
  let text = "", step = 32768;
  for (let i = 0; i < bytes.length; i += step)
    text += String.fromCharCode(...bytes.subarray(i, i + step));
  return btoa(text);
}
function ffpxBase64ToBytes(value2) {
  let text = atob(value2), bytes = new Uint8Array(text.length);
  for (let i = 0; i < text.length; i++) bytes[i] = text.charCodeAt(i);
  return bytes;
}
function ffpxConcat(parts, total) {
  let result = new Uint8Array(total), offset = 0;
  for (let part of parts) {
    result.set(part, offset);
    offset += part.length;
  }
  return result;
}
var ffpxCrcTable = null;
function ffpxCrc32(bytes) {
  if (!ffpxCrcTable) {
    ffpxCrcTable = new Uint32Array(256);
    for (let i = 0; i < 256; i++) {
      let value3 = i;
      for (let bit = 0; bit < 8; bit++)
        value3 = value3 & 1 ? 3988292384 ^ value3 >>> 1 : value3 >>> 1;
      ffpxCrcTable[i] = value3 >>> 0;
    }
  }
  let value2 = 4294967295;
  for (let byte of bytes) value2 = ffpxCrcTable[(value2 ^ byte) & 255] ^ value2 >>> 8;
  return (value2 ^ 4294967295) >>> 0;
}
function ffpxZipStore(entries) {
  let encoder = new TextEncoder(), prepared = entries.map((entry) => {
    if (!entry || typeof entry.name !== "string" || !entry.name || entry.name.split(/[\\/]/).includes("..") || /^[\\/]|^[A-Za-z]:[\\/]/.test(entry.name))
      throw Error("FFPX 자산 경로가 올바르지 않습니다.");
    let name = encoder.encode(entry.name), data = entry.data instanceof Uint8Array ? entry.data : new Uint8Array(entry.data);
    if (name.length > 65535 || data.length > 4294967295)
      throw Error("FFPX 자산 크기가 너무 큽니다.");
    return { name, data, crc: ffpxCrc32(data) };
  }), localSize = prepared.reduce(
    (sum, entry) => sum + 30 + entry.name.length + entry.data.length,
    0
  ), centralSize = prepared.reduce((sum, entry) => sum + 46 + entry.name.length, 0), parts = [], offset = 0;
  for (let entry of prepared) {
    let header = new Uint8Array(30), view = new DataView(header.buffer);
    view.setUint32(0, 67324752, true);
    view.setUint16(4, 20, true);
    view.setUint16(8, 0, true);
    view.setUint32(14, entry.crc, true);
    view.setUint32(18, entry.data.length, true);
    view.setUint32(22, entry.data.length, true);
    view.setUint16(26, entry.name.length, true);
    parts.push(header, entry.name, entry.data);
    entry.offset = offset;
    offset += header.length + entry.name.length + entry.data.length;
  }
  let central = [];
  for (let entry of prepared) {
    let header = new Uint8Array(46), view = new DataView(header.buffer);
    view.setUint32(0, 33639248, true);
    view.setUint16(4, 20, true);
    view.setUint16(6, 20, true);
    view.setUint16(8, 0, true);
    view.setUint32(16, entry.crc, true);
    view.setUint32(20, entry.data.length, true);
    view.setUint32(24, entry.data.length, true);
    view.setUint16(28, entry.name.length, true);
    view.setUint32(42, entry.offset, true);
    central.push(header, entry.name);
  }
  let end = new Uint8Array(22), endView = new DataView(end.buffer);
  endView.setUint32(0, 101010256, true);
  endView.setUint16(8, prepared.length, true);
  endView.setUint16(10, prepared.length, true);
  endView.setUint32(12, centralSize, true);
  endView.setUint32(16, localSize, true);
  return ffpxConcat([...parts, ...central, end], localSize + centralSize + end.length);
}
function ffpxZipRead(bytes) {
  if (!(bytes instanceof Uint8Array) || bytes.length < 22)
    throw Error("FFPX ZIP 파일이 너무 작습니다.");
  let view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength), end = -1;
  for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 65558); i--)
    if (view.getUint32(i, true) === 101010256) {
      end = i;
      break;
    }
  if (end < 0) throw Error("FFPX ZIP 종료 정보를 찾을 수 없습니다.");
  if (view.getUint16(end + 4, true) || view.getUint16(end + 6, true))
    throw Error("분할 ZIP은 지원하지 않습니다.");
  let count = view.getUint16(end + 10, true), centralSize = view.getUint32(end + 12, true), offset = view.getUint32(end + 16, true);
  if (offset + centralSize > end)
    throw Error("FFPX ZIP 중앙 디렉터리가 올바르지 않습니다.");
  let decoder = new TextDecoder(), assets = /* @__PURE__ */ new Map(), cursor = offset;
  for (let index = 0; index < count; index++) {
    if (cursor + 46 > offset + centralSize || view.getUint32(cursor, true) !== 33639248)
      throw Error("FFPX ZIP 항목이 올바르지 않습니다.");
    let flags = view.getUint16(cursor + 8, true), method = view.getUint16(cursor + 10, true), crc = view.getUint32(cursor + 16, true), compressed = view.getUint32(cursor + 20, true), size = view.getUint32(cursor + 24, true), nameLength = view.getUint16(cursor + 28, true), extraLength = view.getUint16(cursor + 30, true), commentLength = view.getUint16(cursor + 32, true), localOffset = view.getUint32(cursor + 42, true), next = cursor + 46 + nameLength + extraLength + commentLength;
    if (flags || method !== 0 || compressed !== size || next > offset + centralSize)
      throw Error("FFPX는 압축되지 않은 STORE ZIP만 지원합니다.");
    let name = decoder.decode(bytes.subarray(cursor + 46, cursor + 46 + nameLength));
    if (!name || name.split(/[\\/]/).includes("..") || /^[\\/]|^[A-Za-z]:[\\/]/.test(name) || assets.has(name) || localOffset + 30 > bytes.length || view.getUint16(cursor + 34, true) !== 0 || view.getUint32(localOffset, true) !== 67324752)
      throw Error("FFPX 자산 경로가 올바르지 않습니다.");
    let localNameLength = view.getUint16(localOffset + 26, true), localExtraLength = view.getUint16(localOffset + 28, true), start = localOffset + 30 + localNameLength + localExtraLength;
    if (start + size > offset || view.getUint16(localOffset + 6, true) !== flags || view.getUint16(localOffset + 8, true) !== method || view.getUint32(localOffset + 14, true) !== crc || view.getUint32(localOffset + 18, true) !== compressed || view.getUint32(localOffset + 22, true) !== size || decoder.decode(bytes.subarray(localOffset + 30, localOffset + 30 + localNameLength)) !== name)
      throw Error("FFPX ZIP local entry가 올바르지 않습니다.");
    let data = bytes.slice(start, start + size);
    if (ffpxCrc32(data) !== crc) throw Error("FFPX 자산 CRC 검증에 실패했습니다.");
    assets.set(name, data);
    cursor = next;
  }
  return assets;
}
function serializeNewDataTable(rows, path) {
  const extension = String(path).toLowerCase();
  if (extension.endsWith(".json")) return new TextEncoder().encode(JSON.stringify(rows));
  const delimiter = extension.endsWith(".tsv") ? "	" : ",", cell = (value2) => {
    const text = value2 == null ? "" : typeof value2 === "object" ? JSON.stringify(value2) : String(value2);
    return text.includes(delimiter) || /["\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
  };
  return new TextEncoder().encode(rows.map((row) => row.map(cell).join(delimiter)).join("\n"));
}
function parseProjectCsvAsset(name, bytes) {
  let text = new TextDecoder().decode(bytes);
  if (String(name).toLowerCase().endsWith(".json")) {
    let data = JSON.parse(text);
    if (!Array.isArray(data) && Array.isArray(data?.data)) data = data.data;
    return dataTable(data);
  }
  const extension = /\.[^./]+$/.exec(String(name))?.[0]?.toLowerCase();
  if (![".csv", ".tsv"].includes(extension)) throw Error("지원하는 데이터 확장자가 아닙니다.");
  return parseCSV(text, extension === ".tsv" ? "	" : ",");
}
function projectCsvDataRef(csv) {
  const extension = /\.[^./]+$/.exec(csv.name || "")?.[0]?.toLowerCase();
  return `data/csv-${csv.id}${[".json", ".tsv", ".csv"].includes(extension) ? extension : ".csv"}`;
}
function ffpxDataUrlBytes(url) {
  let match = /^data:([^,]*),(.*)$/s.exec(url || "");
  if (!match) throw Error("이미지 데이터 URL이 올바르지 않습니다.");
  let meta = match[1].split(";"), mime = meta[0] || "application/octet-stream", base64 = meta.slice(1).some((value2) => value2.toLowerCase() === "base64");
  return {
    mime,
    data: base64 ? ffpxBase64ToBytes(match[2]) : new TextEncoder().encode(decodeURIComponent(match[2]))
  };
}
function ffpxMimeExtension(mime) {
  return {
    "image/png": "png",
    "image/jpeg": "jpg",
    "image/gif": "gif",
    "image/webp": "webp",
    "image/bmp": "bmp",
    "image/svg+xml": "svg"
  }[mime] || "bin";
}
function ffpxXmlEscape(value2) {
  return String(value2).replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&apos;");
}
function ffpxXmlValue(value2) {
  if (value2 === null) return '<value type="null"/>';
  if (Array.isArray(value2))
    return `<value type="array">${Array.from(value2).map((item) => `<item>${ffpxXmlValue(item)}</item>`).join("")}</value>`;
  if (typeof value2 === "object")
    return `<value type="object">${Object.entries(value2).map(
      ([name, item]) => `<property name="${ffpxXmlEscape(name)}">${ffpxXmlValue(item)}</property>`
    ).join("")}</value>`;
  if (!["boolean", "number", "string"].includes(typeof value2) || typeof value2 === "number" && !Number.isFinite(value2))
    throw Error("FFPX XML로 기록할 수 없는 값입니다.");
  return `<value type="${typeof value2}">${ffpxXmlEscape(value2)}</value>`;
}
function ffpxXmlReadValue(element) {
  if (!element || element.tagName !== "value")
    throw Error("FFPX XML 값 형식이 올바르지 않습니다.");
  const type = element.getAttribute("type"), children = [...element.children], hasScalarText = (node) => [...node.childNodes].some((child) => (child.nodeType === 3 || child.nodeType === 4) && child.textContent.trim() !== ""), requireShape = (valid) => {
    if (!valid) throw Error("FFPX XML 값 구조가 올바르지 않습니다.");
  };
  if (type === "null") {
    requireShape(children.length === 0 && !hasScalarText(element));
    return null;
  }
  if (type === "array" || type === "object") {
    requireShape(!hasScalarText(element));
    const result = type === "array" ? [] : {};
    for (const child of children) {
      requireShape(child.tagName === (type === "array" ? "item" : "property") && child.children.length === 1 && child.firstElementChild.tagName === "value" && !hasScalarText(child) && (type === "array" || child.hasAttribute("name")));
      const decoded = ffpxXmlReadValue(child.firstElementChild);
      if (type === "array") result.push(decoded);
      else Object.defineProperty(result, child.getAttribute("name"), {
        value: decoded,
        enumerable: true,
        configurable: true,
        writable: true
      });
    }
    return result;
  }
  requireShape(children.length === 0);
  if (type === "boolean") {
    requireShape(element.textContent === "true" || element.textContent === "false");
    return element.textContent === "true";
  }
  if (type === "number") {
    let number = Number(element.textContent);
    if (!element.textContent.trim() || !Number.isFinite(number))
      throw Error("FFPX XML 숫자 값이 올바르지 않습니다.");
    return number;
  }
  if (type === "string") return element.textContent;
  throw Error("FFPX XML 값 유형이 올바르지 않습니다.");
}
function ffpxXmlDocument(root, version, children) {
  return `<?xml version="1.0" encoding="UTF-8"?><${root} version="${version}">${children}</${root}>`;
}
function ffpxReadXmlDocument(assets, name, root) {
  let bytes = assets.get(name);
  if (!bytes) throw Error(`FFPX ${name}이 없습니다.`);
  let documentNode = new DOMParser().parseFromString(
    new TextDecoder().decode(bytes),
    "application/xml"
  ), rootNode = documentNode.documentElement;
  if (documentNode.querySelector("parsererror") || rootNode?.tagName !== root || rootNode.getAttribute("version") !== String(PACKAGE_FORMAT_VERSION))
    throw Error(`FFPX ${name} 형식이 올바르지 않습니다.`);
  return rootNode;
}
function ffpxDirectChild(root, name, optional = false) {
  const nodes = [...root.children].filter((child) => child.tagName === name);
  if (nodes.length === 0 && optional) return null;
  if (nodes.length !== 1) throw Error(`FFPX ${name} 단일 요소가 필요합니다.`);
  return nodes[0];
}
function ffpxWrappedValue(node) {
  const children = [...node.children];
  if (children.length !== 1 || children[0].tagName !== "value" || [...node.childNodes].some((child) => (child.nodeType === 3 || child.nodeType === 4) && child.textContent.trim()))
    throw Error("FFPX 단일 typed value가 필요합니다.");
  return ffpxXmlReadValue(children[0]);
}
function ffpxNamedValue(root, name) {
  return ffpxWrappedValue(ffpxDirectChild(root, name));
}
function ffpxDeriveHiddenSlots(slotList) {
  const slots = projectClone(slotList);
  for (const slot of slots) slot.hidden = false;
  for (const anchor of slots) {
    if (!Number.isInteger(anchor.rowSpan) || anchor.rowSpan < 1 || !Number.isInteger(anchor.colSpan) || anchor.colSpan < 1 || !Number.isInteger(anchor.row) || !Number.isInteger(anchor.col))
      throw Error("FFPX 병합 geometry가 올바르지 않습니다.");
    if (anchor.rowSpan === 1 && anchor.colSpan === 1) continue;
    for (let row = anchor.row; row < anchor.row + anchor.rowSpan; row++)
      for (let col = anchor.col; col < anchor.col + anchor.colSpan; col++) {
        if (row === anchor.row && col === anchor.col) continue;
        const matches = slots.filter((slot) => slot.row === row && slot.col === col);
        if (matches.length !== 1) throw Error("FFPX 병합 영역에 단일 슬롯이 필요합니다.");
        const covered = matches[0];
        if ((covered.content?.chart ?? covered.chart) != null || (covered.content?.imageId ?? covered.imageId) != null)
          throw Error("FFPX 병합 영역의 가려진 슬롯은 비어 있어야 합니다.");
        covered.hidden = true;
      }
  }
  return slots;
}
function ffpxBuildProject(source = activeProject._state) {
  const snapshot = projectClone(source);
  validateProjectObjectState(snapshot, { requireSlots: true });
  let projectObject = snapshot.meta, layoutObject = snapshot.layout, labelObject = snapshot.annotations.labels, captionObject = snapshot.annotations.captions, dataObjects = snapshot.assets.csvFiles.filter((csv) => !projectVfs.isTrashed(projectAssetPath(csv))), imageObjects = snapshot.assets.images.filter((image) => !projectVfs.isTrashed(projectAssetPath(image))), chartObjects = snapshot.charts, slotObjects = snapshot.slots, appearanceObject = snapshot.appearance, exportObject = snapshot.export, manifest = {
    schema: "fast-figure-project",
    version: PACKAGE_FORMAT_VERSION,
    appBuild: projectObject.appBuild,
    projectName: projectObject.projectName,
    exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
    gridRows: layoutObject.gridRows,
    gridCols: layoutObject.gridCols,
    csvFiles: [],
    images: [],
    charts: [],
    slots: [],
    annotations: {
      labelsEnabled: labelObject.enabled,
      labelSettings: projectClone(labelObject.settings),
      captionsEnabled: captionObject.enabled,
      captionText: captionObject.text,
      captionAfterText: captionObject.afterText,
      captionName: captionObject.name,
      captionNameBold: captionObject.nameBold,
      captionSettings: projectClone(captionObject.settings)
    },
    slotStyle: projectClone(layoutObject.slotStyle),
    uiPalette: projectClone(appearanceObject.uiPalette),
    export: projectClone(exportObject)
  }, assets = [];
  for (let csv of dataObjects) {
    let copy = projectClone(csv), dataRef = `assets/${projectCsvDataRef(copy)}`;
    delete copy.rows;
    delete copy.bytesBase64;
    copy.dataRef = dataRef;
    manifest.csvFiles.push(copy);
    assets.push({
      name: dataRef,
      data: ffpxBase64ToBytes(csv.bytesBase64)
    });
  }
  for (let image of imageObjects) {
    let copy = projectClone(image), dataRef = `assets/media/${image.id}/${projectCsvName(image.name, "image.bin")}`;
    delete copy.bytesBase64;
    delete copy.settings;
    copy.dataRef = dataRef;
    manifest.images.push(copy);
    assets.push({ name: dataRef, data: ffpxBase64ToBytes(image.bytesBase64) });
  }
  for (let chart of chartObjects) {
    chartCsvIds(chart).forEach((id) => {
      let csv = dataObjects.find((item) => item.id === id);
      if (!csv)
        throw Error(`FFPX 차트가 내보낼 수 없는 CSV ${id}를 참조합니다.`);
    });
    manifest.charts.push(chartExportCopy(chart));
  }
  for (let slot of slotObjects) {
    let copy = projectClone(slot);
    if (copy.imageId != null) {
      let image = imageObjects.find((item) => item.id === copy.imageId);
      if (!image)
        throw Error(`FFPX 슬롯이 내보낼 수 없는 이미지 ${copy.imageId}를 참조합니다.`);
    }
    manifest.slots.push(copy);
  }
  let projectDocument = {
    schema: manifest.schema,
    version: manifest.version,
    appBuild: manifest.appBuild,
    projectName: manifest.projectName,
    exportedAt: manifest.exportedAt,
    fileSystem: {
      directories: snapshot.fileSystem.directories.filter((path) => !projectVfs.isTrashed(path))
    },
    appearance: {
      slotStyle: manifest.slotStyle,
      uiPalette: manifest.uiPalette
    },
    export: manifest.export
  }, layoutDocument = {
    gridRows: manifest.gridRows,
    gridCols: manifest.gridCols,
    placements: manifest.slots.map((slot) => ({
      slotId: slot.id,
      row: slot.row,
      col: slot.col,
      rowSpan: slot.rowSpan,
      colSpan: slot.colSpan
    }))
  }, captionDocument = {
    enabled: manifest.annotations.captionsEnabled,
    beforeText: manifest.annotations.captionText,
    afterText: manifest.annotations.captionAfterText,
    name: manifest.annotations.captionName,
    nameBold: manifest.annotations.captionNameBold,
    settings: manifest.annotations.captionSettings
  }, labelDocument = {
    enabled: manifest.annotations.labelsEnabled,
    settings: manifest.annotations.labelSettings
  }, slotDocuments = manifest.slots.map((slot) => {
    let chart = manifest.charts.find((item) => item.id === slot.chart), image = imageObjects.find((item) => item.id === slot.imageId), graphObjects = chart?.editor?.objects || [], chartState = chart ? {
      ...projectClone(chart),
      editor: {
        ...projectClone(chart.editor || {}),
        objects: []
      }
    } : null;
    return {
      slot: {
        id: slot.id,
        contentType: slot.contentType
      },
      caption: {
        text: typeof slot.caption === "string" ? slot.caption : null
      },
      graphObjects: chart ? graphObjects.map((object) => projectClone(object)) : [],
      chartState,
      imageObject: {
        imageRef: image?.id ?? null,
        settings: projectClone(slot.imageSettings || DEFAULT_IMAGE_SETTINGS)
      }
    };
  }), refs = '<assets ref="assets/assets.xml"/><slots ref="slots/"/><layout ref="layout/layout.xml"/><caption ref="caption/caption.xml"/><labels ref="labels/labels.xml"/>';
  manifest.slots.forEach((slot) => {
    delete slot.row;
    delete slot.col;
    delete slot.rowSpan;
    delete slot.colSpan;
  });
  return {
    manifest,
    assets: [
      {
        name: "project.xml",
        data: new TextEncoder().encode(
          ffpxXmlDocument(
            "fastFigureProject",
            PACKAGE_FORMAT_VERSION,
            `${refs}<settings>${ffpxXmlValue(projectDocument)}</settings>`
          )
        )
      },
      {
        name: "assets/assets.xml",
        data: new TextEncoder().encode(
          ffpxXmlDocument(
            "fastFigureAssets",
            PACKAGE_FORMAT_VERSION,
            `<dataAssets>${manifest.csvFiles.map(
              (csv) => `<dataAsset id="${csv.id}" src="${ffpxXmlEscape(csv.dataRef)}">${ffpxXmlValue(csv)}</dataAsset>`
            ).join("")}</dataAssets><imageAssets>${manifest.images.map(
              (image) => `<imageAsset id="${image.id}" src="${ffpxXmlEscape(image.dataRef)}">${ffpxXmlValue(image)}</imageAsset>`
            ).join("")}</imageAssets>`
          )
        )
      },
      {
        name: "layout/layout.xml",
        data: new TextEncoder().encode(
          ffpxXmlDocument(
            "fastFigureLayout",
            PACKAGE_FORMAT_VERSION,
            `<layout>${ffpxXmlValue(layoutDocument)}</layout>`
          )
        )
      },
      {
        name: "caption/caption.xml",
        data: new TextEncoder().encode(
          ffpxXmlDocument(
            "fastFigureCaption",
            PACKAGE_FORMAT_VERSION,
            `<caption>${ffpxXmlValue(captionDocument)}</caption>`
          )
        )
      },
      {
        name: "labels/labels.xml",
        data: new TextEncoder().encode(
          ffpxXmlDocument(
            "fastFigureLabels",
            PACKAGE_FORMAT_VERSION,
            `<labels>${ffpxXmlValue(labelDocument)}</labels>`
          )
        )
      },
      ...slotDocuments.map((document2) => ({
        name: `slots/slot-${document2.slot.id}.xml`,
        data: new TextEncoder().encode(
          ffpxXmlDocument(
            "fastFigureSlot",
            PACKAGE_FORMAT_VERSION,
            `<slot id="${document2.slot.id}" contentType="${ffpxXmlEscape(
              document2.slot.contentType
            )}"><settings>${ffpxXmlValue(document2.slot)}</settings><caption>${ffpxXmlValue(
              document2.caption
            )}</caption>${document2.chartState ? `<graph><settings>${ffpxXmlValue(
              document2.chartState
            )}</settings><graphObjects>${document2.graphObjects.map(
              (object, index) => `<graphObject index="${index}">${ffpxXmlValue(object)}</graphObject>`
            ).join("")}</graphObjects></graph>` : ""}${document2.imageObject ? `<imageObject${document2.imageObject.imageRef === null ? "" : ` imageRef="${document2.imageObject.imageRef}"`}>${ffpxXmlValue(
              document2.imageObject
            )}</imageObject>` : ""}</slot>`
          )
        )
      })),
      ...assets
    ]
  };
}
async function ffpxReadProject(file) {
  return ffpxReadProjectBytes(new Uint8Array(await file.arrayBuffer()));
}
function ffpxReadProjectBytes(bytes) {
  let assets = ffpxZipRead(bytes), xmlBytes = assets.get("project.xml");
  if (!xmlBytes) throw Error("FFPX project.xml이 없습니다.");
  let projectRoot = ffpxReadXmlDocument(
    assets,
    "project.xml",
    "fastFigureProject"
  ), project = ffpxNamedValue(projectRoot, "settings");
  if (project?.schema !== "fast-figure-project" || project.version !== PACKAGE_FORMAT_VERSION)
    throw Error("지원하지 않는 FFPX 프로젝트 형식입니다.");
  let assetRoot = ffpxReadXmlDocument(
    assets,
    "assets/assets.xml",
    "fastFigureAssets"
  ), layoutRoot = ffpxReadXmlDocument(
    assets,
    "layout/layout.xml",
    "fastFigureLayout"
  ), captionRoot = ffpxReadXmlDocument(
    assets,
    "caption/caption.xml",
    "fastFigureCaption"
  ), labelRoot = ffpxReadXmlDocument(
    assets,
    "labels/labels.xml",
    "fastFigureLabels"
  ), layout2 = ffpxNamedValue(layoutRoot, "layout"), caption = ffpxNamedValue(captionRoot, "caption"), labels = ffpxNamedValue(labelRoot, "labels"), csvFiles = [...ffpxDirectChild(assetRoot, "dataAssets").children].filter((node) => node.tagName === "dataAsset").map(ffpxWrappedValue), images = [...ffpxDirectChild(assetRoot, "imageAssets").children].filter((node) => node.tagName === "imageAsset").map(ffpxWrappedValue), charts = [], slots = [];
  for (let placement of layout2.placements || []) {
    let slotRoot = ffpxReadXmlDocument(
      assets,
      `slots/slot-${placement.slotId}.xml`,
      "fastFigureSlot"
    ), slotNode = ffpxDirectChild(slotRoot, "slot"), slotSettings = ffpxNamedValue(slotNode, "settings"), slotCaption = ffpxNamedValue(slotNode, "caption"), graphNode = ffpxDirectChild(slotNode, "graph", true), imageNode = ffpxDirectChild(slotNode, "imageObject", true), chart = graphNode ? ffpxNamedValue(graphNode, "settings") : null;
    if (chart) {
      chart.editor.objects = [...ffpxDirectChild(graphNode, "graphObjects").children].filter((node) => node.tagName === "graphObject").map(ffpxWrappedValue);
      charts.push(chart);
    }
    let imageObject = imageNode ? ffpxWrappedValue(imageNode) : null;
    slots.push({
      ...slotSettings,
      ...placement,
      id: placement.slotId,
      chart: chart?.id ?? null,
      imageId: imageObject?.imageRef ?? null,
      ...imageObject && Object.hasOwn(imageObject, "settings") ? { imageSettings: projectClone(imageObject.settings) } : {},
      caption: slotCaption.text
    });
  }
  slots = ffpxDeriveHiddenSlots(slots);
  let appearance = project.appearance && typeof project.appearance === "object" ? project.appearance : {};
  let payload = {
    ...project,
    schema: "fast-figure-project",
    version: PACKAGE_FORMAT_VERSION,
    gridRows: layout2.gridRows,
    gridCols: layout2.gridCols,
    slotStyle: appearance.slotStyle,
    uiPalette: appearance.uiPalette,
    csvFiles,
    images,
    charts,
    slots,
    annotations: {
      labelsEnabled: labels.enabled,
      labelSettings: labels.settings,
      captionsEnabled: caption.enabled,
      captionText: caption.beforeText,
      captionAfterText: caption.afterText,
      captionName: caption.name,
      captionNameBold: caption.nameBold,
      captionSettings: caption.settings
    }
  };
  if (payload?.schema !== "fast-figure-project" || payload.version !== PACKAGE_FORMAT_VERSION || !Array.isArray(payload.charts) || !Array.isArray(payload.slots))
    throw Error("지원하지 않는 FFPX 프로젝트 형식입니다.");
  if (!Array.isArray(payload.csvFiles)) throw Error("FFPX CSV 목록이 없습니다.");
  for (let csv of payload.csvFiles) {
    let dataRef = csv?.dataRef;
    if (!csv || !Number.isInteger(csv.id) || typeof csv.name !== "string" || typeof dataRef !== "string" || !dataRef.startsWith("assets/data/") || !assets.has(dataRef))
      throw Error("FFPX CSV 자산이 없습니다.");
    csv.rows = parseProjectCsvAsset(csv.name, assets.get(dataRef));
    csv.headerLines = headerLineCount(Object.hasOwn(csv, "headerLines") ? csv.headerLines : 1, csv.rows);
    csv.bytesBase64 = ffpxBytesToBase64(assets.get(dataRef));
    delete csv.dataRef;
  }
  if (!Array.isArray(payload.images)) throw Error("FFPX 이미지 목록이 없습니다.");
  for (let image of payload.images) {
    let dataRef = image?.dataRef;
    if (!image || !Number.isInteger(image.id) || typeof image.name !== "string" || typeof dataRef !== "string" || !dataRef.startsWith("assets/media/") || !assets.has(dataRef))
      throw Error("FFPX 이미지 자산이 없습니다.");
    image.bytesBase64 = ffpxBytesToBase64(assets.get(dataRef));
    delete image.dataRef;
  }
  if (!payload.fileSystem || !Array.isArray(payload.fileSystem.directories))
    throw Error("FFPX 폴더 목록이 없습니다.");
  for (const path of PROJECT_FIXED_DIRECTORIES)
    if (!payload.fileSystem.directories.includes(path)) payload.fileSystem.directories.push(path);
  if (!Object.hasOwn(payload, "export")) {
    payload.export = projectClone(BackendSettings.project_object.export);
    payload.export.width = payload.slotStyle?.referenceWidth ?? BackendSettings.project_object.layout.slotStyle.referenceWidth;
    payload.export.height = payload.export.heightMode === "auto" ? null : BackendSettings.defaults.limits.export.logicalHeight[0];
  }
  const captionState = {};
  for (const [source, target] of [
    ["enabled", "enabled"],
    ["beforeText", "text"],
    ["afterText", "afterText"],
    ["name", "name"],
    ["nameBold", "nameBold"],
    ["settings", "settings"]
  ])
    if (Object.hasOwn(caption, source)) captionState[target] = projectClone(caption[source]);
  const decoded = {
    schema: project.schema,
    version: project.version,
    kind: "fast-figure-project-object",
    meta: { projectName: project.projectName, appBuild: project.appBuild },
    layout: { gridRows: layout2.gridRows, gridCols: layout2.gridCols },
    annotations: { labels: projectClone(labels), captions: captionState },
    fileSystem: payload.fileSystem,
    assets: { csvFiles: payload.csvFiles, images: payload.images },
    charts,
    slots: slots.map((slot) => ({
      id: slot.id,
      row: slot.row,
      col: slot.col,
      rowSpan: slot.rowSpan,
      colSpan: slot.colSpan,
      hidden: slot.hidden,
      caption: slot.caption,
      content: {
        contentType: slot.contentType,
        chart: slot.chart,
        imageId: slot.imageId,
        ...Object.hasOwn(slot, "imageSettings") ? { imageSettings: slot.imageSettings } : {}
      }
    })),
    appearance: {},
    export: payload.export
  };
  if (Object.hasOwn(appearance, "slotStyle")) decoded.layout.slotStyle = projectClone(appearance.slotStyle);
  if (Object.hasOwn(appearance, "uiPalette")) decoded.appearance.uiPalette = projectClone(appearance.uiPalette);
  return decoded;
}
function projectFileStem(value2) {
  let stem = String(value2 || "").trim().replace(/[\\/:*?"<>|\x00-\x1F]/g, "-").replace(/\s+/g, " ").replace(/[. ]+$/, "").slice(0, BackendSettings.defaults.naming.exportStemMaxLength);
  return stem || "fast-figure-project";
}
function slotFileKind(file) {
  let name = String(file?.name || "").toLowerCase(), type = String(file?.type || "").toLowerCase();
  if (name.endsWith(".ffsx")) return "slot";
  if (name.endsWith(".csv") || name.endsWith(".tsv") || name.endsWith(".json")) return "data";
  if (type.startsWith("image/") || /\.(png|jpe?g|gif|webp|bmp|svg)$/i.test(name))
    return "image";
  return "";
}
function movableProjectNode(path, state = activeProject._state) {
  let match = path ? projectVfs.resolve(path, state) : null;
  if (!match) return false;
  if (match.kind === "directory") return !projectVfs.isFixedDirectory(path);
  return true;
}
function projectNodeReferenceCount(path, state = activeProject._state) {
  let match = projectVfs.resolve(path, state);
  if (!match) return 0;
  let movingAssets = match.kind === "directory" ? projectVfs.descendants(path, state) : [{ kind: match.kind, asset: match.asset }];
  return projectAssetReferenceCount(
    new Set(movingAssets.filter(({ kind }) => kind === "csv").map(({ asset }) => asset.id)),
    new Set(movingAssets.filter(({ kind }) => kind === "image").map(({ asset }) => asset.id)),
    state
  );
}
function planProjectNodeMove(path, directory, state = activeProject._state) {
  const match = projectVfs.resolve(path, state);
  if (!match || !movableProjectNode(path, state)) throw Error("이동할 수 없는 프로젝트 항목입니다.");
  const source = match.kind === "directory" ? match.path : projectAssetPath(match.asset), targetDirectory = normalizeProjectPath(directory, { directory: true });
  if (!state.fileSystem.directories.includes(targetDirectory)) throw Error("대상 폴더가 없습니다.");
  if (match.kind === "directory" && projectPathInDirectory(targetDirectory, source))
    throw Error("폴더를 자기 자신 또는 하위 폴더로 이동할 수 없습니다.");
  const destination = normalizeProjectPath(
    `${targetDirectory}/${projectPathName(source)}`,
    { directory: match.kind === "directory" }
  );
  if (destination === source) return null;
  const collision = projectVfs.exists(destination, state), uniquePath = collision ? projectVfs.uniquePath(targetDirectory, projectPathName(source), state) : destination, enteringTrash = projectVfs.isTrashed(destination) && !projectVfs.isTrashed(source);
  return immutableProjectCopy({
    path: source,
    kind: match.kind,
    directory: targetDirectory,
    destination,
    collision,
    uniqueName: projectPathName(uniquePath),
    enteringTrash,
    referenceCount: projectNodeReferenceCount(source, state)
  });
}
function ffsxBuildSlot(slot, chart, source = activeProject._state) {
  validateChartModel(chart, "FFSX 차트", source.assets.csvFiles);
  let copy = chartExportCopy(chart), referenced = chartCsvIds(chart).map((id) => {
    let csv = getProjectCsv(id, source.assets.csvFiles);
    if (!csv) throw Error(`FFSX가 참조하는 CSV ${id}가 없습니다.`);
    return csv;
  }), slotIds = new Map(referenced.map((csv, index) => [csv.id, index + 1])), packaged = referenced.map((source2) => {
    let csv = projectClone(source2);
    csv.id = slotIds.get(source2.id);
    delete csv.rows;
    delete csv.bytesBase64;
    delete csv.directory;
    csv.dataRef = `assets/${projectCsvDataRef(csv)}`;
    return csv;
  });
  delete copy.id;
  if (!chartUsesConversionView(copy)) copy.editor.objects.forEach((object) => {
    object.csvId = slotIds.get(object.csvId);
  });
  let manifest = {
    schema: "fast-figure-slot",
    version: PACKAGE_FORMAT_VERSION,
    appBuild: source.meta.appBuild,
    exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
    slot: {
      contentType: "graph",
      caption: typeof slot.caption === "string" ? slot.caption : null
    },
    chart: copy,
    csvFiles: packaged
  };
  let graphObjects = projectClone(manifest.chart.editor?.objects || []), chartState = {
    ...projectClone(manifest.chart),
    editor: {
      ...projectClone(manifest.chart.editor || {}),
      objects: []
    }
  }, refs = '<assets ref="assets/assets.xml"/>';
  return {
    manifest,
    assets: [
      {
        name: "slot.xml",
        data: new TextEncoder().encode(
          ffpxXmlDocument(
            "fastFigureSlot",
            PACKAGE_FORMAT_VERSION,
            `${refs}<slot contentType="graph"><settings>${ffpxXmlValue(
              { ...manifest.slot, appBuild: manifest.appBuild }
            )}</settings><caption>${ffpxXmlValue({
              text: manifest.slot.caption
            })}</caption><graph><settings>${ffpxXmlValue(
              chartState
            )}</settings><graphObjects>${graphObjects.map(
              (object, index) => `<graphObject index="${index}">${ffpxXmlValue(object)}</graphObject>`
            ).join("")}</graphObjects></graph></slot>`
          )
        )
      },
      {
        name: "assets/assets.xml",
        data: new TextEncoder().encode(
          ffpxXmlDocument(
            "fastFigureAssets",
            PACKAGE_FORMAT_VERSION,
            `<dataAssets>${manifest.csvFiles.map(
              (csv) => `<dataAsset id="${csv.id}" src="${ffpxXmlEscape(csv.dataRef)}">${ffpxXmlValue(csv)}</dataAsset>`
            ).join("")}</dataAssets>`
          )
        )
      },
      ...referenced.map((csv, index) => ({
        name: `assets/${projectCsvDataRef({ ...csv, id: index + 1 })}`,
        data: ffpxBase64ToBytes(csv.bytesBase64)
      }))
    ]
  };
}
async function ffsxReadSlot(file) {
  return ffsxReadSlotBytes(new Uint8Array(await file.arrayBuffer()));
}
function ffsxReadSlotBytes(bytes) {
  let assets = ffpxZipRead(new Uint8Array(bytes)), xmlBytes = assets.get("slot.xml");
  if (!xmlBytes) throw Error("FFSX slot.xml이 없습니다.");
  let slotRoot = ffpxReadXmlDocument(assets, "slot.xml", "fastFigureSlot"), slotNode = ffpxDirectChild(slotRoot, "slot"), slot = ffpxNamedValue(slotNode, "settings"), caption = ffpxNamedValue(slotNode, "caption"), graphNode = ffpxDirectChild(slotNode, "graph"), chart = ffpxNamedValue(graphNode, "settings"), assetRoot = ffpxReadXmlDocument(
    assets,
    "assets/assets.xml",
    "fastFigureAssets"
  );
  if (slot?.contentType !== "graph") throw Error("FFSX graph 슬롯이 필요합니다.");
  delete chart.id;
  delete slot.appBuild;
  chart.editor.objects = [...ffpxDirectChild(graphNode, "graphObjects").children].filter((node) => node.tagName === "graphObject").map(ffpxWrappedValue);
  let payload = {
    schema: "fast-figure-slot",
    version: PACKAGE_FORMAT_VERSION,
    slot: {
      ...slot,
      caption: caption.text
    },
    chart,
    csvFiles: [...ffpxDirectChild(assetRoot, "dataAssets").children].filter((node) => node.tagName === "dataAsset").map(ffpxWrappedValue)
  };
  if (payload?.schema !== "fast-figure-slot" || payload.version !== PACKAGE_FORMAT_VERSION || !payload.chart || typeof payload.chart !== "object")
    throw Error("지원하지 않는 FFSX 슬롯 형식입니다.");
  if (!Array.isArray(payload.csvFiles))
    throw Error("FFSX CSV 목록이 올바르지 않습니다.");
  let slotCsvIds = /* @__PURE__ */ new Set();
  for (let csv of payload.csvFiles) {
    let dataRef = csv?.dataRef, data = typeof dataRef === "string" ? assets.get(dataRef) : null;
    if (!csv || typeof csv.name !== "string" || typeof dataRef !== "string" || !dataRef.startsWith("assets/data/") || !data)
      throw Error("FFSX 슬롯 CSV 자산이 없습니다.");
    if (!Number.isInteger(csv.id) || csv.id < 1 || slotCsvIds.has(csv.id))
      throw Error("FFSX 슬롯 내부 CSV ID가 올바르지 않습니다.");
    slotCsvIds.add(csv.id);
    csv.rows = parseProjectCsvAsset(csv.name, data);
    csv.headerLines = headerLineCount(Object.hasOwn(csv, "headerLines") ? csv.headerLines : 1, csv.rows);
    csv.bytesBase64 = ffpxBytesToBase64(data);
    delete csv.dataRef;
  }
  validateChartModel(chart, "FFSX 차트", payload.csvFiles);
  return payload;
}

// sourcecode/backend/project_efsm.js
function calculateProjectionEffect(event, pre, post) {
  const visualFacts = (source) => {
    const render = {
      layout: source.layout,
      annotations: source.annotations,
      appearance: source.appearance,
      slots: [],
      charts: [],
      csv: [],
      images: []
    }, references = /* @__PURE__ */ new Map(), reference = (parts) => {
      const key = JSON.stringify(parts);
      references.set(key, (references.get(key) || 0) + 1);
    };
    for (const slot of source.slots) {
      if (slot.hidden) continue;
      reference(["slot", slot.id]);
      render.slots.push(slot);
      if (slot.content.contentType === "graph" && slot.content.chart != null) {
        const chart = source.charts.find((chart2) => chart2.id === slot.content.chart);
        if (!chart) throw Error("화면 commit fact의 chart reference가 없습니다.");
        reference(["chart", slot.id, chart.id]);
        render.charts.push(chart);
        if (!chartUsesConversionView(chart)) for (const object of chart.editor.objects) {
          const csv = source.assets.csvFiles.find((csv2) => csv2.id === object.csvId);
          if (!csv) throw Error("화면 commit fact의 CSV reference가 없습니다.");
          reference(["csv", chart.id, csv.id]);
          render.csv.push({ id: csv.id, rows: csv.rows, headerLines: csv.headerLines });
        }
      } else if (slot.content.contentType === "image" && slot.content.imageId != null) {
        const image = source.assets.images.find((image2) => image2.id === slot.content.imageId);
        if (!image) throw Error("화면 commit fact의 image reference가 없습니다.");
        reference(["image", slot.id, image.id]);
        render.images.push({ id: image.id, bytesBase64: image.bytesBase64, mime: image.mime });
      }
    }
    return { render, references };
  }, before = visualFacts(pre), after = visualFacts(post), canonical = (value2) => Array.isArray(value2) ? value2.map(canonical) : value2 && typeof value2 === "object" ? Object.fromEntries(Object.keys(value2).sort().map((key) => [key, canonical(value2[key])])) : value2, tree = [
    "PROJECT_NAME_CHANGED",
    "PROJECT_DIRECTORY_CREATED",
    "PROJECT_NODE_MOVED",
    "PROJECT_TRASH_EMPTIED",
    "ASSETS_IMPORTED",
    "DATA_OBJECT_CREATED",
    "DATA_OBJECT_REPLACED",
    "DATA_OBJECT_DELETED",
    "IMAGE_OBJECT_CREATED",
    "IMAGE_OBJECT_REPLACED",
    "IMAGE_OBJECT_DELETED"
  ];
  return Object.freeze({
    referencesRemoved: [...before.references].some(([key, count]) => count > (after.references.get(key) || 0)),
    pathOnly: tree.includes(event) && JSON.stringify(canonical(before.render)) === JSON.stringify(canonical(after.render))
  });
}
function commitProjectCandidate(candidate, event, payload) {
  const pre = activeProject._state;
  activeProject.initialize(candidate);
  payload.projectionEffect = calculateProjectionEffect(event, pre, activeProject._state);
  payload.commitFacts = { pre, post: activeProject._state };
}
function commitValueKey(value2) {
  if (Array.isArray(value2)) return JSON.stringify(value2.map((item) => JSON.parse(commitValueKey(item))));
  if (value2 && typeof value2 === "object") return JSON.stringify(Object.fromEntries(
    Object.keys(value2).sort().map((key) => [key, JSON.parse(commitValueKey(value2[key]))])
  ));
  return JSON.stringify(value2 === void 0 ? null : value2);
}
function actualChanged(payload) {
  const { pre, post } = payload.commitFacts, ids = (before, after) => [...new Set([...before, ...after].map((item) => item.id))].filter((id) => commitValueKey(before.find((item) => item.id === id)) !== commitValueKey(after.find((item) => item.id === id))), changed = {
    ...payload.changed,
    slotIds: ids(pre.slots, post.slots),
    chartIds: ids(pre.charts, post.charts),
    csvIds: ids(pre.assets.csvFiles, post.assets.csvFiles),
    imageIds: ids(pre.assets.images, post.assets.images),
    assets: []
  };
  for (const fact of payload.changed?.assets || []) {
    const collection = fact.kind === "csv" ? "csvFiles" : "images", source = fact.role === "deleted" ? pre : post, asset = source.assets[collection].find((item) => item.id === fact.id);
    if (!asset || projectAssetPath(asset) !== fact.path) throw Error("commit 결과의 asset identity/path가 일치하지 않습니다.");
    if (fact.role === "deleted") {
      changed.assets.push({ ...fact });
      continue;
    }
    const owners = fact.kind === "csv" ? post.charts.filter((chart) => !chartUsesConversionView(chart) && chart.editor.objects.some((object) => object.csvId === asset.id)).map((chart) => {
      const slot = resolveOwningSlot(chart.id, post);
      if (!slot) throw Error("commit 결과 asset의 chart owner가 없습니다.");
      return { slotId: slot.id, chartId: chart.id };
    }) : post.slots.filter((slot) => slot.content.imageId === asset.id).map((slot) => ({ slotId: slot.id, chartId: null }));
    changed.assets.push({ ...fact, id: asset.id, path: projectAssetPath(asset), owners });
  }
  return changed;
}
function removedReferenceCounts(pre, post) {
  const references = (state) => {
    const counts = /* @__PURE__ */ new Map();
    for (const ref of collectAssetReferences(
      new Set(state.assets.csvFiles.map((csv) => csv.id)),
      new Set(state.assets.images.map((image) => image.id)),
      state
    )) {
      const key = JSON.stringify([ref.kind, ref.kind === "csv" ? ref.chartId : ref.slotId, ref.assetId]);
      const entry = counts.get(key) ?? { kind: ref.kind, count: 0 };
      entry.count++;
      counts.set(key, entry);
    }
    return counts;
  }, before = references(pre), after = references(post), result = { removedGraphReferenceCount: 0, resetImageSlotCount: 0 };
  for (const [key, entry] of before) {
    const removed = Math.max(0, entry.count - (after.get(key)?.count ?? 0));
    result[entry.kind === "csv" ? "removedGraphReferenceCount" : "resetImageSlotCount"] += removed;
  }
  return result;
}
var ProjectStateMachine = class {
  constructor(objects, actions) {
    this.objects = objects;
    this.actions = actions;
    this.writeLocks = /* @__PURE__ */ new Set();
  }
  assertWritable(scope, event) {
    if (this.writeLocks.has(scope))
      throw Error(`${event} 전이 중 잠긴 ${scope} 프로젝트 범위를 수정할 수 없습니다.`);
  }
  send(event, payload = {}) {
    const action = Object.hasOwn(PROJECT_COMMAND_ACTIONS, event) && this.actions[event];
    if (!action) throw Error(`${event}는 등록된 ProjectObject command가 아닙니다.`);
    if (!payload || typeof payload !== "object" || Array.isArray(payload) || ["project", "candidate", "model", "objects"].some((key) => Object.hasOwn(payload, key)))
      throw Error("Project command는 identity와 새 입력만 받습니다.");
    const input = { ...payload };
    for (const key of [
      "changed",
      "selectionHints",
      "projectionEffect",
      "commitFacts",
      "removedGraphReferenceCount",
      "resetImageSlotCount"
    ]) delete input[key];
    const outcome = action({ machine: this, event, payload: input }), committed = outcome !== false && !!input.commitFacts, changed = committed ? actualChanged(input) : {}, counts = committed ? removedReferenceCounts(input.commitFacts.pre, input.commitFacts.post) : { removedGraphReferenceCount: 0, resetImageSlotCount: 0 };
    return immutableProjectCopy({
      event,
      committed,
      changed,
      ...counts,
      selectionHints: committed ? input.selectionHints || {} : {},
      projectionEffect: committed ? input.projectionEffect : null
    });
  }
};
function applySlotTypeAction({ machine, event, payload }) {
  machine.assertWritable("slots", "SLOT_TYPE_CHANGED");
  while (true) {
    const source = activeProject._state, current = source.slots.find((slot) => slot.id === payload.slotId && !slot.hidden);
    if (!Number.isInteger(payload.slotId) || !current) throw Error("콘텐츠 종류를 변경할 visible 슬롯이 없습니다.");
    const candidate = projectClone(source);
    normalizeSlotContents(candidate.slots);
    candidate.slots.find((slot) => slot.id === current.id).content.contentType = payload.contentType === "image" ? "image" : "graph";
    validateProjectObjectState(candidate, { requireSlots: true });
    if (activeProject._state !== source) continue;
    commitProjectCandidate(candidate, event, payload);
    const after = activeProject._state.slots.find((slot) => slot.id === current.id);
    payload.changed = {
      slotIds: JSON.stringify(current) === JSON.stringify(after) ? [] : [after.id],
      chartIds: [],
      csvIds: [],
      imageIds: [],
      assets: []
    };
    return;
  }
}
function applyCaptionTextAction({ machine, event, payload }) {
  machine.assertWritable("captions", "CAPTION_TEXT_INPUT");
  machine.assertWritable("slots", "CAPTION_TEXT_INPUT");
  while (true) {
    const source = activeProject._state, target = payload.target;
    if (target?.kind !== "global" && target?.kind !== "slot") throw Error("캡션 변경 대상이 올바르지 않습니다.");
    const slot = target.kind === "slot" ? source.slots.find((item) => item.id === target.id && !item.hidden) : null;
    if (target.kind === "slot" && (!Number.isInteger(target.id) || !slot)) throw Error("캡션을 변경할 visible 슬롯이 없습니다.");
    const text = String(payload.text ?? ""), candidate = projectClone(source);
    normalizeSlotContents(candidate.slots);
    for (const item of candidate.slots) {
      const original = source.slots.find((before) => before.id === item.id);
      if (original?.content) item.content = projectClone(original.content);
    }
    if (slot) candidate.slots.find((item) => item.id === slot.id).caption = text || null;
    else candidate.annotations.captions.text = text;
    validateProjectObjectState(candidate, { requireSlots: true });
    if (activeProject._state !== source) continue;
    commitProjectCandidate(candidate, event, payload);
    payload.changed = {
      slotIds: candidate.slots.filter((after) => JSON.stringify(source.slots.find((before) => before.id === after.id)) !== JSON.stringify(after)).map((item) => item.id),
      chartIds: [],
      csvIds: [],
      imageIds: [],
      assets: []
    };
    return;
  }
}
function applySlotCaptionsInsertedAction({ machine, event, payload }) {
  machine.assertWritable("captions", "SLOT_CAPTIONS_INSERTED");
  while (true) {
    const source = activeProject._state, candidate = projectClone(source);
    normalizeSlotContents(candidate.slots);
    for (const item of candidate.slots) {
      const original = source.slots.find((before) => before.id === item.id);
      if (original?.content) item.content = projectClone(original.content);
    }
    const text = insertSlotCaptions(candidate, payload.slotIds ?? null);
    if (text === candidate.annotations.captions.text) return false;
    candidate.annotations.captions.text = text;
    validateProjectObjectState(candidate, { requireSlots: true });
    if (activeProject._state !== source) continue;
    commitProjectCandidate(candidate, event, payload);
    payload.changed = { slotIds: [], chartIds: [], csvIds: [], imageIds: [], assets: [] };
    return;
  }
}
function applyDataObjectCreatedAction({ machine, event, payload }) {
  machine.assertWritable("data", "DATA_OBJECT_CREATED");
  machine.assertWritable("files", "DATA_OBJECT_CREATED");
  while (true) {
    const source = activeProject._state, candidate = projectClone(source), rows = projectClone(dataTable(payload.data)), requested = payload.path || `${PROJECT_ASSET_DIRECTORIES.csv}/${projectCsvName(payload.name)}`, normalized = normalizeProjectPath(requested), directory = projectParentPath(normalized);
    if (!source.fileSystem.directories.includes(directory)) throw Error("CSV 상위 directory가 없습니다.");
    const path = projectVfs.uniquePath(directory, projectPathName(normalized), source), id = payload.id == null ? source.nextId.csv : payload.id;
    if (!Number.isInteger(id) || id <= 0 || source.assets.csvFiles.some((csv2) => csv2.id === id))
      throw Error(`CSV ID ${id}가 올바르지 않거나 중복되었습니다.`);
    const original = payload.bytesBase64, bytesBase64 = original != null && original !== "" ? (ffpxBase64ToBytes(original), original) : ffpxBytesToBase64(serializeNewDataTable(rows, path)), csv = {
      id,
      rows,
      bytesBase64,
      mime: payload.mime || "text/csv",
      headerLines: headerLineCount(payload.headerLines, rows),
      directory: projectParentPath(path),
      name: projectPathName(path)
    };
    candidate.assets.csvFiles.push(csv);
    candidate.nextId.csv = Math.max(candidate.nextId.csv, id + 1);
    validateProjectObjectState(candidate, { requireSlots: true });
    if (activeProject._state !== source) continue;
    commitProjectCandidate(candidate, event, payload);
    const committed = activeProject._state.assets.csvFiles.find((item) => item.id === id);
    payload.changed = {
      slotIds: [],
      chartIds: [],
      csvIds: [id],
      imageIds: [],
      assets: [{ role: "created", kind: "csv", id, path: projectAssetPath(committed), owners: [] }]
    };
    return;
  }
}
function applyAssetObjectReplacedAction({ machine, event, payload }, kind) {
  const image = kind === "image", collection = image ? "images" : "csvFiles";
  machine.assertWritable(image ? "images" : "data", event);
  machine.assertWritable("files", event);
  if (!image) machine.assertWritable("charts", event);
  while (true) {
    const source = activeProject._state, previous = source.assets[collection].find((item) => item.id === payload.id);
    if (!previous || Object.hasOwn(payload, "path") && projectAssetPath(previous) !== payload.path)
      throw Error("교체할 asset의 현재 id/path가 요청과 다릅니다.");
    const candidate = projectClone(source), next = candidate.assets[collection].find((item) => item.id === previous.id);
    if (image) {
      const bytes = typeof payload.bytes === "string" ? ffpxBase64ToBytes(payload.bytes) : new Uint8Array(payload.bytes || []);
      if (!bytes.length) throw Error("이미지 데이터가 비어 있습니다.");
      next.bytesBase64 = ffpxBytesToBase64(bytes);
    } else {
      next.rows = projectClone(dataTable(payload.data));
      next.headerLines = headerLineCount(Object.hasOwn(payload, "headerLines") ? payload.headerLines : previous.headerLines, next.rows);
      next.bytesBase64 = payload.bytesBase64 != null && payload.bytesBase64 !== "" ? (ffpxBase64ToBytes(payload.bytesBase64), payload.bytesBase64) : ffpxBytesToBase64(serializeNewDataTable(next.rows, projectAssetPath(previous)));
      for (const chart of candidate.charts)
        if (chart.editor.editable && chartCsvIds(chart).includes(next.id)) rebuildEditableGraph(chart, candidate);
    }
    if (Object.hasOwn(payload, "mime")) next.mime = payload.mime;
    validateProjectObjectState(candidate, { requireSlots: true });
    if (activeProject._state !== source) continue;
    commitProjectCandidate(candidate, event, payload);
    payload.changed = { assets: [{ role: "updated", kind, id: next.id, path: projectAssetPath(next) }] };
    return;
  }
}
function applyDataObjectReplacedAction(context) {
  const { machine, event, payload } = context;
  if (!Object.hasOwn(payload, "headerLines")) {
    applyAssetObjectReplacedAction(context, "csv");
    return;
  }
  machine.assertWritable("data", "DATA_OBJECT_REPLACED");
  machine.assertWritable("files", "DATA_OBJECT_REPLACED");
  machine.assertWritable("charts", "DATA_OBJECT_REPLACED");
  while (true) {
    const source = activeProject._state, current = source.assets.csvFiles.find((csv2) => csv2.id === payload.csvId);
    if (!current) throw Error("헤더를 변경할 프로젝트 CSV가 없습니다.");
    const candidate = projectClone(source), csv = candidate.assets.csvFiles.find((item) => item.id === current.id);
    csv.headerLines = headerLineCount(payload.headerLines, csv.rows);
    candidate.charts.forEach((chart) => {
      if (chart.editor?.editable !== false && chartCsvIds(chart).includes(csv.id))
        rebuildEditableGraph(chart, candidate);
    });
    validateProjectObjectState(candidate, { requireSlots: true });
    if (activeProject._state !== source) continue;
    commitProjectCandidate(candidate, event, payload);
    const post = activeProject._state, committed = post.assets.csvFiles.find((item) => item.id === current.id), changedIds = (before, after) => after.filter((item) => JSON.stringify(before.find((old) => old.id === item.id)) !== JSON.stringify(item)).map((item) => item.id), owners = post.charts.filter((chart) => chartCsvIds(chart).includes(committed.id)).map((chart) => ({
      chartId: chart.id,
      slotId: post.slots.find((slot) => (slot.content?.chart ?? slot.chart) === chart.id).id
    }));
    payload.changed = {
      slotIds: changedIds(source.slots, post.slots),
      chartIds: changedIds(source.charts, post.charts),
      csvIds: changedIds(source.assets.csvFiles, post.assets.csvFiles),
      imageIds: changedIds(source.assets.images, post.assets.images),
      assets: [{ role: "updated", kind: "csv", id: committed.id, path: projectAssetPath(committed), owners }]
    };
    return;
  }
}
function applyDataObjectDeletedAction(context) {
  return applyAssetObjectDeletedAction(context, "csv");
}
function applyAssetObjectDeletedAction({ machine, payload }, kind) {
  const event = kind === "csv" ? "DATA_OBJECT_DELETED" : "IMAGE_OBJECT_DELETED", target = payload.target;
  machine.assertWritable(kind === "csv" ? "data" : "images", event);
  machine.assertWritable("files", event);
  if (!target || target.kind !== kind || !Number.isInteger(target.id) || typeof target.path !== "string")
    throw Error("삭제할 asset의 kind/id/path reference가 올바르지 않습니다.");
  while (true) {
    const source = activeProject._state, node = projectVfs.resolve(target.path, source);
    if (!node) return false;
    if (node.kind !== kind || node.asset.id !== target.id || projectAssetPath(node.asset) !== target.path)
      throw Error("삭제할 asset의 현재 kind/id/path가 요청과 다릅니다.");
    const candidate = projectClone(source);
    candidate.slots.forEach((slot) => {
      const original = source.slots.find((item) => item.id === slot.id);
      if (original?.content) slot.content = projectClone(original.content);
    });
    const csvIds = new Set(kind === "csv" ? [target.id] : []), imageIds = new Set(kind === "image" ? [target.id] : []);
    if (collectAssetReferences(csvIds, imageIds, candidate).length) {
      for (const domain of ["charts", "slots", "editor"]) machine.assertWritable(domain, event);
    }
    const removedReferences = removeProjectAssetReferences(csvIds, imageIds, candidate), collection = kind === "csv" ? "csvFiles" : "images";
    candidate.assets[collection] = candidate.assets[collection].filter((item) => item.id !== target.id);
    validateProjectObjectState(candidate, { requireSlots: true });
    if (activeProject._state !== source) continue;
    commitProjectCandidate(candidate, event, payload);
    const post = activeProject._state, changedIds = (before, after) => [...new Set([...before, ...after].map((item) => item.id))].filter((id) => JSON.stringify(before.find((item) => item.id === id)) !== JSON.stringify(after.find((item) => item.id === id)));
    payload.changed = {
      slotIds: changedIds(source.slots, post.slots),
      chartIds: changedIds(source.charts, post.charts),
      csvIds: [...csvIds],
      imageIds: [...imageIds],
      ...removedReferences,
      assets: [{ role: "deleted", kind, id: target.id, path: target.path, name: node.asset.name }]
    };
    payload.selectionHints = immutableProjectCopy({ graphObjectIndexMaps: removedReferences.graphObjectIndexMaps });
    return;
  }
}
function applyImageObjectCreatedAction({ machine, event, payload }) {
  machine.assertWritable("images", "IMAGE_OBJECT_CREATED");
  machine.assertWritable("files", "IMAGE_OBJECT_CREATED");
  while (true) {
    const source = activeProject._state, candidate = projectClone(source), requested = payload.path || `${PROJECT_ASSET_DIRECTORIES.image}/${projectCsvName(payload.name, "image.bin")}`, normalized = normalizeProjectPath(requested), directory = projectParentPath(normalized);
    if (!source.fileSystem.directories.includes(directory)) throw Error("이미지 상위 directory가 없습니다.");
    const path = projectVfs.uniquePath(directory, projectPathName(normalized), source), id = payload.id == null ? source.nextId.image : payload.id;
    if (!Number.isInteger(id) || id <= 0 || source.assets.images.some((image2) => image2.id === id))
      throw Error(`이미지 ID ${id}가 올바르지 않거나 중복되었습니다.`);
    const input = payload.bytes, bytes = typeof input === "string" ? ffpxBase64ToBytes(input) : new Uint8Array(input || []);
    if (!bytes.length) throw Error("이미지 데이터가 비어 있습니다.");
    candidate.assets.images.push({
      id,
      name: projectPathName(path),
      directory: projectParentPath(path),
      mime: typeof payload.mime === "string" && payload.mime ? payload.mime : "application/octet-stream",
      bytesBase64: ffpxBytesToBase64(bytes)
    });
    candidate.nextId.image = Math.max(candidate.nextId.image, id + 1);
    validateProjectObjectState(candidate, { requireSlots: true });
    if (activeProject._state !== source) continue;
    commitProjectCandidate(candidate, event, payload);
    const image = activeProject._state.assets.images.find((item) => item.id === id);
    payload.changed = {
      slotIds: [],
      chartIds: [],
      csvIds: [],
      imageIds: [id],
      assets: [{ role: "created", kind: "image", id, path: projectAssetPath(image), owners: [] }]
    };
    return;
  }
}
function applyImageObjectReplacedAction(context) {
  applyAssetObjectReplacedAction(context, "image");
}
function applyImageObjectDeletedAction(context) {
  return applyAssetObjectDeletedAction(context, "image");
}
function applySlotsResetAction({ machine, event, payload }) {
  machine.assertWritable("slots", "SLOTS_RESET");
  machine.assertWritable("charts", "SLOTS_RESET");
  machine.assertWritable("workspace", "SLOTS_RESET");
  machine.assertWritable("editor", "SLOTS_RESET");
  while (true) {
    const source = activeProject._state;
    if (!Array.isArray(payload.slotIds) || payload.slotIds.some((id) => !Number.isInteger(id)))
      throw Error("초기화할 explicit 슬롯 ID가 올바르지 않습니다.");
    const ids = [...new Set(payload.slotIds)], targets = ids.map((id) => source.slots.find((slot) => slot.id === id && !slot.hidden));
    if (targets.some((slot) => !slot)) throw Error("초기화할 visible 슬롯이 없습니다.");
    const candidate = projectClone(source);
    normalizeSlotContents(candidate.slots);
    const chartIds = /* @__PURE__ */ new Set();
    for (const id of ids) {
      const slot = candidate.slots.find((slot2) => slot2.id === id);
      if (Number.isInteger(slot.chart)) chartIds.add(slot.chart);
      slot.content = { ...projectClone(BackendSettings.defaults.slotSettings.content), chart: null, imageId: null };
      slot.caption = null;
    }
    candidate.charts = candidate.charts.filter((chart) => !chartIds.has(chart.id));
    validateProjectObjectState(candidate, { requireSlots: true });
    if (activeProject._state !== source) continue;
    commitProjectCandidate(candidate, event, payload);
    const after = activeProject._state;
    payload.changed = {
      slotIds: ids.filter((id) => JSON.stringify(source.slots.find((slot) => slot.id === id)) !== JSON.stringify(after.slots.find((slot) => slot.id === id))),
      chartIds: source.charts.filter((chart) => !after.charts.some((next) => next.id === chart.id)).map((chart) => chart.id),
      csvIds: [],
      imageIds: [],
      assets: []
    };
    return;
  }
}
function applySlotsSwappedAction({ machine, event, payload }) {
  machine.assertWritable("slots", "SLOTS_SWAPPED");
  machine.assertWritable("workspace", "SLOTS_SWAPPED");
  machine.assertWritable("editor", "SLOTS_SWAPPED");
  while (true) {
    const source = activeProject._state, first = source.slots.find((slot) => slot.id === payload.sourceSlotId && !slot.hidden), second = source.slots.find((slot) => slot.id === payload.targetSlotId && !slot.hidden);
    if (!first || !second || first.id === second.id) return false;
    const candidate = projectClone(source);
    normalizeSlotContents(candidate.slots);
    for (const slot of candidate.slots) {
      const current = source.slots.find((item) => item.id === slot.id);
      if (current?.content) slot.content = projectClone(current.content);
    }
    const a = candidate.slots.find((slot) => slot.id === first.id), b = candidate.slots.find((slot) => slot.id === second.id), content = a.content, caption = a.caption;
    a.content = b.content;
    a.caption = b.caption;
    b.content = content;
    b.caption = caption;
    validateProjectObjectState(candidate, { requireSlots: true });
    if (activeProject._state !== source) continue;
    commitProjectCandidate(candidate, event, payload);
    const after = activeProject._state;
    const localKey = (slot) => JSON.stringify([slot.content, slot.caption]);
    payload.changed = { slotIds: [first.id, second.id].filter((id) => localKey(source.slots.find((slot) => slot.id === id)) !== localKey(after.slots.find((slot) => slot.id === id))), chartIds: [], csvIds: [], imageIds: [], assets: [] };
    payload.selectionHints = immutableProjectCopy({ swapSlotIds: [first.id, second.id] });
    return;
  }
}
function applySlotImageLinkedAction(context) {
  return applyProjectAssetConnectedAction(context, "image");
}
function applyProjectAssetConnectedAction({ machine, payload }, kind) {
  const event = kind === "csv" ? "SLOT_DATA_CONNECTED" : "SLOT_IMAGE_LINKED";
  machine.assertWritable("slots", event);
  if (kind === "csv") machine.assertWritable("charts", event);
  while (true) {
    const source = activeProject._state, slot = source.slots.find((item) => item.id === payload.slotId && !item.hidden), node = typeof payload.path === "string" ? projectVfs.resolve(payload.path, source) : null;
    if (payload.kind !== kind || node?.kind !== kind || projectVfs.isTrashed(payload.path) || !slot || slot.contentType !== (kind === "csv" ? "graph" : "image"))
      throw Error("연결할 현재 non-trash asset kind/path 또는 visible slot type이 올바르지 않습니다.");
    const candidate = projectClone(source);
    candidate.slots.forEach((item, index) => {
      item.content = projectClone(source.slots[index].content);
    });
    normalizeSlotContents(candidate.slots);
    const target = candidate.slots.find((item) => item.id === slot.id);
    let chart = null;
    if (kind === "image") target.imageId = node.asset.id;
    else {
      chart = candidate.charts.find((item) => item.id === target.chart);
      if (chart?.editor?.editable === false) throw Error("편집 가능한 graph slot이 필요합니다.");
      if (!chart) {
        chart = createChartModel({ id: candidate.nextId.chart++, editor: {
          title: node.asset.name,
          globalSettings: readGlobalSettings({ editor: {} }),
          plotlyExtensions: { layout: {}, config: {} },
          objects: []
        } });
        candidate.charts.push(chart);
        target.chart = chart.id;
      }
      chart.editor.objects.push(createCandidateBaseGraphObject(candidate.assets.csvFiles.find((item) => item.id === node.asset.id)));
      rebuildEditableGraph(chart, candidate);
    }
    validateProjectObjectState(candidate, { requireSlots: true });
    if (activeProject._state !== source) continue;
    commitProjectCandidate(candidate, event, payload);
    payload.changed = {
      slotIds: slot.chart !== target.chart || slot.imageId !== target.imageId ? [slot.id] : [],
      chartIds: chart ? [chart.id] : [],
      csvIds: [],
      imageIds: [],
      assets: []
    };
    return;
  }
}
function applyGraphFirstObjectAction({ machine, event, payload }) {
  machine.assertWritable("slots", "SLOT_DATA_CONNECTED");
  machine.assertWritable("charts", "SLOT_DATA_CONNECTED");
  machine.assertWritable("editor", "SLOT_DATA_CONNECTED");
  while (true) {
    const source = activeProject._state, slot = source.slots.find((item) => item.id === payload.slotId && !item.hidden), csv = source.assets.csvFiles.find((item) => item.id === payload.csvId);
    if (!slot || slot.contentType !== "graph" || !csv || (slot.content?.chart ?? slot.chart) != null)
      throw Error("첫 오브젝트의 현재 빈 graph 슬롯 또는 CSV가 없습니다.");
    const candidate = projectClone(source);
    normalizeSlotContents(candidate.slots);
    const target = candidate.slots.find((item) => item.id === slot.id), candidateCsv = candidate.assets.csvFiles.find((item) => item.id === csv.id), chart = createChartModel({ id: candidate.nextId.chart++, editor: {
      title: candidateCsv.name,
      globalSettings: readGlobalSettings({ editor: {} }),
      plotlyExtensions: { layout: {}, config: {} },
      objects: [createCandidateBaseGraphObject(candidateCsv)]
    } });
    candidate.charts.push(chart);
    target.chart = chart.id;
    rebuildEditableGraph(chart, candidate);
    validateProjectObjectState(candidate, { requireSlots: true });
    if (activeProject._state !== source) continue;
    commitProjectCandidate(candidate, event, payload);
    payload.changed = { slotIds: [slot.id], chartIds: [chart.id], csvIds: [], imageIds: [], assets: [] };
    payload.selectionHints = Object.freeze({ chartId: chart.id, selectedIndexHint: 0 });
    return;
  }
}
function applySlotDataConnectedAction(context) {
  if (context.payload.operation === "graphs.addObject") return applyGraphFirstObjectAction(context);
  return applyProjectAssetConnectedAction(context, "csv");
}
function applyGraphObjectEditAction({ machine, event, payload }) {
  machine.assertWritable("charts", "GRAPH_OBJECTS_REPLACED");
  const defaults = BackendSettings.defaults.chartSettings.editor.objectStyle, limits = BackendSettings.defaults.limits.graphObject, enums = {
    type: ["scatter", "markers", "lines+markers", "bar", "hidden"],
    xAxisSide: ["bottom", "top"],
    yAxisSide: ["left", "right"],
    lineDash: ["solid", "dot", "dash", "dashdot"],
    markerSymbol: ["circle", "square", "diamond", "cross", "x", "triangle-up", "triangle-down"]
  };
  if (!["graphs.setObjectValues", "graphs.moveObject", "graphs.deleteObject", "graphs.applyPalette", "graphs.addObject"].includes(payload.operation))
    throw Error("등록된 graph object operation이 아닙니다.");
  while (true) {
    const source = activeProject._state, operation = payload.operation, target = operation === "graphs.addObject" ? source.slots.find((slot) => slot.id === payload.slotId && !slot.hidden) : null, chartId = operation === "graphs.addObject" ? target?.content?.chart ?? target?.chart : payload.chartId, current = source.charts.find((chart2) => chart2.id === chartId), owners = source.slots.filter((slot) => (slot.content?.chart ?? slot.chart) === chartId), index = payload.index, values = payload.values || {};
    if (!current || owners.length !== 1 || owners[0].hidden || owners[0].contentType === "image" || current.editor?.editable === false)
      throw Error("변경할 현재 편집 가능 차트 또는 유일한 visible graph owner가 없습니다.");
    const validIndex = (value2) => Number.isInteger(value2) && value2 >= 0 && value2 < current.editor.objects.length;
    if (operation === "graphs.moveObject") {
      if (!validIndex(payload.from) || !validIndex(payload.to)) throw Error("이동할 현재 오브젝트 index가 없습니다.");
      if (payload.from === payload.to) return false;
    } else if (!["graphs.applyPalette", "graphs.addObject"].includes(operation) && !validIndex(index)) throw Error("변경할 현재 오브젝트 index가 없습니다.");
    const candidate = projectClone(source), chart = candidate.charts.find((item) => item.id === current.id);
    let selectedIndexHint = index;
    if (operation === "graphs.addObject") {
      const csv = candidate.assets.csvFiles.find((item) => item.id === payload.csvId);
      if (!csv) throw Error("추가할 현재 CSV가 없습니다.");
      chart.editor.objects.push(createCandidateBaseGraphObject(csv));
      selectedIndexHint = chart.editor.objects.length - 1;
    } else if (operation === "graphs.moveObject") {
      const moved = chart.editor.objects.splice(payload.from, 1)[0];
      chart.editor.objects.splice(payload.to, 0, moved);
      selectedIndexHint = payload.to;
    } else if (operation === "graphs.deleteObject") {
      chart.editor.objects.splice(index, 1);
      selectedIndexHint = null;
    } else if (operation === "graphs.applyPalette") {
      if (!Array.isArray(payload.colors) || !payload.colors.length) throw Error("적용할 non-empty 색상 배열이 없습니다.");
      const colors = [];
      for (const color of payload.colors) {
        if (typeof color !== "string" || !color.trim()) throw Error("팔레트 색상은 non-empty text여야 합니다.");
        colors.push(color.trim());
      }
      chart.editor.objects.forEach((object, position) => {
        object.color = colors[position % colors.length];
      });
    } else {
      const object = chart.editor.objects[index], requestedCsvId = Object.hasOwn(values, "csvId") ? values.csvId : null, csv = candidate.assets.csvFiles.find((item) => item.id === requestedCsvId) || candidate.assets.csvFiles.find((item) => item.id === object.csvId);
      if (!csv) throw Error("그래프 오브젝트에 연결할 현재 CSV가 없습니다.");
      const columns = new Set(columnDefinitions(csv.rows, csv.headerLines).map((column) => column.id)), selection = graphDataSelection(csv.rows, csv.headerLines);
      object.csvId = csv.id;
      for (const key of ["x", "y"]) {
        const value2 = Object.hasOwn(values, key) ? values[key] : void 0;
        object[key] = columns.has(value2) ? value2 : columns.has(object[key]) ? object[key] : selection[key];
      }
      for (const [key, value2] of Object.entries(defaults))
        if (!Object.hasOwn(object, key)) object[key] = projectClone(value2);
      for (const [key, allowed] of Object.entries(enums)) {
        if (Object.hasOwn(values, key)) {
          const value2 = values[key];
          if (allowed.includes(value2)) object[key] = value2;
        }
      }
      for (const [key, [min, max]] of Object.entries(limits)) {
        if (Object.hasOwn(values, key)) {
          const edit = values[key], value2 = ["number", "string"].includes(typeof edit) ? Number(edit) : NaN;
          if (Number.isFinite(value2)) object[key] = Math.max(min, Math.min(max, value2));
        }
      }
      if (Object.hasOwn(values, "color")) {
        const color = values.color;
        if (typeof color === "string" && color.length) object.color = color;
      }
      if (Object.hasOwn(values, "legendName")) {
        const legend = values.legendName;
        if (typeof legend === "string") object.legendName = legend;
      }
    }
    for (const item of chart.editor.objects) {
      for (const [key, value2] of Object.entries(defaults))
        if (!Object.hasOwn(item, key)) item[key] = projectClone(value2);
      for (const [key, allowed] of Object.entries(enums))
        if (!allowed.includes(item[key])) throw Error(`그래프 오브젝트 ${key} enum이 올바르지 않습니다.`);
      for (const [key, [min, max]] of Object.entries(limits))
        if (!Number.isFinite(item[key]) || item[key] < min || item[key] > max)
          throw Error(`그래프 오브젝트 ${key} 범위가 올바르지 않습니다.`);
    }
    validateChartModel(chart, "변경할 차트", candidate.assets.csvFiles);
    rebuildEditableGraph(chart, candidate);
    validateProjectObjectState(candidate, { requireSlots: true });
    if (activeProject._state !== source) continue;
    commitProjectCandidate(candidate, event, payload);
    const post = activeProject._state, changedIds = (before, after) => after.filter((item) => JSON.stringify(before.find((old) => old.id === item.id)) !== JSON.stringify(item)).map((item) => item.id);
    payload.changed = {
      slotIds: changedIds(source.slots, post.slots),
      chartIds: changedIds(source.charts, post.charts),
      csvIds: changedIds(source.assets.csvFiles, post.assets.csvFiles),
      imageIds: changedIds(source.assets.images, post.assets.images),
      assets: []
    };
    payload.selectionHints = Object.freeze(operation === "graphs.applyPalette" ? { chartId: current.id } : { chartId: current.id, selectedIndexHint });
    return;
  }
}
function applyGraphObjectsReplacedAction(context) {
  return applyGraphObjectEditAction(context);
}
function applyChartLayoutChangedAction({ machine, event, payload }) {
  machine.assertWritable("charts", "CHART_LAYOUT_CHANGED");
  machine.assertWritable("editor", "CHART_LAYOUT_CHANGED");
  while (true) {
    const source = activeProject._state, slot = source.slots.find((item) => item.id === payload.slotId && !item.hidden), chartId = slot?.content?.chart ?? slot?.chart, current = source.charts.find((item) => item.id === chartId), owners = source.slots.filter((item) => (item.content?.chart ?? item.chart) === chartId), values = payload.settings;
    if (!slot || slot.contentType === "image" || !current || current.id !== payload.chartId || owners.length !== 1)
      throw Error("전역 설정을 변경할 현재 owning chart가 없습니다.");
    if (!values || typeof values !== "object" || Array.isArray(values)) throw Error("적용할 그래프 설정이 없습니다.");
    const candidate = projectClone(source), chart = candidate.charts.find((item) => item.id === chartId), settings = projectClone(chart.editor.globalSettings || {}), edits = values.globalSettings;
    if (Object.hasOwn(values, "title")) chart.editor.title = String(values.title ?? "");
    const record = (value2) => value2 && typeof value2 === "object" && !Array.isArray(value2), applyAxis = (key, patch) => {
      if (!record(patch)) throw Error("axis settings는 record여야 합니다.");
      for (const field of Object.keys(settings.axes[key]))
        if (Object.hasOwn(patch, field)) settings.axes[key][field] = patch[field];
    };
    if (Object.hasOwn(values, "globalSettings")) {
      if (!record(edits)) throw Error("global settings는 record여야 합니다.");
      for (const key of ["showLegend", "showTitle", "showZeroLine", "graphFontFamily", "titleFontSize", "legendFontSize"])
        if (Object.hasOwn(edits, key)) settings[key] = edits[key];
      if (Object.hasOwn(edits, "axes")) {
        if (!record(edits.axes)) throw Error("axes는 record여야 합니다.");
        for (const key of ["xBottom", "xTop", "yLeft", "yRight"])
          if (Object.hasOwn(edits.axes, key)) applyAxis(key, edits.axes[key]);
      }
    }
    if (["xBottom", "xTop", "yLeft", "yRight"].includes(values.axisKey)) applyAxis(values.axisKey, values.axisValues);
    chart.editor.globalSettings = normalizeGraphLayoutSettings(settings);
    if (chart.editor.editable) rebuildEditableGraph(chart, candidate);
    validateProjectObjectState(candidate, { requireSlots: true });
    if (activeProject._state !== source) continue;
    commitProjectCandidate(candidate, event, payload);
    const after = activeProject._state;
    payload.changed = {
      slotIds: [],
      chartIds: after.charts.filter((item) => JSON.stringify(item) !== JSON.stringify(source.charts.find((before) => before.id === item.id))).map((item) => item.id),
      csvIds: [],
      imageIds: [],
      assets: []
    };
    return;
  }
}
function applyChartModelReplacedAction({ machine, event, payload }) {
  for (const target of ["charts", "editor", "data", "files"])
    machine.assertWritable(target, "CHART_MODEL_REPLACED");
  while (true) {
    const source = activeProject._state, owners = source.slots.filter((slot) => (slot.content?.chart ?? slot.chart) === payload.chartId), current = source.charts.find((chart2) => chart2.id === payload.chartId);
    if (!current || owners.length !== 1 || owners[0].hidden || owners[0].contentType === "image" || owners[0].id !== payload.slotId || typeof payload.editable !== "boolean")
      throw Error("편집 상태를 변경할 현재 차트 또는 유일한 graph owner가 없습니다.");
    const candidate = projectClone(source), chart = candidate.charts.find((item) => item.id === current.id);
    let created = null;
    if (payload.editable && chart.editor.editable === false && Object.hasOwn(chart.editor, "conversionRows")) {
      if (chart.editor.objects.length) {
        if (!Array.isArray(chart.editor.conversionRows) || !chart.editor.conversionRows.length || !chart.editor.conversionRows.every(Array.isArray))
          throw Error("Plotly 변환 데이터가 없어 편집 가능한 차트로 바꿀 수 없습니다.");
        created = buildProjectCsvModel(
          chart.editor.conversionRows,
          "Plotly JSON.csv",
          candidate.nextId.csv,
          "",
          "text/csv",
          1,
          candidate
        );
        projectVfs.prepare(created, "csv", candidate);
        candidate.assets.csvFiles.push(created);
        candidate.nextId.csv = created.id + 1;
        for (const object of chart.editor.objects) object.csvId = created.id;
      }
      delete chart.editor.conversionRows;
    }
    chart.editor.editable = payload.editable;
    validateChartModel(chart, "편집 상태 변경 차트", candidate.assets.csvFiles);
    if (chart.editor.editable) rebuildEditableGraph(chart, candidate);
    validateProjectObjectState(candidate, { requireSlots: true });
    if (activeProject._state !== source) continue;
    commitProjectCandidate(candidate, event, payload);
    const post = activeProject._state, changedIds = (before, after) => after.filter((item) => JSON.stringify(before.find((old) => old.id === item.id)) !== JSON.stringify(item)).map((item) => item.id);
    payload.changed = {
      slotIds: changedIds(source.slots, post.slots),
      chartIds: changedIds(source.charts, post.charts),
      csvIds: changedIds(source.assets.csvFiles, post.assets.csvFiles),
      imageIds: changedIds(source.assets.images, post.assets.images),
      assets: created ? [{
        role: "created",
        kind: "csv",
        id: created.id,
        path: projectAssetPath(created),
        owners: [{ slotId: owners[0].id, chartId: chart.id }]
      }] : []
    };
    return;
  }
}
function applyEmptyImageInsertedAction({ machine, event, payload }) {
  machine.assertWritable("slots", "SLOT_IMAGE_IMPORTED");
  machine.assertWritable("images", "SLOT_IMAGE_IMPORTED");
  machine.assertWritable("files", "SLOT_IMAGE_IMPORTED");
  machine.assertWritable("charts", "SLOT_IMAGE_IMPORTED");
  while (true) {
    const source = activeProject._state, current = source.slots.find((slot) => slot.id === payload.slotId && !slot.hidden);
    if (!current || (current.content?.contentType ?? current.contentType) !== "image")
      throw Error("빈 이미지를 삽입할 현재 visible image 슬롯이 없습니다.");
    const input = payload.operation === "images.insertEmpty" ? payload.imageInput : payload, bytes = typeof input?.bytes === "string" ? ffpxBase64ToBytes(input.bytes) : new Uint8Array(input?.bytes || []), directory = PROJECT_ASSET_DIRECTORIES.image;
    if (!bytes.length || !source.fileSystem.directories.includes(directory)) throw Error("이미지 데이터 또는 directory가 없습니다.");
    const path = projectVfs.uniquePath(directory, projectCsvName(input.name, "image.bin"), source), id = source.nextId.image;
    if (!Number.isInteger(id) || id <= 0 || source.assets.images.some((image2) => image2.id === id))
      throw Error("이미지 next-id가 올바르지 않습니다.");
    const candidate = projectClone(source);
    normalizeSlotContents(candidate.slots);
    for (const slot of candidate.slots) {
      const original = source.slots.find((item) => item.id === slot.id);
      if (original?.content) slot.content = projectClone(original.content);
    }
    candidate.assets.images.push({
      id,
      name: projectPathName(path),
      directory: projectParentPath(path),
      mime: typeof input.mime === "string" && input.mime ? input.mime : "application/octet-stream",
      bytesBase64: ffpxBytesToBase64(bytes)
    });
    candidate.nextId.image = id + 1;
    const target = candidate.slots.find((slot) => slot.id === current.id), removedChartId = target.content.chart;
    candidate.charts = candidate.charts.filter((chart) => chart.id !== removedChartId);
    target.content.chart = null;
    target.content.imageId = id;
    validateProjectObjectState(candidate, { requireSlots: true });
    if (activeProject._state !== source) continue;
    commitProjectCandidate(candidate, event, payload);
    const image = activeProject._state.assets.images.find((item) => item.id === id);
    payload.changed = {
      slotIds: [current.id],
      chartIds: Number.isInteger(removedChartId) ? [removedChartId] : [],
      csvIds: [],
      imageIds: [id],
      assets: [{ role: "created", kind: "image", id, path: projectAssetPath(image), owners: [{ slotId: current.id, chartId: null }] }]
    };
    return;
  }
}
function applySlotImageImportedAction(context) {
  return applyEmptyImageInsertedAction(context);
}
function applySlotChartImportedAction({ machine, event, payload }) {
  for (const scope of ["slots", "data", "charts", "files"])
    machine.assertWritable(scope, "SLOT_CHART_IMPORTED");
  while (true) {
    const source = activeProject._state, slot = source.slots.find((item) => item.id === payload.slotId && !item.hidden), file = payload.file;
    if (!Number.isInteger(payload.slotId) || !slot) throw Error("불러올 visible 슬롯이 없습니다.");
    if (!file || !(file.bytes instanceof Uint8Array)) throw Error("불러올 copied file bytes가 없습니다.");
    const bytes = new Uint8Array(file.bytes), packaged = bytes[0] === 80 && bytes[1] === 75, input = packaged ? ffsxReadSlotBytes(bytes) : JSON.parse(new TextDecoder().decode(bytes)), candidate = projectClone(source);
    normalizeSlotContents(candidate.slots);
    for (const target2 of candidate.slots) {
      const original = source.slots.find((item) => item.id === target2.id);
      if (original?.content) target2.content = projectClone(original.content);
    }
    if (!packaged && (!input || typeof input !== "object" || !Array.isArray(input.data) && !input.layout))
      throw Error("유효한 Plotly JSON이 아닙니다.");
    let chart = packaged ? projectClone(input.chart) : parsePlotlyToEditor(input, null);
    chart.editor.globalSettings = normalizeGlobalSettings(chart.editor.globalSettings);
    const csvIds = [], assets = [];
    if (packaged) {
      const mapping = /* @__PURE__ */ new Map();
      for (const localId of chartCsvIds(chart)) {
        const local = input.csvFiles.find((item) => item.id === localId);
        if (!local || typeof local.name !== "string" || !local.name || projectCsvName(local.name, "") !== local.name)
          throw Error("FFSX CSV 이름 또는 reference가 올바르지 않습니다.");
        const model = projectClone(local);
        model.id = candidate.nextId.csv++;
        model.bytesBase64 = ffpxBytesToBase64(ffpxBase64ToBytes(local.bytesBase64));
        projectVfs.assignLocation(
          model,
          projectVfs.uniquePath(PROJECT_ASSET_DIRECTORIES.csv, local.name, candidate)
        );
        candidate.assets.csvFiles.push(model);
        mapping.set(localId, model.id);
        csvIds.push(model.id);
        assets.push({
          role: "created",
          kind: "csv",
          id: model.id,
          path: projectAssetPath(model),
          owners: [{ slotId: slot.id, chartId: candidate.nextId.chart }]
        });
      }
      if (!chartUsesConversionView(chart))
        for (const object of chart.editor.objects) object.csvId = mapping.get(object.csvId);
    }
    chart.id = candidate.nextId.chart++;
    validateChartModel(chart, "불러온 슬롯 차트", candidate.assets.csvFiles);
    const target = candidate.slots.find((item) => item.id === slot.id), oldChartId = target.content.chart;
    if (oldChartId !== null && (!source.charts.some((item) => item.id === oldChartId) || source.slots.filter((item) => item.content.chart === oldChartId).length !== 1))
      throw Error("교체할 차트의 슬롯 소유권이 올바르지 않습니다.");
    candidate.charts = candidate.charts.filter((item) => item.id !== oldChartId);
    candidate.charts.push(chart);
    target.content.chart = chart.id;
    target.content.imageId = null;
    target.content.contentType = "graph";
    if (packaged) target.caption = input.slot.caption;
    validateProjectObjectState(candidate, { requireSlots: true });
    if (activeProject._state !== source) continue;
    commitProjectCandidate(candidate, event, payload);
    payload.changed = {
      slotIds: [slot.id],
      chartIds: [...new Set([oldChartId, chart.id].filter(Number.isInteger))],
      csvIds,
      imageIds: [],
      assets
    };
    return;
  }
}
function applyGridLayoutChangedAction({ machine, event, payload }) {
  machine.assertWritable("layout", "GRID_LAYOUT_CHANGED");
  machine.assertWritable("slots", "GRID_LAYOUT_CHANGED");
  while (true) {
    const source = activeProject._state, candidate = buildGridResizeInProject(source, payload.rows, payload.cols);
    if (activeProject._state !== source) continue;
    commitProjectCandidate(candidate, event, payload);
    return;
  }
}
function applyProjectDirectoryCreatedAction({ machine, event, payload }) {
  machine.assertWritable("files", "PROJECT_DIRECTORY_CREATED");
  while (true) {
    const source = activeProject._state, parent = normalizeProjectPath(payload.parent, { directory: true }), rawName = String(payload.name || "").trim(), name = projectCsvName(rawName, "");
    if (parent !== "/" && !source.fileSystem.directories.includes(parent))
      throw Error(`상위 폴더 ${parent}가 없습니다.`);
    if (!name || name !== rawName || /[\\/]/.test(rawName))
      throw Error("폴더 이름이 올바르지 않습니다.");
    const path = normalizeProjectPath(`${parent}/${name}`, { directory: true });
    if (projectVfs.exists(path, source)) throw Error(`${path}가 이미 존재합니다.`);
    const candidate = projectClone(source);
    candidate.fileSystem.directories.push(path);
    candidate.fileSystem.directories.sort();
    validateProjectObjectState(candidate, { requireSlots: true });
    if (activeProject._state !== source) continue;
    commitProjectCandidate(candidate, event, payload);
    const actual = projectVfs.resolve(path, activeProject._state);
    payload.changed = {
      slotIds: [],
      chartIds: [],
      csvIds: [],
      imageIds: [],
      assets: [],
      createdDirectoryPath: actual.path
    };
    return;
  }
}
function applyProjectTrashEmptiedAction({ machine, event, payload }) {
  machine.assertWritable("files", "PROJECT_TRASH_EMPTIED");
  machine.assertWritable("data", "PROJECT_TRASH_EMPTIED");
  machine.assertWritable("images", "PROJECT_TRASH_EMPTIED");
  while (true) {
    const source = activeProject._state, candidate = projectClone(source);
    candidate.slots.forEach((slot) => {
      const original = source.slots.find((item) => item.id === slot.id);
      if (original?.content) slot.content = projectClone(original.content);
    });
    const csvFiles = candidate.assets.csvFiles.filter((csv) => projectVfs.isTrashed(projectAssetPath(csv))), images = candidate.assets.images.filter((image) => projectVfs.isTrashed(projectAssetPath(image))), directories = candidate.fileSystem.directories.filter((path) => !projectVfs.isFixedDirectory(path) && projectVfs.isTrashed(path)), csvIds = new Set(csvFiles.map((csv) => csv.id)), imageIds = new Set(images.map((image) => image.id));
    if (collectAssetReferences(csvIds, imageIds, candidate).length) {
      machine.assertWritable("charts", "PROJECT_TRASH_EMPTIED");
      machine.assertWritable("slots", "PROJECT_TRASH_EMPTIED");
      machine.assertWritable("editor", "PROJECT_TRASH_EMPTIED");
    }
    const removedReferences = removeProjectAssetReferences(csvIds, imageIds, candidate);
    candidate.assets.csvFiles = candidate.assets.csvFiles.filter((csv) => !csvIds.has(csv.id));
    candidate.assets.images = candidate.assets.images.filter((image) => !imageIds.has(image.id));
    candidate.fileSystem.directories = candidate.fileSystem.directories.filter((path) => !directories.includes(path));
    validateProjectObjectState(candidate, { requireSlots: true });
    if (activeProject._state !== source) continue;
    commitProjectCandidate(candidate, event, payload);
    const post = activeProject._state, changedIds = (before, after) => [...new Set([...before, ...after].map((item) => item.id))].filter((id) => JSON.stringify(before.find((item) => item.id === id)) !== JSON.stringify(after.find((item) => item.id === id)));
    Object.assign(payload, removedReferences, {
      csvCount: csvFiles.length,
      imageCount: images.length,
      directoryCount: directories.length,
      removedReferenceCount: removedReferences.removedGraphReferenceCount + removedReferences.resetImageSlotCount
    });
    payload.changed = {
      slotIds: changedIds(source.slots, post.slots),
      chartIds: changedIds(source.charts, post.charts),
      csvIds: [...csvIds],
      imageIds: [...imageIds],
      assets: [],
      ...removedReferences,
      csvCount: csvFiles.length,
      imageCount: images.length,
      directoryCount: directories.length
    };
    payload.selectionHints = immutableProjectCopy({ graphObjectIndexMaps: removedReferences.graphObjectIndexMaps });
    return;
  }
}
function applyProjectNodeMovedAction({ machine, event, payload }) {
  machine.assertWritable("files", "PROJECT_NODE_MOVED");
  while (true) {
    const source = activeProject._state, plan = planProjectNodeMove(payload.path, payload.directory, source);
    if (!plan) return false;
    const candidate = projectClone(source);
    candidate.slots.forEach((slot) => {
      const original = source.slots.find((item) => item.id === slot.id);
      if (original?.content) slot.content = projectClone(original.content);
    });
    const match = projectVfs.resolve(plan.path, candidate), moving = match.kind === "directory" ? projectVfs.descendants(plan.path, candidate) : [match], csvIds = new Set(moving.filter((node) => node.kind === "csv").map((node) => node.asset.id)), imageIds = new Set(moving.filter((node) => node.kind === "image").map((node) => node.asset.id));
    if (csvIds.size) machine.assertWritable("data", "PROJECT_NODE_MOVED");
    if (imageIds.size) machine.assertWritable("images", "PROJECT_NODE_MOVED");
    let destination = plan.destination;
    if (projectVfs.exists(destination, candidate)) {
      if (!payload.useUniqueName) throw Error(`${destination}가 이미 존재합니다.`);
      destination = projectVfs.uniquePath(plan.directory, projectPathName(plan.path), candidate);
    }
    const enteringTrash = !projectVfs.isTrashed(plan.path) && projectVfs.isTrashed(destination);
    let removed = { removedGraphReferenceCount: 0, resetImageSlotCount: 0, graphObjectIndexMaps: [] };
    if (enteringTrash) {
      for (const domain of ["charts", "slots", "editor"]) machine.assertWritable(domain, "PROJECT_NODE_MOVED");
      removed = removeProjectAssetReferences(csvIds, imageIds, candidate);
    }
    const rewrite = (path) => `${destination}${path.slice(plan.path.length)}`;
    if (match.kind === "directory") {
      candidate.fileSystem.directories = candidate.fileSystem.directories.map((path) => projectPathInDirectory(path, plan.path) ? rewrite(path) : path).sort();
      moving.filter((node) => node.kind !== "directory").forEach(({ asset }) => {
        asset.directory = projectParentPath(rewrite(projectAssetPath(asset)));
      });
    } else {
      match.asset.directory = projectParentPath(destination);
      match.asset.name = projectPathName(destination);
    }
    validateProjectObjectState(candidate, { requireSlots: true });
    if (activeProject._state !== source) continue;
    commitProjectCandidate(candidate, event, payload);
    const post = activeProject._state, changedIds = (before, after) => [...new Set([...before, ...after].map((item) => item.id))].filter((id) => JSON.stringify(before.find((item) => item.id === id)) !== JSON.stringify(after.find((item) => item.id === id)));
    payload.changed = {
      slotIds: changedIds(source.slots, post.slots),
      chartIds: changedIds(source.charts, post.charts),
      csvIds: changedIds(source.assets.csvFiles, post.assets.csvFiles),
      imageIds: changedIds(source.assets.images, post.assets.images),
      movedPathFrom: plan.path,
      movedPathTo: destination,
      ...removed
    };
    payload.selectionHints = immutableProjectCopy({
      movedPathFrom: plan.path,
      movedPathTo: destination,
      enteringTrash,
      graphObjectIndexMaps: removed.graphObjectIndexMaps
    });
    return;
  }
}
function applyProjectNameChangedAction({ machine, event, payload }) {
  machine.assertWritable("project", "PROJECT_NAME_CHANGED");
  while (true) {
    const source = activeProject._state;
    let name = String(payload.value);
    if (payload.trim === true) name = name.trim();
    const candidate = projectClone(source);
    candidate.meta.projectName = name.slice(0, BackendSettings.defaults.naming.projectNameMaxLength);
    validateProjectObjectState(candidate, { requireSlots: true });
    if (activeProject._state !== source) continue;
    commitProjectCandidate(candidate, event, payload);
    const post = activeProject._state, changedIds = (before, after) => [...new Set([...before, ...after].map((item) => item.id))].filter((id) => JSON.stringify(before.find((item) => item.id === id)) !== JSON.stringify(after.find((item) => item.id === id)));
    payload.changed = {
      slotIds: changedIds(source.slots, post.slots),
      chartIds: changedIds(source.charts, post.charts),
      csvIds: changedIds(source.assets.csvFiles, post.assets.csvFiles),
      imageIds: changedIds(source.assets.images, post.assets.images),
      assets: []
    };
    return;
  }
}
function applyLabelSettingsChangedAction({ machine, event, payload }) {
  machine.assertWritable("labels", "LABEL_SETTINGS_CHANGED");
  while (true) {
    const source = activeProject._state, candidate = projectClone(source);
    if (Object.prototype.hasOwnProperty.call(payload, "enabled"))
      candidate.annotations.labels.enabled = payload.enabled === true;
    if (payload.settings && typeof payload.settings === "object") {
      const edits = payload.settings, settings = candidate.annotations.labels.settings;
      if (["lower-alpha", "upper-alpha", "decimal", "lower-roman", "upper-roman"].includes(edits.format))
        settings.format = edits.format;
      if (["row-major", "column-major"].includes(edits.order)) settings.order = edits.order;
      if (Object.prototype.hasOwnProperty.call(edits, "parentheses"))
        settings.parentheses = edits.parentheses === true;
      if (Object.prototype.hasOwnProperty.call(edits, "fontFamily"))
        settings.fontFamily = String(edits.fontFamily ?? "");
      if (Object.prototype.hasOwnProperty.call(edits, "fontSize")) {
        const number = Number(edits.fontSize);
        if (Number.isFinite(number))
          settings.fontSize = Math.max(BackendSettings.defaults.limits.labels.fontSizeMin, number);
      }
      for (const key of ["x", "y"]) {
        if (!Object.prototype.hasOwnProperty.call(edits, key)) continue;
        if (!Number.isFinite(edits[key])) throw Error("레이블 위치는 유한한 수여야 합니다.");
        settings[key] = edits[key];
      }
    }
    validateProjectObjectState(candidate, { requireSlots: true });
    if (activeProject._state !== source) continue;
    commitProjectCandidate(candidate, event, payload);
    return;
  }
}
function applyLabelPositionChangedAction({ machine, event, payload }) {
  machine.assertWritable("labels", "LABEL_POSITION_CHANGED");
  while (true) {
    const source = activeProject._state, candidate = projectClone(source), settings = candidate.annotations.labels.settings, defaults = BackendSettings.project_object.annotations.labels.settings, x = payload.reset === true ? defaults.x : payload.x, y = payload.reset === true ? defaults.y : payload.y;
    if (!Number.isFinite(x) || !Number.isFinite(y))
      throw Error("레이블 위치는 유한한 수여야 합니다.");
    settings.x = x;
    settings.y = y;
    validateProjectObjectState(candidate, { requireSlots: true });
    if (activeProject._state !== source) continue;
    commitProjectCandidate(candidate, event, payload);
    return;
  }
}
function applyAppearanceChangedAction({ machine, event, payload }) {
  machine.assertWritable("appearance", "APPEARANCE_CHANGED");
  while (true) {
    const source = activeProject._state, candidate = projectClone(source);
    candidate.appearance.uiPalette = Object.fromEntries(
      Object.entries(DEFAULT_UI_PALETTE).map(([key, fallback]) => {
        const value2 = payload.palette?.[key];
        return [key, typeof value2 === "string" && /^#[0-9a-f]{6}$/i.test(value2) ? value2 : fallback];
      })
    );
    validateProjectObjectState(candidate, { requireSlots: true });
    if (activeProject._state !== source) continue;
    commitProjectCandidate(candidate, event, payload);
    return;
  }
}
function applyExportSettingsChangedAction({ machine, event, payload }) {
  machine.assertWritable("export", "EXPORT_SETTINGS_CHANGED");
  while (true) {
    const source = activeProject._state, candidate = projectClone(source), current = source.export, next = { ...current }, values = payload.settings || {}, limits = BackendSettings.defaults.limits.export;
    normalizeSlotContents(candidate.slots);
    for (const slot of candidate.slots) {
      const original = source.slots.find((item) => item.id === slot.id);
      if (original?.content) slot.content = projectClone(original.content);
    }
    for (const [key, allowed] of [["heightMode", ["auto", "explicit"]], ["format", ["png", "jpeg"]]]) {
      if (!Object.prototype.hasOwnProperty.call(values, key)) continue;
      const value2 = values[key];
      if (allowed.includes(value2)) next[key] = value2;
    }
    for (const [key, limitKey] of [["width", "logicalWidth"], ["height", "logicalHeight"], ["dpi", "dpi"]]) {
      if (!Object.prototype.hasOwnProperty.call(values, key)) continue;
      const value2 = values[key];
      const number = value2 === null || typeof value2 === "object" ? NaN : Number(value2);
      if (Number.isFinite(number)) {
        const [min, max] = limits[limitKey];
        next[key] = Math.max(min, Math.min(max, number));
      }
    }
    next.height = next.heightMode === "auto" ? null : next.height ?? current.height ?? limits.logicalHeight[0];
    candidate.export = next;
    validateProjectObjectState(candidate, { requireSlots: true });
    if (activeProject._state !== source) continue;
    commitProjectCandidate(candidate, event, payload);
    const post = activeProject._state, changedIds = (before, after) => after.filter((item) => JSON.stringify(before.find((old) => old.id === item.id)) !== JSON.stringify(item)).map((item) => item.id);
    payload.changed = {
      slotIds: changedIds(source.slots, post.slots),
      chartIds: changedIds(source.charts, post.charts),
      csvIds: changedIds(source.assets.csvFiles, post.assets.csvFiles),
      imageIds: changedIds(source.assets.images, post.assets.images),
      assets: []
    };
    return;
  }
}
function applySlotImageSettingsChangedAction({ machine, event, payload }) {
  machine.assertWritable("slots", "SLOT_IMAGE_SETTINGS_CHANGED");
  while (true) {
    const source = activeProject._state, candidate = projectClone(source);
    normalizeSlotContents(candidate.slots);
    const target = candidate.slots.find((slot) => slot.id === payload.slotId);
    if (!target || target.hidden || target.content.contentType !== "image" || !candidate.assets.images.some((image) => image.id === target.content.imageId))
      throw Error("이미지 설정을 변경할 슬롯이 없습니다.");
    const next = { ...target.content.imageSettings }, values = payload.settings || {}, limits = BackendSettings.defaults.limits.imageSettings;
    if (Object.prototype.hasOwnProperty.call(values, "fit")) {
      const fit = values.fit;
      if (["contain", "cover", "manual"].includes(fit)) next.fit = fit;
    }
    if (next.fit === "manual") {
      for (const key of ["scale", "x", "y"]) {
        if (!Object.prototype.hasOwnProperty.call(values, key)) continue;
        const value2 = values[key];
        const number = value2 === null || typeof value2 === "object" ? NaN : Number(value2);
        if (Number.isFinite(number)) {
          const [min, max] = limits[key];
          next[key] = Math.max(min, Math.min(max, number));
        }
      }
    }
    target.content.imageSettings = next;
    validateProjectObjectState(candidate, { requireSlots: true });
    if (activeProject._state !== source) continue;
    commitProjectCandidate(candidate, event, payload);
    const post = activeProject._state, changedIds = (before, after) => after.filter((item) => JSON.stringify(before.find((old) => old.id === item.id)) !== JSON.stringify(item)).map((item) => item.id);
    payload.changed = {
      slotIds: changedIds(source.slots, post.slots),
      chartIds: changedIds(source.charts, post.charts),
      csvIds: changedIds(source.assets.csvFiles, post.assets.csvFiles),
      imageIds: changedIds(source.assets.images, post.assets.images),
      assets: []
    };
    return;
  }
}
function applyCaptionSettingsChangedAction({ machine, event, payload }) {
  machine.assertWritable("captions", "CAPTION_SETTINGS_CHANGED");
  while (true) {
    const source = activeProject._state, candidate = projectClone(source), captions = candidate.annotations.captions;
    normalizeSlotContents(candidate.slots);
    for (const slot of candidate.slots) {
      const original = source.slots.find((item) => item.id === slot.id);
      if (original?.content) slot.content = projectClone(original.content);
    }
    if (Object.prototype.hasOwnProperty.call(payload, "enabled"))
      captions.enabled = payload.enabled === true;
    if (Object.prototype.hasOwnProperty.call(payload, "name"))
      captions.name = String(payload.name ?? "");
    if (Object.prototype.hasOwnProperty.call(payload, "nameBold"))
      captions.nameBold = payload.nameBold === true;
    if (payload.settings && typeof payload.settings === "object") {
      const edits = payload.settings, defaults = BackendSettings.project_object.annotations.captions.settings, limits = BackendSettings.defaults.limits.captions;
      if (Object.prototype.hasOwnProperty.call(edits, "fontFamily"))
        captions.settings.fontFamily = String(edits.fontFamily ?? "");
      for (const key of ["fontSize", "lineHeight"]) {
        if (!Object.prototype.hasOwnProperty.call(edits, key)) continue;
        const number = Number(edits[key]), [min, max] = limits[key];
        captions.settings[key] = Number.isFinite(number) ? Math.max(min, Math.min(max, number)) : defaults[key];
      }
    }
    validateProjectObjectState(candidate, { requireSlots: true });
    if (activeProject._state !== source) continue;
    commitProjectCandidate(candidate, event, payload);
    const post = activeProject._state, changedIds = (before, after) => after.filter((item) => JSON.stringify(before.find((old) => old.id === item.id)) !== JSON.stringify(item)).map((item) => item.id);
    payload.changed = {
      slotIds: changedIds(source.slots, post.slots),
      chartIds: changedIds(source.charts, post.charts),
      csvIds: changedIds(source.assets.csvFiles, post.assets.csvFiles),
      imageIds: changedIds(source.assets.images, post.assets.images),
      assets: []
    };
    return;
  }
}
function applyLayoutStyleChangedAction({ machine, event, payload }) {
  machine.assertWritable("layout", "LAYOUT_STYLE_CHANGED");
  while (true) {
    const source = activeProject._state, candidate = projectClone(source);
    const style = candidate.layout.slotStyle, limits = BackendSettings.defaults.limits.layout;
    for (const key of ["referenceWidth", "gap", "outerMargin", "radius", "aspect"]) {
      if (!Object.prototype.hasOwnProperty.call(payload, key)) continue;
      style[key] = readProjectNumber(payload[key], style[key], ...limits[key]);
    }
    if (Object.prototype.hasOwnProperty.call(payload, "showBorders"))
      style.showBorders = payload.showBorders === true;
    validateProjectObjectState(candidate, { requireSlots: true });
    if (activeProject._state !== source) continue;
    commitProjectCandidate(candidate, event, payload);
    return;
  }
}
function applySlotsMergedAction({ machine, event, payload }) {
  machine.assertWritable("slots", "SLOTS_MERGED");
  machine.assertWritable("charts", "SLOTS_MERGED");
  while (true) {
    const current = activeProject._state, candidate = projectClone(current);
    normalizeSlotContents(candidate.slots);
    let selected = resolveLayoutCommandSlots(candidate, payload.slotIds);
    let top = Math.min(...selected.map((slot) => slot.row)), left = Math.min(...selected.map((slot) => slot.col)), bottom = Math.max(...selected.map((slot) => slot.row + slot.rowSpan - 1)), right = Math.max(...selected.map((slot) => slot.col + slot.colSpan - 1)), selectedCells = /* @__PURE__ */ new Set();
    selected.forEach((slot) => {
      for (let row = slot.row; row < slot.row + slot.rowSpan; row++)
        for (let col = slot.col; col < slot.col + slot.colSpan; col++)
          selectedCells.add(`${row}:${col}`);
    });
    if (selectedCells.size !== (bottom - top + 1) * (right - left + 1))
      throw Error("선택한 슬롯의 전체 영역이 빈칸 없는 직사각형이어야 합니다.");
    let cells = candidate.slots.filter((slot) => slot.row >= top && slot.row <= bottom && slot.col >= left && slot.col <= right);
    if (cells.length !== selectedCells.size) throw Error("선택 영역을 확인할 수 없습니다.");
    let nonDefault = selected.filter(slotHasNonDefaultLocalState);
    if (nonDefault.length > 1)
      throw Error("로컬 상태가 두 개 이상 있는 슬롯은 합칠 수 없습니다.");
    let anchor = cells.find((slot) => slot.row === top && slot.col === left), local = nonDefault.length ? slotLocalState(nonDefault[0]) : null;
    cells.forEach((cell) => {
      cell.hidden = cell !== anchor;
      if (cell !== anchor) resetSlotLocalState(cell);
    });
    setSlotLocalState(anchor, local);
    anchor.rowSpan = bottom - top + 1;
    anchor.colSpan = right - left + 1;
    anchor.hidden = false;
    validateProjectObjectState(candidate, { requireSlots: true });
    if (activeProject._state !== current) continue;
    commitProjectCandidate(candidate, event, payload);
    payload.selectionHints = {
      mergeSlotIds: selected.map((slot) => slot.id),
      anchorId: anchor.id
    };
    return;
  }
}
function applySlotsSplitAction({ machine, event, payload }) {
  machine.assertWritable("slots", "SLOTS_SPLIT");
  while (true) {
    const current = activeProject._state, candidate = projectClone(current);
    normalizeSlotContents(candidate.slots);
    let selected = resolveLayoutCommandSlots(candidate, payload.slotIds);
    if (selected.some((slot) => slot.rowSpan <= 1 && slot.colSpan <= 1))
      throw Error("나눌 합쳐진 슬롯을 선택하세요.");
    for (let source of selected) {
      let anchor = candidate.slots.find((slot) => slot.id === source.id), endRow = anchor.row + anchor.rowSpan, endCol = anchor.col + anchor.colSpan, local = slotLocalState(anchor);
      candidate.slots.forEach((cell) => {
        if (cell.row >= anchor.row && cell.row < endRow && cell.col >= anchor.col && cell.col < endCol) {
          cell.hidden = false;
          cell.rowSpan = 1;
          cell.colSpan = 1;
          if (cell.id === anchor.id) setSlotLocalState(cell, local);
          else resetSlotLocalState(cell);
        }
      });
    }
    validateProjectObjectState(candidate, { requireSlots: true });
    if (activeProject._state !== current) continue;
    commitProjectCandidate(candidate, event, payload);
    return;
  }
}
function applyAssetsImportedAction({ machine, event, payload }) {
  for (const scope of ["data", "images", "files", "charts", "slots"])
    machine.assertWritable(scope, "ASSETS_IMPORTED");
  while (true) {
    const source = activeProject._state, calculation = buildProjectAssetImportCandidate(source, payload);
    if (!calculation) return false;
    const { candidate, imported } = calculation;
    validateProjectObjectState(candidate, { requireSlots: true });
    if (activeProject._state !== source) continue;
    const changedIds = (before, after) => after.filter((item) => JSON.stringify(before.find((old) => old.id === item.id)) !== JSON.stringify(item)).map((item) => item.id);
    const changed = {
      slotIds: changedIds(source.slots, candidate.slots),
      chartIds: changedIds(source.charts, candidate.charts),
      csvIds: changedIds(source.assets.csvFiles, candidate.assets.csvFiles),
      imageIds: changedIds(source.assets.images, candidate.assets.images),
      assets: imported
    };
    commitProjectCandidate(candidate, event, payload);
    payload.changed = changed;
    return;
  }
}
var PROJECT_COMMAND_ACTIONS = Object.freeze({
  PROJECT_LOADED: applyProjectLoadedAction,
  PROJECT_NAME_CHANGED: applyProjectNameChangedAction,
  PROJECT_DIRECTORY_CREATED: applyProjectDirectoryCreatedAction,
  PROJECT_NODE_MOVED: applyProjectNodeMovedAction,
  PROJECT_TRASH_EMPTIED: applyProjectTrashEmptiedAction,
  DATA_OBJECT_CREATED: applyDataObjectCreatedAction,
  DATA_OBJECT_REPLACED: applyDataObjectReplacedAction,
  DATA_OBJECT_DELETED: applyDataObjectDeletedAction,
  IMAGE_OBJECT_CREATED: applyImageObjectCreatedAction,
  IMAGE_OBJECT_REPLACED: applyImageObjectReplacedAction,
  IMAGE_OBJECT_DELETED: applyImageObjectDeletedAction,
  SLOT_TYPE_CHANGED: applySlotTypeAction,
  SLOTS_RESET: applySlotsResetAction,
  SLOTS_SWAPPED: applySlotsSwappedAction,
  SLOT_IMAGE_LINKED: applySlotImageLinkedAction,
  SLOT_IMAGE_SETTINGS_CHANGED: applySlotImageSettingsChangedAction,
  SLOT_DATA_CONNECTED: applySlotDataConnectedAction,
  GRAPH_OBJECTS_REPLACED: applyGraphObjectsReplacedAction,
  CHART_LAYOUT_CHANGED: applyChartLayoutChangedAction,
  CHART_MODEL_REPLACED: applyChartModelReplacedAction,
  SLOT_IMAGE_IMPORTED: applySlotImageImportedAction,
  SLOT_CHART_IMPORTED: applySlotChartImportedAction,
  GRID_LAYOUT_CHANGED: applyGridLayoutChangedAction,
  LAYOUT_STYLE_CHANGED: applyLayoutStyleChangedAction,
  SLOTS_MERGED: applySlotsMergedAction,
  SLOTS_SPLIT: applySlotsSplitAction,
  CAPTION_TEXT_INPUT: applyCaptionTextAction,
  SLOT_CAPTIONS_INSERTED: applySlotCaptionsInsertedAction,
  CAPTION_SETTINGS_CHANGED: applyCaptionSettingsChangedAction,
  LABEL_SETTINGS_CHANGED: applyLabelSettingsChangedAction,
  LABEL_POSITION_CHANGED: applyLabelPositionChangedAction,
  APPEARANCE_CHANGED: applyAppearanceChangedAction,
  EXPORT_SETTINGS_CHANGED: applyExportSettingsChangedAction,
  ASSETS_IMPORTED: applyAssetsImportedAction
});
var projectEFSM;
function initializeProjectEFSM() {
  projectEFSM = new ProjectStateMachine(projectObjects, PROJECT_COMMAND_ACTIONS);
}
function applyProjectLoadedAction({ machine, event, payload }) {
  for (const scope of projectObjects.names()) machine.assertWritable(scope, "PROJECT_LOADED");
  while (true) {
    const source = activeProject._state, file = payload.file;
    if (!file || !(file.bytes instanceof Uint8Array)) throw Error("불러올 copied FFPX bytes가 없습니다.");
    const candidate = buildProjectObject(ffpxReadProjectBytes(new Uint8Array(file.bytes)), file.name)._state;
    validateProjectObjectState(candidate, { requireSlots: true });
    if (activeProject._state !== source) continue;
    commitProjectCandidate(candidate, event, payload);
    projectRuntime.projectObjectGeneration += 1;
    const changedIds = (before, after) => [...new Set([...before, ...after].map((item) => item.id))].filter((id) => JSON.stringify(before.find((item) => item.id === id) && { ...before.find((item) => item.id === id) }) !== JSON.stringify(after.find((item) => item.id === id) && { ...after.find((item) => item.id === id) }));
    payload.changed = {
      slotIds: changedIds(source.slots, candidate.slots),
      chartIds: changedIds(source.charts, candidate.charts),
      csvIds: changedIds(source.assets.csvFiles, candidate.assets.csvFiles),
      imageIds: changedIds(source.assets.images, candidate.assets.images),
      assets: []
    };
    payload.generation = projectRuntime.projectObjectGeneration;
    payload.selectionHints = Object.freeze({ resetInterfaceSelection: true });
    return;
  }
}

// sourcecode/frontend/renderer.js
var $ = (id) => document.getElementById(id);
var uiTelemetryListeners = /* @__PURE__ */ new Set();
var uiTelemetryState = Object.freeze({
  revision: 0,
  status: "",
  debugEnabled: false,
  debugLines: []
});
function publishUiTelemetry(patch = {}) {
  uiTelemetryState = Object.freeze({
    ...uiTelemetryState,
    ...patch,
    revision: uiTelemetryState.revision + 1
  });
  uiTelemetryListeners.forEach((listener) => listener());
  return uiTelemetryState;
}
function subscribeUiTelemetry(listener) {
  uiTelemetryListeners.add(listener);
  return () => uiTelemetryListeners.delete(listener);
}
function getUiTelemetrySnapshot() {
  return uiTelemetryState;
}
function status(message) {
  let text = String(message ?? "");
  publishUiTelemetry({ status: text });
  return text;
}
var debugEnabled = false;
var debugSequence = 0;
function readDebugEnabled() {
  return debugEnabled;
}
function setDebugEnabled(enabled) {
  debugEnabled = enabled === true;
  publishUiTelemetry({ debugEnabled });
  return debugEnabled;
}
function clearDebugOutput() {
  debugSequence = 0;
  publishUiTelemetry({ debugLines: [] });
}
function saveDebugOutput() {
  auditApp("debug:save");
  debugLog("debugLog:save", {
    build: APP_BUILD,
    userAgent: navigator.userAgent,
    location: location.href
  });
  let blob = new Blob([getUiTelemetrySnapshot().debugLines.join("\n")], {
    type: "text/plain;charset=utf-8"
  }), link = document.createElement("a"), stamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
  link.href = URL.createObjectURL(blob);
  link.download = `chart-builder-debug-${stamp}.log`;
  link.click();
  setTimeout(() => URL.revokeObjectURL(link.href), 0);
}
function debugValue(value2) {
  if (value2 instanceof Error)
    return { name: value2.name, message: value2.message, stack: value2.stack };
  try {
    return JSON.parse(JSON.stringify(value2));
  } catch (error) {
    return { serializationError: error.message, value: String(value2) };
  }
}
function debugLog(event, data = {}, level = "debug") {
  if (!debugEnabled) return;
  let payload = debugValue(data), line = `${String(++debugSequence).padStart(4, "0")} ${(/* @__PURE__ */ new Date()).toISOString().slice(11, 23)} ${level.toUpperCase()} ${event} ${JSON.stringify(payload)}`;
  let method = console[level] || console.debug;
  method.call(console, "[chart-builder]", event, payload);
  let lines = [...uiTelemetryState.debugLines, line].slice(-500);
  publishUiTelemetry({ debugEnabled, debugLines: lines });
}
function readmeContentHtml() {
  let template = $("readmeContent");
  return template ? template.innerHTML.replaceAll("{{APP_BUILD}}", APP_BUILD) : "";
}
function applyReferenceGeometryProjection(element, style, width) {
  if (!element) return;
  const scale = width / style.referenceWidth, geometry = {
    outerMargin: Math.min(style.outerMargin * scale, Math.min(width, width / style.aspect) * 0.49),
    gap: style.gap * scale,
    radius: style.radius * scale,
    scale
  };
  element.style.setProperty("--dashboard-outer-margin", `${geometry.outerMargin}px`);
  element.style.setProperty("--slot-gap", `${geometry.gap}px`);
  element.style.setProperty("--slot-radius", `${geometry.radius}px`);
  return geometry;
}
function syncDashboardCaptionWidth() {
  let dashboard = $("dashboard"), caption = $("dashboardCaption");
  if (!dashboard || !caption) return;
  let width = dashboard.getBoundingClientRect().width;
  caption.style.marginLeft = "0px";
  caption.style.width = `${width}px`;
  caption.style.minWidth = `${width}px`;
}
function applySlotStyleProjection(style, interfaceState) {
  const dashboard = $("dashboard"), border = style.showBorders ? "var(--ui-color)" : "transparent", width = interfaceState.dashboardZoomLocked ? interfaceState.dashboardZoomLockedWidth : style.referenceWidth * interfaceState.dashboardZoomIntent / 100;
  for (const id of ["dashboard", "dashboardCaption"]) {
    const host = $(id);
    host?.style.setProperty("--slot-border-color", border);
    host?.style.setProperty("--layout-slot-border-style", style.showBorders ? "solid" : "dashed");
  }
  const hasAspect = Number.isFinite(style.aspect) && style.aspect > 0;
  dashboard.classList.toggle("fixed-aspect", hasAspect);
  if (hasAspect) dashboard.style.setProperty("--dashboard-aspect", `${style.aspect} / 1`);
  else dashboard.style.removeProperty("--dashboard-aspect");
  applyReferenceGeometryProjection(dashboard, style, width);
  syncDashboardCaptionWidth();
}
var projectImageDisplayUrls = /* @__PURE__ */ new Map();
function projectImageDisplayUrl(image) {
  if (!image) return "";
  let cached = projectImageDisplayUrls.get(image);
  if (cached) return cached;
  let url = URL.createObjectURL(
    new Blob([ffpxBase64ToBytes(image.bytesBase64 || "")], {
      type: image.mime || "application/octet-stream"
    })
  );
  projectImageDisplayUrls.set(image, url);
  return url;
}
function releaseProjectImageDisplayUrl(image) {
  let url = image && projectImageDisplayUrls.get(image);
  if (!url) return;
  URL.revokeObjectURL(url);
  projectImageDisplayUrls.delete(image);
}
function releaseProjectImageDisplayUrls(collection) {
  (Array.isArray(collection) ? collection : []).forEach(releaseProjectImageDisplayUrl);
}
function esc(v) {
  return String(v).replace(
    /[&<>'"]/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[c]
  );
}
function hasLiveGraphSurface(record) {
  return record.host.isConnected && record.plot.isConnected && record.host.contains(record.plot);
}
function hasLiveImageSurface(surface) {
  return surface.host.isConnected && surface.element.isConnected && surface.host.contains(surface.element);
}
function releaseImageSurface(surface) {
  if (rendererRuntime.imageSurfaces.get(surface.slotId) === surface)
    rendererRuntime.imageSurfaces.delete(surface.slotId);
  surface.element.remove();
  surface.element.removeAttribute("src");
}
function currentResizeRequests() {
  return [...rendererRuntime.graphInstances.values()].map((record) => ({
    record,
    generation: record.generation,
    operation: record.operation,
    slotId: record.slotId,
    chartId: record.chartId,
    host: record.host,
    plot: record.plot
  }));
}
function resizePlots(requests = currentResizeRequests()) {
  for (const { record, generation, operation, slotId, chartId, host, plot } of requests) {
    if (generation !== rendererRuntime.dashboardRenderGeneration || record.generation !== generation || record.operation !== operation || record.slotId !== slotId || record.chartId !== chartId || record.host !== host || record.plot !== plot || rendererRuntime.graphInstances.get(slotId) !== record || !hasLiveGraphSurface(record)) continue;
    try {
      Plotly.Plots.resize(plot);
    } catch (_) {
    }
  }
}
function schedulePlotResize() {
  rendererRuntime.resizeRequests = currentResizeRequests();
  if (rendererRuntime.resizePending) return;
  rendererRuntime.resizePending = true;
  requestAnimationFrame(() => {
    const requests = rendererRuntime.resizeRequests;
    rendererRuntime.resizeRequests = [];
    rendererRuntime.resizePending = false;
    resizePlots(requests);
  });
}
function installResizeObserver(frontendActions = {}) {
  if (rendererRuntime.resizeObserverInstalled) return;
  const target = $("dashboard"), area = $("graphArea"), handleResize = () => {
    if (frontendActions.refreshDashboard) {
      frontendActions.refreshDashboard();
      return;
    }
    schedulePlotResize();
  };
  if (window.ResizeObserver) {
    let dashboardObserver, graphAreaObserver;
    try {
      dashboardObserver = new ResizeObserver(() => {
        syncDashboardCaptionWidth();
        schedulePlotResize();
      });
      dashboardObserver.observe(target);
      graphAreaObserver = new ResizeObserver(handleResize);
      if (area) graphAreaObserver.observe(area);
    } catch (error) {
      try {
        dashboardObserver?.disconnect();
      } catch {
      }
      try {
        graphAreaObserver?.disconnect();
      } catch {
      }
      throw error;
    }
    rendererRuntime.dashboardObserver = dashboardObserver;
    rendererRuntime.graphAreaObserver = graphAreaObserver;
  } else window.addEventListener("resize", handleResize);
  rendererRuntime.resizeObserverInstalled = true;
}
function clearSlotDragState() {
  rendererRuntime.slotDragSourceId = null;
  document.querySelectorAll("#dashboard .slot.drag-over").forEach((slot) => slot.classList.remove("drag-over"));
}
function scheduleSlotDragClickSuppressionRelease() {
  const suppression = rendererRuntime.slotDragSuppressClick;
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      if (rendererRuntime.slotDragSourceId === null && rendererRuntime.slotDragSuppressClick === suppression)
        rendererRuntime.slotDragSuppressClick = false;
    });
  });
}
function installSlotClickControllerProjection(frontendActions) {
  const dashboard = $("dashboard");
  if (dashboard.dataset.clickController) return;
  dashboard.dataset.clickController = "true";
  const hostFor = (event) => {
    const host = event.target.closest?.(".slot");
    return host?.parentElement === dashboard ? host : null;
  };
  dashboard.addEventListener("click", (event) => {
    const host = hostFor(event), bookmark = !!event.target.closest?.(".slot-tab");
    if (bookmark && rendererRuntime.slotDragSuppressClick) {
      event.preventDefault();
      event.stopPropagation();
      rendererRuntime.slotDragSuppressClick = false;
      return;
    }
    if (!host) {
      if (dashboard.querySelector(".slot.selected")) frontendActions.slots.select(null, "fsm-to-model");
    } else if (!host.classList.contains("selected") || bookmark || host.classList.contains("empty")) {
      event.preventDefault();
      event.stopPropagation();
      frontendActions.slots.select(Number(host.dataset.slot), "ui-to-fsm");
    }
  }, true);
  dashboard.addEventListener("dragstart", (event) => {
    const host = hostFor(event), bookmark = event.target.closest?.('.slot-tab[draggable="true"]');
    if (!host || !bookmark) {
      event.preventDefault();
      return;
    }
    rendererRuntime.slotDragSourceId = Number(host.dataset.slot);
    rendererRuntime.slotDragSuppressClick = {};
    event.dataTransfer.effectAllowed = "move";
    event.dataTransfer.setData("text/plain", String(rendererRuntime.slotDragSourceId));
  });
  dashboard.addEventListener("dragover", (event) => {
    const host = hostFor(event);
    if (!host) return;
    const files = dataTransferHasFiles(event.dataTransfer);
    if (!files && (rendererRuntime.slotDragSourceId === null || rendererRuntime.slotDragSourceId === Number(host.dataset.slot))) return;
    event.preventDefault();
    event.dataTransfer.dropEffect = files ? "copy" : "move";
    dashboard.querySelectorAll(".slot.drag-over").forEach((other) => other.classList.toggle("drag-over", other === host));
    host.classList.add("drag-over");
  });
  dashboard.addEventListener("dragleave", (event) => {
    const host = hostFor(event);
    if (host && !host.contains(event.relatedTarget)) host.classList.remove("drag-over");
  });
  dashboard.addEventListener("drop", (event) => {
    if (dataTransferHasFiles(event.dataTransfer)) return;
    const host = hostFor(event), source = rendererRuntime.slotDragSourceId;
    clearSlotDragState();
    scheduleSlotDragClickSuppressionRelease();
    if (!host || source === null || source === Number(host.dataset.slot)) return;
    event.preventDefault();
    event.stopPropagation();
    frontendActions.slots.swap(source, Number(host.dataset.slot));
  });
  dashboard.addEventListener("dragend", () => {
    clearSlotDragState();
    scheduleSlotDragClickSuppressionRelease();
  });
}
function syncDashboardCaptionProjection(view, scale = 1) {
  let box = $("dashboardCaption"), input = $("captionText"), prefix = $("captionPrefix");
  if (!box || !input || !prefix) return;
  box.classList.toggle("hidden", !view.enabled);
  box.classList.toggle("slot-caption-view", !!view.slot);
  let prefixText = view.label || view.name;
  prefix.textContent = prefixText;
  prefix.classList.toggle("hidden", !prefixText);
  prefix.classList.toggle("bold", view.nameBold);
  if (view.aggregate) {
    input.contentEditable = "false";
    let before = input.querySelector('[data-caption-region="before"]'), sections = input.querySelector('[data-caption-region="sections"]'), after = input.querySelector('[data-caption-region="after"]');
    if (!before || !sections || !after) {
      before = document.createElement("span");
      before.dataset.captionRegion = "before";
      before.className = "caption-edit-region";
      before.contentEditable = "true";
      sections = document.createElement("span");
      sections.dataset.captionRegion = "sections";
      sections.contentEditable = "false";
      after = document.createElement("span");
      after.dataset.captionRegion = "after";
      after.className = "caption-edit-region";
      after.contentEditable = "true";
      input.replaceChildren(before, sections, after);
    }
    if (before.textContent !== view.text) before.textContent = view.text;
    if (after.textContent !== view.afterText) after.textContent = view.afterText;
    let signature = JSON.stringify(view.sections);
    if (sections.dataset.signature !== signature) {
      sections.dataset.signature = signature;
      sections.replaceChildren(
        ...view.sections.map((section) => {
          let wrapper = document.createElement("span");
          wrapper.className = "caption-section";
          if (section.label) {
            let label = document.createElement("span");
            label.className = "caption-section-label";
            label.textContent = section.label;
            label.contentEditable = "false";
            wrapper.append(label);
          }
          wrapper.append(document.createTextNode(section.text));
          return wrapper;
        })
      );
    }
  } else {
    input.contentEditable = "true";
    if (input.querySelector("[data-caption-region]") || input.textContent !== view.text)
      input.textContent = view.text;
  }
  box.style.fontFamily = view.settings.fontFamily;
  box.style.fontSize = `${view.settings.fontSize * scale}px`;
  box.style.lineHeight = view.settings.lineHeight;
}
function presentSuppliedGraph(record, slot, selected, generation, scale, frontendActions) {
  record.generation = generation;
  const operation = {}, slotId = slot.id, chartId = slot.content.chart;
  record.operation = operation;
  const current = () => generation === rendererRuntime.dashboardRenderGeneration && record.generation === generation && record.operation === operation && record.slotId === slotId && record.chartId === chartId && rendererRuntime.graphInstances.get(slotId) === record && hasLiveGraphSurface(record);
  record.pending = record.pending.catch(() => {
  }).then(async () => {
    if (!current()) return;
    const figure = scalePlotlyFigure(slot.figure, scale);
    await Plotly.react(
      record.plot,
      figure.data,
      figure.layout,
      { ...figure.config, staticPlot: !selected, responsive: true, displaylogo: false, doubleClick: "reset" }
    );
    if (!current()) return;
    record.plot.removeAllListeners?.("plotly_relayout");
    record.plot.removeAllListeners?.("plotly_doubleclick");
    const report = (event = {}, all = false) => {
      if (!current() || rendererRuntime.programmaticPlotlyRelayout.get(record.plot) > 0) return;
      const ranges = {};
      for (const axis of ["xaxis", "xaxis2", "yaxis", "yaxis2"]) {
        if (all || Object.keys(event).some((key) => key === axis + ".autorange" || key === axis + ".range" || key.startsWith(axis + ".range["))) {
          const range = record.plot._fullLayout?.[axis]?.range;
          if (Array.isArray(range) && range.length === 2) ranges[axis] = [...range];
        }
      }
      frontendActions.graphRangesChanged?.(slotId, chartId, ranges);
    };
    record.plot.on?.("plotly_relayout", (event) => report(event));
    record.plot.on?.("plotly_doubleclick", () => setTimeout(() => report({}, true), 0));
    requestAnimationFrame(() => {
      if (current()) {
        try {
          Plotly.Plots.resize(record.plot);
        } catch {
        }
      }
    });
  }).catch((error) => {
    if (!current()) return;
    try {
      status(`그래프 렌더링 오류: ${error?.message || error}`);
    } catch {
    }
    throw error;
  });
}
function applyDashboardProjectionInvalidation(event, mutationResult, interfaceState, projectProjection, frontendActions = {}) {
  if (mutationResult.projectionEffect?.pathOnly && !mutationResult.projectionEffect?.referencesRemoved)
    return "NONE";
  const slots = projectProjection.visibleSlots, dashboard = $("dashboard"), hosts = [...dashboard.querySelectorAll(":scope > .slot")], sameHosts = hosts.length === slots.length && slots.every((slot) => {
    const host = hosts.find((host2) => host2.dataset.slot === String(slot.id));
    if (!host) return false;
    if (slot.contentType !== "image" && slot.figure) {
      const record = rendererRuntime.graphInstances.get(slot.id);
      return record?.host === host && record.chartId === slot.content.chart && hasLiveGraphSurface(record);
    }
    if (slot.imageView) {
      const surface = rendererRuntime.imageSurfaces.get(slot.id);
      return surface?.host === host && hasLiveImageSurface(surface) && surface.imageInput.src === slot.imageView.src;
    }
    return host.classList.contains("empty");
  }), narrow = [
    "CAPTION_TEXT_INPUT",
    "SLOT_CAPTIONS_INSERTED",
    "CAPTION_SETTINGS_CHANGED",
    "LABEL_SETTINGS_CHANGED",
    "LABEL_POSITION_CHANGED",
    "SLOT_IMAGE_SETTINGS_CHANGED",
    "APPEARANCE_CHANGED"
  ].includes(event);
  if (mutationResult.projectionEffect?.referencesRemoved || !narrow || !sameHosts) {
    renderDashboardProjection(projectProjection, interfaceState, frontendActions);
    return "FULL_DASHBOARD";
  }
  const style = projectProjection.layout.slotStyle, width = interfaceState.dashboardZoomLocked ? interfaceState.dashboardZoomLockedWidth : style.referenceWidth * interfaceState.dashboardZoomIntent / 100, scale = width / style.referenceWidth;
  if (["CAPTION_TEXT_INPUT", "SLOT_CAPTIONS_INSERTED", "CAPTION_SETTINGS_CHANGED"].includes(event)) {
    syncDashboardCaptionProjection(projectProjection.annotations.captions, scale);
    syncDashboardCaptionWidth();
  } else if (event === "APPEARANCE_CHANGED") {
    applyUiPaletteProjection(projectProjection.appearance.uiPalette);
    for (const slot of slots) {
      const record = rendererRuntime.graphInstances.get(slot.id);
      if (record) presentSuppliedGraph(
        record,
        slot,
        slot.id === interfaceState.selectedSlotId,
        rendererRuntime.dashboardRenderGeneration,
        scale,
        frontendActions
      );
    }
    Promise.all([...rendererRuntime.graphInstances.values()].map((record) => record.pending)).catch(() => {
    });
  } else if (event === "SLOT_IMAGE_SETTINGS_CHANGED") {
    for (const slot of slots) {
      if (!slot.imageView) continue;
      const element = rendererRuntime.imageSurfaces.get(slot.id).element, settings = slot.imageView.settings;
      element.classList.toggle("manual", settings.fit === "manual");
      element.style.width = settings.fit === "manual" ? `${settings.scale}%` : "";
      element.style.left = settings.fit === "manual" ? `${settings.x}%` : "";
      element.style.top = settings.fit === "manual" ? `${settings.y}%` : "";
      element.style.objectFit = settings.fit === "manual" ? "" : settings.fit;
    }
  } else {
    const labels = new Map(projectProjection.orderedSlotLabels.map((label) => [label.slotId, label.displayLabel])), settings = projectProjection.annotations.labels.settings;
    for (const slot of slots) {
      const host = hosts.find((host2) => host2.dataset.slot === String(slot.id));
      host.querySelectorAll(":scope > .slot-label").forEach((label2) => label2.remove());
      if (!projectProjection.annotations.labels.enabled || !labels.has(slot.id)) continue;
      const label = document.createElement("span");
      label.className = "slot-label";
      label.textContent = labels.get(slot.id);
      label.setAttribute("aria-label", "슬롯 식별자");
      label.style.left = `${settings.x * scale}px`;
      label.style.top = `${settings.y * scale}px`;
      label.style.fontFamily = settings.fontFamily;
      label.style.fontSize = `${settings.fontSize * scale}px`;
      host.append(label);
    }
  }
  return "TARGETED_PROJECTION";
}
function resolveSelectedChart(projectProjection, interfaceState) {
  const slot = projectProjection.visibleSlots.find((slot2) => slot2.id === interfaceState.selectedSlotId);
  return slot && slot.contentType !== "image" ? slot.chart || null : null;
}
function updateGraphViewProjection(projectProjection, interfaceState, frontendActions = {}) {
  const dashboard = $("dashboard"), slots = projectProjection.visibleSlots, hosts = new Map([...dashboard.children].filter((host) => host.classList.contains("slot")).map((host) => [host.dataset.slot, host])), generation = rendererRuntime.dashboardRenderGeneration;
  if (hosts.size !== slots.length || slots.some((slot) => {
    const host = hosts.get(String(slot.id)), record = rendererRuntime.graphInstances.get(slot.id), surface = rendererRuntime.imageSurfaces.get(slot.id);
    if (!host?.isConnected) return true;
    if (slot.contentType !== "image" && slot.figure)
      return !record || record.host !== host || !hasLiveGraphSurface(record) || record.chartId !== slot.content.chart;
    if (record) return true;
    return slot.imageView ? !surface || surface.host !== host || !hasLiveImageSurface(surface) || surface.imageInput.src !== slot.imageView.src : !!surface;
  })) return renderDashboardProjection(projectProjection, interfaceState, frontendActions);
  const chart = resolveSelectedChart(projectProjection, interfaceState), style = projectProjection.layout.slotStyle, scale = (interfaceState.dashboardZoomLocked ? interfaceState.dashboardZoomLockedWidth : style.referenceWidth * interfaceState.dashboardZoomIntent / 100) / style.referenceWidth;
  for (const slot of slots) {
    const selected = slot.id === interfaceState.selectedSlotId, record = rendererRuntime.graphInstances.get(slot.id);
    hosts.get(String(slot.id)).classList.toggle("selected", selected);
    if (record) presentSuppliedGraph(record, slot, selected && slot.chart === chart, generation, scale, frontendActions);
  }
  const completion = Promise.all([
    ...[...rendererRuntime.graphInstances.values()].map((record) => record.pending),
    ...[...rendererRuntime.imageSurfaces.values()].map((surface) => surface.pending)
  ]);
  completion.catch(() => {
  });
  return { generation, completion };
}
function startupCoreRuntimeProjection(projectProjection, interfaceState, frontendActions) {
  applyDashboardZoomProjection(projectProjection.layout, interfaceState);
  installSlotClickControllerProjection(frontendActions);
  const presentation = renderDashboardProjection(projectProjection, interfaceState, frontendActions);
  applySlotStyleProjection(projectProjection.layout.slotStyle, interfaceState);
  auditSuppliedRendererContracts(projectProjection, interfaceState);
  return presentation;
}
function auditSuppliedRendererContracts(projectProjection, interfaceState) {
  const slots = /* @__PURE__ */ new Map();
  for (const slot of projectProjection.visibleSlots) {
    if (slots.has(slot.id) || slot.hidden || slot.content.chart != null && slot.chart?.id !== slot.content.chart || slot.imageView && slot.imageView.slotId !== slot.id)
      throw Error("renderer input의 visible slot reference가 유효하지 않습니다.");
    slots.set(slot.id, slot);
  }
  for (const label of projectProjection.orderedSlotLabels)
    if (!slots.has(label.slotId)) throw Error("renderer input의 label reference가 유효하지 않습니다.");
  if (interfaceState.selectedSlotId != null && !slots.has(interfaceState.selectedSlotId))
    throw Error("renderer input의 selected slot reference가 유효하지 않습니다.");
}
function renderDashboardProjection(projectProjection, interfaceState, frontendActions = {}) {
  const generation = ++rendererRuntime.dashboardRenderGeneration, dashboard = $("dashboard"), style = projectProjection.layout.slotStyle, width = interfaceState.dashboardZoomLocked ? interfaceState.dashboardZoomLockedWidth : style.referenceWidth * interfaceState.dashboardZoomIntent / 100, scale = width / style.referenceWidth, geometry = {
    scale,
    outerMargin: Math.min(style.outerMargin * scale, Math.min(width, width / style.aspect) * 0.49),
    gap: style.gap * scale,
    radius: style.radius * scale
  }, slots = projectProjection.visibleSlots, labels = new Map(projectProjection.orderedSlotLabels.map((label) => [label.slotId, label.displayLabel]));
  dashboard.style.width = dashboard.style.minWidth = `${width}px`;
  dashboard.style.setProperty("--grid-cols", projectProjection.layout.gridCols);
  dashboard.style.setProperty("--grid-rows", projectProjection.layout.gridRows);
  dashboard.style.setProperty("--dashboard-outer-margin", `${geometry.outerMargin}px`);
  dashboard.style.setProperty("--slot-gap", `${geometry.gap}px`);
  dashboard.style.setProperty("--slot-radius", `${geometry.radius}px`);
  dashboard.style.setProperty("--dashboard-aspect", `${style.aspect} / 1`);
  dashboard.classList.toggle("fixed-aspect", Number.isFinite(style.aspect) && style.aspect > 0);
  for (const host of [dashboard, $("dashboardCaption")]) {
    host?.style.setProperty("--slot-border-color", style.showBorders ? "var(--ui-color)" : "transparent");
    host?.style.setProperty("--layout-slot-border-style", style.showBorders ? "solid" : "dashed");
  }
  applyUiPaletteProjection(projectProjection.appearance.uiPalette);
  const discard = (record) => {
    rendererRuntime.graphInstances.delete(record.slotId);
    record.host.remove();
    record.plot.remove();
    try {
      Plotly.purge(record.plot);
    } catch {
    }
    record.pending?.finally(() => {
      try {
        Plotly.purge(record.plot);
      } catch {
      }
    }).catch(() => {
    });
  };
  for (const record of rendererRuntime.graphInstances.values()) {
    const slot = slots.find((slot2) => slot2.id === record.slotId);
    if (!slot || slot.contentType === "image" || !slot.figure || slot.content.chart !== record.chartId || !hasLiveGraphSurface(record)) discard(record);
  }
  for (const surface of rendererRuntime.imageSurfaces.values()) releaseImageSurface(surface);
  const ids = new Set(slots.map((slot) => String(slot.id)));
  dashboard.querySelectorAll(":scope > .slot").forEach((host) => {
    if (!ids.has(host.dataset.slot)) host.remove();
  });
  for (const slot of slots) {
    const graph = slot.contentType !== "image" && slot.figure, image = !graph && slot.imageView, selected = slot.id === interfaceState.selectedSlotId;
    let record = rendererRuntime.graphInstances.get(slot.id), host = record?.host || [...dashboard.children].find((host2) => host2.dataset.slot === String(slot.id));
    if (!host) {
      host = document.createElement("section");
      host.dataset.slot = slot.id;
    }
    host.className = "slot" + (!graph && !image ? " empty" : "") + (selected ? " selected" : "");
    host.style.gridArea = `${slot.row} / ${slot.col} / span ${slot.rowSpan} / span ${slot.colSpan}`;
    if (graph && !record) {
      host.replaceChildren();
      const card = document.createElement("div"), plot = document.createElement("div");
      card.className = "chart-card";
      plot.className = "plot-item";
      plot.id = `plot-${slot.id}`;
      card.append(plot);
      host.append(card);
      record = { host, plot, slotId: slot.id, chartId: slot.content.chart, generation, pending: Promise.resolve() };
      rendererRuntime.graphInstances.set(slot.id, record);
    } else if (!graph) {
      host.replaceChildren();
      if (image) {
        const frame = document.createElement("div"), element = document.createElement("img"), settings = image.settings;
        frame.className = "slot-image-frame";
        element.className = "slot-image";
        element.alt = image.name || "슬롯 이미지";
        element.src = image.src;
        if (settings.fit === "manual") {
          element.classList.add("manual");
          element.style.width = `${settings.scale}%`;
          element.style.left = `${settings.x}%`;
          element.style.top = `${settings.y}%`;
        } else element.style.objectFit = settings.fit;
        frame.append(element);
        host.append(frame);
        const surface = { host, element, slotId: slot.id, imageInput: image, generation, pending: null };
        rendererRuntime.imageSurfaces.set(slot.id, surface);
        const current = () => generation === rendererRuntime.dashboardRenderGeneration && rendererRuntime.imageSurfaces.get(slot.id) === surface && surface.imageInput === image && hasLiveImageSurface(surface) && element.parentElement === frame;
        surface.pending = Promise.resolve().then(async () => {
          if (!current()) {
            releaseImageSurface(surface);
            return;
          }
          try {
            await element.decode();
            if (!current()) releaseImageSurface(surface);
          } catch (error) {
            const wasCurrent = current();
            releaseImageSurface(surface);
            if (wasCurrent) throw error;
          }
        });
      }
    }
    host.querySelectorAll(".slot-tab,.slot-label").forEach((element) => element.remove());
    if (graph || image) {
      const tab = document.createElement("button");
      tab.className = "slot-tab";
      tab.type = "button";
      tab.draggable = true;
      tab.setAttribute("aria-label", "슬롯 이동 및 선택");
      tab.innerHTML = '<span class="slot-tab-shape"></span>';
      host.append(tab);
    }
    if (projectProjection.annotations.labels.enabled && labels.has(slot.id)) {
      const label = document.createElement("span"), settings = projectProjection.annotations.labels.settings;
      label.className = "slot-label";
      label.textContent = labels.get(slot.id);
      label.setAttribute("aria-label", "슬롯 식별자");
      label.style.left = `${settings.x * scale}px`;
      label.style.top = `${settings.y * scale}px`;
      label.style.fontFamily = settings.fontFamily;
      label.style.fontSize = `${settings.fontSize * scale}px`;
      host.append(label);
    }
    dashboard.append(host);
    if (record) presentSuppliedGraph(record, slot, selected, generation, scale, frontendActions);
  }
  syncDashboardCaptionProjection(projectProjection.annotations.captions, scale);
  syncDashboardCaptionWidth();
  installResizeObserver(frontendActions);
  const completion = Promise.all([
    ...[...rendererRuntime.graphInstances.values()].map((record) => record.pending),
    ...[...rendererRuntime.imageSurfaces.values()].map((surface) => surface.pending)
  ]);
  completion.catch(() => {
  });
  return { generation, completion };
}
function plotlyConfig(chart, extra = {}) {
  return {
    ...chart.graph?.config || {},
    ...extra,
    responsive: true,
    displaylogo: false,
    doubleClick: "reset"
  };
}
function syncSlotImageElement(projectProjection) {
  if (!projectProjection) return false;
  let element = document.querySelector(`.slot[data-slot="${projectProjection.slotId}"] .slot-image`);
  if (!element) return false;
  let settings = projectProjection.settings;
  element.classList.toggle("manual", settings.fit === "manual");
  element.removeAttribute("style");
  if (settings.fit === "manual") {
    element.style.width = `${settings.scale}%`;
    element.style.left = `${settings.x}%`;
    element.style.top = `${settings.y}%`;
  } else element.style.objectFit = settings.fit;
  return true;
}
function dataTransferHasFiles(dataTransfer) {
  return Array.from(dataTransfer?.types || []).includes("Files");
}
function exportImageLoad(src) {
  return new Promise((resolve, reject) => {
    let image = new Image();
    image.onload = () => {
      image.onload = image.onerror = null;
      resolve(image);
    };
    image.onerror = () => {
      const failure = Error("이미지를 읽을 수 없습니다.");
      image.onload = image.onerror = null;
      try {
        image.removeAttribute("src");
      } catch {
      }
      reject(failure);
    };
    try {
      image.src = src;
    } catch (failure) {
      image.onload = image.onerror = null;
      try {
        image.removeAttribute("src");
      } catch {
      }
      reject(failure);
    }
  });
}
async function paintExportImage(src, paint) {
  const image = await exportImageLoad(src);
  let failed = false;
  try {
    return paint(image);
  } catch (failure) {
    failed = true;
    throw failure;
  } finally {
    try {
      image.removeAttribute("src");
    } catch (cleanupFailure) {
      if (!failed) throw cleanupFailure;
    }
  }
}
function exportDrawImage(ctx, image, rect, slot, scaleX, scaleY) {
  let settings = readImageSettings(slot?.content?.imageSettings), width = rect.width, height = rect.height, ratio = image.naturalWidth / image.naturalHeight || 1, fit = settings.fit || "contain", drawW, drawH, left, top;
  if (fit === "manual") {
    drawW = width * (Number(settings.scale) || 100) / 100;
    drawH = drawW / ratio;
    left = rect.left + width * (settings.x / 100) - drawW / 2;
    top = rect.top + height * (settings.y / 100) - drawH / 2;
  } else {
    let contain = fit !== "cover", fitWidth = width, fitHeight = fitWidth / ratio;
    if (contain && fitHeight > height || !contain && fitHeight < height) {
      fitHeight = height;
      fitWidth = fitHeight * ratio;
    }
    drawW = fitWidth;
    drawH = fitHeight;
    left = rect.left + (width - drawW) / 2;
    top = rect.top + (height - drawH) / 2;
  }
  ctx.drawImage(image, left * scaleX, top * scaleY, drawW * scaleX, drawH * scaleY);
}
function exportWrapText(ctx, text, x, y, maxWidth, lineHeight) {
  let words = (text || "").split(/\s+/), line = "";
  for (let word of words) {
    let trial = line ? line + " " + word : word;
    if (ctx.measureText(trial).width > maxWidth && line) {
      ctx.fillText(line, x, y);
      y += lineHeight;
      line = word;
    } else line = trial;
  }
  if (line) ctx.fillText(line, x, y);
  return y + lineHeight;
}
function exportCrc32(bytes) {
  let crc = 4294967295;
  for (let byte of bytes) {
    crc ^= byte;
    for (let i = 0; i < 8; i++) crc = crc >>> 1 ^ (crc & 1 ? 3988292384 : 0);
  }
  return (crc ^ 4294967295) >>> 0;
}
function exportSetPngDpi(bytes, dpi) {
  let meter = Math.round(dpi / 0.0254), chunk = new Uint8Array(21), view = new DataView(chunk.buffer);
  view.setUint32(0, 9);
  chunk.set([112, 72, 89, 115], 4);
  view.setUint32(8, meter);
  view.setUint32(12, meter);
  chunk[16] = 1;
  view.setUint32(17, exportCrc32(chunk.slice(4, 17)));
  let ihdrLength = new DataView(bytes.buffer, bytes.byteOffset + 8, 4).getUint32(0), offset = 8 + 4 + 4 + ihdrLength + 4, result = new Uint8Array(bytes.length + chunk.length);
  result.set(bytes.slice(0, offset));
  result.set(chunk, offset);
  result.set(bytes.slice(offset), offset + chunk.length);
  return result;
}
function exportSetJpegDpi(bytes, dpi) {
  let result = new Uint8Array(bytes);
  for (let i = 0; i + 17 < result.length; i++)
    if (result[i] === 74 && result[i + 1] === 70 && result[i + 2] === 73 && result[i + 3] === 70 && result[i + 4] === 0) {
      let value2 = Math.max(1, Math.min(65535, Math.round(dpi)));
      result[i + 7] = 1;
      result[i + 8] = value2 >> 8;
      result[i + 9] = value2 & 255;
      result[i + 10] = value2 >> 8;
      result[i + 11] = value2 & 255;
      break;
    }
  return result;
}
async function exportCanvasBlob(canvas, mime, dpi) {
  let blob = await new Promise(
    (resolve, reject) => canvas.toBlob(
      (value2) => value2 ? resolve(value2) : reject(Error("이미지 인코딩에 실패했습니다.")),
      mime,
      mime === "image/jpeg" ? 0.92 : void 0
    )
  ), bytes = new Uint8Array(await blob.arrayBuffer()), withDpi = mime === "image/png" ? exportSetPngDpi(bytes, dpi) : exportSetJpegDpi(bytes, dpi);
  return new Blob([withDpi], { type: mime });
}
async function exportDashboard(snapshot, statusSink) {
  let dashboard = $("dashboard"), caption = $("dashboardCaption"), statusOut = {
    set textContent(value2) {
      try {
        statusSink?.(value2);
      } catch {
      }
    }
  }, bordersVisible = snapshot.layout.slotStyle.showBorders, captionView = snapshot.annotations.captions, dashboardRect = dashboard.getBoundingClientRect();
  if (!dashboardRect.width || !dashboardRect.height) {
    statusOut.textContent = "저장할 그래프 영역이 없습니다.";
    return { outcome: "rejected", reason: "grid-geometry" };
  }
  let captionShown = captionView.enabled && !caption.classList.contains("hidden"), captionRect = captionShown ? caption.getBoundingClientRect() : null, labels = snapshot.annotations.labels.enabled ? [...dashboard.querySelectorAll(".slot-label")].flatMap((element) => {
    const slotId = Number(element.closest(".slot")?.dataset.slot), label = snapshot.orderedSlotLabels.find((item) => item.slotId === slotId);
    if (!label) return [];
    const style = getComputedStyle(element);
    return [{
      rect: element.getBoundingClientRect(),
      text: label.displayLabel,
      color: style.color,
      fontWeight: style.fontWeight,
      fontSize: parseFloat(style.fontSize),
      fontFamily: style.fontFamily,
      paddingLeft: parseFloat(style.paddingLeft || 0)
    }];
  }) : [], left = dashboardRect.left, top = dashboardRect.top, right = dashboardRect.right, bottom = Math.max(dashboardRect.bottom, captionRect?.bottom || 0);
  labels.forEach((label) => {
    let rect = label.rect;
    left = Math.min(left, rect.left);
    top = Math.min(top, rect.top);
    right = Math.max(right, rect.right);
    bottom = Math.max(bottom, rect.bottom);
  });
  let sourceWidth = right - left, sourceHeight = bottom - top, width = Math.round(sourceWidth), height = Math.round(sourceHeight), dpi = snapshot.export.dpi, format = snapshot.export.format;
  if (width > snapshot.rasterLimits.rasterDimension || height > snapshot.rasterLimits.rasterDimension || width * height > snapshot.rasterLimits.rasterArea) {
    return { outcome: "rejected", reason: "raster-limit" };
  }
  const slotElements = [...dashboard.querySelectorAll(".slot")].flatMap((element) => {
    const slot = snapshot.visibleSlots.find((item) => item.id === Number(element.dataset.slot));
    if (!slot) return [];
    const style = getComputedStyle(element);
    return [{
      slot,
      rect: element.getBoundingClientRect(),
      background: style.backgroundColor,
      border: style.borderColor,
      radius: parseFloat(style.borderRadius) || 0
    }];
  }), captionStyle = captionShown ? getComputedStyle(caption) : null, captionColors = captionStyle ? {
    background: captionStyle.backgroundColor,
    border: captionStyle.borderColor,
    color: captionStyle.color,
    fontFamily: captionStyle.fontFamily,
    fontSize: parseFloat(captionStyle.fontSize),
    padding: parseFloat(captionStyle.paddingLeft) || 0,
    lineHeight: parseFloat(captionStyle.lineHeight) / parseFloat(captionStyle.fontSize)
  } : null, presentationScale = dashboardRect.width / snapshot.layout.slotStyle.referenceWidth;
  const canvas = document.createElement("canvas");
  let failed = false;
  try {
    const ctx = canvas.getContext("2d"), scaleX = width / sourceWidth, scaleY = height / sourceHeight, point = (rect) => ({
      left: rect.left - left,
      top: rect.top - top,
      width: rect.width,
      height: rect.height
    });
    canvas.width = width;
    canvas.height = height;
    ctx.fillStyle = getComputedStyle(dashboard).backgroundColor || "#fff";
    ctx.fillRect(0, 0, width, height);
    statusOut.textContent = "그래프를 합성하는 중…";
    for (let element of slotElements) {
      let rect = point(element.rect);
      ctx.fillStyle = element.background || "#fff";
      ctx.fillRect(
        rect.left * scaleX,
        rect.top * scaleY,
        rect.width * scaleX,
        rect.height * scaleY
      );
      if (bordersVisible) {
        ctx.strokeStyle = element.border || "#B0CFCE";
        ctx.lineWidth = Math.max(1, scaleX);
        ctx.strokeRect(
          rect.left * scaleX,
          rect.top * scaleY,
          rect.width * scaleX,
          rect.height * scaleY
        );
      }
      ctx.save();
      try {
        ctx.beginPath();
        ctx.roundRect(
          rect.left * scaleX,
          rect.top * scaleY,
          rect.width * scaleX,
          rect.height * scaleY,
          element.radius * Math.min(scaleX, scaleY)
        );
        ctx.clip();
        const figure = element.slot.figure, imageView = element.slot.imageView;
        if (element.slot.content.contentType !== "image" && figure) {
          const uri = await exportChartImage(
            figure,
            rect.width * scaleX,
            rect.height * scaleY,
            presentationScale * scaleY,
            1
          );
          await paintExportImage(uri, (image) => ctx.drawImage(
            image,
            rect.left * scaleX,
            rect.top * scaleY,
            rect.width * scaleX,
            rect.height * scaleY
          ));
        } else if (imageView) {
          await paintExportImage(imageView.src, (image) => exportDrawImage(ctx, image, rect, element.slot, scaleX, scaleY));
        }
      } finally {
        ctx.restore();
      }
    }
    for (let label of labels) {
      let rect = point(label.rect);
      ctx.fillStyle = label.color || "#383A42";
      ctx.font = `${label.fontWeight} ${label.fontSize * scaleY}px ${label.fontFamily}`;
      ctx.textBaseline = "middle";
      ctx.fillText(
        label.text,
        (rect.left + label.paddingLeft) * scaleX,
        (rect.top + rect.height / 2) * scaleY
      );
    }
    if (captionShown && captionRect) {
      let rect = point(captionRect), style = captionColors;
      ctx.fillStyle = style.background || "#fff";
      ctx.fillRect(
        rect.left * scaleX,
        rect.top * scaleY,
        rect.width * scaleX,
        rect.height * scaleY
      );
      if (bordersVisible) {
        ctx.strokeStyle = style.border || "#B0CFCE";
        ctx.strokeRect(rect.left * scaleX, rect.top * scaleY, rect.width * scaleX, rect.height * scaleY);
      }
      const layout2 = await exportCaptionLayout({
        ...snapshot,
        layout: { ...snapshot.layout, slotStyle: { ...snapshot.layout.slotStyle, referenceWidth: rect.width } },
        annotations: { ...snapshot.annotations, captions: {
          ...captionView,
          settings: {
            ...captionView.settings,
            fontFamily: style.fontFamily,
            fontSize: style.fontSize,
            lineHeight: style.lineHeight
          }
        } },
        captionReferenceStyle: { ...snapshot.captionReferenceStyle, padding: style.padding }
      }, (text, family, size, weight) => {
        ctx.font = `${weight} ${size}px ${family}`;
        return ctx.measureText(text).width;
      });
      ctx.save();
      try {
        ctx.beginPath();
        ctx.rect(rect.left * scaleX, rect.top * scaleY, rect.width * scaleX, rect.height * scaleY);
        ctx.clip();
        ctx.fillStyle = style.color || "#383A42";
        ctx.textBaseline = "alphabetic";
        let y = (rect.top + layout2.padding + layout2.fontSize) * scaleY;
        for (const line of layout2.lines) {
          let x = (rect.left + layout2.padding) * scaleX;
          if (line.prefix) {
            ctx.font = `${layout2.prefixWeight} ${layout2.fontSize * scaleY}px ${layout2.fontFamily}`;
            ctx.fillText(line.prefix, x, y);
            x += line.prefixWidth * scaleX;
          }
          ctx.font = `${layout2.bodyWeight} ${layout2.fontSize * scaleY}px ${layout2.fontFamily}`;
          ctx.fillText(line.text, x, y);
          y += layout2.lineHeight * scaleY;
        }
      } finally {
        ctx.restore();
      }
    }
    let mime = format === "jpeg" ? "image/jpeg" : "image/png", blob = await exportCanvasBlob(canvas, mime, dpi), stamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
    await downloadExportPayload({
      blob,
      name: `전체-그래프-${width}x${height}-${dpi}dpi-${stamp}.${format === "jpeg" ? "jpg" : "png"}`
    });
    statusOut.textContent = `${width} × ${height}px, ${dpi} DPI로 저장했습니다.`;
    try {
      debugLog("dashboard:export", { format, width, height, dpi, slots: slotElements.length });
    } catch {
    }
    return { outcome: "saved", width, height, automaticHeight: false };
  } catch (error) {
    failed = true;
    try {
      statusOut.textContent = "저장 실패: " + (error?.message ?? String(error));
    } catch {
    }
    try {
      debugLog("dashboard:export-error", { message: error?.message ?? String(error) });
    } catch {
    }
    throw error;
  } finally {
    try {
      canvas.width = canvas.height = 0;
    } catch (cleanupFailure) {
      if (!failed) throw cleanupFailure;
    }
  }
}
async function exportChartImage(suppliedFigure, width, height, layoutScale, rasterScale) {
  let host = document.createElement("div"), figure = scalePlotlyFigure(suppliedFigure, layoutScale);
  host.style.cssText = "position:fixed;left:-100000px;top:0;visibility:hidden;pointer-events:none;";
  host.style.width = `${Math.max(2, width)}px`;
  host.style.height = `${Math.max(2, height)}px`;
  document.body.append(host);
  let failed = false;
  try {
    await Plotly.newPlot(
      host,
      figure.data,
      { ...figure.layout, width, height, autosize: false },
      { ...figure.config, staticPlot: true, responsive: false }
    );
    return await Plotly.toImage(host, {
      format: "png",
      width: Math.max(2, Math.round(width)),
      height: Math.max(2, Math.round(height)),
      scale: rasterScale
    });
  } catch (error) {
    failed = true;
    throw error;
  } finally {
    try {
      try {
        Plotly.purge(host);
      } finally {
        host.remove();
      }
    } catch (cleanupError) {
      if (!failed) throw cleanupError;
    }
  }
}
async function exportCaptionLayout(snapshot, measureText) {
  const view = snapshot.annotations.captions, style = snapshot.captionReferenceStyle, referenceWidth = snapshot.layout.slotStyle.referenceWidth;
  if (!view.enabled)
    return {
      height: 0,
      gap: 0,
      padding: 0,
      fontSize: 0,
      lineHeight: 0,
      lines: []
    };
  const fontFamily = view.settings.fontFamily, fontSize = view.settings.fontSize;
  await document.fonts.load(`400 ${fontSize}px ${fontFamily}`);
  if (view.name && view.nameBold)
    await document.fonts.load(`700 ${fontSize}px ${fontFamily}`);
  let padding = style.padding, lineHeight = fontSize * view.settings.lineHeight, available = Math.max(style.minimumTextWidth, referenceWidth - padding * 2), prefix = view.name || "", body = view.text || "", lines = [], firstLine = true, prefixWidth = 0;
  if (prefix) {
    prefix += " ";
    prefixWidth = measureText(prefix, fontFamily, fontSize, view.nameBold ? 700 : 400);
  }
  let paragraphs = String(body).split(/\n/);
  paragraphs.forEach((paragraph) => {
    let words = paragraph.split(/\s+/).filter(Boolean), line = "";
    let wi = 0;
    while (wi < words.length) {
      let word = words[wi], trial = line ? `${line} ${word}` : word, budget = Math.max(style.minimumTextWidth, available - (firstLine ? prefixWidth : 0));
      if (measureText(trial, fontFamily, fontSize, 400) > budget && line !== "") {
        lines.push({ text: line, prefix: firstLine ? prefix : "", prefixWidth: firstLine ? prefixWidth : 0 });
        line = "";
        firstLine = false;
      } else {
        line = trial;
        wi += 1;
      }
    }
    lines.push({ text: line, prefix: firstLine ? prefix : "", prefixWidth: firstLine ? prefixWidth : 0 });
    firstLine = false;
  });
  return {
    referenceWidth,
    height: padding * 2 + lines.length * lineHeight + style.borderHeight,
    gap: style.dashboardGap,
    padding,
    fontFamily,
    fontSize,
    prefixWeight: view.nameBold ? 700 : 400,
    bodyWeight: 400,
    lineHeight,
    lines
  };
}
function targetExportGeometry(layout2, width, heightOverride = null) {
  let slotStyle = layout2.slotStyle, referenceWidth = slotStyle.referenceWidth, scale = width / referenceWidth, height = heightOverride === null ? width / slotStyle.aspect : heightOverride, outerMargin = Math.min(slotStyle.outerMargin * scale, Math.min(width, height) * 0.49);
  return {
    referenceWidth,
    width,
    height,
    scale,
    aspect: width / height,
    outerMargin,
    gap: slotStyle.gap * scale,
    radius: slotStyle.radius * scale
  };
}
function targetSlotIdentifier(index, settings) {
  if (settings.format === "decimal") return String(index + 1);
  if (settings.format === "lower-roman") return romanIdentifier(index).toLowerCase();
  if (settings.format === "upper-roman") return romanIdentifier(index);
  return alphaIdentifier(index, settings.format === "upper-alpha");
}
function createTargetExportView(input) {
  const palette = input.appearance.uiPalette, style = { background: palette.paperColor, border: palette.uiColor, color: palette.fontColor };
  return {
    ...input,
    slots: input.visibleSlots,
    labels: input.annotations.labels,
    bordersVisible: input.layout.slotStyle.showBorders,
    slotColors: Object.fromEntries(input.visibleSlots.map((slot) => [slot.id, style])),
    labelText: Object.fromEntries(input.orderedSlotLabels.map((label) => [label.slotId, label.displayLabel])),
    dashboardStyle: style,
    captionStyle: style
  };
}
async function exportDashboardTarget(suppliedSnapshot, statusSink) {
  let statusOut = { set textContent(value2) {
    try {
      statusSink?.(value2);
    } catch {
    }
  } }, snapshot = createTargetExportView(suppliedSnapshot), options = snapshot.export, captionView = snapshot.annotations.captions, width = options.width, requestedHeight = options.height, dpi = options.dpi, rasterScale = 1, format = options.format, bordersVisible = snapshot.bordersVisible, visibleSlots = snapshot.slots.filter((slot) => !slot.hidden), captionShown = captionView.enabled;
  const canvas = document.createElement("canvas");
  let failed = false;
  try {
    const ctx = canvas.getContext("2d"), baseReference = targetExportGeometry(snapshot.layout, width), outputScale = width / baseReference.referenceWidth, captionReference = await exportCaptionLayout(snapshot, (text, family, size, weight) => {
      ctx.font = `${weight} ${size}px ${family}`;
      return ctx.measureText(text).width;
    }), captionLayout = {
      ...captionReference,
      padding: captionReference.padding * outputScale,
      fontSize: captionReference.fontSize * outputScale,
      lineHeight: captionReference.lineHeight * outputScale,
      height: captionReference.height * outputScale,
      gap: captionReference.gap * outputScale
    }, automaticHeight = options.heightMode === "auto", height = automaticHeight ? Math.ceil(baseReference.height + captionLayout.height + captionLayout.gap) : requestedHeight, rasterWidth = Math.round(width), rasterHeight = Math.round(height), maxRasterDimension = snapshot.rasterLimits.rasterDimension, maxRasterArea = snapshot.rasterLimits.rasterArea;
    if (rasterWidth > maxRasterDimension || rasterHeight > maxRasterDimension || rasterWidth * rasterHeight > maxRasterArea) {
      statusOut.textContent = `요청한 ${rasterWidth} × ${rasterHeight}px 래스터가 출력 한도(한 변 16384px, 총 64MP)를 넘습니다. 가로 또는 세로 크기를 낮추세요.`;
      return { outcome: "rejected", reason: "raster-limit" };
    }
    canvas.width = rasterWidth;
    canvas.height = rasterHeight;
    ctx.imageSmoothingQuality = "high";
    ctx.fillStyle = snapshot.dashboardStyle.background;
    ctx.fillRect(0, 0, width, height);
    let reference = targetExportGeometry(snapshot.layout, width), dashboardHeight = automaticHeight ? baseReference.height : height - captionLayout.height - captionLayout.gap, minimumDashboardHeight = Math.ceil(
      reference.outerMargin * 2 + reference.gap * Math.max(0, snapshot.layout.gridRows - 1) + snapshot.layout.gridRows
    );
    if (dashboardHeight <= 0) {
      let minimumHeight = Math.ceil(
        captionLayout.height + captionLayout.gap + minimumDashboardHeight
      );
      statusOut.textContent = `캡션 높이 ${Math.ceil(captionLayout.height)}px를 배치하기에는 설정된 세로 ${height}px가 너무 작습니다. 세로를 최소 ${minimumHeight}px로 늘리세요.`;
      return { outcome: "rejected", reason: "caption-height" };
    }
    let geometry = targetExportGeometry(snapshot.layout, width, dashboardHeight), dashboardLeft = 0, dashboardTop = 0, gap = geometry.gap, grid = gridSlotGeometry(snapshot.layout, geometry), colWidth = grid.colWidth, rowHeight = grid.rowHeight;
    if (colWidth <= 0 || rowHeight <= 0)
      return { outcome: "rejected", reason: "grid-geometry" };
    let slotRect = (slot) => ({
      left: dashboardLeft + geometry.outerMargin + (slot.col - 1) * (colWidth + gap),
      top: dashboardTop + geometry.outerMargin + (slot.row - 1) * (rowHeight + gap),
      width: colWidth * slot.colSpan + gap * (slot.colSpan - 1),
      height: rowHeight * slot.rowSpan + gap * (slot.rowSpan - 1)
    });
    let slotRadius = () => geometry.radius;
    statusOut.textContent = "출력 크기로 그래프를 다시 렌더링하는 중…";
    for (let slot of visibleSlots) {
      let rect = slotRect(slot), colors = snapshot.slotColors[slot.id], figure = slot.figure, imageModel = slot.imageView;
      ctx.save();
      ctx.beginPath();
      ctx.roundRect(rect.left, rect.top, rect.width, rect.height, slotRadius());
      ctx.clip();
      ctx.fillStyle = colors?.background || "#fff";
      ctx.fillRect(rect.left, rect.top, rect.width, rect.height);
      if (slot.content.contentType !== "image" && figure) {
        let uri = await exportChartImage(
          figure,
          rect.width,
          rect.height,
          geometry.scale,
          rasterScale
        );
        await paintExportImage(uri, (image) => ctx.drawImage(image, rect.left, rect.top, rect.width, rect.height));
      } else if (imageModel) {
        await paintExportImage(imageModel.src, (image) => exportDrawImage(ctx, image, rect, slot, 1, 1));
      }
      ctx.restore();
      if (bordersVisible) {
        ctx.strokeStyle = colors?.border || "#B0CFCE";
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.roundRect(
          rect.left + 0.5,
          rect.top + 0.5,
          Math.max(0, rect.width - 1),
          Math.max(0, rect.height - 1),
          slotRadius()
        );
        ctx.stroke();
      }
    }
    if (snapshot.labels.enabled) {
      let ordered = snapshot.orderedSlotLabels.map((label) => visibleSlots.find((slot) => slot.id === label.slotId));
      for (let slot of ordered) {
        let rect = slotRect(slot), text = snapshot.labelText[slot.id], x = rect.left + snapshot.labels.settings.x * geometry.scale, y = rect.top + snapshot.labels.settings.y * geometry.scale;
        let scaledLabelFontSize = snapshot.labels.settings.fontSize * geometry.scale;
        ctx.font = `800 ${scaledLabelFontSize}px ${snapshot.labels.settings.fontFamily}`;
        let labelHeight = Math.ceil(scaledLabelFontSize * 1.2) + 4 * geometry.scale;
        ctx.fillStyle = snapshot.dashboardStyle.color;
        ctx.textBaseline = "middle";
        ctx.fillText(text, x + 6 * geometry.scale, y + labelHeight / 2);
      }
    }
    if (captionShown) {
      let top = dashboardTop + geometry.height + captionLayout.gap;
      ctx.fillStyle = snapshot.captionStyle.background;
      ctx.fillRect(0, top, width, captionLayout.height);
      if (bordersVisible) {
        ctx.strokeStyle = snapshot.captionStyle.border;
        ctx.strokeRect(
          0.5,
          top + 0.5,
          Math.max(0, width - 1),
          captionLayout.height - 1
        );
      }
      ctx.save();
      ctx.beginPath();
      ctx.rect(0, top, width, captionLayout.height);
      ctx.clip();
      let y = top + captionLayout.padding + captionLayout.fontSize;
      ctx.textBaseline = "alphabetic";
      ctx.fillStyle = snapshot.captionStyle.color;
      for (let line of captionLayout.lines) {
        let x = captionLayout.padding;
        if (line.prefix) {
          ctx.font = `${captionView.nameBold ? "700" : "400"} ${captionLayout.fontSize}px ${captionView.settings.fontFamily}`;
          ctx.fillText(line.prefix, x, y);
          x += line.prefixWidth * outputScale;
        }
        ctx.font = `400 ${captionLayout.fontSize}px ${captionView.settings.fontFamily}`;
        ctx.fillText(line.text, x, y);
        y += captionLayout.lineHeight;
      }
      ctx.restore();
    }
    let mime = format === "jpeg" ? "image/jpeg" : "image/png", blob = await exportCanvasBlob(canvas, mime, dpi), stamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
    await downloadExportPayload({
      blob,
      name: `전체-그래프-${width}x${height}-r${rasterWidth}x${rasterHeight}-${dpi}dpi-${stamp}.${format === "jpeg" ? "jpg" : "png"}`
    });
    statusOut.textContent = `레이아웃 ${width} × ${height}px · 래스터 ${rasterWidth} × ${rasterHeight}px · ${dpi} DPI로 저장했습니다.`;
    try {
      debugLog("dashboard:export-target", {
        format,
        width,
        height,
        rasterWidth,
        rasterHeight,
        dpi,
        rasterScale,
        slots: visibleSlots.length,
        gridRows: snapshot.layout.gridRows,
        gridCols: snapshot.layout.gridCols,
        gap,
        referenceWidth: reference.referenceWidth,
        renderScale: geometry.scale,
        dashboardWidth: geometry.width,
        dashboardHeight: geometry.height,
        dashboardAspect: geometry.aspect,
        captionHeight: captionLayout.height,
        automaticHeight,
        revision: snapshot.revision
      });
    } catch {
    }
    return { outcome: "saved", width: rasterWidth, height: rasterHeight, automaticHeight };
  } catch (error) {
    failed = true;
    try {
      statusOut.textContent = "저장 실패: " + (error?.message ?? String(error));
    } catch {
    }
    try {
      debugLog("dashboard:export-error", { message: error?.message ?? String(error) });
    } catch {
    }
    throw error;
  } finally {
    try {
      canvas.width = canvas.height = 0;
    } catch (cleanupFailure) {
      if (!failed) throw cleanupFailure;
    }
  }
}
async function downloadExportPayload(payload) {
  const blob = payload.blob || new Blob([
    payload.entries ? ffpxZipStore(payload.entries) : Uint8Array.from(payload.bytes)
  ], { type: payload.mime }), url = URL.createObjectURL(blob);
  let failed = false;
  try {
    const link = document.createElement("a");
    link.href = url;
    link.download = payload.name;
    link.click();
    await new Promise((resolve) => setTimeout(resolve, 0));
  } catch (error) {
    failed = true;
    throw error;
  } finally {
    try {
      URL.revokeObjectURL(url);
    } catch (cleanupError) {
      if (!failed) throw cleanupError;
    }
  }
}
function applyDashboardZoomProjection(layout2, interfaceState, resize = true) {
  const dashboard = $("dashboard"), style = layout2.slotStyle, width = interfaceState.dashboardZoomLocked ? interfaceState.dashboardZoomLockedWidth : style.referenceWidth * interfaceState.dashboardZoomIntent / 100;
  dashboard.style.minWidth = dashboard.style.width = `${width}px`;
  applyReferenceGeometryProjection(dashboard, style, width);
  syncDashboardCaptionWidth();
  if (resize) schedulePlotResize();
}
function readDashboardRenderedWidth() {
  const width = $("dashboard")?.getBoundingClientRect().width;
  return Number.isFinite(width) && width > 0 ? width : null;
}
function applyUiPaletteProjection(palette) {
  document.documentElement.style.setProperty("--ui-color", palette.uiColor);
  document.documentElement.style.setProperty(
    "--paper",
    palette.uiBackgroundColor
  );
  document.documentElement.style.setProperty("--ui-subtle", palette.uiSubtleColor);
  document.documentElement.style.setProperty("--ink", palette.fontColor);
  document.documentElement.style.setProperty("--graph-bg", palette.paperColor);
  return Object.freeze({
    "--ui-color": palette.uiColor,
    "--paper": palette.uiBackgroundColor,
    "--ui-subtle": palette.uiSubtleColor,
    "--ink": palette.fontColor,
    "--graph-bg": palette.paperColor
  });
}
var rendererRuntime = {
  graphInstances: /* @__PURE__ */ new Map(),
  imageSurfaces: /* @__PURE__ */ new Map(),
  dashboardObserver: null,
  graphAreaObserver: null,
  resizePending: false,
  resizeRequests: [],
  resizeObserverInstalled: false,
  programmaticPlotlyRelayout: /* @__PURE__ */ new WeakMap(),
  dashboardRenderGeneration: 0,
  slotDragSourceId: null,
  slotDragSuppressClick: false
};

// sourcecode/frontend/interface_fsm.js
var REFERENCE_EVENTS = /* @__PURE__ */ new Set(["SELECT_SLOT", "SELECT_ASSET", "SELECT_GRAPH_OBJECT"]);
var INTERFACE_EVENTS = /* @__PURE__ */ new Set([
  ...REFERENCE_EVENTS,
  "CLEAR_ASSET_SELECTION",
  "CLEAR_GRAPH_OBJECT",
  "TOGGLE_OVERLAY",
  "CLOSE_OVERLAY",
  "OUTSIDE_CLICK",
  "ESCAPE",
  "SET_DASHBOARD_ZOOM",
  "SET_DASHBOARD_ZOOM_LOCK",
  "RESET_DASHBOARD_ZOOM",
  "LIFECYCLE_START",
  "LIFECYCLE_COMPLETE",
  "LIFECYCLE_FAILED"
]);
var InterfaceStateMachine = class {
  constructor(definitions) {
    this.definitions = definitions;
    this.state = Object.freeze({
      lifecycle: "booting",
      workspace: "project",
      overlay: "none",
      assetSelection: "none",
      assetPath: null,
      graphObject: "none",
      graphObjectIndex: null,
      direction: "model-to-ui",
      revision: 0,
      error: null
    });
    this.listeners = /* @__PURE__ */ new Set();
    this.writeLocks = /* @__PURE__ */ new Set();
  }
  definition(region, state = this.state[region]) {
    const definition = this.definitions[region]?.[state];
    if (!definition) throw Error(`${region}.${state} FSM 상태가 등록되지 않았습니다.`);
    return definition;
  }
  assertWritable(scope, event) {
    if (this.writeLocks.has(scope)) throw Error(`${event} 전이 중 잠긴 ${scope} 모델을 수정할 수 없습니다.`);
  }
  publish(event) {
    this.state = Object.freeze({ ...this.state, revision: this.state.revision + 1 });
    const state = this.readState(), busy = state.lifecycle === "importing" || state.lifecycle === "exporting";
    document.body.classList.toggle("app-busy", busy);
    document.body.setAttribute("aria-busy", String(busy));
    document.body.dataset.appLifecycle = state.lifecycle;
    document.body.dataset.appWorkspace = state.workspace;
    document.body.dataset.appOverlay = state.overlay;
    document.body.dataset.appAssetSelection = state.assetSelection;
    document.body.dataset.appGraphObject = state.graphObject;
    this.listeners.forEach((listener) => listener(state, event));
    debugLog("fsm:transition", { event, ...state });
    return state;
  }
  send(event, payload = {}) {
    const input = payload.validatedInput ?? (REFERENCE_EVENTS.has(event) ? { accepted: false } : { accepted: payload.accepted !== false, payload });
    if (input.accepted !== true) return this.readState();
    if (!INTERFACE_EVENTS.has(event)) throw Error(`${event}는 등록된 Frontend event가 아닙니다.`);
    const values = input.payload ?? payload, next = { ...this.state };
    if (event === "SELECT_SLOT") {
      const reference = input.reference;
      interfaceRuntime.selectedSlotId = reference === null || input.selectionHint === "toggle-clear" && reference === interfaceRuntime.selectedSlotId ? null : reference;
      next.workspace = interfaceRuntime.selectedSlotId === null ? "project" : input.workspaceHint;
      next.graphObject = "none";
      next.graphObjectIndex = null;
      if (interfaceRuntime.selectedSlotId === null || input.selectionHint === "toggle-clear") {
        next.assetSelection = "none";
        next.assetPath = null;
      }
      if (interfaceRuntime.selectedSlotId !== null) next.overlay = "none";
    } else if (event === "SELECT_ASSET") {
      next.assetSelection = input.selectionHint ?? "none";
      next.assetPath = input.reference;
      next.graphObject = "none";
      next.graphObjectIndex = null;
    } else if (event === "SELECT_GRAPH_OBJECT") {
      next.graphObject = input.reference === null ? "none" : "selected";
      next.graphObjectIndex = input.reference;
      if (input.reference !== null && input.selectionHint != null) {
        next.assetSelection = "csv";
        next.assetPath = input.selectionHint;
      }
    } else if (event === "CLEAR_ASSET_SELECTION") {
      next.assetSelection = "none";
      next.assetPath = null;
    } else if (event === "CLEAR_GRAPH_OBJECT") {
      next.graphObject = "none";
      next.graphObjectIndex = null;
    } else if (event === "TOGGLE_OVERLAY") {
      next.overlay = next.overlay === values.overlay ? "none" : values.overlay;
    } else if (["CLOSE_OVERLAY", "OUTSIDE_CLICK", "ESCAPE"].includes(event)) {
      next.overlay = "none";
    } else if (event === "SET_DASHBOARD_ZOOM") {
      if (interfaceRuntime.dashboardZoomLocked) return this.readState();
      const raw = values.value, numeric = typeof raw === "number" || typeof raw === "string" && raw.trim() !== "" ? Number(raw) : NaN, value2 = Number.isFinite(numeric) ? Math.max(50, Math.min(200, numeric)) : 100;
      if (value2 === interfaceRuntime.dashboardZoomIntent) return this.readState();
      interfaceRuntime.dashboardZoomIntent = value2;
    } else if (event === "SET_DASHBOARD_ZOOM_LOCK" || event === "RESET_DASHBOARD_ZOOM") {
      if (event === "SET_DASHBOARD_ZOOM_LOCK" && values.locked === true) {
        if (interfaceRuntime.dashboardZoomLocked || !Number.isFinite(values.renderedWidth) || values.renderedWidth <= 0)
          return this.readState();
        interfaceRuntime.dashboardZoomLocked = true;
        interfaceRuntime.dashboardZoomLockedWidth = values.renderedWidth;
      } else {
        if (!interfaceRuntime.dashboardZoomLocked && interfaceRuntime.dashboardZoomLockedWidth === null && interfaceRuntime.dashboardZoomIntent === 100) return this.readState();
        interfaceRuntime.dashboardZoomLocked = false;
        interfaceRuntime.dashboardZoomLockedWidth = null;
        interfaceRuntime.dashboardZoomIntent = 100;
      }
    } else if (event === "LIFECYCLE_START") {
      next.lifecycle = values.lifecycle;
      next.error = null;
    } else if (event === "LIFECYCLE_COMPLETE") {
      next.lifecycle = "ready";
      next.error = null;
    } else if (event === "LIFECYCLE_FAILED") {
      next.lifecycle = "error";
      next.error = Object.freeze({ event: values.event, message: values.message });
      this.state = Object.freeze(next);
      this.publish(`${values.event}:failed`);
      this.state = Object.freeze({ ...this.state, lifecycle: "ready" });
      return this.publish(`${values.event}:recovered`);
    }
    this.state = Object.freeze(next);
    const outcomeLabel = event === "LIFECYCLE_COMPLETE" ? typeof values.outcome === "string" ? values.outcome : values.outcome?.outcome : null;
    const label = event === "LIFECYCLE_START" ? `${values.event}:start` : event === "LIFECYCLE_COMPLETE" ? `${values.event}:${outcomeLabel || "complete"}` : event;
    return this.publish(label);
  }
  readState() {
    return Object.freeze({
      ...this.state,
      selectedSlotId: interfaceRuntime.selectedSlotId,
      dashboardZoomIntent: interfaceRuntime.dashboardZoomIntent,
      dashboardZoomLocked: interfaceRuntime.dashboardZoomLocked,
      dashboardZoomLockedWidth: interfaceRuntime.dashboardZoomLockedWidth
    });
  }
  reconcileProjectResult(event, input) {
    interfaceRuntime.selectedSlotId = input.selectedSlot;
    this.state = Object.freeze({
      ...this.state,
      workspace: input.workspaceHint,
      direction: "model-to-fsm",
      assetSelection: input.assetKind ?? "none",
      assetPath: input.assetSelection,
      graphObject: input.graphObject === null ? "none" : "selected",
      graphObjectIndex: input.graphObject
    });
    return this.publish(`${event}:reconcile`);
  }
  notify(objectName, event, payload = {}) {
    this.state = Object.freeze({ ...this.state, direction: "model-to-fsm" });
    return this.publish(event);
  }
  ready(workspaceHint = "project") {
    this.state = Object.freeze({ ...this.state, workspace: workspaceHint, overlay: "none" });
    return this.send("LIFECYCLE_COMPLETE", { event: "READY" });
  }
  subscribe(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }
};
function requestedWorkspaceState({ payload }) {
  return interfaceRuntime.selectedSlotId === null ? "project" : payload.validatedInput.workspaceHint;
}
function applySlotSelectionAction({ machine, payload }) {
  let input = payload.validatedInput, same = input.reference !== null && interfaceRuntime.selectedSlotId === input.reference;
  machine.assertWritable("workspace", "SELECT_SLOT");
  interfaceRuntime.selectedSlotId = same && input.selectionHint === "toggle-clear" ? null : input.reference;
  machine.state = Object.freeze({
    ...machine.state,
    graphObject: "none",
    graphObjectIndex: null
  });
}
function applyGraphObjectSelectionAction({ machine, payload }) {
  machine.assertWritable("editor", "SELECT_GRAPH_OBJECT");
  let index = payload.validatedInput?.event === "SELECT_GRAPH_OBJECT" ? payload.validatedInput.reference : null;
  machine.state = Object.freeze({
    ...machine.state,
    graphObjectIndex: index,
    ...index !== null && payload.validatedInput.selectionHint ? {
      assetSelection: "csv",
      assetPath: payload.validatedInput.selectionHint
    } : {}
  });
}
function selectedGraphObjectGuard() {
  return interfaceFSM?.state.graphObject === "selected" && Number.isInteger(interfaceFSM.state.graphObjectIndex);
}
function applyAssetSelectionAction({ machine, payload }) {
  if (payload.validatedInput?.event === "SELECT_SLOT" && payload.validatedInput.reference !== null && payload.validatedInput.selectionHint === "clear-graph-object") return;
  let path = payload.validatedInput?.event === "SELECT_ASSET" ? payload.validatedInput.reference : null;
  machine.state = Object.freeze({
    ...machine.state,
    assetPath: path ?? null
  });
}
function assetSelectionTarget({ payload }) {
  return payload.validatedInput.selectionHint || "none";
}
function requestedOverlayState({ state, payload }) {
  return state === payload.overlay ? "none" : payload.overlay;
}
function exitGraphWorkspaceState({ machine }) {
  machine.state = Object.freeze({
    ...machine.state,
    graphObject: "none",
    graphObjectIndex: null
  });
}
function enterLifecycleState({ state, payload }) {
  let busy = state === "importing" || state === "exporting";
  document.body.classList.toggle("app-busy", busy);
  document.body.setAttribute("aria-busy", String(busy));
  if (state === "error" && payload.error)
    debugLog("fsm:lifecycle-error", payload.error, "error");
}
var SHARED_WORKSPACE_EVENTS = {
  SELECT_SLOT: {
    action: applySlotSelectionAction,
    target: requestedWorkspaceState
  }
};
var SHARED_OVERLAY_EVENTS = {
  TOGGLE_OVERLAY: { target: requestedOverlayState },
  CLOSE_OVERLAY: { target: "none" },
  OUTSIDE_CLICK: { target: "none" },
  ESCAPE: { target: "none" },
  SELECT_SLOT: {
    target: ({ state, payload }) => payload.slotId == null ? state : "none"
  }
};
var GRAPH_OBJECT_EVENTS = {
  SELECT_ASSET: {
    action: applyGraphObjectSelectionAction,
    target: "none"
  },
  SELECT_GRAPH_OBJECT: {
    action: applyGraphObjectSelectionAction,
    target: ({ payload }) => payload.validatedInput.reference !== null ? "selected" : "none"
  },
  CLEAR_GRAPH_OBJECT: {
    action: applyGraphObjectSelectionAction,
    target: "none"
  },
  SELECT_SLOT: {
    action: applyGraphObjectSelectionAction,
    target: "none"
  }
};
var ASSET_SELECTION_EVENTS = {
  SELECT_ASSET: {
    action: applyAssetSelectionAction,
    target: assetSelectionTarget
  },
  CLEAR_ASSET_SELECTION: {
    action: applyAssetSelectionAction,
    target: "none"
  },
  SELECT_SLOT: {
    action: applyAssetSelectionAction,
    target: ({ machine, payload }) => payload.validatedInput.reference !== null && payload.validatedInput.selectionHint === "clear-graph-object" ? machine.state.assetSelection : "none"
  }
};
var APP_STATE_DEFINITIONS = {
  lifecycle: {
    booting: {
      objects: ["project"],
      entry: enterLifecycleState,
      on: { READY: { target: "ready" } }
    },
    ready: {
      objects: ["project", "ui"],
      entry: enterLifecycleState,
      on: {
        BEGIN_IMPORT: { target: "importing" },
        BEGIN_EXPORT: { target: "exporting" },
        FAIL: { target: "error" }
      }
    },
    importing: {
      objects: ["project", "data", "images", "charts", "slots"],
      entry: enterLifecycleState,
      on: { COMPLETE: { target: "ready" }, FAIL: { target: "error" } }
    },
    exporting: {
      objects: ["project", "layout", "labels", "captions", "data", "images", "charts", "slots"],
      entry: enterLifecycleState,
      on: { COMPLETE: { target: "ready" }, FAIL: { target: "error" } }
    },
    error: {
      objects: ["project", "ui"],
      entry: enterLifecycleState,
      on: { RECOVER: { target: "ready" } }
    }
  },
  workspace: {
    project: {
      objects: [
        "project",
        "layout",
        "labels",
        "captions",
        "data",
        "images",
        "files",
        "charts",
        "slots",
        "ui"
      ],
      on: SHARED_WORKSPACE_EVENTS
    },
    "slot.graph": {
      objects: [
        "slots",
        "charts",
        "data",
        "images",
        "files",
        "layout",
        "labels",
        "captions",
        "ui"
      ],
      exit: exitGraphWorkspaceState,
      on: SHARED_WORKSPACE_EVENTS
    },
    "slot.image": {
      objects: [
        "slots",
        "charts",
        "data",
        "images",
        "files",
        "layout",
        "labels",
        "captions",
        "ui"
      ],
      on: SHARED_WORKSPACE_EVENTS
    }
  },
  overlay: {
    none: {
      objects: ["ui"],
      on: SHARED_OVERLAY_EVENTS
    },
    layout: {
      objects: ["layout", "slots", "ui"],
      on: SHARED_OVERLAY_EVENTS
    },
    label: {
      objects: ["labels", "slots", "ui"],
      on: SHARED_OVERLAY_EVENTS
    },
    caption: {
      objects: ["captions", "slots", "labels", "ui"],
      on: SHARED_OVERLAY_EVENTS
    },
    print: {
      objects: ["project", "layout", "labels", "captions", "charts", "images", "slots", "ui"],
      on: SHARED_OVERLAY_EVENTS
    },
    readme: {
      objects: ["project", "ui"],
      on: SHARED_OVERLAY_EVENTS
    }
  },
  assetSelection: {
    none: {
      objects: ["data", "images", "ui"],
      on: ASSET_SELECTION_EVENTS
    },
    csv: {
      objects: ["data", "images", "ui"],
      on: ASSET_SELECTION_EVENTS
    },
    image: {
      objects: ["data", "images", "ui"],
      on: ASSET_SELECTION_EVENTS
    },
    directory: {
      objects: ["data", "images", "ui"],
      on: ASSET_SELECTION_EVENTS
    }
  },
  graphObject: {
    none: {
      objects: ["slots", "charts"],
      on: GRAPH_OBJECT_EVENTS
    },
    selected: {
      objects: ["slots", "charts"],
      on: GRAPH_OBJECT_EVENTS
    }
  }
};
var interfaceFSM;
function initializeInterfaceFSM() {
  interfaceFSM = new InterfaceStateMachine(APP_STATE_DEFINITIONS);
}
function isSlotSelected(slot) {
  return !!slot && slot.id === interfaceRuntime.selectedSlotId;
}
var interfaceRuntime = {
  selectedSlotId: null,
  dashboardZoomIntent: 100,
  dashboardZoomLocked: false,
  dashboardZoomLockedWidth: null
};

// sourcecode/application/public_api/layout_annotations.js
function swapSlots(sourceSlotId, targetSlotId) {
  const [result, frontendState, projection] = dispatchProjectCommand("SLOTS_SWAPPED", { sourceSlotId, targetSlotId });
  if (result.committed) renderDashboard(projection, frontendState);
  return result.committed;
}
function setSelectedSlot(slotId, direction = "ui-to-fsm", pendingContentType = null) {
  const [state, , projection] = dispatchSlotSelection(slotId, pendingContentType, direction);
  if (projection === null) return state;
  updateGraphView(projection, state);
  schedulePlotResize();
  return state;
}
function mergeSlots(slotIds = []) {
  const [result, frontendState, projection] = dispatchProjectCommand("SLOTS_MERGED", { slotIds });
  if (!result.committed) return false;
  renderDashboard(projection, frontendState);
  return readLayoutApiState();
}
function splitSlots(slotIds = []) {
  const [result, frontendState, projection] = dispatchProjectCommand("SLOTS_SPLIT", { slotIds });
  if (!result.committed) return false;
  renderDashboard(projection, frontendState);
  return readLayoutApiState();
}
function insertEmptyImageIntoSelectedSlot() {
  const slotId = interfaceFSM.readState().selectedSlotId, context = appFSM.query("slot-selection-context", { slotId });
  if (!context || context.contentType !== "image") return null;
  const imageInput = {
    bytes: new TextEncoder().encode('<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="900" viewBox="0 0 1600 900"></svg>'),
    name: "빈 이미지.svg",
    mime: "image/svg+xml"
  }, [result, frontendState, projection] = dispatchProjectCommand("SLOT_IMAGE_IMPORTED", { slotId, operation: "images.insertEmpty", imageInput });
  if (!result.committed) return null;
  const path = result.changed.assets.find((asset) => asset.role === "created" && asset.kind === "image").path, target = appFSM.query("project-api", { operation: "assets.readDeletionTarget", path }).target;
  renderDashboard(projection, frontendState);
  return target;
}
function setSlotContentType(slotId, contentType) {
  const [result, frontendState, projection] = dispatchProjectCommand("SLOT_TYPE_CHANGED", { slotId, contentType });
  if (result.committed) renderDashboard(projection, frontendState);
  return null;
}
function applyImageSettingsFromValues(slotId, values = {}) {
  if (!appFSM.query("project-api", { operation: "images.readEditor", slotId })) return false;
  let [result, frontendState, projection] = dispatchProjectCommand("SLOT_IMAGE_SETTINGS_CHANGED", { slotId, settings: values });
  if (!result.committed) return false;
  applyCommittedDashboardProjection("SLOT_IMAGE_SETTINGS_CHANGED", result, frontendState, projection);
  appFSM.notify("images", "IMAGE_SETTINGS_CHANGED");
  return appFSM.query("project-api", { operation: "images.readEditor", slotId });
}
function readSelectedSlotApi() {
  return appFSM.query("project-api", {
    operation: "slots.readSelected",
    frontendState: interfaceFSM.readState()
  });
}
function resetSlotApi(slotId) {
  const [result, frontendState, projection] = dispatchProjectCommand("SLOTS_RESET", { slotIds: [slotId] });
  if (result.committed) renderDashboard(projection, frontendState);
  return null;
}
function prepareDashboardFileDrop(slotId) {
  const context = appFSM.query("slot-selection-context", { slotId });
  if (!context) return false;
  if (interfaceFSM.readState().selectedSlotId === slotId) return true;
  const [state, , projection] = dispatchSlotSelection(slotId, null, "model-to-fsm");
  if (projection === null || state.selectedSlotId !== slotId) return false;
  updateGraphView(projection, state);
  return true;
}
function finishDashboardFileDrop() {
  clearSlotDragState();
  return null;
}
function readImageEditorApi() {
  return appFSM.query("project-api", {
    operation: "images.readEditor",
    slotId: appFSM.readState().selectedSlotId
  });
}
function setAnnotationEnabled(kind, enabled) {
  if (kind === "label")
    appFSM.send("LABEL_SETTINGS_CHANGED", { enabled, direction: "ui-to-fsm" });
  else
    appFSM.send("CAPTION_SETTINGS_CHANGED", { enabled, direction: "ui-to-fsm" });
  renderDashboard();
  debugLog(`annotation:${kind}`, { enabled });
  appFSM.notify(
    kind === "label" ? "labels" : "captions",
    "ANNOTATION_VISIBILITY_CHANGED"
  );
}
function applyCaptionSettings(notify = true) {
  syncDashboardCaption();
  debugLog("annotation:caption-settings", {
    name: activeProject.captionName,
    bold: activeProject.captionNameBold,
    ...activeProject.captionSettings
  });
  if (notify) appFSM.notify("captions", "CAPTION_SETTINGS_CHANGED");
}
function readGlobalCaptionState() {
  return appFSM.query("project-api", { operation: "captions.readGlobal" });
}
function readSlotCaptionState(slotId) {
  return appFSM.query("project-api", { operation: "captions.readSlot", slotId });
}
function setCaptionsApiEnabled(enabled) {
  let [result, frontendState, projection] = dispatchProjectCommand("CAPTION_SETTINGS_CHANGED", { enabled });
  if (!result.committed) return false;
  const state = readGlobalCaptionState();
  applyCommittedDashboardProjection("CAPTION_SETTINGS_CHANGED", result, frontendState, projection);
  debugLog("annotation:caption", { enabled: state.enabled });
  appFSM.notify("captions", "ANNOTATION_VISIBILITY_CHANGED");
  return state;
}
function setGlobalCaptionText(text) {
  let [result, frontendState, projection] = dispatchProjectCommand("CAPTION_TEXT_INPUT", {
    target: { kind: "global" },
    text
  });
  if (!result.committed) return false;
  const state = readGlobalCaptionState();
  syncDashboardCaption(state, projection, frontendState);
  return state;
}
function setSlotCaptionText(slotId, text) {
  let [result] = dispatchProjectCommand("CAPTION_TEXT_INPUT", {
    target: { kind: "slot", id: slotId },
    text
  });
  return result.committed ? readSlotCaptionState(slotId) : false;
}
function insertCaptionsApiSlotCaptions(slotIds = null) {
  let [result, frontendState, projection] = dispatchProjectCommand("SLOT_CAPTIONS_INSERTED", { slotIds });
  if (!result.committed) return false;
  let state = readGlobalCaptionState();
  syncDashboardCaption(state, projection, frontendState);
  return state;
}
function setCaptionsApiName(name) {
  let [result, frontendState, projection] = dispatchProjectCommand("CAPTION_SETTINGS_CHANGED", { name });
  if (!result.committed) return false;
  const state = readGlobalCaptionState();
  syncDashboardCaption(state, projection, frontendState);
  appFSM.notify("captions", "CAPTION_NAME_CHANGED");
  return state;
}
function setCaptionsApiNameBold(bold) {
  let [result, frontendState, projection] = dispatchProjectCommand("CAPTION_SETTINGS_CHANGED", { nameBold: bold });
  if (!result.committed) return false;
  const state = readGlobalCaptionState();
  syncDashboardCaption(state, projection, frontendState);
  appFSM.notify("captions", "CAPTION_NAME_WEIGHT_CHANGED");
  return state;
}
function setCaptionsApiSettings(patch = {}) {
  let [result, frontendState, projection] = dispatchProjectCommand("CAPTION_SETTINGS_CHANGED", { settings: patch });
  if (!result.committed) return false;
  const state = readGlobalCaptionState();
  syncDashboardCaption(state, projection, frontendState);
  appFSM.notify("captions", "CAPTION_SETTINGS_CHANGED");
  return state;
}
function readPrintApiSettings() {
  return appFSM.query("project-api", { operation: "print.readSettings" });
}
function setPrintApiSettings(values = {}) {
  let [result] = dispatchProjectCommand("EXPORT_SETTINGS_CHANGED", { settings: values });
  return result.committed ? readPrintApiSettings() : false;
}
function savePrintApi(options = {}) {
  return appFSM.run("exporting", "print.save", () => {
    const snapshot = appFSM.query("export", { operation: "print.save" });
    return exportDashboardTarget(snapshot, options.onStatus);
  });
}
function capturePrintApi(options = {}) {
  return appFSM.run("exporting", "print.capture", () => {
    const snapshot = appFSM.query("export", { operation: "print.capture" });
    return exportDashboard(snapshot, options.onStatus);
  });
}
function readLabelsApiState() {
  return appFSM.query("project-api", {
    operation: "labels.readState",
    slotId: interfaceFSM.readState().selectedSlotId
  });
}
function setLabelsApiEnabled(enabled) {
  let [result, frontendState, projection] = dispatchProjectCommand("LABEL_SETTINGS_CHANGED", { enabled });
  if (!result.committed) return false;
  applyCommittedDashboardProjection("LABEL_SETTINGS_CHANGED", result, frontendState, projection);
  debugLog("annotation:label", { enabled });
  appFSM.notify("labels", "ANNOTATION_VISIBILITY_CHANGED");
  return readLabelsApiState();
}
function setLabelsApiSettings(patch = {}) {
  let [result, frontendState, projection] = dispatchProjectCommand("LABEL_SETTINGS_CHANGED", { settings: patch });
  if (!result.committed) return false;
  applyCommittedDashboardProjection("LABEL_SETTINGS_CHANGED", result, frontendState, projection);
  debugLog("mantine:label-settings", { ...patch });
  appFSM.notify("labels", "LABEL_SETTINGS_CHANGED");
  return readLabelsApiState();
}
function updateLabelsApiPosition(x, y, eventName = null) {
  let [result, frontendState, projection] = dispatchProjectCommand("LABEL_POSITION_CHANGED", { x, y });
  if (!result.committed) return false;
  applyCommittedDashboardProjection("LABEL_POSITION_CHANGED", result, frontendState, projection);
  if (eventName) {
    debugLog("mantine:label-settings", { x, y });
    appFSM.notify("labels", eventName);
  }
  return readLabelsApiState();
}
function setLabelsApiPosition(x, y) {
  return updateLabelsApiPosition(x, y, "LABEL_POSITION_CHANGED");
}
function finishLabelsApiPositionInteraction() {
  debugLog("mantine:label-position", {});
  appFSM.notify("labels", "LABEL_POSITION_DRAGGED");
  return readLabelsApiState();
}
function resetLabelsApiPosition() {
  let [result, frontendState, projection] = dispatchProjectCommand("LABEL_POSITION_CHANGED", { reset: true });
  if (!result.committed) return false;
  applyCommittedDashboardProjection("LABEL_POSITION_CHANGED", result, frontendState, projection);
  appFSM.notify("labels", "LABEL_POSITION_RESET");
  return readLabelsApiState();
}
function readAppearanceApiPalette() {
  return appFSM.query("project-api", { operation: "appearance.readPalette" });
}
function setAppearanceApiPalette(values) {
  return applyUiPaletteValues(values);
}
function resetAppearanceApiPalette() {
  return applyUiPaletteValues({ ...DEFAULT_UI_PALETTE });
}
function readLayoutApiState(previewWidth = null) {
  const layout2 = appFSM.query("project-api", { operation: "layout.readState", renderedWidth: previewWidth }), session = interfaceFSM.readState();
  return Object.freeze({ ...layout2, zoom: session.dashboardZoomIntent, zoomLocked: session.dashboardZoomLocked });
}
function setLayoutApiStyle(patch = {}) {
  const [result, frontendState, projection] = dispatchProjectCommand("LAYOUT_STYLE_CHANGED", patch);
  if (!result.committed) return false;
  applyCommittedDashboardProjection("LAYOUT_STYLE_CHANGED", result, frontendState, projection);
  appFSM.notify("layout", "LAYOUT_STYLE_CHANGED");
  return readLayoutApiState();
}
function setLayoutApiGrid(rows, cols) {
  const [result, frontendState, projection] = dispatchProjectCommand("GRID_LAYOUT_CHANGED", { rows, cols });
  if (!result.committed) return false;
  applyCommittedDashboardProjection("GRID_LAYOUT_CHANGED", result, frontendState, projection);
  appFSM.notify("layout", "LAYOUT_STYLE_CHANGED");
  return readLayoutApiState();
}
function setLayoutApiZoom(value2) {
  const session = interfaceFSM.readState();
  const state = appFSM.send("SET_DASHBOARD_ZOOM", { value: value2 });
  if (state.revision !== session.revision) renderDashboard();
  return readLayoutApiState();
}
function commitLayoutApiZoom() {
  appFSM.notify("layout", "DASHBOARD_ZOOM_CHANGED");
  return readLayoutApiState();
}
function setLayoutApiZoomLocked(locked) {
  const session = interfaceFSM.readState();
  let renderedWidth = null;
  if (locked === true && !session.dashboardZoomLocked) {
    renderedWidth = readDashboardRenderedWidth();
    if (!Number.isFinite(renderedWidth) || renderedWidth <= 0) return false;
  }
  const state = appFSM.send("SET_DASHBOARD_ZOOM_LOCK", { locked: locked === true, renderedWidth });
  if (state.revision !== session.revision) renderDashboard();
  return readLayoutApiState();
}
function resetLayoutApiZoom() {
  const session = interfaceFSM.readState();
  const state = appFSM.send("RESET_DASHBOARD_ZOOM");
  if (state.revision !== session.revision) renderDashboard();
  return readLayoutApiState();
}

// sourcecode/application/adapter.js
function readWorkspaceHint() {
  const slot = readBackendProjection("slot-selection-context", { slotId: interfaceFSM.readState().selectedSlotId });
  return !slot ? "project" : slot.contentType === "image" ? "slot.image" : "slot.graph";
}
function installSlotClickController() {
  return installSlotClickControllerProjection({ slots: { select: setSelectedSlot, swap: swapSlots } });
}
function renderDashboard(projection = readBackendProjection("renderer"), state = interfaceFSM.readState()) {
  return renderDashboardProjection(projection, state, dashboardFrontendActions());
}
function startupCoreRuntime() {
  const projection = readBackendProjection("renderer"), state = interfaceFSM.readState(), actions = { ...dashboardFrontendActions(), slots: { select: setSelectedSlot, swap: swapSlots } }, presentation = startupCoreRuntimeProjection(projection, state, actions);
  appFSM.notify("layout", "LAYOUT_STYLE_CHANGED");
  return presentation;
}
function applyCommittedDashboardProjection(event, result, state, projection) {
  if (!result.committed) return "NONE";
  return applyDashboardProjectionInvalidation(event, result, state, projection, dashboardFrontendActions());
}
function dashboardFrontendActions() {
  return {
    refreshDashboard: renderDashboard,
    graphRangesChanged(slotId, chartId, ranges) {
      const current = readBackendProjection("project-api", { operation: "graphs.readLayout", selectedSlotId: slotId });
      if (!current || current.chartId !== chartId || !current.editable) return false;
      const axes = {}, keys = { xaxis: "xBottom", xaxis2: "xTop", yaxis: "yLeft", yaxis2: "yRight" };
      for (const [axis, range] of Object.entries(ranges)) {
        const key = keys[axis], setting = current.settings.axes[key];
        if (!setting || !Array.isArray(range) || range.length !== 2) continue;
        const min = axisRangeValueFromPlotly(range[0], setting.scaleType), max = axisRangeValueFromPlotly(range[1], setting.scaleType);
        if (min !== setting.min || max !== setting.max) axes[key] = { min, max };
      }
      if (!Object.keys(axes).length) return false;
      const [result] = dispatchProjectCommand("CHART_LAYOUT_CHANGED", {
        slotId,
        chartId,
        settings: { globalSettings: { axes } }
      });
      return result.committed;
    }
  };
}
function syncDashboardCaption(view, projection = readBackendProjection("renderer"), state = interfaceFSM.readState()) {
  const style = projection.layout.slotStyle, width = state.dashboardZoomLocked ? state.dashboardZoomLockedWidth : style.referenceWidth * state.dashboardZoomIntent / 100;
  return syncDashboardCaptionProjection(view || projection.annotations.captions, width / style.referenceWidth);
}
function applyReferenceGeometry(element) {
  const style = readBackendProjection("renderer").layout.slotStyle, state = interfaceFSM.readState(), width = state.dashboardZoomLocked ? state.dashboardZoomLockedWidth : style.referenceWidth * state.dashboardZoomIntent / 100;
  return applyReferenceGeometryProjection(element, style, width);
}
function applySlotStyle(_fromControls = false, notify = true) {
  applySlotStyleProjection(readBackendProjection("renderer").layout.slotStyle, interfaceFSM.readState());
  if (notify) appFSM.notify("layout", "LAYOUT_STYLE_CHANGED");
}
function applyDashboardZoom(resize = true) {
  return applyDashboardZoomProjection(readBackendProjection("renderer").layout, interfaceFSM.readState(), resize);
}
function syncDashboardZoomDisplay() {
  const width = readDashboardRenderedWidth(), state = interfaceFSM.readState();
  if (!width) return;
  const reference = readBackendProjection("renderer").layout.slotStyle.referenceWidth;
  return state.dashboardZoomLocked ? Math.max(50, Math.min(200, Math.round(width / reference * 100))) : Math.round(state.dashboardZoomIntent);
}
function updateFileAvailability() {
  const state = interfaceFSM.readState();
  if (state.selectedSlotId !== null && state.overlay === "readme")
    appFSM.send("CLOSE_OVERLAY", { reason: "slot-selected" });
}
function dispatchSlotSelection(slotId, pendingContentType = null, direction = "ui-to-fsm") {
  const validatedInput = validateFrontendIntent("SELECT_SLOT", { slotId, direction });
  if (!validatedInput.accepted) return [interfaceFSM.readState(), null, null];
  let state = interfaceFSM.send("SELECT_SLOT", { validatedInput }), projectResult = null;
  if (state.selectedSlotId !== null && pendingContentType !== null) {
    const context = readBackendProjection("slot-selection-context", { slotId: state.selectedSlotId });
    if (context?.empty && context.contentType !== pendingContentType) {
      [projectResult, state] = dispatchProjectCommand("SLOT_TYPE_CHANGED", {
        slotId: state.selectedSlotId,
        contentType: pendingContentType
      });
    }
  }
  return [state, projectResult, readBackendProjection("renderer", { frontendState: state })];
}
function updateGraphView(projection = readBackendProjection("renderer"), state = interfaceFSM.readState()) {
  debugLog("updateGraphView", { selectedSlotId: state.selectedSlotId });
  return updateGraphViewProjection(projection, state, dashboardFrontendActions());
}
function swapSlotContents(source, target) {
  return swapSlots(source?.id, target?.id);
}
function applyUiPalette(palette, notify = true) {
  const result = applyUiPaletteProjection(palette);
  if (notify) appFSM.notify("ui", "UI_PALETTE_CHANGED");
  return result;
}
function applyCurrentUiPalette(notify = true) {
  applyUiPalette(readBackendProjection("renderer", { operation: "ui-palette" }), notify);
  return renderDashboard();
}
function applyUiPaletteValues(values, notify = true) {
  const [result, state, projection] = dispatchProjectCommand("APPEARANCE_CHANGED", { palette: values });
  if (!result.committed) return false;
  applyCommittedDashboardProjection("APPEARANCE_CHANGED", result, state, projection);
  if (notify) appFSM.notify("ui", "UI_PALETTE_CHANGED");
  return readAppearanceApiPalette();
}
function renderProjectObject(projection, state) {
  const presentation = renderDashboard(projection, state);
  updateFileAvailability();
  return presentation;
}
var BACKEND_REFERENCE_EVENTS = /* @__PURE__ */ new Set(["SELECT_SLOT", "SELECT_ASSET", "SELECT_GRAPH_OBJECT"]);
var PROJECT_COMMANDS = new Set(Object.keys(PROJECT_COMMAND_ACTIONS));
function dispatchProjectQuery(query, payload) {
  return readBackendProjection(query, payload);
}
function dispatchInterfaceEvent(event, payload = {}) {
  const request = event === "SELECT_GRAPH_OBJECT" ? { ...payload, selectedSlotId: interfaceFSM.readState().selectedSlotId } : payload ?? {}, validatedInput = BACKEND_REFERENCE_EVENTS.has(event) ? validateFrontendIntent(event, request) : { event, accepted: true, payload };
  if (!validatedInput.accepted) return interfaceFSM.readState();
  return interfaceFSM.send(event, { ...payload, validatedInput });
}
function runLifecycleTask(lifecycle, event, task) {
  const state = interfaceFSM.readState();
  if (state.lifecycle !== "ready")
    return Promise.reject(
      Error(`현재 ${state.lifecycle} 상태에서는 ${event} 작업을 시작할 수 없습니다.`)
    );
  if (lifecycle !== "importing" && lifecycle !== "exporting")
    return Promise.reject(Error("작업 lifecycle은 importing 또는 exporting이어야 합니다."));
  dispatchInterfaceEvent("LIFECYCLE_START", { lifecycle, event });
  const complete = (result) => {
    dispatchInterfaceEvent("LIFECYCLE_COMPLETE", { event, outcome: result });
    return result;
  };
  const fail = (error) => {
    dispatchInterfaceEvent("LIFECYCLE_FAILED", { event, message: error?.message || String(error) });
    throw error;
  };
  let completion;
  try {
    completion = task();
  } catch (error) {
    return Promise.reject(error).then(void 0, fail);
  }
  return Promise.resolve(completion).then(complete, fail);
}
function dispatchProjectCommand(event, payload = {}) {
  if (!PROJECT_COMMANDS.has(event)) throw Error(`${event}는 등록된 ProjectObject command가 아닙니다.`);
  const result = projectEFSM.send(event, payload), frontendBefore = interfaceFSM.readState();
  if (!result.committed) return [result, frontendBefore, null];
  const reconciliationInput = buildFrontendReconciliationInput(event, result, frontendBefore), state = interfaceFSM.reconcileProjectResult(event, reconciliationInput), projection = readBackendProjection("renderer", { frontendState: state, mutationResult: result });
  return [result, state, projection];
}
var appFSM = Object.freeze({
  get state() {
    return interfaceFSM.readState();
  },
  get writeLocks() {
    return interfaceFSM.writeLocks;
  },
  readState: () => interfaceFSM.readState(),
  query: (kind, request) => dispatchProjectQuery(kind, request),
  definition: (...args) => interfaceFSM.definition(...args),
  send(event, payload = {}) {
    if (PROJECT_COMMANDS.has(event)) {
      const [, state] = dispatchProjectCommand(event, payload);
      return state;
    }
    return dispatchInterfaceEvent(event, payload);
  },
  notify: (...args) => interfaceFSM.notify(...args),
  run: (...args) => runLifecycleTask(...args),
  ready: () => interfaceFSM.ready(readWorkspaceHint()),
  subscribe: (...args) => interfaceFSM.subscribe(...args)
});
function selectedProjectAsset() {
  let path = appFSM.state.assetPath;
  return path ? projectVfs.resolve(path) : null;
}
function selectedProjectCsv() {
  let selected = selectedProjectAsset();
  return selected?.kind === "csv" ? selected.asset : null;
}
function dashboardProjectionEffect(event, payload = {}) {
  if (event === "PROJECT_NODE_MOVED" || event === "PROJECT_TRASH_EMPTIED")
    return (payload.removedGraphReferenceCount || 0) > 0 || (payload.resetImageSlotCount || 0) > 0 ? "FULL_DASHBOARD" : "NONE";
  if (event === "SLOTS_SWAPPED") return "FULL_DASHBOARD";
  return "NONE";
}
function dispatchDashboardAffectingEvent(event, payload = {}) {
  const [result, state, projection] = dispatchProjectCommand(event, payload), projectionEffect = applyCommittedDashboardProjection(event, result, state, projection);
  return { state, payload, projectionEffect };
}
function activateChartModel(id) {
  let chart = getChart(id);
  if (!chart) {
    debugLog("chart:activate-missing", { chartId: id });
    return null;
  }
  if (chart.editor?.editable !== false) {
    for (let object of chart.editor?.objects || [])
      if (!getProjectCsv(object.csvId))
        throw Error("차트가 참조하는 프로젝트 CSV가 없습니다.");
  }
  debugLog("chart:activate", { chartId: id });
  return chart;
}

// sourcecode/application/public_api/graphs.js
function graphEditorSelectCsv(path) {
  return selectProjectCsv(path);
}
function createEmptyProjectCsvAndSelect() {
  const csv = createEmptyProjectCsv();
  if (csv?.committed === false) return csv;
  return selectProjectCsv(projectAssetPath(csv));
}
function graphEditorSelectObject(index) {
  return appFSM.send("SELECT_GRAPH_OBJECT", {
    index,
    selectedSlotId: interfaceFSM.readState().selectedSlotId,
    selectAsset: true,
    direction: "ui-to-fsm"
  });
}
function graphEditorObjectValues(chartId, index, values = {}) {
  const [result, state, projection] = dispatchProjectCommand("GRAPH_OBJECTS_REPLACED", {
    chartId,
    operation: "graphs.setObjectValues",
    index,
    values
  });
  if (!result.committed) return result;
  const chart = appFSM.query("project-api", { operation: "graphs.readData", chartId }).chart;
  renderDashboard(projection, state);
  return chart;
}
function setGraphObjectValuesApi(index, values = {}) {
  const context = appFSM.query("project-api", {
    operation: "graphs.readData",
    frontendState: interfaceFSM.readState()
  });
  return graphEditorObjectValues(context.chart?.id ?? null, index, values);
}
function graphEditorAdd(slotId, csvId) {
  const slot = appFSM.query("project-api", { operation: "slots.readSelected", frontendState: { selectedSlotId: slotId } });
  if (!slot) return null;
  const event = slot.content.chart == null ? "SLOT_DATA_CONNECTED" : "GRAPH_OBJECTS_REPLACED", [result, state, projection] = dispatchProjectCommand(event, { slotId, csvId, operation: "graphs.addObject" });
  if (!result.committed) return result;
  const chart = appFSM.query("project-api", { operation: "graphs.readData", frontendState: { selectedSlotId: slotId } }).chart;
  renderDashboard(projection, state);
  return chart;
}
function addGraphObjectApi(csvId) {
  const state = interfaceFSM.readState();
  if (csvId === void 0) csvId = appFSM.query("project-api", {
    operation: "graphs.readData",
    frontendState: state
  }).currentCsv?.id;
  return graphEditorAdd(state.selectedSlotId, csvId);
}
function graphEditorMove(chartId, from, to) {
  const context = appFSM.query("project-api", { operation: "graphs.readData", chartId });
  if (from === to && context.chart?.editor.editable !== false && Number.isInteger(from) && from >= 0 && from < context.objects.length) return context.chart;
  const [result, state, projection] = dispatchProjectCommand("GRAPH_OBJECTS_REPLACED", {
    chartId,
    operation: "graphs.moveObject",
    from,
    to
  });
  if (!result.committed) return result;
  const chart = appFSM.query("project-api", { operation: "graphs.readData", chartId }).chart;
  renderDashboard(projection, state);
  return chart;
}
function graphEditorDelete(chartId, index) {
  const [result, state, projection] = dispatchProjectCommand("GRAPH_OBJECTS_REPLACED", {
    chartId,
    operation: "graphs.deleteObject",
    index
  });
  if (!result.committed) return result;
  const chart = appFSM.query("project-api", { operation: "graphs.readData", chartId }).chart;
  renderDashboard(projection, state);
  return chart;
}
function moveGraphObjectApi(from, to) {
  const context = appFSM.query("project-api", {
    operation: "graphs.readData",
    frontendState: interfaceFSM.readState()
  });
  return graphEditorMove(context.chart?.id ?? null, from, to);
}
function deleteGraphObjectApi(index) {
  const context = appFSM.query("project-api", {
    operation: "graphs.readData",
    frontendState: interfaceFSM.readState()
  });
  return graphEditorDelete(context.chart?.id ?? null, index);
}
function graphEditorHeaderLines(csvId, value2) {
  const [result, state, projection] = dispatchProjectCommand("DATA_OBJECT_REPLACED", { csvId, headerLines: value2 });
  if (!result.committed) return result;
  const updated = result.changed.assets.find((asset) => asset.kind === "csv" && asset.role === "updated"), read = appFSM.query("project-api", { operation: "assets.readDeletionTarget", path: updated.path });
  renderDashboard(projection, state);
  return read.target.headerLines;
}
function graphEditorSetEditable(slotId, chartId, editable) {
  const [result, state, projection] = dispatchProjectCommand("CHART_MODEL_REPLACED", { slotId, chartId, editable });
  if (!result.committed) return result;
  const chart = appFSM.query("project-api", { operation: "graphs.readData", chartId }).chart;
  renderDashboard(projection, state);
  return chart.editor.editable;
}
function setGraphEditableApi(editable = null) {
  const state = interfaceFSM.readState(), context = appFSM.query("project-api", { operation: "graphs.readData", frontendState: state });
  if (!context.chart) return null;
  const next = typeof editable === "boolean" ? editable : context.chart.editor.editable === false;
  return graphEditorSetEditable(state.selectedSlotId, context.chart.id, next);
}
function readGraphDataApi() {
  const state = interfaceFSM.readState();
  return appFSM.query("project-api", { operation: "graphs.readData", frontendState: {
    selectedSlotId: state.selectedSlotId,
    assetPath: state.assetPath,
    assetSelection: state.assetSelection,
    graphObjectIndex: state.graphObjectIndex
  } });
}
function readGraphLayoutApi() {
  return appFSM.query("project-api", { operation: "graphs.readLayout", selectedSlotId: interfaceFSM.readState().selectedSlotId });
}
function readGraphPaletteApi() {
  return appFSM.query("project-api", {
    operation: "graphs.readPalette",
    selectedSlotId: interfaceFSM.readState().selectedSlotId
  });
}
async function importSelectedGraphFile(file, slotId) {
  const [copied] = await prepareCopiedImportFiles([file]), [result, state, projection] = dispatchProjectCommand("SLOT_CHART_IMPORTED", { slotId, file: copied });
  if (!result.committed) return result;
  const chart = appFSM.query("project-api", {
    operation: "graphs.readData",
    frontendState: { selectedSlotId: slotId }
  }).chart;
  renderDashboard(projection, state);
  updateFileAvailability();
  status(`${file.name}을 슬롯에 불러왔습니다.`);
  return chart;
}
function graphEditorUpdateLayout(slotId, chartId, values) {
  const [result, state, projection] = dispatchProjectCommand("CHART_LAYOUT_CHANGED", { slotId, chartId, settings: values });
  if (!result.committed) return result;
  const output = appFSM.query("project-api", { operation: "graphs.readLayout", selectedSlotId: slotId });
  renderDashboard(projection, state);
  return output;
}
function updateGraphLayoutApi(values = {}) {
  const slotId = interfaceFSM.readState().selectedSlotId, context = appFSM.query("project-api", { operation: "graphs.readLayout", selectedSlotId: slotId });
  return graphEditorUpdateLayout(slotId, context?.chartId ?? null, values);
}
function graphEditorApplyPalette(chartId, colors) {
  const [result, state, projection] = dispatchProjectCommand("GRAPH_OBJECTS_REPLACED", { chartId, operation: "graphs.applyPalette", colors });
  if (!result.committed) return result;
  const chart = appFSM.query("project-api", { operation: "graphs.readData", chartId }).chart;
  renderDashboard(projection, state);
  return chart;
}
function applyGraphPaletteApi(colors) {
  const context = appFSM.query("project-api", { operation: "graphs.readData", frontendState: interfaceFSM.readState() });
  return graphEditorApplyPalette(context.chart?.id ?? null, colors);
}
function downloadSlotFfsx() {
  return appFSM.run("exporting", "graphs.exportFfsx", () => exportSelectedGraph(interfaceFSM.readState().selectedSlotId, "graphs.exportFfsx"));
}
async function exportSelectedGraph(slotId, operation) {
  const payload = appFSM.query("export", {
    operation,
    slotId,
    stamp: (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-")
  });
  if (payload === null) return;
  await downloadExportPayload(payload);
}
function downloadPlotlyJson() {
  return appFSM.run("exporting", "graphs.exportPlotlyJson", () => exportSelectedGraph(interfaceFSM.readState().selectedSlotId, "graphs.exportPlotlyJson"));
}

// sourcecode/application/public_api/assets.js
function readAssetFileKind(file) {
  return readBackendProjection("project-api", {
    operation: "assets.fileKind",
    file: { name: file?.name, type: file?.type }
  });
}
function readAssetCollisionModel(file, directory, reservedPaths = null) {
  return readBackendProjection("project-api", {
    operation: "assets.collisionModel",
    file: { name: file?.name, type: file?.type },
    directory,
    reservedPaths: Array.from(reservedPaths || [])
  });
}
function readAssetImportPlan(model, choice = "rename", reservedPaths = null) {
  return readBackendProjection("project-api", {
    operation: "assets.resolveImportPlan",
    model: immutableProjectCopy(model),
    choice,
    reservedPaths: Array.from(reservedPaths || [])
  });
}
async function prepareCopiedImportFiles(files) {
  const copied = [];
  for (const file of files)
    copied.push({ name: file.name, type: file.type, bytes: new Uint8Array(await file.arrayBuffer()).slice() });
  return copied;
}
async function collectCompletedImportChoices(files, directory, choosePlan) {
  if (typeof choosePlan !== "function") throw Error("프로젝트 자산 가져오기 계획이 없습니다.");
  const reserved = /* @__PURE__ */ new Set(), choices = [];
  for (const file of files) {
    const plan = await choosePlan(file, directory, reserved);
    if (!plan) return null;
    if (typeof plan.path !== "string" || !(plan.replaceId === null || Number.isInteger(plan.replaceId) && plan.replaceId > 0))
      throw Error("프로젝트 자산 가져오기 계획이 올바르지 않습니다.");
    choices.push({ path: plan.path, replaceId: plan.replaceId });
    reserved.add(plan.path);
  }
  return choices;
}
function readImportedAssets(result) {
  return result.changed.assets.map((fact) => readBackendProjection(
    "project-api",
    { operation: "assets.readDeletionTarget", path: fact.path }
  ).target);
}
async function importProjectFilesToDirectory(files, directory, planImport) {
  const list = Array.from(files || []);
  if (!list.length) return [];
  const choices = await collectCompletedImportChoices(list, directory, planImport);
  if (!choices) return null;
  const copied = await prepareCopiedImportFiles(list), [result, state, projection] = dispatchProjectCommand("ASSETS_IMPORTED", { files: copied, directory, choices });
  if (!result.committed) return result;
  const imported = readImportedAssets(result);
  updateFileAvailability();
  renderDashboard(projection, state);
  status(`${imported.length}개 자산을 프로젝트에 추가했습니다.`);
  return imported;
}
function projectDataTreeObjects() {
  return {
    files: projectObjects.read("files"),
    data: projectObjects.read("data"),
    images: projectObjects.read("images"),
    charts: projectObjects.read("charts"),
    slots: projectObjects.read("slots")
  };
}
function connectProjectAssetToSlot(path, kind, slotId) {
  if (!["csv", "image"].includes(kind)) throw Error("연결할 asset kind가 올바르지 않습니다.");
  const [result] = dispatchProjectCommand(kind === "csv" ? "SLOT_DATA_CONNECTED" : "SLOT_IMAGE_LINKED", { path, kind, slotId });
  if (!result.committed) return null;
  setSelectedSlot(slotId, "model-to-fsm");
  status("프로젝트 파일을 슬롯에 연결했습니다.");
  return null;
}
function downloadProjectAsset(path) {
  return appFSM.run("exporting", "assets.download", async () => {
    const target = path === void 0 ? interfaceFSM.readState().assetPath : path, payload = appFSM.query("export", { operation: "assets.download", path: target });
    if (payload === null) return false;
    await downloadExportPayload(payload);
    return true;
  });
}
function selectDirectoryFromTree(path) {
  return appFSM.send("SELECT_ASSET", { kind: "directory", path, direction: "ui-to-fsm" });
}
function selectProjectCsv(path) {
  const resolved = appFSM.query("project-api", { operation: "assets.readDeletionTarget", path });
  if (resolved?.kind !== "csv") return null;
  const priorRevision = interfaceFSM.readState().revision, state = appFSM.send("SELECT_ASSET", {
    kind: "csv",
    path: resolved.path,
    direction: "ui-to-fsm"
  });
  if (!(state.revision > priorRevision && state.assetSelection === "csv" && state.assetPath === resolved.path)) return null;
  const current = appFSM.query("project-api", { operation: "assets.readDeletionTarget", path: resolved.path });
  return current?.kind === "csv" ? current.target : null;
}
function selectImageFromTree(path) {
  return appFSM.send("SELECT_ASSET", { kind: "image", path, direction: "ui-to-fsm" });
}
function readAssetDeletionTarget(path) {
  return appFSM.query("project-api", { operation: "assets.readDeletionTarget", path });
}
function deleteProjectAsset(target) {
  if (!target || !["csv", "image"].includes(target.kind)) return null;
  const [result, state, projection] = dispatchProjectCommand(target.kind === "csv" ? "DATA_OBJECT_DELETED" : "IMAGE_OBJECT_DELETED", {
    target: { kind: target.kind, id: target.id, path: target.path }
  });
  if (!result.committed) return null;
  const removed = result.changed.assets[0], count = result.changed.removedGraphReferenceCount + result.changed.resetImageSlotCount;
  if (count) renderDashboard(projection, state);
  status(`${removed.name}을 프로젝트에서 삭제했습니다.`);
  return null;
}
function readProjectTrash() {
  return appFSM.query("project-api", { operation: "assets.readTrash" });
}
function projectNodeMoveOptions(path) {
  return appFSM.query("project-api", { operation: "assets.moveOptions", path });
}
function moveProjectNode(plan, useUniqueName = false) {
  if (!plan) return null;
  const [result, state, projection] = dispatchProjectCommand("PROJECT_NODE_MOVED", {
    path: plan.path,
    directory: plan.directory,
    useUniqueName
  });
  if (!result.committed) return null;
  const path = result.changed.movedPathTo, trashed = appFSM.query("project-api", { operation: "assets.isTrashed", path });
  applyCommittedDashboardProjection("PROJECT_NODE_MOVED", result, state, projection);
  status(trashed ? `${projectPathName(result.changed.movedPathFrom)}을 휴지통으로 이동했습니다.` : `${projectPathName(result.changed.movedPathFrom)}을 ${projectParentPath(path)}로 이동했습니다.`);
  return immutableProjectCopy({ path, trashed });
}
function createProjectDirectory(parent, name) {
  const [result] = dispatchProjectCommand("PROJECT_DIRECTORY_CREATED", { parent, name });
  if (!result.committed) return null;
  const path = result.changed.createdDirectoryPath;
  appFSM.send("SELECT_ASSET", { kind: "directory", path, direction: "ui-to-fsm" });
  return path;
}
function emptyProjectTrash() {
  const [result, state, projection] = dispatchProjectCommand("PROJECT_TRASH_EMPTIED", {});
  if (!result.committed) return null;
  applyCommittedDashboardProjection("PROJECT_TRASH_EMPTIED", result, state, projection);
  updateFileAvailability();
  status(`휴지통을 비웠습니다. 폴더 ${result.changed.directoryCount}개, CSV ${result.changed.csvCount}개, 이미지 ${result.changed.imageCount}개를 삭제했습니다.`);
  return null;
}
function draggableProjectAsset(path) {
  return appFSM.query("project-api", { operation: "assets.draggableAsset", path });
}
function connectProjectAssetPathToSlot(path, kind, slotId) {
  return connectProjectAssetToSlot(path, kind, slotId);
}
async function importProjectFileToSlot(file, slotId, choosePlan) {
  const target = readBackendProjection("slot-selection-context", { slotId });
  if (!target) throw Error("가져올 대상 슬롯이 없습니다.");
  const kind = readAssetFileKind(file);
  if (kind === "slot") return importSelectedGraphFile(file, target.id);
  if (!["data", "image"].includes(kind)) throw Error("지원하지 않는 파일 형식입니다.");
  const directory = PROJECT_ASSET_DIRECTORIES[kind === "data" ? "csv" : "image"], choices = await collectCompletedImportChoices([file], directory, choosePlan);
  if (!choices) return null;
  const files = await prepareCopiedImportFiles([file]), [result, state, projection] = dispatchProjectCommand("ASSETS_IMPORTED", { files, directory, choices, targetSlotId: slotId });
  if (!result.committed) return result;
  const imported = readImportedAssets(result)[0];
  renderDashboard(projection, state);
  updateFileAvailability();
  return imported;
}
async function importProjectAssetFiles(files, choosePlan) {
  return runLifecycleTask("importing", "assets.importFiles", async () => {
    const inputs = Array.from(files && typeof files[Symbol.iterator] === "function" ? files : files ? [files] : []);
    if (!inputs.length) return [];
    const targetSlotId = interfaceFSM.readState().selectedSlotId, output = [];
    for (const file of inputs) {
      const kind = readAssetFileKind(file);
      let item;
      if (kind === "slot") {
        if (targetSlotId == null) throw Error("FFSX를 불러올 슬롯을 먼저 선택하세요.");
        item = await importSelectedGraphFile(file, targetSlotId);
      } else if (kind === "data" || kind === "image") {
        if (targetSlotId != null) item = await importProjectFileToSlot(file, targetSlotId, choosePlan);
        else {
          const directory = PROJECT_ASSET_DIRECTORIES[kind === "data" ? "csv" : "image"];
          item = await importProjectFilesToDirectory([file], directory, choosePlan);
          if (Array.isArray(item)) item = item[0];
        }
      } else throw Error(`${file?.name || "파일"}: 지원하지 않는 파일 형식입니다.`);
      if (item == null || item.committed === false) return item;
      output.push(item);
    }
    return output;
  });
}

// sourcecode/application/public_api/index.js
function importProjectFile(file) {
  return appFSM.run("importing", "project.importFile", async () => {
    const [copied] = await prepareCopiedImportFiles([file]), [result, state, projection] = dispatchProjectCommand("PROJECT_LOADED", { file: copied });
    if (!result.committed) return result;
    const snapshot = appFSM.query("export", {});
    renderProjectObject(projection, state);
    appFSM.send("CLOSE_OVERLAY", { reason: "project-loaded" });
    status(`${file.name} 프로젝트를 불러왔습니다.`);
    return snapshot;
  });
}
function downloadProject() {
  return appFSM.run("exporting", "project.exportFile", async () => {
    if (interfaceFSM.readState().selectedSlotId !== null) {
      status("프로젝트 내보내기는 슬롯 선택을 해제한 뒤 사용할 수 있습니다.");
      return;
    }
    const payload = appFSM.query("export", {
      operation: "project.exportFile",
      stamp: (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-")
    });
    await downloadExportPayload(payload);
  });
}
function setProjectName(value2, trim = false) {
  const [result] = dispatchProjectCommand("PROJECT_NAME_CHANGED", { value: value2, trim });
  if (!result.committed) return null;
  return appFSM.query("project-api", { operation: "project.readName" });
}
function publishPublicApi() {
  window.FastFigureApi = Object.freeze({
    project: Object.freeze({
      readName: () => appFSM.query("project-api", { operation: "project.readName" }),
      setName: setProjectName,
      importFile: importProjectFile,
      exportFile: downloadProject
    }),
    slots: Object.freeze({
      readSelected: readSelectedSlotApi,
      select: (slotId, pendingContentType = null, direction = "ui-to-fsm") => setSelectedSlot(slotId, direction, pendingContentType),
      setContentType: setSlotContentType,
      reset: resetSlotApi,
      swap: swapSlots,
      prepareFileDrop: prepareDashboardFileDrop,
      finishFileDrop: finishDashboardFileDrop
    }),
    images: Object.freeze({
      readEditor: readImageEditorApi,
      setSettings: applyImageSettingsFromValues,
      insertEmpty: insertEmptyImageIntoSelectedSlot
    }),
    assets: Object.freeze({
      readDeletionTarget: readAssetDeletionTarget,
      delete: deleteProjectAsset,
      readTree: () => appFSM.query("project-api", { operation: "assets.readTree" }),
      isTrashed: (path) => appFSM.query("project-api", { operation: "assets.isTrashed", path }),
      movable: (path) => appFSM.query("project-api", { operation: "assets.movable", path }),
      readTrash: readProjectTrash,
      moveOptions: projectNodeMoveOptions,
      planMove: (path, directory) => appFSM.query("project-api", { operation: "assets.planMove", path, directory }),
      move: moveProjectNode,
      createDirectory: createProjectDirectory,
      createEmptyCsv: createEmptyProjectCsvAndSelect,
      emptyTrash: emptyProjectTrash,
      draggableAsset: draggableProjectAsset,
      connectToSlot: connectProjectAssetPathToSlot,
      importToDirectory: (...args) => appFSM.run("importing", "assets.importToDirectory", () => importProjectFilesToDirectory(...args)),
      importToSlot: (...args) => appFSM.run("importing", "assets.importToSlot", () => importProjectFileToSlot(...args)),
      fileKind: readAssetFileKind,
      importFiles: importProjectAssetFiles,
      collisionModel: readAssetCollisionModel,
      resolveImportPlan: readAssetImportPlan,
      selectDirectory: selectDirectoryFromTree,
      selectCsv: selectProjectCsv,
      selectImage: selectImageFromTree,
      download: downloadProjectAsset
    }),
    graphs: Object.freeze({
      readData: readGraphDataApi,
      readLayout: readGraphLayoutApi,
      readPalette: readGraphPaletteApi,
      selectCsv: graphEditorSelectCsv,
      setHeaderLines: graphEditorHeaderLines,
      setEditable: graphEditorSetEditable,
      addObject: graphEditorAdd,
      moveObject: graphEditorMove,
      selectObject: graphEditorSelectObject,
      setObjectValues: graphEditorObjectValues,
      deleteObject: graphEditorDelete,
      updateLayout: graphEditorUpdateLayout,
      applyPalette: graphEditorApplyPalette,
      defaultColors: () => appFSM.query("project-api", { operation: "graphs.defaultColors" }),
      hasSelectedSlot: () => appFSM.query("project-api", {
        operation: "graphs.hasSelectedSlot",
        selectedSlotId: interfaceFSM.readState().selectedSlotId
      }),
      importFile: (slotId, file) => appFSM.run("importing", "graphs.importFile", () => importSelectedGraphFile(file, slotId)),
      exportFfsx: downloadSlotFfsx,
      exportPlotlyJson: downloadPlotlyJson
    }),
    print: Object.freeze({
      readSettings: readPrintApiSettings,
      setSettings: setPrintApiSettings,
      save: (statusSink) => savePrintApi({ onStatus: statusSink }),
      capture: (statusSink) => capturePrintApi({ onStatus: statusSink })
    }),
    captions: Object.freeze({
      readGlobal: readGlobalCaptionState,
      readSlot: readSlotCaptionState,
      setEnabled: setCaptionsApiEnabled,
      setGlobalText: setGlobalCaptionText,
      setSlotText: setSlotCaptionText,
      insertSlotCaptions: insertCaptionsApiSlotCaptions,
      setName: setCaptionsApiName,
      setNameBold: setCaptionsApiNameBold,
      setSettings: setCaptionsApiSettings
    }),
    labels: Object.freeze({
      readState: readLabelsApiState,
      setEnabled: setLabelsApiEnabled,
      setSettings: setLabelsApiSettings,
      setPosition: setLabelsApiPosition,
      finishPositionInteraction: finishLabelsApiPositionInteraction,
      resetPosition: resetLabelsApiPosition
    }),
    appearance: Object.freeze({
      readPalette: readAppearanceApiPalette,
      setPalette: setAppearanceApiPalette,
      resetPalette: resetAppearanceApiPalette
    }),
    layout: Object.freeze({
      readState: readLayoutApiState,
      setStyle: setLayoutApiStyle,
      setGrid: setLayoutApiGrid,
      setZoom: setLayoutApiZoom,
      commitZoom: commitLayoutApiZoom,
      setZoomLocked: setLayoutApiZoomLocked,
      resetZoom: resetLayoutApiZoom,
      mergeSlots,
      splitSlots
    })
  });
}

// sourcecode/frontend/mantine_ui.js
async function dashboardExternalFileDrop(file, slotId, choosePlan, frontendActions) {
  if (!frontendActions.slots.prepareFileDrop(slotId)) return false;
  let failed = false;
  try {
    return await frontendActions.assets.importToSlot(file, slotId, choosePlan);
  } catch (error) {
    failed = true;
    throw error;
  } finally {
    try {
      frontendActions.slots.finishFileDrop();
    } catch (error) {
      if (!failed) throw error;
    }
  }
}
function mountMantineUi() {
  const runtime = window.FastFigureUiRuntime;
  if (!runtime) throw new Error("Fast Figure UI runtime failed to load");
  if (!window.fastFigureUiRoot) throw new Error("Fast Figure React root is not initialized");
  const { React, MantineCore } = runtime;
  const {
    ActionIcon,
    AppShell,
    Box,
    Button,
    Code,
    ColorInput,
    FileButton,
    Group,
    Image: Image2,
    Input,
    MantineProvider,
    Menu,
    Modal,
    NumberInput,
    ScrollArea,
    Select,
    Stack,
    Table,
    TableTbody,
    TableTd,
    TableTh,
    TableThead,
    TableTr,
    Text,
    TextInput,
    Textarea,
    Tree,
    UnstyledButton,
    createTheme,
    useTree
  } = MantineCore;
  const { useCallback, useEffect, useMemo, useRef, useState, useSyncExternalStore } = React;
  const FAST_FIGURE_SETTINGS_MODAL_SIZE = "min(96vw, 1320px)";
  const fastFigureTheme = createTheme({
    fontFamily: 'system-ui, "Segoe UI", sans-serif',
    fontSizes: { ff: "14px" },
    radius: { ff: "6px" },
    defaultRadius: "ff",
    other: {
      settingsModalSize: FAST_FIGURE_SETTINGS_MODAL_SIZE,
      shell: {
        headerHeight: 57,
        navbarWidth: 370,
        navbarMinWidth: 360,
        navbarMaxWidth: 620,
        resizeHandleWidth: 8
      }
    },
    components: {
      Button: Button.extend({
        defaultProps: { size: "ff" },
        vars: (_theme, props) => props.size === "ff" ? {
          root: {
            "--button-height": "38px",
            "--button-padding-x": "12px",
            "--button-fz": "14px"
          }
        } : { root: {} }
      }),
      ActionIcon: ActionIcon.extend({
        defaultProps: { size: "ff" },
        vars: (_theme, props) => props.size === "ff" ? { root: { "--ai-size": "38px" } } : { root: {} }
      }),
      Input: Input.extend({
        defaultProps: { size: "ff" },
        vars: (_theme, props) => props.size === "ff" ? {
          wrapper: {
            "--input-height": "38px",
            "--input-fz": "14px",
            "--input-radius": "6px"
          }
        } : { wrapper: {} }
      }),
      Modal: Modal.extend({
        defaultProps: {
          centered: true,
          closeOnClickOutside: true,
          closeOnEscape: true
        }
      })
    }
  });
  const FONT_SELECT_PREFIX = "ff-font:";
  const GRAPH_FONT_OPTIONS = Object.freeze([
    { value: "", label: "자동" },
    { value: "Arial, sans-serif", label: "Arial" },
    { value: "Helvetica, Arial, sans-serif", label: "Helvetica" },
    { value: "Open Sans, Arial, sans-serif", label: "Open Sans" },
    { value: "Verdana, sans-serif", label: "Verdana" },
    { value: "Times New Roman, serif", label: "Times New Roman" },
    { value: "Georgia, serif", label: "Georgia" },
    { value: "Courier New, monospace", label: "Courier New" }
  ]);
  const ANNOTATION_FONT_OPTIONS = Object.freeze([
    { value: "system-ui, sans-serif", label: "기본" },
    { value: "Arial, sans-serif", label: "Arial" },
    { value: "Times New Roman, serif", label: "Times New Roman" },
    { value: "Georgia, serif", label: "Georgia" },
    { value: "Courier New, monospace", label: "Courier New" }
  ]);
  function fontSelectData(options, currentValue) {
    const current = typeof currentValue === "string" ? currentValue : "";
    const values = options.some((option) => option.value === current) ? options : [
      ...options,
      {
        value: current,
        label: current ? `기존: ${current}` : "기존: 빈 값"
      }
    ];
    return values.map((option) => ({
      value: FONT_SELECT_PREFIX + option.value,
      label: option.label
    }));
  }
  function fontSelectValue(value2) {
    return FONT_SELECT_PREFIX + (typeof value2 === "string" ? value2 : "");
  }
  function fontValueFromSelect(value2) {
    return typeof value2 === "string" && value2.startsWith(FONT_SELECT_PREFIX) ? value2.slice(FONT_SELECT_PREFIX.length) : null;
  }
  function subscribeAppState(onStoreChange) {
    return appFSM.subscribe(onStoreChange);
  }
  function getAppStateSnapshot() {
    return appFSM.readState().revision;
  }
  function useAppState() {
    useSyncExternalStore(subscribeAppState, getAppStateSnapshot, getAppStateSnapshot);
    return appFSM.readState();
  }
  function addSelectedGraphObject() {
    const current = appFSM.readState();
    if (current.lifecycle !== "ready" || current.selectedSlotId == null) return null;
    const context = window.FastFigureApi.graphs.readData();
    if (!context.currentCsv || context.chart?.editor.editable === false) return null;
    return window.FastFigureApi.graphs.addObject(current.selectedSlotId, context.currentCsv.id);
  }
  function setSelectedGraphEditable(editable) {
    const current = appFSM.readState();
    if (current.lifecycle !== "ready" || current.selectedSlotId == null) return null;
    const context = window.FastFigureApi.graphs.readData();
    if (!context.chart) return null;
    return window.FastFigureApi.graphs.setEditable(current.selectedSlotId, context.chart.id, editable);
  }
  function updateSelectedGraphLayout(values) {
    const current = appFSM.readState();
    if (current.lifecycle !== "ready" || current.selectedSlotId == null) return null;
    const context = window.FastFigureApi.graphs.readData();
    if (!context.chart || context.chart.editor.editable === false) return null;
    return window.FastFigureApi.graphs.updateLayout(current.selectedSlotId, context.chart.id, values);
  }
  function importSelectedSlotFile(file) {
    if (!file) return null;
    const current = appFSM.readState();
    if (current.selectedSlotId == null) return null;
    return window.FastFigureApi.graphs.importFile(current.selectedSlotId, file);
  }
  function useUiTelemetry() {
    return useSyncExternalStore(
      subscribeUiTelemetry,
      getUiTelemetrySnapshot,
      getUiTelemetrySnapshot
    );
  }
  function selectedTargetText(state) {
    if (state.workspace === "project") return "빈 슬롯 또는 그래프를 선택하세요.";
    const slot = window.FastFigureApi.slots.readSelected();
    return slot ? `선택한 슬롯: ${slot.row}행 ${slot.col}열` : "빈 슬롯 또는 그래프를 선택하세요.";
  }
  function toggleOverlay(overlay) {
    appFSM.send("TOGGLE_OVERLAY", { overlay, source: "mantine" });
  }
  function reportTaskError(eventName, error) {
    debugLog(
      "fsm:lifecycle-task-error",
      { event: eventName, message: error.message },
      "error"
    );
  }
  function runLifecycleTask2(lifecycle, eventName, task) {
    return appFSM.run(lifecycle, eventName, task).catch((error) => reportTaskError(eventName, error));
  }
  function useProjectAssetImportCollision() {
    const resolverRef = useRef(null);
    const [collision, setCollision] = useState(null);
    const resolveCollision = (choice = null) => {
      const resolve = resolverRef.current;
      resolverRef.current = null;
      setCollision(null);
      resolve?.(choice);
    };
    useEffect(() => () => {
      const resolve = resolverRef.current;
      resolverRef.current = null;
      resolve?.(null);
    }, []);
    const choosePlan = useCallback(async (file, directory, reservedPaths = null) => {
      const model = window.FastFigureApi.assets.collisionModel(file, directory, reservedPaths);
      if (model.mode === "available")
        return window.FastFigureApi.assets.resolveImportPlan(model, "available", reservedPaths);
      const choice = await new Promise((resolve) => {
        resolverRef.current = resolve;
        setCollision(model);
      });
      if (choice !== "rename" && choice !== "replace") return null;
      return window.FastFigureApi.assets.resolveImportPlan(model, choice, reservedPaths);
    }, []);
    const modal = React.createElement(
      Modal,
      {
        opened: !!collision,
        onClose: () => resolveCollision(null),
        title: collision?.mode === "replace-or-rename" ? "같은 이름의 파일" : "파일 이름 충돌"
      },
      collision ? React.createElement(
        Stack,
        { gap: "sm" },
        React.createElement(
          Text,
          { style: { whiteSpace: "pre-wrap" } },
          collision.mode === "replace-or-rename" ? collision.message : collision.notice || `${collision.path}에 같은 이름의 항목이 있습니다.`
        ),
        React.createElement(
          Group,
          { justify: "flex-end", gap: "xs" },
          React.createElement(
            Button,
            { variant: "light", onClick: () => resolveCollision("rename") },
            "새 이름으로 추가"
          ),
          collision.mode === "replace-or-rename" ? React.createElement(
            Button,
            { onClick: () => resolveCollision("replace") },
            "기존 파일 교체"
          ) : null
        )
      ) : null
    );
    return { choosePlan, modal };
  }
  function exportProjectFromMantine() {
    return window.FastFigureApi.project.exportFile().catch((error) => reportTaskError("PROJECT_EXPORT", error));
  }
  function exportSlotFfsxFromMantine() {
    return window.FastFigureApi.graphs.exportFfsx().catch((error) => reportTaskError("SLOT_EXPORT", error));
  }
  function exportPlotlyJsonFromMantine() {
    return window.FastFigureApi.graphs.exportPlotlyJson().catch((error) => reportTaskError("PLOTLY_EXPORT", error));
  }
  function FastFigureToolbar() {
    const state = useAppState();
    const activeOverlay = state.overlay;
    const buttonProps = (overlay) => ({
      variant: activeOverlay === overlay ? "filled" : "light",
      "aria-expanded": activeOverlay === overlay,
      onClick: () => toggleOverlay(overlay)
    });
    return React.createElement(
      Group,
      { gap: "xs", wrap: "nowrap", role: "toolbar", "aria-label": "Fast figure 도구" },
      React.createElement(Button, { ...buttonProps("layout") }, "레이아웃"),
      React.createElement(Button, { ...buttonProps("label") }, "레이블"),
      React.createElement(Button, { ...buttonProps("caption") }, "캡션"),
      React.createElement(
        Text,
        {
          size: "sm",
          c: "dimmed",
          style: { flex: "1 1 auto", minWidth: 0 }
        },
        selectedTargetText(state)
      ),
      React.createElement(Button, { ...buttonProps("print"), "aria-label": "프린트" }, "프린트")
    );
  }
  function FastFigureDataActions() {
    const state = useAppState();
    const busy = state.lifecycle !== "ready";
    const slotApi = window.FastFigureApi.slots;
    const slot = state.workspace === "project" ? null : slotApi.readSelected();
    const slotType = slot?.content.contentType || "graph";
    const [resetSlotId, setResetSlotId] = useState(null);
    const assetApi = window.FastFigureApi.assets;
    const selectedAssetDeletable = !!assetApi.readDeletionTarget(state.assetPath);
    const [deleteTarget, setDeleteTarget] = useState(null);
    const fileResetRef = useRef(null);
    const { choosePlan: chooseProjectAssetImportPlan, modal: importCollisionModal } = useProjectAssetImportCollision();
    const importFilesFromMantine = async (files) => {
      const selectedFiles = Array.isArray(files) ? files : files ? [files] : [];
      if (!selectedFiles.length) return;
      try {
        await assetApi.importFiles(selectedFiles, chooseProjectAssetImportPlan);
      } catch (error) {
        status("불러오기 실패: " + error.message);
      } finally {
        fileResetRef.current?.();
      }
    };
    const performAssetDelete = (target) => {
      try {
        assetApi.delete({ kind: target.kind, id: target.target.id, path: target.path });
        setDeleteTarget(null);
      } catch (error) {
        status(`에셋 삭제 오류: ${error.message}`);
      }
    };
    const requestAssetDelete = () => {
      const target = assetApi.readDeletionTarget(appFSM.readState().assetPath);
      if (!target) return;
      if (target.referenceCount > 0) setDeleteTarget(target);
      else performAssetDelete(target);
    };
    const closeResetDialog = () => setResetSlotId(null);
    const confirmSlotReset = () => {
      if (!Number.isInteger(resetSlotId)) return;
      try {
        slotApi.reset(resetSlotId);
        closeResetDialog();
      } catch (error) {
        status(`슬롯 초기화 오류: ${error.message}`);
      }
    };
    return React.createElement(
      Stack,
      { gap: "xs", p: "md" },
      React.createElement(Text, { fw: 600 }, "데이터"),
      slot ? React.createElement(
        Group,
        { gap: "xs", grow: true },
        React.createElement(
          Button,
          {
            variant: slotType === "graph" ? "filled" : "light",
            disabled: busy,
            onClick: () => slotApi.setContentType(slot.id, "graph")
          },
          "그래프"
        ),
        React.createElement(
          Button,
          {
            variant: slotType === "image" ? "filled" : "light",
            disabled: busy,
            onClick: () => slotApi.setContentType(slot.id, "image")
          },
          "이미지"
        )
      ) : null,
      React.createElement(
        FileButton,
        {
          onChange: importFilesFromMantine,
          accept: ".csv,.tsv,.json",
          multiple: true,
          resetRef: fileResetRef,
          disabled: busy
        },
        (props) => React.createElement(
          Button,
          { ...props, variant: "light", disabled: busy },
          "데이터 추가"
        )
      ),
      importCollisionModal,
      React.createElement(
        Button,
        {
          variant: "light",
          disabled: busy || !["csv", "image"].includes(state.assetSelection),
          onClick: () => assetApi.download()
        },
        "선택 에셋 다운로드"
      ),
      React.createElement(
        Button,
        {
          variant: "light",
          disabled: busy || !selectedAssetDeletable,
          onClick: requestAssetDelete
        },
        "선택 에셋 삭제"
      ),
      React.createElement(
        Modal,
        {
          opened: !!deleteTarget,
          onClose: () => setDeleteTarget(null),
          title: "선택 에셋 삭제"
        },
        deleteTarget ? React.createElement(
          Stack,
          { gap: "sm" },
          React.createElement(
            Text,
            null,
            deleteTarget.kind === "csv" ? `${deleteTarget.target.name}을 ${deleteTarget.referenceCount}개 그래프 오브젝트가 참조 중입니다. 참조 중인 그래프 오브젝트와 CSV를 함께 삭제할까요?` : `${deleteTarget.target.name}을 ${deleteTarget.referenceCount}개 이미지 슬롯이 참조 중입니다. 참조 슬롯을 초기화하고 이미지를 삭제할까요?`
          ),
          React.createElement(
            Group,
            { justify: "flex-end", gap: "xs" },
            React.createElement(
              Button,
              { variant: "light", onClick: () => setDeleteTarget(null) },
              "취소"
            ),
            React.createElement(
              Button,
              { onClick: () => performAssetDelete(deleteTarget) },
              "삭제"
            )
          )
        ) : null
      ),
      slot ? React.createElement(
        Button,
        {
          variant: "light",
          disabled: busy,
          onClick: () => setResetSlotId(slot.id)
        },
        "선택 슬롯 초기화"
      ) : null,
      React.createElement(
        Modal,
        {
          opened: Number.isInteger(resetSlotId),
          onClose: closeResetDialog,
          title: "선택 슬롯 초기화"
        },
        React.createElement(
          Stack,
          { gap: "sm" },
          React.createElement(Text, null, "데이터를 잃습니다."),
          React.createElement(
            Group,
            { justify: "flex-end", gap: "xs" },
            React.createElement(Button, { variant: "light", onClick: closeResetDialog }, "취소"),
            React.createElement(Button, { onClick: confirmSlotReset }, "초기화")
          )
        )
      )
    );
  }
  function FastFigureImageEditor() {
    const state = useAppState();
    if (state.workspace !== "slot.image") return null;
    const busy = state.lifecycle !== "ready";
    const imageApi = window.FastFigureApi.images;
    const image = imageApi.readEditor();
    const settings = image?.settings;
    const updateSettings = (patch) => {
      if (!settings) return;
      imageApi.setSettings(image.slotId, patch);
    };
    return React.createElement(
      Stack,
      { gap: "xs", px: "md", pb: "md" },
      React.createElement(Text, { fw: 600, size: "sm" }, "이미지"),
      image ? React.createElement(Image2, {
        src: image.src,
        alt: image.name || "선택 이미지",
        h: 160,
        fit: "contain",
        radius: "sm"
      }) : React.createElement(
        Text,
        { size: "sm", c: "dimmed" },
        "이미지를 추가하거나 프로젝트 이미지 에셋을 연결하세요."
      ),
      React.createElement(
        Button,
        {
          variant: "light",
          disabled: busy,
          onClick: imageApi.insertEmpty
        },
        "빈 이미지 삽입"
      ),
      React.createElement(Button, {
        variant: "light",
        disabled: busy || state.assetSelection !== "image" || !state.assetPath,
        onClick: () => {
          const slot = window.FastFigureApi.slots.readSelected();
          if (slot?.content.contentType === "image")
            window.FastFigureApi.assets.connectToSlot(state.assetPath, "image", slot.id);
        }
      }, "선택 이미지 추가"),
      React.createElement(Select, {
        label: "맞춤",
        value: settings?.fit || "contain",
        data: [
          { value: "contain", label: "맞춰 넣기" },
          { value: "cover", label: "채우기" },
          { value: "manual", label: "수동" }
        ],
        disabled: busy || !image,
        allowDeselect: false,
        onChange: (value2) => updateSettings({ fit: value2 || settings?.fit || "contain" })
      }),
      settings?.fit === "manual" ? React.createElement(
        Stack,
        { gap: "xs" },
        React.createElement(NumberInput, {
          label: "크기 (%)",
          value: settings.scale,
          min: 1,
          max: 1e3,
          disabled: busy,
          onChange: (value2) => updateSettings({ scale: value2 })
        }),
        React.createElement(
          Group,
          { gap: "xs", grow: true },
          React.createElement(NumberInput, {
            label: "X (%)",
            value: settings.x,
            min: -100,
            max: 200,
            disabled: busy,
            onChange: (value2) => updateSettings({ x: value2 })
          }),
          React.createElement(NumberInput, {
            label: "Y (%)",
            value: settings.y,
            min: -100,
            max: 200,
            disabled: busy,
            onChange: (value2) => updateSettings({ y: value2 })
          })
        )
      ) : null
    );
  }
  function readProjectAssetDisplay() {
    const assetNodes = window.FastFigureApi.assets.readTree();
    const slotRows = window.FastFigureApi.layout.readState().visibleSlots;
    return { assetNodes, slotRows };
  }
  function FastFigureProjectDataTree() {
    const state = useAppState();
    const assetApi = window.FastFigureApi.assets;
    const { assetNodes, slotRows } = readProjectAssetDisplay();
    const snapshot = {
      directories: assetNodes.filter((node) => node.kind === "directory").map((node) => node.path),
      data: assetNodes.filter((node) => node.kind === "csv").map((node) => ({
        id: node.id,
        name: node.name,
        path: node.path,
        readable: Array.isArray(node.asset.rows),
        rowCount: Math.max(0, node.asset.rows.length - (Number(node.asset.headerLines) || 0))
      })),
      images: assetNodes.filter((node) => node.kind === "image").map((node) => ({
        id: node.id,
        name: node.name,
        path: node.path
      }))
    };
    const selectedSlotId = window.FastFigureApi.slots.readSelected()?.id;
    const assetTreeController = useTree({
      initialExpandedState: { "/assets": true }
    });
    const [slotsExpanded, setSlotsExpanded] = useState(true);
    const [lastDirectory, setLastDirectory] = useState("/assets");
    const [folderDialog, setFolderDialog] = useState({
      opened: false,
      parent: "/assets",
      name: "New Folder"
    });
    const [trashDialog, setTrashDialog] = useState(null);
    const [movePicker, setMovePicker] = useState(null);
    const [moveConfirm, setMoveConfirm] = useState(null);
    const dragNodeRef = useRef(null);
    const { choosePlan: chooseTreeImportPlan, modal: treeImportCollisionModal } = useProjectAssetImportCollision();
    const busy = state.lifecycle !== "ready";
    const directories = [...new Set(snapshot.directories)].filter((path) => path === "/assets" || path.startsWith("/assets/")).sort((a, b) => a.localeCompare(b));
    const openFolderDialog = () => {
      const selectedDirectory = state.assetSelection === "directory" ? state.assetPath : lastDirectory;
      const parent = typeof selectedDirectory === "string" && (selectedDirectory === "/assets" || selectedDirectory.startsWith("/assets/")) && !assetApi.isTrashed(selectedDirectory) ? selectedDirectory : "/assets";
      setFolderDialog({ opened: true, parent, name: "New Folder" });
    };
    const closeFolderDialog = () => setFolderDialog((current) => ({ ...current, opened: false }));
    const createFolderFromMantine = () => {
      try {
        const path = assetApi.createDirectory(folderDialog.parent, folderDialog.name);
        if (path !== null) setLastDirectory(path);
        closeFolderDialog();
      } catch (error) {
        status(`폴더 생성 오류: ${error.message}`);
      }
    };
    const trashSelected = state.assetSelection === "directory" && state.assetPath === PROJECT_TRASH_DIRECTORY;
    const trash = assetApi.readTrash();
    const trashHasContents = !!trash?.children.length;
    const countTrashReferences = (node) => node.kind === "directory" ? node.children.reduce((count, child) => count + countTrashReferences(child), 0) : assetApi.readDeletionTarget(node.path)?.referenceCount ?? 0;
    const trashReferenceCount = trash ? countTrashReferences(trash) : 0;
    const openTrashDialog = () => {
      if (!trashSelected || !trashHasContents) return;
      setTrashDialog({ referenceCount: trashReferenceCount });
    };
    const closeTrashDialog = () => setTrashDialog(null);
    const emptyTrashFromMantine = () => {
      try {
        assetApi.emptyTrash();
        closeTrashDialog();
      } catch (error) {
        status(`휴지통 비우기 오류: ${error.message}`);
      }
    };
    const rewriteLastDirectoryAfterMove = (source, destination) => {
      setLastDirectory(
        (current) => projectPathInDirectory(current, source) ? `${destination}${current.slice(source.length)}` : current
      );
    };
    const executeProjectNodeMove = (plan, useUniqueName = false) => {
      if (!plan) return;
      try {
        const result = assetApi.move(plan, useUniqueName);
        if (result === null) return;
        if (plan.kind === "directory" && !result.trashed)
          rewriteLastDirectoryAfterMove(plan.path, result.path);
        setMovePicker(null);
        setMoveConfirm(null);
      } catch (error) {
        status(`프로젝트 항목 이동 오류: ${error.message}`);
      }
    };
    const requestProjectNodeMove = (path, directory) => {
      try {
        const plan = assetApi.planMove(path, directory);
        if (!plan) {
          setMovePicker(null);
          return;
        }
        if (plan.collision || plan.enteringTrash && plan.referenceCount > 0)
          setMoveConfirm(plan);
        else executeProjectNodeMove(plan);
      } catch (error) {
        status(`프로젝트 항목 이동 오류: ${error.message}`);
      }
    };
    const assetReferenceCount = (path) => assetApi.readDeletionTarget(path)?.referenceCount ?? 0;
    const dataByPath = new Map(
      snapshot.data.map((asset) => [asset.path, { kind: "csv", asset }])
    );
    snapshot.images.forEach(
      (asset) => dataByPath.set(asset.path, { kind: "image", asset })
    );
    const directorySet = new Set(directories);
    const treeNodeForDirectory = (path) => ({
      value: path,
      label: path === "/assets" ? "/assets" : projectPathName(path),
      kind: "directory",
      children: [
        ...directories.filter((candidate) => candidate !== path && projectParentPath(candidate) === path).map(treeNodeForDirectory),
        ...snapshot.data.filter((asset) => projectParentPath(asset.path) === path).map((asset) => ({
          value: asset.path,
          label: projectPathName(asset.path),
          kind: "csv"
        })),
        ...snapshot.images.filter((asset) => projectParentPath(asset.path) === path).map((asset) => ({
          value: asset.path,
          label: projectPathName(asset.path),
          kind: "image"
        }))
      ]
    });
    const assetTreeRevision = [
      ...directories,
      ...snapshot.data.map((asset) => `csv:${asset.path}`),
      ...snapshot.images.map((asset) => `image:${asset.path}`)
    ].join("\0");
    const assetTreeData = useMemo(
      () => [treeNodeForDirectory("/assets")],
      [assetTreeRevision]
    );
    const treeNodeKind = (path) => directorySet.has(path) ? "directory" : dataByPath.get(path)?.kind || null;
    const treeNodeMeta = (path, kind) => {
      const asset = dataByPath.get(path)?.asset;
      if (!asset) return "";
      return kind === "csv" ? `${asset.readable ? `${asset.rowCount}행` : "읽기 실패"} · 참조 ${assetReferenceCount(path)}` : `참조 ${assetReferenceCount(path)}`;
    };
    const allowProjectTreeDrop = ({ draggedNode, targetNode, position }) => !busy && position === "inside" && directorySet.has(targetNode) && assetApi.movable(draggedNode);
    const moveProjectTreeNode = (payload) => {
      if (!allowProjectTreeDrop(payload)) return;
      requestProjectNodeMove(payload.draggedNode, payload.targetNode);
    };
    const renderProjectTreeNode = ({
      node,
      expanded: nodeExpanded,
      hasChildren,
      tree,
      elementProps
    }) => {
      const path = node.value;
      const kind = treeNodeKind(path);
      const directory = kind === "directory";
      const movable = assetApi.movable(path);
      const trashed = assetApi.isTrashed(path);
      const selected = state.assetPath === path && state.assetSelection === kind;
      const originalClick = elementProps.onClick;
      const originalDragStart = elementProps.onDragStart;
      const originalDragOver = elementProps.onDragOver;
      const originalDragLeave = elementProps.onDragLeave;
      const originalDrop = elementProps.onDrop;
      const originalDragEnd = elementProps.onDragEnd;
      const selectNode = (event) => {
        originalClick?.(event);
        if (busy || !kind) return;
        if (directory) {
          setLastDirectory(path);
          assetApi.selectDirectory(path);
          if (hasChildren) tree.toggleExpanded(path);
        } else if (kind === "csv") assetApi.selectCsv(path);
        else if (kind === "image") assetApi.selectImage(path);
      };
      const startTreeDrag = (event) => {
        if (busy || !movable) return event.preventDefault();
        dragNodeRef.current = { path };
        originalDragStart?.(event);
        if (!event.defaultPrevented) event.dataTransfer.effectAllowed = "all";
      };
      const finishTreeDrag = (event) => {
        originalDragEnd?.(event);
        dragNodeRef.current = null;
      };
      const treeDragOver = (event) => {
        if (dataTransferHasFiles(event.dataTransfer)) {
          if (!directory || trashed) return false;
          return allowExternalFileDrop(event);
        }
        return originalDragOver?.(event);
      };
      const treeDrop = (event) => {
        if (dataTransferHasFiles(event.dataTransfer)) {
          if (!directory || trashed) return false;
          return importExternalFilesToDirectory(event, path);
        }
        return originalDrop?.(event);
      };
      const row = React.createElement(
        UnstyledButton,
        {
          ...elementProps,
          type: "button",
          disabled: busy,
          onClick: selectNode,
          onDragStart: startTreeDrag,
          onDragOver: treeDragOver,
          onDragLeave: originalDragLeave,
          onDrop: treeDrop,
          onDragEnd: finishTreeDrag,
          "aria-expanded": directory && hasChildren ? nodeExpanded : void 0,
          "data-fastfigure-tree-path": path,
          style: {
            ...elementProps.style || {},
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            gap: 8,
            width: "100%",
            minWidth: 0,
            padding: "6px 8px",
            borderRadius: "var(--mantine-radius-sm)",
            background: selected ? "var(--mantine-primary-color-light)" : "transparent",
            color: "inherit",
            cursor: busy ? "default" : movable ? "grab" : "pointer"
          }
        },
        React.createElement(
          Text,
          {
            component: "span",
            size: "xs",
            style: {
              minWidth: 0,
              overflow: "hidden",
              textOverflow: "ellipsis",
              whiteSpace: "nowrap"
            }
          },
          directory ? `${hasChildren ? nodeExpanded ? "▾" : "▸" : "•"} ${node.label}` : node.label
        ),
        !directory ? React.createElement(
          Text,
          { component: "span", size: "xs", c: "dimmed", style: { flexShrink: 0 } },
          treeNodeMeta(path, kind)
        ) : null
      );
      let menu = null;
      if (directory && movable) {
        menu = React.createElement(
          Menu,
          { position: "bottom-end", withinPortal: true },
          React.createElement(
            Menu.Target,
            null,
            React.createElement(
              ActionIcon,
              {
                variant: "subtle",
                size: "sm",
                "aria-label": `${projectPathName(path)} 폴더 작업`
              },
              "···"
            )
          ),
          React.createElement(
            Menu.Dropdown,
            null,
            React.createElement(
              Menu.Item,
              {
                onClick: () => setMovePicker({
                  path,
                  directory: projectParentPath(path)
                })
              },
              "이동…"
            ),
            !trashed ? React.createElement(
              Menu.Item,
              {
                onClick: () => requestProjectNodeMove(path, PROJECT_TRASH_DIRECTORY)
              },
              "휴지통으로 이동"
            ) : null
          )
        );
      } else if (!directory && kind) {
        menu = React.createElement(
          Menu,
          { position: "bottom-end", withinPortal: true },
          React.createElement(
            Menu.Target,
            null,
            React.createElement(
              ActionIcon,
              {
                variant: "subtle",
                size: "sm",
                "aria-label": `${projectPathName(path)} 작업`
              },
              "···"
            )
          ),
          React.createElement(
            Menu.Dropdown,
            null,
            React.createElement(
              Menu.Item,
              { onClick: () => assetApi.download(path) },
              "다운로드"
            ),
            movable ? React.createElement(
              Menu.Item,
              {
                onClick: () => setMovePicker({
                  path,
                  directory: projectParentPath(path)
                })
              },
              "이동…"
            ) : null,
            movable && !trashed ? React.createElement(
              Menu.Item,
              {
                onClick: () => requestProjectNodeMove(path, PROJECT_TRASH_DIRECTORY)
              },
              "휴지통으로 이동"
            ) : null
          )
        );
      }
      return React.createElement(
        Group,
        { gap: 2, wrap: "nowrap", style: { width: "100%" } },
        React.createElement(Box, { style: { flex: 1, minWidth: 0 } }, row),
        menu
      );
    };
    const visibleSlots = [...slotRows].sort((a, b) => a.row - b.row || a.col - b.col);
    const slotReference = (slot) => {
      if (slot.assetDisplay.kind === "embedded")
        return "Plotly JSON 내부 데이터 · 외부 참조 없음";
      const references = slot.assetDisplay.assets.map((asset) => `${asset.name} · ${asset.path}`);
      return references.length ? references.join(", ") : "(에셋 없음)";
    };
    const draggedProjectAsset = (event) => {
      const path = dragNodeRef.current?.path || event.dataTransfer?.getData("text/plain") || "";
      return assetApi.draggableAsset(path);
    };
    const allowProjectAssetSlotDrop = (event) => {
      const dragged = draggedProjectAsset(event);
      if (!dragged) return false;
      event.preventDefault();
      event.dataTransfer.dropEffect = "link";
      return true;
    };
    const dropProjectAssetOnSlot = (event, slot) => {
      const dragged = draggedProjectAsset(event);
      dragNodeRef.current = null;
      if (!dragged) return;
      event.preventDefault();
      try {
        assetApi.connectToSlot(dragged.path, dragged.kind, slot.id);
      } catch (error) {
        status(`슬롯 연결 오류: ${error.message}`);
      }
    };
    const externalFiles = (event) => Array.from(event.dataTransfer?.files || []);
    const allowExternalFileDrop = (event) => {
      if (!dataTransferHasFiles(event.dataTransfer)) return false;
      event.preventDefault();
      event.stopPropagation();
      event.dataTransfer.dropEffect = "copy";
      return true;
    };
    const importExternalFilesToDirectory = async (event, directory) => {
      const files = externalFiles(event);
      if (!files.length) return;
      event.preventDefault();
      event.stopPropagation();
      try {
        await assetApi.importToDirectory(files, directory, chooseTreeImportPlan);
        status(`${directory}에 외부 파일 ${files.length}개를 가져왔습니다.`);
      } catch (error) {
        status(`폴더 가져오기 실패: ${error.message}`);
        debugLog("mantine:folder-drop-error", { directory, message: error.message }, "error");
      }
    };
    const importExternalFileToSlot = async (event, slot) => {
      const files = externalFiles(event);
      event.preventDefault();
      event.stopPropagation();
      if (files.length !== 1)
        return status("슬롯에는 한 번에 외부 파일 하나만 놓을 수 있습니다.");
      try {
        await assetApi.importToSlot(files[0], slot.id, chooseTreeImportPlan);
      } catch (error) {
        status(`슬롯 가져오기 실패: ${error.message}`);
      }
    };
    return React.createElement(
      Stack,
      { gap: "xs", px: "md", pb: "md" },
      React.createElement(Text, { fw: 600, size: "sm" }, "PROJECT DATA"),
      React.createElement(
        Button,
        {
          variant: "light",
          size: "xs",
          disabled: busy,
          onClick: openFolderDialog
        },
        "새 폴더"
      ),
      React.createElement(
        Modal,
        {
          opened: folderDialog.opened,
          onClose: closeFolderDialog,
          title: "새 폴더"
        },
        React.createElement(
          Stack,
          { gap: "sm" },
          React.createElement(Text, { size: "sm", c: "dimmed" }, `위치: ${folderDialog.parent}`),
          React.createElement(TextInput, {
            label: "폴더 이름",
            value: folderDialog.name,
            autoFocus: true,
            onChange: (event) => setFolderDialog((current) => ({ ...current, name: event.target.value })),
            onKeyDown: (event) => {
              if (event.key !== "Enter" || event.nativeEvent?.isComposing) return;
              event.preventDefault();
              createFolderFromMantine();
            }
          }),
          React.createElement(
            Group,
            { justify: "flex-end", gap: "xs" },
            React.createElement(Button, { variant: "light", onClick: closeFolderDialog }, "취소"),
            React.createElement(Button, { onClick: createFolderFromMantine }, "만들기")
          )
        )
      ),
      trashSelected ? React.createElement(
        Button,
        {
          variant: "light",
          size: "xs",
          disabled: busy || !trashHasContents,
          onClick: openTrashDialog
        },
        "휴지통 비우기"
      ) : null,
      React.createElement(
        Modal,
        {
          opened: !!trashDialog,
          onClose: closeTrashDialog,
          title: "휴지통 비우기"
        },
        trashDialog ? React.createElement(
          Stack,
          { gap: "sm" },
          React.createElement(
            Text,
            null,
            trashDialog.referenceCount ? `휴지통 자산에 남아 있는 참조 ${trashDialog.referenceCount}개도 함께 제거됩니다. 휴지통의 폴더와 파일을 영구적으로 비우시겠습니까?` : "휴지통의 폴더와 파일을 영구적으로 비우시겠습니까?"
          ),
          React.createElement(
            Group,
            { justify: "flex-end", gap: "xs" },
            React.createElement(Button, { variant: "light", onClick: closeTrashDialog }, "취소"),
            React.createElement(Button, { onClick: emptyTrashFromMantine }, "비우기")
          )
        ) : null
      ),
      React.createElement(
        Modal,
        {
          opened: !!movePicker,
          onClose: () => setMovePicker(null),
          title: "프로젝트 항목 이동"
        },
        movePicker ? React.createElement(
          Stack,
          { gap: "sm" },
          React.createElement(
            Text,
            { size: "sm", c: "dimmed" },
            `이동: ${movePicker.path}`
          ),
          React.createElement(Select, {
            label: "대상 폴더",
            value: movePicker.directory,
            data: assetApi.moveOptions(movePicker.path).map((directory) => ({ value: directory, label: directory })),
            allowDeselect: false,
            searchable: true,
            onChange: (value2) => value2 && setMovePicker((current) => ({
              ...current,
              directory: value2
            }))
          }),
          React.createElement(
            Group,
            { justify: "flex-end", gap: "xs" },
            React.createElement(
              Button,
              { variant: "light", onClick: () => setMovePicker(null) },
              "취소"
            ),
            React.createElement(
              Button,
              {
                onClick: () => requestProjectNodeMove(movePicker.path, movePicker.directory)
              },
              "이동"
            )
          )
        ) : null
      ),
      React.createElement(
        Modal,
        {
          opened: !!moveConfirm,
          onClose: () => setMoveConfirm(null),
          title: moveConfirm?.collision ? "이름 충돌" : "휴지통으로 이동"
        },
        moveConfirm ? React.createElement(
          Stack,
          { gap: "sm" },
          React.createElement(
            Text,
            { style: { whiteSpace: "pre-wrap" } },
            [
              moveConfirm.collision ? `${moveConfirm.destination}가 이미 존재합니다.
${moveConfirm.uniqueName} 이름으로 이동할 수 있습니다.` : null,
              moveConfirm.enteringTrash && moveConfirm.referenceCount > 0 ? `이 항목을 휴지통으로 이동하면 그래프·슬롯 참조 ${moveConfirm.referenceCount}개가 제거됩니다.` : null
            ].filter(Boolean).join("\n\n")
          ),
          React.createElement(
            Group,
            { justify: "flex-end", gap: "xs" },
            React.createElement(
              Button,
              { variant: "light", onClick: () => setMoveConfirm(null) },
              "취소"
            ),
            React.createElement(
              Button,
              {
                onClick: () => executeProjectNodeMove(moveConfirm, moveConfirm.collision)
              },
              moveConfirm.collision ? "새 이름으로 이동" : "이동"
            )
          )
        ) : null
      ),
      treeImportCollisionModal,
      React.createElement(Tree, {
        data: assetTreeData,
        tree: assetTreeController,
        levelOffset: "md",
        expandOnClick: false,
        selectOnClick: false,
        allowRangeSelection: false,
        onDragDrop: moveProjectTreeNode,
        allowDrop: allowProjectTreeDrop,
        renderNode: renderProjectTreeNode,
        "data-fastfigure-project-tree": "assets"
      }),
      React.createElement(
        Button,
        {
          variant: "subtle",
          size: "xs",
          fullWidth: true,
          justify: "flex-start",
          "aria-expanded": slotsExpanded,
          onClick: () => setSlotsExpanded((value2) => !value2)
        },
        `${slotsExpanded ? "▾" : "▸"} /slots`
      ),
      slotsExpanded ? React.createElement(
        Stack,
        { gap: 2, pl: "md" },
        ...visibleSlots.length ? visibleSlots.map(
          (slot) => React.createElement(
            Button,
            {
              key: slot.id,
              variant: state.workspace !== "project" && selectedSlotId === slot.id ? "filled" : "subtle",
              size: "xs",
              fullWidth: true,
              justify: "flex-start",
              disabled: busy,
              onClick: () => window.FastFigureApi.slots.select(slot.id),
              onDragOver: (event) => {
                if (dataTransferHasFiles(event.dataTransfer))
                  return allowExternalFileDrop(event);
                return allowProjectAssetSlotDrop(event);
              },
              onDrop: (event) => {
                if (dataTransferHasFiles(event.dataTransfer))
                  return importExternalFileToSlot(event, slot);
                return dropProjectAssetOnSlot(event, slot);
              }
            },
            `[row=${slot.row},col=${slot.col}] — ${slotReference(slot)}`
          )
        ) : [React.createElement(Text, { key: "empty", size: "xs", c: "dimmed" }, "(표시 슬롯 없음)")]
      ) : null
    );
  }
  function FastFigureProjectActions() {
    const state = useAppState();
    const busy = state.lifecycle !== "ready";
    const importResetRef = useRef(null);
    const projectApi = window.FastFigureApi.project;
    const openProjectImportPicker = (open) => {
      if (window.FastFigureApi.slots.readSelected())
        return status("프로젝트 불러오기는 슬롯 선택을 해제한 뒤 사용할 수 있습니다.");
      open();
    };
    const importProjectFileFromMantine = async (file) => {
      if (!file) return;
      try {
        try {
          await projectApi.importFile(file);
        } catch (error) {
          status("프로젝트 불러오기 오류: " + error.message);
          debugLog("project:import-error", { message: error.message });
        }
      } finally {
        importResetRef.current?.();
      }
    };
    return React.createElement(
      Stack,
      { gap: "xs", p: "md" },
      React.createElement(Text, { fw: 600 }, "프로젝트"),
      React.createElement(TextInput, {
        key: `project-name-${projectApi.readName()}`,
        label: "프로젝트 이름",
        defaultValue: projectApi.readName(),
        disabled: busy,
        onChange: (event) => {
          projectApi.setName(event.target.value);
        },
        onBlur: (event) => {
          event.target.value = projectApi.setName(event.target.value, true);
        }
      }),
      React.createElement(
        Group,
        { gap: "xs" },
        React.createElement(
          Button,
          { variant: "light", disabled: busy, onClick: exportProjectFromMantine },
          "FFPX 내보내기"
        ),
        React.createElement(
          FileButton,
          {
            onChange: importProjectFileFromMantine,
            resetRef: importResetRef,
            disabled: busy
          },
          (props) => React.createElement(
            Button,
            {
              ...props,
              variant: "light",
              disabled: busy,
              onClick: () => openProjectImportPicker(props.onClick)
            },
            "FFPX 불러오기"
          )
        )
      )
    );
  }
  function FastFigureGraphDataEditor() {
    const state = useAppState();
    const busy = state.lifecycle !== "ready";
    const dragRef = useRef(null);
    if (state.workspace !== "slot.graph") return null;
    const graphApi = window.FastFigureApi.graphs;
    const assetApi = window.FastFigureApi.assets;
    const editor = graphApi.readData();
    const chartId = editor.chart?.id ?? null, editable = editor.chart?.editor?.editable !== false;
    const csvAssets = assetApi.readTree().filter((node) => node.kind === "csv").map((node) => node.asset);
    const csvOptions = csvAssets.map((csv) => ({ value: String(csv.id), label: csv.name }));
    const objects = editor.objects;
    const selectedIndex = editor.selectedIndex;
    const selected = selectedIndex === null ? null : objects[selectedIndex];
    const activeCsv = editor.currentCsv;
    const columns = editor.columns;
    const objectColumns = editor.objectColumns || [];
    const columnOptions = objectColumns.map((column) => ({ value: column.id, label: column.label }));
    const update = (values) => selectedIndex !== null && graphApi.setObjectValues(chartId, selectedIndex, values);
    const selectField = (label, key, data) => React.createElement(Select, {
      label,
      data,
      value: selected?.[key] ?? null,
      disabled: busy,
      onChange: (value2) => value2 !== null && update({ [key]: value2 })
    });
    const numberField = (label, key, min, max, step = 1) => React.createElement(NumberInput, {
      label,
      value: selected?.[key],
      min,
      max,
      step,
      disabled: busy,
      onChange: (value2) => update({ [key]: value2 })
    });
    return React.createElement(
      Stack,
      { gap: "xs", p: "md" },
      React.createElement(Text, { fw: 600 }, "그래프 / 데이터"),
      React.createElement(
        Button,
        {
          variant: "light",
          disabled: busy,
          onClick: assetApi.createEmptyCsv
        },
        "빈 CSV 삽입"
      ),
      React.createElement(Select, {
        label: "사용할 CSV",
        data: csvOptions,
        value: activeCsv ? String(activeCsv.id) : null,
        disabled: busy || !csvOptions.length,
        onChange: (value2) => {
          const csv = csvAssets.find((item) => String(item.id) === value2);
          if (csv) graphApi.selectCsv(csv.path);
        }
      }),
      activeCsv ? React.createElement(NumberInput, {
        label: "헤더 행 수",
        value: activeCsv.headerLines,
        min: 0,
        max: activeCsv.rows.length,
        allowDecimal: false,
        disabled: busy,
        onChange: (value2) => graphApi.setHeaderLines(activeCsv.id, value2)
      }) : null,
      activeCsv && columns.length ? React.createElement(
        ScrollArea,
        { h: 220, type: "auto" },
        React.createElement(
          Table,
          { fz: "xs" },
          React.createElement(
            TableThead,
            null,
            React.createElement(
              TableTr,
              null,
              ...columns.map(
                (column) => React.createElement(TableTh, { key: column.id }, column.label)
              )
            )
          ),
          React.createElement(
            TableTbody,
            null,
            ...activeCsv.rows.slice(0, 30).map(
              (row, rowIndex) => React.createElement(
                TableTr,
                { key: rowIndex },
                ...columns.map(
                  (column) => React.createElement(
                    TableTd,
                    {
                      key: column.id,
                      fw: rowIndex < activeCsv.headerLines ? 600 : 400
                    },
                    String(row?.[column.index] ?? "")
                  )
                )
              )
            )
          )
        )
      ) : null,
      React.createElement(
        Group,
        { gap: "xs", grow: true },
        React.createElement(Button, {
          variant: editable ? "filled" : "light",
          disabled: busy || chartId === null,
          onClick: () => {
            const context = graphApi.readData();
            if (context.chart) return setSelectedGraphEditable(!context.chart.editor.editable);
          }
        }, editable ? "편집 가능" : "원본 JSON"),
        React.createElement(Button, {
          variant: "light",
          disabled: busy || !activeCsv || !editable,
          onClick: addSelectedGraphObject
        }, "오브젝트 추가")
      ),
      React.createElement(Text, { size: "sm", fw: 600 }, "그래프 오브젝트"),
      objects.length ? React.createElement(
        Stack,
        { gap: 4 },
        ...objects.map((object, index) => React.createElement(
          Group,
          {
            key: `${chartId}-${index}`,
            gap: 4,
            wrap: "nowrap",
            draggable: editable && !busy,
            onDragStart: (event) => {
              if (!editable || busy) return event.preventDefault();
              dragRef.current = index;
            },
            onDragEnd: () => {
              dragRef.current = null;
            },
            onDragOver: (event) => {
              if (editable && !busy) event.preventDefault();
            },
            onDrop: (event) => {
              if (!editable || busy) return;
              event.preventDefault();
              if (Number.isInteger(dragRef.current)) graphApi.moveObject(chartId, dragRef.current, index);
              dragRef.current = null;
            }
          },
          React.createElement(Button, {
            size: "xs",
            variant: selectedIndex === index ? "filled" : "light",
            style: { flex: "1 1 auto", minWidth: 0 },
            onClick: () => graphApi.selectObject(index)
          }, `${index + 1}. ${object.legendName || `${object.x} · ${object.y}`}`),
          React.createElement(ColorInput, {
            size: "xs",
            value: object.color,
            style: { width: 72 },
            disabled: busy || !editable,
            onChange: (color) => graphApi.setObjectValues(chartId, index, { color })
          }),
          React.createElement(ActionIcon, {
            size: "sm",
            variant: "subtle",
            disabled: busy || !editable,
            "aria-label": `${index + 1}번 그래프 오브젝트 삭제`,
            onClick: () => graphApi.deleteObject(chartId, index)
          }, "×")
        ))
      ) : React.createElement(Text, { size: "xs", c: "dimmed" }, "추가된 그래프 오브젝트가 없습니다."),
      selected && activeCsv && editable ? React.createElement(
        Stack,
        { gap: "xs" },
        React.createElement(Select, {
          label: "오브젝트 CSV",
          data: csvOptions,
          value: String(selected.csvId),
          disabled: busy,
          onChange: (value2) => value2 !== null && update({ csvId: Number(value2) })
        }),
        React.createElement(
          Group,
          { gap: "xs", grow: true },
          selectField("X 열", "x", columnOptions),
          selectField("Y 열", "y", columnOptions)
        ),
        React.createElement(
          Group,
          { gap: "xs", grow: true },
          selectField("X 축", "xAxisSide", [{ value: "bottom", label: "아래" }, { value: "top", label: "위" }]),
          selectField("Y 축", "yAxisSide", [{ value: "left", label: "왼쪽" }, { value: "right", label: "오른쪽" }])
        ),
        selectField("유형", "type", [
          { value: "scatter", label: "선" },
          { value: "markers", label: "마커" },
          { value: "lines+markers", label: "선 + 마커" },
          { value: "bar", label: "막대" },
          { value: "hidden", label: "숨김" }
        ]),
        React.createElement(TextInput, {
          label: "범례 이름",
          value: selected.legendName,
          disabled: busy,
          onChange: (event) => update({ legendName: event.target.value })
        }),
        ["scatter", "lines+markers", "hidden"].includes(selected.type) ? React.createElement(
          Group,
          { gap: "xs", grow: true },
          numberField("선 굵기", "lineWidth", 0.1, 20, 0.1),
          React.createElement(TextInput, {
            label: "선 스타일",
            value: selected.lineDash,
            disabled: busy,
            onChange: (event) => update({ lineDash: event.target.value })
          })
        ) : null,
        ["markers", "lines+markers"].includes(selected.type) ? React.createElement(
          Group,
          { gap: "xs", grow: true },
          React.createElement(TextInput, {
            label: "마커",
            value: selected.markerSymbol,
            disabled: busy,
            onChange: (event) => update({ markerSymbol: event.target.value })
          }),
          numberField("마커 크기", "markerSize", 1, 40)
        ) : null,
        selected.type === "bar" ? React.createElement(
          Group,
          { gap: "xs", grow: true },
          numberField("막대 불투명도", "barOpacity", 0.05, 1, 0.05),
          numberField("막대 테두리", "barLineWidth", 0, 10, 0.1)
        ) : null
      ) : null
    );
  }
  function FastFigureGraphLayoutEditor() {
    const state = useAppState();
    const busy = state.lifecycle !== "ready";
    if (state.workspace !== "slot.graph") return null;
    const graphApi = window.FastFigureApi.graphs;
    const editor = graphApi.readLayout();
    if (!editor) return null;
    const settings = editor.settings;
    const editable = editor.editable;
    const axisLabels = {
      xBottom: "아래 X축",
      xTop: "위 X축",
      yLeft: "왼쪽 Y축",
      yRight: "오른쪽 Y축"
    };
    const updateGlobal = (values) => updateSelectedGraphLayout({ globalSettings: values });
    const updateTitle = (title) => updateSelectedGraphLayout({ title });
    const updateAxis = (key, values) => updateSelectedGraphLayout({ axisKey: key, axisValues: values });
    const toggleGlobal = (key, label) => React.createElement(
      Button,
      {
        size: "xs",
        variant: settings[key] ? "filled" : "light",
        disabled: busy || !editable,
        "aria-pressed": settings[key],
        onClick: () => updateGlobal({ [key]: !settings[key] })
      },
      label
    );
    const axisNumber = (key, axis, field, label, options = {}) => React.createElement(NumberInput, {
      label,
      value: axis[field],
      disabled: busy || !editable,
      ...options,
      onChange: (value2) => updateAxis(key, {
        [field]: value2 === "" ? "" : String(value2)
      })
    });
    const axisToggle = (key, axis, field, label) => React.createElement(
      Button,
      {
        size: "xs",
        variant: axis[field] ? "filled" : "light",
        disabled: busy || !editable,
        "aria-pressed": axis[field],
        onClick: () => updateAxis(key, { [field]: !axis[field] })
      },
      label
    );
    const axisEditor = (key) => {
      const axis = settings.axes[key];
      const logScale = axis.scaleType === "log";
      return React.createElement(
        Stack,
        { key, gap: "xs" },
        React.createElement(Text, { size: "sm", fw: 600 }, axisLabels[key]),
        React.createElement(TextInput, {
          label: "축 이름",
          value: axis.title,
          disabled: busy || !editable,
          onChange: (event) => updateAxis(key, { title: event.target.value })
        }),
        React.createElement(
          Group,
          { gap: "xs", grow: true },
          axisNumber(key, axis, "min", "최소"),
          axisNumber(key, axis, "max", "최대")
        ),
        React.createElement(
          Group,
          { gap: "xs", grow: true },
          React.createElement(
            Button,
            {
              variant: logScale ? axis.minorTicks ? "filled" : "light" : axis.tickMode === "increment" ? "filled" : "light",
              disabled: busy || !editable,
              "aria-pressed": logScale ? axis.minorTicks : axis.tickMode === "increment",
              onClick: () => logScale ? updateAxis(key, { minorTicks: !axis.minorTicks, tickMode: "plotly" }) : updateAxis(key, {
                tickMode: axis.tickMode === "increment" ? "plotly" : "increment"
              })
            },
            logScale ? axis.minorTicks ? "minor tick 표시" : "minor tick 숨김" : axis.tickMode === "increment" ? "increment" : "Plotly tick"
          ),
          logScale ? null : axisNumber(key, axis, "tick", "tick 간격")
        ),
        React.createElement(
          Group,
          { gap: "xs", grow: true },
          React.createElement(Select, {
            label: "표기",
            data: [
              { value: "none", label: "숫자" },
              { value: "power", label: "지수" },
              { value: "e", label: "과학 표기" }
            ],
            value: axis.notation,
            disabled: busy || !editable,
            onChange: (value2) => value2 !== null && updateAxis(key, { notation: value2 })
          }),
          React.createElement(Select, {
            label: "축 유형",
            data: [
              { value: "linear", label: "선형" },
              { value: "log", label: "로그" },
              { value: "reciprocal", label: "역수" }
            ],
            value: axis.scaleType,
            disabled: busy || !editable,
            onChange: (value2) => value2 !== null && updateAxis(key, {
              scaleType: value2,
              tickMode: value2 === "log" ? "plotly" : axis.tickMode
            })
          })
        ),
        axisNumber(key, axis, "divide", "값 나누기"),
        React.createElement(
          Group,
          { gap: "xs", grow: true },
          axisNumber(key, axis, "titleSize", "축 이름 크기"),
          axisNumber(key, axis, "fontSize", "숫자 크기")
        ),
        axisNumber(key, axis, "lineWidth", "축선 굵기", { min: 0 }),
        React.createElement(
          Group,
          { gap: "xs", grow: true },
          axisToggle(key, axis, "showGrid", "격자"),
          axisToggle(key, axis, "visible", "축"),
          axisToggle(key, axis, "showValues", "값")
        )
      );
    };
    return React.createElement(
      Stack,
      { gap: "xs", p: "md" },
      React.createElement(Text, { fw: 600 }, "그래프 전역 / 축"),
      React.createElement(TextInput, {
        label: "그래프 제목",
        value: editor.title,
        disabled: busy || !editable,
        onChange: (event) => updateTitle(event.target.value)
      }),
      React.createElement(
        Group,
        { gap: "xs", grow: true },
        toggleGlobal("showLegend", "범례"),
        toggleGlobal("showTitle", "제목"),
        toggleGlobal("showZeroLine", "0선")
      ),
      React.createElement(Select, {
        label: "그래프 글꼴",
        data: fontSelectData(GRAPH_FONT_OPTIONS, settings.graphFontFamily),
        value: fontSelectValue(settings.graphFontFamily),
        disabled: busy || !editable,
        allowDeselect: false,
        "data-fastfigure-font-select": "graph",
        onChange: (value2) => {
          const fontFamily = fontValueFromSelect(value2);
          if (fontFamily !== null) updateGlobal({ graphFontFamily: fontFamily });
        }
      }),
      React.createElement(
        Group,
        { gap: "xs", grow: true },
        React.createElement(NumberInput, {
          label: "제목 크기",
          value: settings.titleFontSize,
          disabled: busy || !editable,
          onChange: (value2) => updateGlobal({ titleFontSize: value2 === "" ? "" : String(value2) })
        }),
        React.createElement(NumberInput, {
          label: "범례 크기",
          value: settings.legendFontSize,
          disabled: busy || !editable,
          onChange: (value2) => updateGlobal({ legendFontSize: value2 === "" ? "" : String(value2) })
        })
      ),
      ...Object.keys(axisLabels).map(axisEditor)
    );
  }
  function FastFigureGraphPaletteActions() {
    const state = useAppState();
    const busy = state.lifecycle !== "ready";
    const importResetRef = useRef(null);
    if (state.workspace !== "slot.graph") return null;
    const graphApi = window.FastFigureApi.graphs;
    const editor = graphApi.readData(), colors = graphApi.readPalette();
    const canEdit = !!editor.chart && editor.chart.editor.editable !== false;
    const commitColors = (colors2) => graphApi.applyPalette(editor.chart?.id ?? null, colors2);
    const resetPalette = () => {
      if (!editor.chart) return status("그래프 슬롯을 먼저 선택하세요.");
      const result = commitColors(graphApi.defaultColors());
      if (result?.id == null || result.id !== editor.chart?.id) return result;
      debugLog("graphPalette:reset", { slotId: state.selectedSlotId });
    };
    const savePalette = () => {
      if (!editor.chart) return status("그래프 슬롯을 먼저 선택하세요.");
      const savedColors = colors.filter(Boolean);
      const blob = new Blob([JSON.stringify({ colors: savedColors }, null, 2)], {
        type: "application/json;charset=utf-8"
      });
      const link = document.createElement("a");
      const stamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
      link.href = URL.createObjectURL(blob);
      link.download = `chart-palette-${stamp}.json`;
      link.click();
      setTimeout(() => URL.revokeObjectURL(link.href), 0);
      debugLog("graphPalette:save", {
        slotId: state.selectedSlotId,
        colors: savedColors.length
      });
    };
    const loadPalette = async (file) => {
      if (!file) return;
      try {
        await runLifecycleTask2("importing", "PALETTE_IMPORT", async () => {
          try {
            const parsed = JSON.parse(await file.text());
            const colors2 = Array.isArray(parsed) ? parsed : parsed.colors;
            if (!Array.isArray(colors2) || !colors2.length)
              throw Error("colors 배열이 없습니다.");
            const valid = colors2.filter(
              (color) => typeof color === "string" && /^#[0-9a-f]{6}$/i.test(color)
            );
            if (!valid.length) throw Error("유효한 HEX 색상이 없습니다.");
            const result = commitColors(valid);
            if (result?.id == null || result.id !== editor.chart?.id) return result;
            status(`${file.name} 색상 구성을 덮어썼습니다.`);
            debugLog("graphPalette:load", {
              slotId: appFSM.readState().selectedSlotId,
              name: file.name,
              colors: valid.length
            });
          } catch (error) {
            status("팔레트 불러오기 실패: " + error.message);
            debugLog("graphPalette:load-error", { message: error.message });
            throw error;
          }
        });
      } finally {
        importResetRef.current?.();
      }
    };
    return React.createElement(
      Stack,
      { gap: "xs", px: "md", pb: "md" },
      React.createElement(Text, { fw: 600 }, "그래프 색상 구성"),
      React.createElement(
        Group,
        { gap: "xs", grow: true },
        React.createElement(
          Button,
          { variant: "light", disabled: busy || !canEdit, onClick: resetPalette },
          "기본색"
        ),
        React.createElement(
          Button,
          { variant: "light", disabled: busy || !editor.chart, onClick: savePalette },
          "저장"
        ),
        React.createElement(
          FileButton,
          {
            onChange: loadPalette,
            accept: ".json,application/json",
            resetRef: importResetRef,
            disabled: busy || !canEdit
          },
          (props) => React.createElement(
            Button,
            { ...props, variant: "light", disabled: busy || !canEdit },
            "불러오기"
          )
        )
      )
    );
  }
  function FastFigureGraphFileActions() {
    const state = useAppState();
    const busy = state.lifecycle !== "ready";
    const importResetRef = useRef(null);
    if (state.workspace !== "slot.graph") return null;
    const graphApi = window.FastFigureApi.graphs;
    const openSlotImportPicker = (open) => {
      if (!graphApi.hasSelectedSlot())
        return status("FFSX 또는 Plotly JSON을 불러올 슬롯을 먼저 선택하세요.");
      open();
    };
    const importSlotFileFromMantine = async (file) => {
      if (!file) return;
      try {
        await importSelectedSlotFile(file);
      } catch (error) {
        status("슬롯 불러오기 오류: " + String(error?.message ?? error));
        debugLog("slot:import-error", { message: String(error?.message ?? error) });
      } finally {
        importResetRef.current?.();
      }
    };
    return React.createElement(
      Stack,
      { gap: "xs", p: "md" },
      React.createElement(Text, { fw: 600 }, "그래프 파일"),
      React.createElement(
        Group,
        { gap: "xs", grow: true },
        React.createElement(
          Button,
          { variant: "light", disabled: busy, onClick: exportSlotFfsxFromMantine },
          "FFSX 내보내기"
        ),
        React.createElement(
          Button,
          { variant: "light", disabled: busy, onClick: exportPlotlyJsonFromMantine },
          "Plotly JSON 내보내기"
        )
      ),
      React.createElement(
        FileButton,
        {
          onChange: importSlotFileFromMantine,
          resetRef: importResetRef,
          disabled: busy
        },
        (props) => React.createElement(
          Button,
          {
            ...props,
            variant: "light",
            disabled: busy,
            onClick: () => openSlotImportPicker(props.onClick)
          },
          "FFSX/Plotly JSON 불러오기"
        )
      )
    );
  }
  function FastFigurePaletteActions() {
    const state = useAppState();
    const busy = state.lifecycle !== "ready";
    const appearanceApi = window.FastFigureApi.appearance;
    const [opened, setOpened] = useState(false);
    const [draft, setDraft] = useState(() => ({
      ...appearanceApi.readPalette()
    }));
    const fields = [
      ["uiColor", "강조색"],
      ["uiBackgroundColor", "UI 배경"],
      ["uiSurfaceColor", "UI 표면"],
      ["uiMutedColor", "보조 텍스트"],
      ["uiSubtleColor", "약한 텍스트"],
      ["uiDisabledBgColor", "비활성 배경"],
      ["uiDisabledTextColor", "비활성 텍스트"],
      ["uiShadowColor", "그림자"],
      ["paperColor", "그래프 배경"],
      ["fontColor", "그래프 글자"]
    ];
    const openPalette = () => {
      setDraft({ ...appearanceApi.readPalette() });
      setOpened(true);
    };
    const applyPalette = () => {
      appearanceApi.setPalette(draft);
      setOpened(false);
    };
    const resetPalette = () => {
      const result = appearanceApi.resetPalette();
      if (result === false) return;
      setDraft({ ...result });
    };
    return React.createElement(
      Stack,
      { gap: "xs", px: "md", pb: "md" },
      React.createElement(
        Button,
        { variant: "light", disabled: busy, onClick: openPalette },
        "UI 색상"
      ),
      React.createElement(
        Modal,
        {
          opened,
          onClose: () => setOpened(false),
          title: "UI 색상",
          size: "lg"
        },
        React.createElement(
          Stack,
          { gap: "sm" },
          ...fields.map(
            ([key, label]) => React.createElement(ColorInput, {
              key,
              label,
              value: draft[key],
              disabled: busy,
              onChange: (value2) => setDraft((current) => ({ ...current, [key]: value2 }))
            })
          ),
          React.createElement(
            Group,
            { justify: "space-between", gap: "xs" },
            React.createElement(
              Button,
              { variant: "light", disabled: busy, onClick: resetPalette },
              "기본값"
            ),
            React.createElement(
              Group,
              { gap: "xs" },
              React.createElement(
                Button,
                { variant: "light", onClick: () => setOpened(false) },
                "취소"
              ),
              React.createElement(
                Button,
                { disabled: busy, onClick: applyPalette },
                "적용"
              )
            )
          )
        )
      )
    );
  }
  function FastFigureUtilityActions() {
    const state = useAppState();
    return React.createElement(
      Stack,
      { gap: "xs", p: "md", mt: "auto" },
      React.createElement(
        Button,
        {
          variant: state.overlay === "readme" ? "filled" : "light",
          "aria-expanded": state.overlay === "readme",
          onClick: () => toggleOverlay("readme")
        },
        "README"
      )
    );
  }
  function FastFigureStatusDebug() {
    const telemetry = useUiTelemetry();
    const state = useAppState();
    const busy = state.lifecycle !== "ready";
    return React.createElement(
      Stack,
      { gap: "xs", px: "md", pb: "md" },
      React.createElement(
        Text,
        {
          size: "sm",
          c: "dimmed",
          "aria-live": "polite",
          style: { whiteSpace: "pre-wrap" }
        },
        telemetry.status || "준비됨"
      ),
      React.createElement(
        Group,
        { gap: "xs", grow: true },
        React.createElement(
          Button,
          {
            size: "xs",
            variant: telemetry.debugEnabled ? "filled" : "light",
            disabled: busy,
            "aria-pressed": telemetry.debugEnabled,
            onClick: () => setDebugEnabled(!readDebugEnabled())
          },
          telemetry.debugEnabled ? "디버깅 끄기" : "디버깅 켜기"
        ),
        React.createElement(
          Button,
          {
            size: "xs",
            variant: "light",
            disabled: busy || !telemetry.debugLines.length,
            onClick: saveDebugOutput
          },
          "로그 저장"
        ),
        React.createElement(
          Button,
          {
            size: "xs",
            variant: "light",
            disabled: busy || !telemetry.debugLines.length,
            onClick: clearDebugOutput
          },
          "로그 지우기"
        )
      ),
      telemetry.debugEnabled ? React.createElement(
        ScrollArea,
        { h: 220, type: "auto" },
        React.createElement(
          Code,
          {
            block: true,
            style: {
              whiteSpace: "pre-wrap",
              overflowWrap: "anywhere"
            }
          },
          telemetry.debugLines.join("\n")
        )
      ) : null
    );
  }
  function FastFigureReadmeOverlay() {
    const state = useAppState();
    if (state.overlay !== "readme") return null;
    return React.createElement(
      Modal,
      {
        opened: true,
        onClose: () => appFSM.send("CLOSE_OVERLAY", { reason: "mantine-readme" }),
        title: "Fast figure README",
        size: "xl",
        "data-fastfigure-overlay": "readme"
      },
      React.createElement(
        ScrollArea.Autosize,
        { mah: "75vh", type: "auto" },
        React.createElement(Box, {
          dangerouslySetInnerHTML: { __html: readmeContentHtml() }
        })
      )
    );
  }
  function FastFigureSettingsModal({ title, overlay, onClose, onContentClick, children }) {
    const modalRootRef = useRef(null);
    const resizeRef = useRef(null);
    const resizeListenersRef = useRef(null);
    const clearResizeListeners = () => {
      const listeners = resizeListenersRef.current;
      if (listeners) {
        window.removeEventListener("mousemove", listeners.move);
        window.removeEventListener("mouseup", listeners.end);
      }
      resizeListenersRef.current = null;
      resizeRef.current = null;
      document.body.style.userSelect = "";
      document.body.style.cursor = "";
    };
    useEffect(() => () => clearResizeListeners(), []);
    const resolveModalContent = () => modalRootRef.current?.querySelector?.("[data-modal-content]") || null;
    const startResize = (event) => {
      if (event.button !== 0) return;
      const content = resolveModalContent();
      if (!content) return;
      clearResizeListeners();
      const rect = content.getBoundingClientRect();
      const inner = content.parentElement;
      if (inner) {
        inner.style.alignItems = "flex-start";
        inner.style.paddingTop = `${rect.top}px`;
        inner.style.paddingBottom = "0px";
      }
      resizeRef.current = {
        startY: event.clientY,
        startHeight: rect.height,
        top: rect.top
      };
      const move = (moveEvent) => {
        const drag = resizeRef.current;
        if (!drag) return;
        const minHeight = 240;
        const maxHeight = Math.max(minHeight, window.innerHeight - drag.top - 12);
        const nextHeight = Math.max(
          minHeight,
          Math.min(maxHeight, drag.startHeight + moveEvent.clientY - drag.startY)
        );
        const currentContent = resolveModalContent();
        currentContent?.style.setProperty("--modal-content-height", `${nextHeight}px`);
      };
      const end = () => clearResizeListeners();
      resizeListenersRef.current = { move, end };
      window.addEventListener("mousemove", move);
      window.addEventListener("mouseup", end);
      document.body.style.userSelect = "none";
      document.body.style.cursor = "ns-resize";
      event.preventDefault();
    };
    return React.createElement(
      Modal,
      {
        ref: modalRootRef,
        opened: true,
        onClose,
        title,
        centered: true,
        size: fastFigureTheme.other.settingsModalSize,
        "data-fastfigure-overlay": overlay,
        styles: {
          content: {
            "--modal-content-height": "min(72dvh, 720px)",
            "--modal-content-max-height": "calc(100dvh - 24px)"
          },
          body: {
            minHeight: 0,
            display: "flex",
            flexDirection: "column"
          }
        }
      },
      React.createElement(
        Box,
        {
          onClick: onContentClick,
          "data-fastfigure-settings-content": overlay,
          style: {
            minHeight: 0,
            flex: "1 1 auto"
          }
        },
        children
      ),
      React.createElement(
        Box,
        {
          role: "separator",
          "aria-orientation": "horizontal",
          "aria-label": `${title} 창 높이 조절`,
          onMouseDown: startResize,
          "data-fastfigure-modal-resize": overlay,
          style: {
            position: "sticky",
            bottom: 0,
            flexShrink: 0,
            width: "100%",
            height: 24,
            marginTop: 12,
            cursor: "ns-resize",
            userSelect: "none",
            display: "grid",
            placeItems: "center",
            borderTop: "1px solid var(--mantine-color-default-border)",
            background: "var(--mantine-color-body)",
            zIndex: 1
          }
        },
        React.createElement(Box, {
          w: 42,
          h: 4,
          style: {
            borderRadius: 99,
            background: "var(--mantine-primary-color-filled)"
          }
        })
      )
    );
  }
  function FastFigureLabelOverlay() {
    const state = useAppState();
    const previewRef = useRef(null);
    const dragRef = useRef(null);
    const [, setPreviewRevision] = useState(0);
    if (state.overlay !== "label") return null;
    const busy = state.lifecycle !== "ready";
    const labelApi = window.FastFigureApi.labels;
    const label = labelApi.readState();
    const settings = label.settings;
    const reference = label.reference;
    const previewWidth = 420;
    const previewScale = previewWidth / Math.max(1, reference.width);
    const previewHeight = Math.max(120, reference.height * previewScale);
    const commit = (patch) => labelApi.setSettings(patch);
    const startPreviewDrag = (event) => {
      if (busy) return;
      const rect = event.currentTarget.getBoundingClientRect();
      dragRef.current = {
        pointerId: event.pointerId,
        offsetX: event.clientX - rect.left,
        offsetY: event.clientY - rect.top
      };
      event.currentTarget.setPointerCapture?.(event.pointerId);
      event.preventDefault();
    };
    const movePreviewDrag = (event) => {
      const drag = dragRef.current;
      const preview = previewRef.current;
      if (!drag || drag.pointerId !== event.pointerId || !preview) return;
      const previewRect = preview.getBoundingClientRect();
      const labelRect = event.currentTarget.getBoundingClientRect();
      const labelWidth = labelRect.width / previewScale;
      const labelHeight = labelRect.height / previewScale;
      const nextX = (event.clientX - previewRect.left - drag.offsetX) / previewScale;
      const nextY = (event.clientY - previewRect.top - drag.offsetY) / previewScale;
      labelApi.setPosition(
        Math.max(0, Math.min(Math.max(0, reference.width - labelWidth), nextX)),
        Math.max(0, Math.min(Math.max(0, reference.height - labelHeight), nextY))
      );
      setPreviewRevision((revision) => revision + 1);
    };
    const stopPreviewDrag = (event) => {
      if (dragRef.current?.pointerId !== event.pointerId) return;
      event.currentTarget.releasePointerCapture?.(event.pointerId);
      dragRef.current = null;
      labelApi.finishPositionInteraction();
    };
    const close = () => appFSM.send("CLOSE_OVERLAY", { reason: "mantine-label" });
    return React.createElement(
      FastFigureSettingsModal,
      {
        onClose: close,
        title: "레이블",
        overlay: "label"
      },
      React.createElement(
        Stack,
        { gap: "md" },
        React.createElement(
          Button,
          {
            variant: label.enabled ? "filled" : "light",
            disabled: busy,
            "aria-pressed": label.enabled,
            onClick: () => labelApi.setEnabled(!label.enabled)
          },
          label.enabled ? "레이블 표시" : "레이블 숨김"
        ),
        React.createElement(
          Group,
          { gap: "xs", grow: true },
          React.createElement(Select, {
            label: "형식",
            value: settings.format,
            data: [
              { value: "lower-alpha", label: "a, b, c" },
              { value: "upper-alpha", label: "A, B, C" },
              { value: "decimal", label: "1, 2, 3" },
              { value: "lower-roman", label: "i, ii, iii" },
              { value: "upper-roman", label: "I, II, III" }
            ],
            disabled: busy,
            onChange: (value2) => value2 !== null && commit({ format: value2 })
          }),
          React.createElement(Select, {
            label: "순서",
            value: settings.order,
            data: [
              { value: "row-major", label: "행 우선" },
              { value: "column-major", label: "열 우선" }
            ],
            disabled: busy,
            onChange: (value2) => value2 !== null && commit({ order: value2 })
          })
        ),
        React.createElement(
          Group,
          { gap: "xs", grow: true },
          React.createElement(
            Button,
            {
              variant: settings.parentheses ? "filled" : "light",
              disabled: busy,
              "aria-pressed": settings.parentheses,
              onClick: () => commit({ parentheses: !settings.parentheses })
            },
            "괄호"
          ),
          React.createElement(Select, {
            label: "글꼴",
            data: fontSelectData(ANNOTATION_FONT_OPTIONS, settings.fontFamily),
            value: fontSelectValue(settings.fontFamily),
            disabled: busy,
            allowDeselect: false,
            "data-fastfigure-font-select": "label",
            onChange: (value2) => {
              const fontFamily = fontValueFromSelect(value2);
              if (fontFamily !== null) commit({ fontFamily });
            }
          }),
          React.createElement(NumberInput, {
            label: "크기",
            value: settings.fontSize,
            min: 6,
            disabled: busy,
            onChange: (value2) => {
              const number = Number(value2);
              commit({ fontSize: Number.isFinite(number) ? Math.max(6, number) : 14 });
            }
          })
        ),
        React.createElement(
          Group,
          { gap: "xs", grow: true },
          React.createElement(NumberInput, {
            label: "X (px)",
            value: settings.x,
            disabled: busy,
            onChange: (value2) => labelApi.setPosition(
              Number.isFinite(Number(value2)) ? Number(value2) : 0,
              settings.y
            )
          }),
          React.createElement(NumberInput, {
            label: "Y (px)",
            value: settings.y,
            disabled: busy,
            onChange: (value2) => labelApi.setPosition(
              settings.x,
              Number.isFinite(Number(value2)) ? Number(value2) : 0
            )
          }),
          React.createElement(
            Button,
            {
              variant: "light",
              disabled: busy,
              onClick: () => labelApi.resetPosition()
            },
            "위치 초기화"
          )
        ),
        React.createElement(
          "div",
          {
            ref: previewRef,
            style: {
              position: "relative",
              width: previewWidth,
              maxWidth: "100%",
              height: previewHeight,
              border: "1px solid var(--mantine-color-default-border)",
              borderRadius: "var(--mantine-radius-sm)",
              overflow: "hidden",
              touchAction: "none"
            }
          },
          React.createElement(
            "div",
            {
              role: "button",
              tabIndex: 0,
              "aria-label": "레이블 위치 드래그",
              onPointerDown: startPreviewDrag,
              onPointerMove: movePreviewDrag,
              onPointerUp: stopPreviewDrag,
              onPointerCancel: stopPreviewDrag,
              style: {
                position: "absolute",
                left: settings.x * previewScale,
                top: settings.y * previewScale,
                fontFamily: settings.fontFamily,
                fontSize: settings.fontSize * previewScale,
                fontWeight: 800,
                lineHeight: 1.2,
                padding: `${2 * previewScale}px ${6 * previewScale}px`,
                cursor: busy ? "default" : "grab",
                userSelect: "none",
                touchAction: "none"
              }
            },
            label.sampleText
          )
        )
      )
    );
  }
  function FastFigureCaptionOverlay() {
    const state = useAppState();
    const [targetMode, setTargetMode] = useState("global");
    useEffect(() => {
      if (state.overlay !== "caption") setTargetMode("global");
    }, [state.overlay]);
    if (state.overlay !== "caption") return null;
    const busy = state.lifecycle !== "ready";
    const captionApi = window.FastFigureApi.captions;
    const slotApi = window.FastFigureApi.slots;
    const globalCaption = captionApi.readGlobal();
    const selectedSlot = slotApi.readSelected();
    const slotCaption = targetMode === "slot" && selectedSlot ? captionApi.readSlot(selectedSlot.id) : null;
    const settings = globalCaption.settings;
    const close = () => appFSM.send("CLOSE_OVERLAY", { reason: "mantine-caption" });
    const commitSettings = (patch) => captionApi.setSettings(patch);
    const slotMode = targetMode === "slot";
    return React.createElement(
      FastFigureSettingsModal,
      {
        onClose: close,
        title: "캡션",
        overlay: "caption"
      },
      React.createElement(
        Stack,
        { gap: "md" },
        React.createElement(
          Group,
          { gap: "xs", grow: true },
          React.createElement(
            Button,
            {
              variant: globalCaption.enabled ? "filled" : "light",
              disabled: busy,
              "aria-pressed": globalCaption.enabled,
              onClick: () => captionApi.setEnabled(!globalCaption.enabled)
            },
            globalCaption.enabled ? "캡션 표시" : "캡션 숨김"
          ),
          React.createElement(
            Button,
            {
              variant: slotMode ? "filled" : "light",
              disabled: busy || !selectedSlot,
              "aria-pressed": slotMode,
              onClick: () => setTargetMode(slotMode ? "global" : "slot")
            },
            "슬롯별 캡션"
          ),
          React.createElement(
            Button,
            {
              variant: "light",
              disabled: busy,
              onClick: () => captionApi.insertSlotCaptions()
            },
            "슬롯 캡션 삽입"
          )
        ),
        React.createElement(
          Text,
          { size: "sm", c: "dimmed" },
          slotMode ? slotCaption ? `대상: ${slotCaption.row}행 ${slotCaption.col}열` : "대상 슬롯을 선택하세요." : "대상: 전체 캡션"
        ),
        React.createElement(Textarea, {
          label: "내용",
          value: slotMode ? slotCaption?.text ?? "" : globalCaption.text,
          placeholder: slotMode ? "슬롯 캡션" : void 0,
          minRows: 5,
          autosize: true,
          disabled: busy || slotMode && !slotCaption,
          onChange: (event) => slotMode ? slotCaption && captionApi.setSlotText(slotCaption.id, event.target.value) : captionApi.setGlobalText(event.target.value)
        }),
        React.createElement(
          Group,
          { gap: "xs", grow: true },
          React.createElement(TextInput, {
            label: "이름",
            value: globalCaption.name,
            disabled: busy || slotMode,
            onChange: (event) => captionApi.setName(event.target.value)
          }),
          React.createElement(
            Button,
            {
              variant: globalCaption.nameBold ? "filled" : "light",
              disabled: busy || slotMode,
              "aria-pressed": globalCaption.nameBold,
              onClick: () => captionApi.setNameBold(!globalCaption.nameBold)
            },
            "이름 굵게"
          )
        ),
        React.createElement(
          Group,
          { gap: "xs", grow: true },
          React.createElement(Select, {
            label: "글꼴",
            data: fontSelectData(ANNOTATION_FONT_OPTIONS, settings.fontFamily),
            value: fontSelectValue(settings.fontFamily),
            disabled: busy,
            allowDeselect: false,
            "data-fastfigure-font-select": "caption",
            onChange: (value2) => {
              const fontFamily = fontValueFromSelect(value2);
              if (fontFamily !== null) commitSettings({ fontFamily });
            }
          }),
          React.createElement(NumberInput, {
            label: "크기",
            value: settings.fontSize,
            min: 6,
            max: 96,
            disabled: busy,
            onChange: (value2) => commitSettings({ fontSize: value2 })
          }),
          React.createElement(NumberInput, {
            label: "줄 간격",
            value: settings.lineHeight,
            min: 0.8,
            max: 4,
            step: 0.05,
            disabled: busy,
            onChange: (value2) => commitSettings({ lineHeight: value2 })
          })
        )
      )
    );
  }
  function FastFigurePrintOverlay() {
    const state = useAppState();
    const printApi = window.FastFigureApi.print;
    const initial = printApi.readSettings();
    const [width, setWidth] = useState(initial.width);
    const [height, setHeight] = useState(
      initial.heightMode === "explicit" ? initial.height : ""
    );
    const [dpi, setDpi] = useState(initial.dpi);
    const [format, setFormat] = useState(initial.format);
    const [message, setMessage] = useState("");
    useEffect(() => {
      if (state.overlay !== "print") return;
      const saved = printApi.readSettings();
      setWidth(saved.width);
      setHeight(saved.heightMode === "explicit" ? saved.height : "");
      setDpi(saved.dpi);
      setFormat(saved.format);
    }, [state.overlay]);
    if (state.overlay !== "print") return null;
    const busy = state.lifecycle !== "ready";
    const close = () => appFSM.send("CLOSE_OVERLAY", { reason: "mantine-print" });
    const commit = (patch) => {
      const next = printApi.setSettings(patch);
      setWidth(next.width);
      setHeight(next.heightMode === "explicit" ? next.height : "");
      setDpi(next.dpi);
      setFormat(next.format);
      return next;
    };
    const save = () => printApi.save(setMessage).catch((error) => reportTaskError("PRINT_EXPORT", error));
    const capture = () => printApi.capture(setMessage).catch((error) => reportTaskError("CAPTURE_EXPORT", error));
    return React.createElement(
      FastFigureSettingsModal,
      {
        onClose: close,
        title: "프린트 / 내보내기",
        overlay: "print"
      },
      React.createElement(
        Stack,
        { gap: "md" },
        React.createElement(
          Group,
          { gap: "xs", grow: true },
          React.createElement(Select, {
            label: "형식",
            value: format,
            data: [
              { value: "png", label: "PNG" },
              { value: "jpeg", label: "JPEG" }
            ],
            disabled: busy,
            onChange: (value2) => value2 !== null && commit({ format: value2 })
          }),
          React.createElement(NumberInput, {
            label: "DPI",
            value: dpi,
            min: 36,
            max: 1200,
            disabled: busy,
            onChange: (value2) => commit({ dpi: value2 })
          })
        ),
        React.createElement(
          Group,
          { gap: "xs", grow: true },
          React.createElement(NumberInput, {
            label: "가로 (px)",
            value: width,
            min: 100,
            max: 2e4,
            disabled: busy,
            onChange: (value2) => commit({ width: value2 })
          }),
          React.createElement(NumberInput, {
            label: "세로 (px, 비우면 자동)",
            value: height,
            min: 100,
            max: 2e4,
            disabled: busy,
            onChange: (value2) => {
              if (value2 === "" || value2 === null)
                commit({ heightMode: "auto" });
              else commit({ heightMode: "explicit", height: value2 });
            }
          })
        ),
        React.createElement(
          Group,
          { gap: "xs", grow: true },
          React.createElement(
            Button,
            { disabled: busy, onClick: save },
            "설정 크기로 저장"
          ),
          React.createElement(
            Button,
            { variant: "light", disabled: busy, onClick: capture },
            "현재 화면 캡처"
          )
        ),
        React.createElement(
          Text,
          { size: "sm", c: "dimmed", "aria-live": "polite" },
          message || "PNG/JPEG, 36–1200 DPI. 세로를 비우면 레이아웃과 캡션에 맞춰 자동 계산합니다."
        )
      )
    );
  }
  function FastFigureLayoutOverlay() {
    const state = useAppState();
    const [layoutSelection, setLayoutSelection] = useState(() => /* @__PURE__ */ new Set());
    const [renderedPreviewWidth, setRenderedPreviewWidth] = useState(600);
    const previewFrameRef = useRef(null);
    const layoutApi = window.FastFigureApi.layout;
    const layout2 = state.overlay === "layout" ? layoutApi.readState(renderedPreviewWidth) : null;
    useEffect(() => {
      setLayoutSelection(/* @__PURE__ */ new Set());
    }, [state.overlay, layout2?.gridRows, layout2?.gridCols]);
    useEffect(() => {
      if (state.overlay !== "layout") return;
      const element = previewFrameRef.current;
      if (!element) return;
      const updateRenderedWidth = () => {
        const width = element.getBoundingClientRect().width;
        if (width > 0) setRenderedPreviewWidth(width);
      };
      updateRenderedWidth();
      const observer = new ResizeObserver(updateRenderedWidth);
      observer.observe(element);
      return () => observer.disconnect();
    }, [state.overlay]);
    if (state.overlay !== "layout") return null;
    const busy = state.lifecycle !== "ready";
    const style = layout2.slotStyle;
    const visibleSlots = layout2.visibleSlots;
    const previewGeometry = layout2.previewGeometry;
    const clamp = (value2, fallback, min, max) => {
      const number = Number(value2);
      return Number.isFinite(number) ? Math.max(min, Math.min(max, number)) : fallback;
    };
    const commitStyle = (patch) => layoutApi.setStyle(patch);
    const changeGrid = (dimension, value2) => {
      if (!["rows", "cols"].includes(dimension)) throw Error("알 수 없는 grid 편집 차원입니다.");
      const current = layoutApi.readState();
      const number = typeof value2 === "number" || typeof value2 === "string" && value2.trim() !== "" ? Number(value2) : NaN;
      const bounds = current.gridLimits[dimension === "rows" ? "gridRows" : "gridCols"];
      const edited = Number.isFinite(number) ? Math.max(bounds[0], Math.min(bounds[1], number)) : dimension === "rows" ? current.gridRows : current.gridCols;
      const rows = dimension === "rows" ? edited : current.gridRows;
      const cols = dimension === "cols" ? edited : current.gridCols;
      const result = layoutApi.setGrid(rows, cols);
      setLayoutSelection(/* @__PURE__ */ new Set());
      return result;
    };
    const toggleSlot = (slotId) => {
      setLayoutSelection((current) => {
        const next = new Set(current);
        if (next.has(slotId)) next.delete(slotId);
        else next.add(slotId);
        return next;
      });
    };
    const runLayoutCommand = (command) => {
      const layoutState = command([...layoutSelection]);
      if (layoutState !== false) {
        const visibleIds = new Set(layoutState.visibleSlots.map((slot) => slot.id));
        setLayoutSelection((current) => new Set([...current].filter((id) => visibleIds.has(id))));
      }
    };
    const changeZoom = (value2) => layoutApi.setZoom(clamp(value2, 100, 50, 200));
    const commitZoom = () => layoutApi.commitZoom();
    const close = () => appFSM.send("CLOSE_OVERLAY", { reason: "mantine-layout" });
    return React.createElement(
      FastFigureSettingsModal,
      {
        onClose: close,
        title: "레이아웃",
        overlay: "layout",
        onContentClick: () => setLayoutSelection(/* @__PURE__ */ new Set())
      },
      React.createElement(
        Stack,
        { gap: "md" },
        React.createElement(
          Group,
          { gap: "xs", grow: true },
          React.createElement(NumberInput, {
            label: "행",
            value: layout2.gridRows,
            min: layout2.gridLimits.gridRows[0],
            max: layout2.gridLimits.gridRows[1],
            allowDecimal: false,
            disabled: busy,
            onChange: (value2) => changeGrid("rows", value2)
          }),
          React.createElement(NumberInput, {
            label: "열",
            value: layout2.gridCols,
            min: layout2.gridLimits.gridCols[0],
            max: layout2.gridLimits.gridCols[1],
            allowDecimal: false,
            disabled: busy,
            onChange: (value2) => changeGrid("cols", value2)
          })
        ),
        React.createElement(
          Group,
          { gap: "xs", grow: true },
          React.createElement(NumberInput, {
            label: "기준 폭",
            value: style.referenceWidth,
            min: 100,
            max: 2e4,
            disabled: busy,
            onChange: (value2) => commitStyle({ referenceWidth: clamp(value2, style.referenceWidth, 100, 2e4) })
          }),
          React.createElement(NumberInput, {
            label: "간격",
            value: style.gap,
            min: 0,
            max: 2e3,
            disabled: busy,
            onChange: (value2) => commitStyle({ gap: clamp(value2, style.gap, 0, 2e3) })
          }),
          React.createElement(NumberInput, {
            label: "바깥 여백",
            value: style.outerMargin,
            min: 0,
            max: 5e3,
            disabled: busy,
            onChange: (value2) => commitStyle({ outerMargin: clamp(value2, style.outerMargin, 0, 5e3) })
          })
        ),
        React.createElement(
          Group,
          { gap: "xs", grow: true },
          React.createElement(NumberInput, {
            label: "모서리 반경",
            value: style.radius,
            min: 0,
            max: 2e3,
            disabled: busy,
            onChange: (value2) => commitStyle({ radius: clamp(value2, style.radius, 0, 2e3) })
          }),
          React.createElement(NumberInput, {
            label: "종횡비",
            value: style.aspect,
            min: 0.1,
            max: 10,
            step: 0.01,
            disabled: busy,
            onChange: (value2) => commitStyle({ aspect: clamp(value2, style.aspect, 0.1, 10) })
          }),
          React.createElement(
            Button,
            {
              variant: style.showBorders ? "filled" : "light",
              disabled: busy,
              "aria-pressed": style.showBorders,
              onClick: () => commitStyle({ showBorders: !style.showBorders })
            },
            "슬롯 외곽선"
          )
        ),
        React.createElement(
          Group,
          { gap: "xs", grow: true },
          React.createElement(NumberInput, {
            label: "확대 비율 (%)",
            value: layout2.zoom,
            min: 50,
            max: 200,
            disabled: busy || layout2.zoomLocked,
            onChange: changeZoom,
            onBlur: commitZoom
          }),
          React.createElement(
            Button,
            {
              variant: layout2.zoomLocked ? "filled" : "light",
              disabled: busy,
              "aria-pressed": layout2.zoomLocked,
              onClick: () => layoutApi.setZoomLocked(!layout2.zoomLocked)
            },
            layout2.zoomLocked ? "크기 고정" : "크기 고정 해제"
          ),
          React.createElement(
            Button,
            {
              variant: "light",
              disabled: busy,
              onClick: () => layoutApi.resetZoom()
            },
            "100% 초기화"
          )
        ),
        React.createElement(
          Box,
          {
            ref: previewFrameRef,
            style: {
              width: 600,
              maxWidth: "100%",
              marginInline: "auto"
            }
          },
          React.createElement(
            "div",
            {
              role: "grid",
              "aria-label": "레이아웃 슬롯 선택",
              style: {
                display: "grid",
                boxSizing: "border-box",
                width: "100%",
                height: previewGeometry.height,
                aspectRatio: `${style.aspect} / 1`,
                gridTemplateColumns: `repeat(${layout2.gridCols}, minmax(0, 1fr))`,
                gridTemplateRows: `repeat(${layout2.gridRows}, minmax(0, 1fr))`,
                gap: previewGeometry.gap,
                padding: previewGeometry.outerMargin,
                border: "1px solid var(--mantine-color-default-border)",
                borderRadius: previewGeometry.radius,
                overflow: "hidden"
              }
            },
            ...visibleSlots.map((slot) => {
              const selected = layoutSelection.has(slot.id);
              return React.createElement(
                UnstyledButton,
                {
                  key: slot.id,
                  disabled: busy,
                  "aria-pressed": selected,
                  onClick: (event) => {
                    event.stopPropagation();
                    toggleSlot(slot.id);
                  },
                  style: {
                    gridColumn: `${slot.col} / span ${slot.colSpan}`,
                    gridRow: `${slot.row} / span ${slot.rowSpan}`,
                    width: "100%",
                    height: "100%",
                    minWidth: 0,
                    minHeight: 0,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    padding: 0,
                    borderWidth: 1,
                    borderStyle: style.showBorders ? "solid" : "dashed",
                    borderColor: selected ? "var(--mantine-primary-color-filled)" : "var(--mantine-color-default-border)",
                    background: selected ? "var(--mantine-primary-color-light)" : "transparent",
                    color: "inherit",
                    cursor: busy ? "default" : "pointer"
                  }
                },
                `${slot.row},${slot.col}`
              );
            })
          )
        ),
        React.createElement(
          Group,
          { gap: "xs", grow: true },
          React.createElement(
            Button,
            {
              disabled: busy || layoutSelection.size < 2,
              onClick: (event) => {
                event.stopPropagation();
                runLayoutCommand(layoutApi.mergeSlots);
              }
            },
            "선택 슬롯 합치기"
          ),
          React.createElement(
            Button,
            {
              variant: "light",
              disabled: busy || layoutSelection.size < 1,
              onClick: (event) => {
                event.stopPropagation();
                runLayoutCommand(layoutApi.splitSlots);
              }
            },
            "선택 슬롯 나누기"
          ),
          React.createElement(
            Button,
            {
              variant: "subtle",
              disabled: busy || layoutSelection.size < 1,
              onClick: (event) => {
                event.stopPropagation();
                setLayoutSelection(/* @__PURE__ */ new Set());
              }
            },
            "선택 해제"
          )
        )
      )
    );
  }
  function FastFigureDashboardFileDrop() {
    const { choosePlan, modal } = useProjectAssetImportCollision();
    useEffect(() => {
      const dashboard = document.getElementById("dashboard");
      if (!dashboard) return;
      const handleDrop = async (event) => {
        const file = event.dataTransfer?.files?.[0];
        if (!file) return;
        const element = event.target.closest?.(".slot");
        const slotId = element?.parentElement === dashboard ? Number(element.dataset.slot) : NaN;
        event.preventDefault();
        event.stopPropagation();
        try {
          const result = await dashboardExternalFileDrop(file, slotId, choosePlan, window.FastFigureApi);
          if (result === false) return;
          debugLog("slot:file-drop", {
            slotId,
            name: file.name,
            kind: window.FastFigureApi.assets.fileKind(file)
          });
        } catch (error) {
          status("불러오기 실패: " + String(error?.message ?? error));
        }
      };
      dashboard.addEventListener("drop", handleDrop, true);
      return () => dashboard.removeEventListener("drop", handleDrop, true);
    }, [choosePlan]);
    return modal;
  }
  function FastFigureShell() {
    const shellGeometry = fastFigureTheme.other.shell;
    const [navbarWidth, setNavbarWidth] = useState(shellGeometry.navbarWidth);
    const [navbarCollapsed, setNavbarCollapsed] = useState(false);
    const navbarDragRef = useRef(null);
    const clampNavbarWidth = (value2) => Math.max(shellGeometry.navbarMinWidth, Math.min(shellGeometry.navbarMaxWidth, value2));
    useEffect(() => {
      const app = document.querySelector(".app");
      if (!app) return;
      app.style.setProperty(
        "--ff-renderer-navbar-width",
        navbarCollapsed ? "0px" : `${navbarWidth}px`
      );
      requestAnimationFrame(() => schedulePlotResize());
    }, [navbarWidth, navbarCollapsed]);
    const toggleNavbar = () => {
      setNavbarCollapsed((collapsed) => !collapsed);
    };
    const startNavbarResize = (event) => {
      if (navbarCollapsed) return;
      navbarDragRef.current = event.pointerId;
      event.currentTarget.setPointerCapture?.(event.pointerId);
      document.body.style.userSelect = "none";
      document.body.style.cursor = "col-resize";
    };
    const resizeNavbar = (event) => {
      if (navbarDragRef.current !== event.pointerId) return;
      const width = clampNavbarWidth(event.clientX);
      setNavbarWidth(width);
    };
    const stopNavbarResize = (event) => {
      if (navbarDragRef.current !== event.pointerId) return;
      navbarDragRef.current = null;
      event.currentTarget.releasePointerCapture?.(event.pointerId);
      document.body.style.userSelect = "";
      document.body.style.cursor = "";
      debugLog("mantine:sidebar-resize", { width: navbarWidth });
    };
    return React.createElement(
      AppShell,
      {
        header: { height: shellGeometry.headerHeight },
        navbar: {
          width: navbarWidth,
          breakpoint: "sm",
          collapsed: { desktop: navbarCollapsed, mobile: navbarCollapsed }
        },
        padding: 0
      },
      React.createElement(
        AppShell.Header,
        { style: { pointerEvents: "auto" } },
        React.createElement(
          Group,
          { h: "100%", px: "md", gap: "md", wrap: "nowrap" },
          React.createElement(
            Button,
            {
              variant: "light",
              "aria-expanded": !navbarCollapsed,
              onClick: toggleNavbar
            },
            navbarCollapsed ? "사이드바 표시" : "사이드바 숨기기"
          ),
          React.createElement(Text, { fw: 700, size: "xl", style: { flex: "0 0 auto" } }, "Fast figure"),
          React.createElement(
            Box,
            { style: { flex: "1 1 auto", minWidth: 0 } },
            React.createElement(FastFigureToolbar)
          )
        )
      ),
      React.createElement(
        AppShell.Navbar,
        { p: 0, style: { position: "relative", pointerEvents: "auto" } },
        React.createElement(
          ScrollArea,
          { h: "100%", type: "auto" },
          React.createElement(FastFigureDataActions),
          React.createElement(FastFigureImageEditor),
          React.createElement(FastFigureProjectDataTree),
          React.createElement(FastFigureProjectActions),
          React.createElement(FastFigureGraphDataEditor),
          React.createElement(FastFigureGraphLayoutEditor),
          React.createElement(FastFigureGraphPaletteActions),
          React.createElement(FastFigureGraphFileActions),
          React.createElement(FastFigurePaletteActions),
          React.createElement(FastFigureStatusDebug),
          React.createElement(FastFigureUtilityActions)
        ),
        React.createElement(Box, {
          role: "separator",
          "aria-orientation": "vertical",
          "aria-label": "사이드바 너비 조절",
          onPointerDown: startNavbarResize,
          onPointerMove: resizeNavbar,
          onPointerUp: stopNavbarResize,
          onPointerCancel: stopNavbarResize,
          pos: "absolute",
          top: 0,
          right: -shellGeometry.resizeHandleWidth / 2,
          bottom: 0,
          w: shellGeometry.resizeHandleWidth,
          style: {
            cursor: "col-resize",
            touchAction: "none"
          }
        })
      ),
      React.createElement(AppShell.Main, null),
      React.createElement(FastFigureLabelOverlay),
      React.createElement(FastFigureCaptionOverlay),
      React.createElement(FastFigureLayoutOverlay),
      React.createElement(FastFigurePrintOverlay),
      React.createElement(FastFigureReadmeOverlay),
      React.createElement(FastFigureDashboardFileDrop)
    );
  }
  window.FastFigureMantineUi = Object.freeze({
    FastFigureShell,
    FastFigureToolbar,
    FastFigureDataActions,
    FastFigureImageEditor,
    FastFigureProjectDataTree,
    FastFigureProjectActions,
    FastFigureGraphDataEditor,
    FastFigureGraphLayoutEditor,
    FastFigureGraphPaletteActions,
    FastFigureGraphFileActions,
    FastFigureLabelOverlay,
    FastFigureCaptionOverlay,
    FastFigureLayoutOverlay,
    FastFigurePrintOverlay,
    FastFigureReadmeOverlay,
    FastFigureStatusDebug,
    FastFigureUtilityActions,
    getAppStateSnapshot,
    selectedTargetText
  });
  function FastFigureApp() {
    useAppState();
    const palette = window.FastFigureApi.appearance.readPalette();
    const theme = createTheme({
      ...fastFigureTheme,
      colors: { ffui: Array(10).fill(palette.uiColor) },
      primaryColor: "ffui"
    });
    const channels = [1, 3, 5].map((index) => {
      const value2 = parseInt(palette.uiColor.slice(index, index + 2), 16) / 255;
      return value2 <= 0.04045 ? value2 / 12.92 : ((value2 + 0.055) / 1.055) ** 2.4;
    });
    const contrast = 0.2126 * channels[0] + 0.7152 * channels[1] + 0.0722 * channels[2] > 0.179 ? "#000000" : "#FFFFFF";
    return React.createElement(
      MantineProvider,
      {
        defaultColorScheme: "light",
        theme,
        cssVariablesResolver: (theme2) => ({
          variables: {
            "--ff-header-height": `${theme2.other.shell.headerHeight}px`,
            "--ff-navbar-width": `${theme2.other.shell.navbarWidth}px`,
            ...Object.fromEntries(
              Object.entries(theme2.shadows).map(([size, shadow]) => [
                `--mantine-shadow-${size}`,
                shadow.replace(
                  /rgba\(0, 0, 0, (0?\.\d+)\)/g,
                  (_match, opacity) => `color-mix(in srgb, ${palette.uiShadowColor} ${Number(opacity) * 100}%, transparent)`
                )
              ])
            )
          },
          light: {
            "--mantine-color-body": palette.uiBackgroundColor,
            "--mantine-color-text": palette.fontColor,
            "--mantine-color-default": palette.uiSurfaceColor,
            "--mantine-color-default-hover": `color-mix(in srgb, ${palette.uiColor} 12%, ${palette.uiSurfaceColor})`,
            "--mantine-color-default-color": palette.fontColor,
            "--mantine-color-default-border": palette.uiColor,
            "--mantine-color-dimmed": palette.uiMutedColor,
            "--mantine-color-placeholder": palette.uiSubtleColor,
            "--mantine-color-disabled": palette.uiDisabledBgColor,
            "--mantine-color-disabled-color": palette.uiDisabledTextColor,
            "--mantine-color-disabled-border": palette.uiDisabledBgColor,
            "--mantine-primary-color-filled": palette.uiColor,
            "--mantine-primary-color-filled-hover": `color-mix(in srgb, ${palette.uiColor} 75%, #64748b)`,
            "--mantine-primary-color-light": `color-mix(in srgb, ${palette.uiColor} 18%, transparent)`,
            "--mantine-primary-color-light-hover": `color-mix(in srgb, ${palette.uiColor} 24%, transparent)`,
            "--mantine-primary-color-light-color": palette.fontColor,
            "--mantine-primary-color-contrast": contrast,
            "--mantine-color-ffui-filled": "var(--mantine-primary-color-filled)",
            "--mantine-color-ffui-filled-hover": "var(--mantine-primary-color-filled-hover)",
            "--mantine-color-ffui-light": "var(--mantine-primary-color-light)",
            "--mantine-color-ffui-light-hover": "var(--mantine-primary-color-light-hover)",
            "--mantine-color-ffui-light-color": "var(--mantine-primary-color-light-color)",
            "--mantine-color-ffui-contrast": "var(--mantine-primary-color-contrast)"
          },
          dark: {}
        })
      },
      React.createElement(FastFigureShell)
    );
  }
  window.fastFigureUiRoot.render(React.createElement(FastFigureApp));
}

// sourcecode/system.js
var REQUIRED_RENDERER_HOSTS = ["dashboard", "dashboardCaption", "graphArea", "readmeContent"];
var REQUIRED_APP_FUNCTIONS = [
  ["readProjectNumber", () => typeof readProjectNumber === "function"],
  ["importProjectFile", () => typeof importProjectFile === "function"],
  ["ffpxReadProject", () => typeof ffpxReadProject === "function"],
  ["downloadProject", () => typeof downloadProject === "function"],
  ["ffpxDataUrlBytes", () => typeof ffpxDataUrlBytes === "function"],
  ["ffpxBase64ToBytes", () => typeof ffpxBase64ToBytes === "function"],
  ["ffpxBytesToBase64", () => typeof ffpxBytesToBase64 === "function"],
  ["normalizeGlobalSettings", () => typeof normalizeGlobalSettings === "function"],
  ["normalizeImageSettings", () => typeof normalizeImageSettings === "function"],
  ["traces", () => typeof traces === "function"],
  ["layout", () => typeof layout === "function"],
  ["renderDashboard", () => typeof renderDashboard === "function"],
  ["createProjectState", () => typeof createProjectState === "function"],
  ["applyImageSettingsFromValues", () => typeof applyImageSettingsFromValues === "function"],
  ["projectClone", () => typeof projectClone === "function"],
  ["ProjectObject", () => activeProject instanceof ProjectObject],
  ["buildProjectObject", () => typeof buildProjectObject === "function"],
  ["validateProjectObject", () => typeof validateProjectObject === "function"],
  ["renderProjectObject", () => typeof renderProjectObject === "function"],
  ["projectObjects", () => projectObjects instanceof ProjectObjectRegistry],
  ["interfaceFSM", () => interfaceFSM instanceof InterfaceStateMachine],
  ["projectEFSM", () => projectEFSM instanceof ProjectStateMachine],
  ["auditApp", () => typeof auditApp === "function"]
];
function requireCoreRuntimeAndRendererHosts() {
  const missing = REQUIRED_APP_FUNCTIONS.filter(([, check]) => !check()).map(([name]) => name);
  missing.push(...REQUIRED_RENDERER_HOSTS.filter((id) => !document.getElementById(id)));
  if (typeof window.Plotly?.react !== "function") missing.push("Plotly.react");
  if (!window.FastFigureUiRuntime) missing.push("FastFigureUiRuntime");
  if (!window.fastFigureUiRoot) missing.push("fastFigureUiRoot");
  if (missing.length) throw Error(`Fast Figure startup prerequisites missing: ${missing.join(", ")}`);
}
function auditObject(object, chartId, index, issues, allowNoCsv = false) {
  if (!object || typeof object !== "object") {
    issues.push({ kind: "invalid-object", chartId, index, value: object });
    return;
  }
  let keys = Object.keys(object), unknown = keys.filter((key) => !CURRENT_OBJECT_KEYS.has(key));
  if (unknown.length)
    issues.push({ kind: "unknown-object-keys", chartId, index, keys: unknown });
  if (typeof object.x !== "string" || typeof object.y !== "string")
    issues.push({ kind: "invalid-object-columns", chartId, index, x: object.x, y: object.y });
  if (!allowNoCsv && (!Number.isInteger(object.csvId) || !getProjectCsv(object.csvId)))
    issues.push({ kind: "orphan-object-csv", chartId, index, csvId: object.csvId });
  if (!ALLOWED_CHART_TYPES.has(object.type))
    issues.push({ kind: "invalid-chart-type", chartId, index, value: object.type });
  if (!ALLOWED_AXIS_SIDES.x.has(object.xAxisSide))
    issues.push({ kind: "invalid-x-axis-side", chartId, index, value: object.xAxisSide });
  if (!ALLOWED_AXIS_SIDES.y.has(object.yAxisSide))
    issues.push({ kind: "invalid-y-axis-side", chartId, index, value: object.yAxisSide });
  if (!ALLOWED_LINE_DASHES.has(object.lineDash || "solid"))
    issues.push({ kind: "invalid-line-dash", chartId, index, value: object.lineDash });
  if (!ALLOWED_MARKER_SYMBOLS.has(object.markerSymbol || "circle"))
    issues.push({
      kind: "invalid-marker-symbol",
      chartId,
      index,
      value: object.markerSymbol
    });
  [
    ["lineWidth", 0.1, 20],
    ["markerSize", 1, 40],
    ["barOpacity", 0.05, 1],
    ["barLineWidth", 0, 10]
  ].forEach(([key, min, max]) => {
    let value2 = Number(object[key]);
    if (!Number.isFinite(value2) || value2 < min || value2 > max)
      issues.push({
        kind: "invalid-numeric-value",
        chartId,
        index,
        key,
        value: object[key],
        min,
        max
      });
  });
}
function auditApp(context = "manual") {
  let issues = [], ids = [...document.querySelectorAll("[id]")].map((node) => node.id), duplicates = [...new Set(ids.filter((id, index) => ids.indexOf(id) !== index))], missingControls = REQUIRED_RENDERER_HOSTS.filter(
    (id) => !document.getElementById(id)
  ), missingFunctions = REQUIRED_APP_FUNCTIONS.filter(([, check]) => !check()).map(
    ([name]) => name
  );
  if (missingFunctions.length)
    issues.push({ kind: "missing-functions", names: missingFunctions });
  if (duplicates.length) issues.push({ kind: "duplicate-controls", ids: duplicates });
  if (missingControls.length) issues.push({ kind: "missing-controls", ids: missingControls });
  if (!["booting", "ready", "importing", "exporting", "error"].includes(appFSM.state.lifecycle))
    issues.push({ kind: "invalid-fsm-lifecycle", lifecycle: appFSM.state.lifecycle });
  if (!["project", "slot.graph", "slot.image"].includes(appFSM.state.workspace))
    issues.push({ kind: "invalid-fsm-workspace", workspace: appFSM.state.workspace });
  if (!["none", "layout", "label", "caption", "print", "readme"].includes(appFSM.state.overlay))
    issues.push({ kind: "invalid-fsm-overlay", overlay: appFSM.state.overlay });
  if (!["fsm-to-model", "model-to-fsm", "model-to-ui"].includes(
    appFSM.state.direction
  ))
    issues.push({
      kind: "invalid-fsm-direction",
      direction: appFSM.state.direction
    });
  if (appFSM.state.lifecycle === "ready" && appFSM.writeLocks.size)
    issues.push({
      kind: "fsm-write-lock-leak",
      locks: [...appFSM.writeLocks]
    });
  let derivedWorkspace = readWorkspaceHint();
  if (appFSM.state.workspace !== derivedWorkspace)
    issues.push({
      kind: "fsm-workspace-out-of-sync",
      state: appFSM.state,
      derived: derivedWorkspace
    });
  for (let region of ["lifecycle", "workspace", "overlay"]) {
    let definition = appFSM.definition(region);
    (definition.objects || []).forEach((name) => {
      try {
        if (name === "ui") interfaceFSM.readState();
        else projectObjects.read(name);
      } catch (error) {
        issues.push({
          kind: "fsm-object-unavailable",
          region,
          state: appFSM.state[region],
          object: name,
          message: error.message
        });
      }
    });
  }
  for (let state of ["project", "slot.graph", "slot.image"]) {
    let names = APP_STATE_DEFINITIONS.workspace[state].objects || [], missing = ["data", "images", "charts", "slots"].filter(
      (name) => !names.includes(name)
    );
    if (missing.length)
      issues.push({
        kind: "fsm-data-tree-objects-missing",
        state,
        missing
      });
  }
  try {
    validateProjectObject(activeProject, { requireSlots: true });
  } catch (error) {
    issues.push({
      kind: "invalid-project-object",
      message: error.message
    });
  }
  let selectedPathAsset = appFSM.state.assetPath ? projectVfs.resolve(appFSM.state.assetPath) : null;
  if (appFSM.state.assetSelection === "none" !== (selectedPathAsset === null) || selectedPathAsset && selectedPathAsset.kind !== appFSM.state.assetSelection)
    issues.push({
      kind: "fsm-asset-path-out-of-sync",
      selection: appFSM.state.assetSelection,
      path: appFSM.state.assetPath
    });
  if (typeof activeProject.captionAfterText !== "string")
    issues.push({
      kind: "invalid-caption-after-text",
      value: activeProject.captionAfterText
    });
  document.querySelectorAll("select[id]").forEach((select) => {
    if (select.value && ![...select.options].some((option) => option.value === select.value))
      issues.push({ kind: "invalid-select-value", id: select.id, value: select.value });
  });
  let csvIds = /* @__PURE__ */ new Set();
  activeProject.csvFiles.forEach((csv, index) => {
    if (!csv || !Number.isInteger(csv.id) || csvIds.has(csv.id) || Object.prototype.hasOwnProperty.call(csv, "path") || typeof csv.name !== "string" || typeof csv.directory !== "string" || !Array.isArray(csv.rows) || typeof csv.bytesBase64 !== "string" || !Number.isInteger(csv.headerLines))
      issues.push({ kind: "invalid-project-csv", index, id: csv?.id });
    else csvIds.add(csv.id);
  });
  let imageIds = /* @__PURE__ */ new Set();
  activeProject.images.forEach((image, index) => {
    if (!image || !Number.isInteger(image.id) || imageIds.has(image.id) || Object.prototype.hasOwnProperty.call(image, "path") || typeof image.name !== "string" || typeof image.directory !== "string" || typeof image.mime !== "string" || typeof image.bytesBase64 !== "string" || !image.bytesBase64)
      issues.push({ kind: "invalid-project-image", index, id: image?.id });
    else imageIds.add(image.id);
  });
  let chartIds = /* @__PURE__ */ new Set();
  activeProject.charts.forEach((chart, index) => {
    if (!chart || typeof chart !== "object") {
      issues.push({ kind: "invalid-chart", index, value: chart });
      return;
    }
    if (!Number.isInteger(chart.id) || chartIds.has(chart.id))
      issues.push({ kind: "invalid-or-duplicate-chart-id", index, id: chart.id });
    chartIds.add(chart.id);
    if (!chart.editor || !Array.isArray(chart.editor.objects))
      issues.push({ kind: "missing-object-array", chartId: chart.id });
    else
      chart.editor.objects.forEach(
        (object, objectIndex) => auditObject(
          object,
          chart.id,
          objectIndex,
          issues,
          chart.editor.editable === false
        )
      );
  });
  activeProject.slots.forEach((slot, index) => {
    if (!slot || typeof slot !== "object") issues.push({ kind: "invalid-slot", index });
    else {
      if (slot.chart !== null && slot.chart !== void 0 && !chartIds.has(slot.chart))
        issues.push({ kind: "orphan-slot-chart", slotId: slot.id, chart: slot.chart });
      if (slot.imageId !== null && slot.imageId !== void 0 && !imageIds.has(slot.imageId))
        issues.push({ kind: "orphan-slot-image", slotId: slot.id, imageId: slot.imageId });
      if (slot.caption !== null && typeof slot.caption !== "string")
        issues.push({
          kind: "invalid-slot-caption",
          slotId: slot.id,
          caption: slot.caption
        });
    }
  });
  let summary = {
    context,
    build: projectObjects.read("project").appBuild,
    controls: ids.length,
    csvFiles: activeProject.csvFiles.length,
    images: activeProject.images.length,
    charts: activeProject.charts.length,
    slots: activeProject.slots.length,
    issues: issues.length
  };
  debugLog("audit:summary", summary, issues.length ? "warn" : "info");
  issues.forEach((issue) => debugLog("audit:issue", issue, "warn"));
  return { summary, issues };
}
function initializeFastFigure() {
  initializeActiveProject();
  initializeProjectObjects();
  initializeInterfaceFSM();
  initializeProjectEFSM();
  requireCoreRuntimeAndRendererHosts();
  window.addEventListener(
    "error",
    (event) => debugLog("window:error", {
      message: event.message,
      source: event.filename,
      line: event.lineno,
      column: event.colno
    })
  );
  window.addEventListener(
    "unhandledrejection",
    (event) => debugLog("window:unhandledrejection", {
      message: event.reason?.message || String(event.reason)
    })
  );
  debugLog("app:init", {
    build: projectObjects.read("project").appBuild,
    userAgent: navigator.userAgent,
    location: location.href
  });
  startupCoreRuntime();
  appFSM.ready();
  debugLog(
    "app:init-complete",
    {
      slots: activeProject.slots.length,
      charts: activeProject.charts.length,
      build: projectObjects.read("project").appBuild
    },
    "info"
  );
  publishPublicApi();
  mountMantineUi();
  auditApp("app:init");
  return "initialized_runtime";
}
initializeFastFigure();
